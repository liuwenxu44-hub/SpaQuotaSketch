# SpaQuotaSketch research code

This repository contains the code and saved source tables needed to inspect the analyses reported in the manuscript. It replaces the earlier incomplete snapshot whose entry point imported modules that were absent from the archive.

## Installation

Use Python 3.11 or later in a clean environment:

```bash
python -m pip install -e .
```

The supplied raw spatial-transcriptomics inputs are not redistributed. Their filenames, byte counts and SHA256 hashes are listed in `manifests/input_verification_manifest.csv`; configure local input paths before running any data-dependent command.

## Main entry points

- `scripts/run_controlled_reproduction_public_path_template.py`: four-input Equal versus matched stratified-SRS comparison. Copy the file and set the documented project, data and output paths.
- `scripts/run_mouse_brain_16um_input_correction.py`: targeted correction wrapper for the affected Visium HD mouse-brain conditions.
- `scripts/run_mouse_brain_16um_gate_correction.py`: corrected retrospective mouse-brain weighting example.
- `scripts/run_final_gate_confirmatory_validation.py`: independent simulation gate confirmation.
- `scripts/run_final_gate_independent_real_validation.py`: first real-input gate confirmation.
- `scripts/run_independent_real_weighting_confirmation_20260904.py`: second real-input gate confirmation.

Run `python <script> --help` to inspect each command-line interface. The two correction wrappers record the exact historical local paths used for the correction run; users working elsewhere must replace those paths or call the underlying relative-path entry point.

## Visium HD correction

The corrected adapter reads native 2 μm feature-slice coordinates, derives the target bin size from the selected mask name, divides both coordinate axes by the required scale (eight for `square_016um`), and sums duplicate gene-bin entries. Reading the 16 μm mask alone is not a substitute for this aggregation.

## Supplied result/source tables

`source_data/` contains the corrected 240 method-endpoint records, 120 paired records, mouse-brain correction audit, corrected retrospective gate example, and the 36 per-condition values underlying Fig 4C/D. These are saved results; no analysis is rerun when they are opened.

## Verification

The archive was checked by extracting it into a clean temporary directory, installing/importing the packaged source tree through `PYTHONPATH=src`, running the adapter unit tests, and invoking `--help` on the listed entry points. Data-dependent analyses require the external inputs listed in the manifest.

## Final exploratory and computational-cost extension

The `extension_analysis/` directory contains the frozen post-outcome local-similarity plan, the executed analysis and profiling scripts, source tables, environment record and source mapping used for S3 and S4 Figs and worksheets S8–S11 in S1 Table. The exploratory module does not alter the accepted formal efficacy table. The performance scripts use separate seeds and distinguish measured stages from calculated stage sums and amortized values.


## License

The code in this archive is available under the MIT License; see `LICENSE`.

## Frozen configuration snapshot

The three historical `real_fixed_quota_probability_*.yaml` files referenced by `SNAPSHOT_FILES` in the controlled-reproduction entry point are included under `configs/`. They are copied into the run snapshot; they are not new analyses.

## Manuscript

Matched fixed-quota probability designs show dataset-dependent point-estimation differences in spatial transcriptomics.

Authors: Wenxu Liu, Yipan Zheng, and Zhe Liu.

This public snapshot contains the code and retained result tables formerly packaged as S1 File. The complete raw spatial-transcriptomics inputs are not included. Data-dependent reproduction requires the source inputs and path configuration described above.

The S4 plotting display has been synchronized with the submitted figure: measured SVD and neighbour-plan times are stacked on a zero-based linear axis, with grey and blue marking the two stages. The numerical summaries, stored measurements, and sampling algorithms are unchanged.

## Detailed mouse-brain input-correction records

`diagnostics/mouse_brain_16um/` contains the saved correction audit, endpoint records, and elementwise comparison with the aligned official raw 16-µm matrix, formerly packaged as S2 File. These records are provided unchanged.
