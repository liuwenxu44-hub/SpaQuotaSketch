"""Calibrated spatial-expression sampling."""

from __future__ import annotations

from collections import Counter, defaultdict
from typing import Hashable

from .soft_balance import minmax_scale, proportional_quotas


def split_quota(quota: int, base_fraction: float) -> tuple[int, int]:
    """Split one spatial quota into a stable base part and an expression-aware part."""
    if quota < 0:
        raise ValueError("quota must be non-negative.")
    if not (0 <= base_fraction <= 1):
        raise ValueError("base_fraction must be in [0, 1].")
    if quota <= 1:
        return quota, 0
    base_quota = int(round(quota * base_fraction))
    base_quota = min(quota, max(1, base_quota))
    return base_quota, quota - base_quota


def _representative_scores(indices_by_spatial: dict[Hashable, list[int]], features):
    import numpy as np

    values = np.asarray(features)
    scores = np.zeros(values.shape[0], dtype=float)
    for indices in indices_by_spatial.values():
        if not indices:
            continue
        local = values[indices]
        centroid = local.mean(axis=0)
        distances = np.linalg.norm(local - centroid, axis=1)
        scores[indices] = 1.0 - minmax_scale(distances)
    return scores


def expression_caps(
    expression_bin_ids: list[Hashable],
    target_n: int,
    cap_multiplier: float = 1.25,
    cap_floor: int = 1,
) -> dict[Hashable, int]:
    """Set soft upper limits for selected cells per expression bin."""
    import math

    if cap_multiplier <= 0:
        raise ValueError("cap_multiplier must be positive.")
    if cap_floor < 0:
        raise ValueError("cap_floor must be non-negative.")
    quotas = proportional_quotas(expression_bin_ids, target_n)
    return {
        bin_id: max(int(cap_floor), int(math.ceil(quota * cap_multiplier)))
        for bin_id, quota in quotas.items()
    }


def calibrated_spatial_expression_sample(
    spatial_bin_ids: list[Hashable],
    expression_bin_ids: list[Hashable],
    features,
    target_n: int,
    seed: int = 0,
    base_fraction: float = 0.75,
    expression_cap_multiplier: float = 1.25,
    expression_cap_floor: int = 1,
    expression_weight: float = 0.25,
    representative_weight: float = 0.35,
    local_diversity_weight: float = 0.30,
    cap_room_weight: float = 0.05,
    jitter_weight: float = 0.05,
) -> tuple[list[int], dict[str, object]]:
    """Sample with a spatial base, a small expression supplement, and expression caps."""
    import numpy as np

    if len(spatial_bin_ids) != len(expression_bin_ids):
        raise ValueError("spatial_bin_ids and expression_bin_ids must have the same length.")
    if len(spatial_bin_ids) != len(features):
        raise ValueError("features must have one row per observation.")
    if not (0 <= base_fraction <= 1):
        raise ValueError("base_fraction must be in [0, 1].")
    score_weights = [
        expression_weight,
        representative_weight,
        local_diversity_weight,
        cap_room_weight,
        jitter_weight,
    ]
    if any(weight < 0 for weight in score_weights):
        raise ValueError("score weights must be non-negative.")
    if sum(score_weights) <= 0:
        raise ValueError("at least one score weight must be positive.")

    n_obs = len(spatial_bin_ids)
    target_n = min(max(int(target_n), 0), n_obs)
    if target_n == 0:
        return [], {"n_selected": 0, "n_filled_shortfall": 0}

    rng = np.random.default_rng(seed)
    spatial_quotas = proportional_quotas(spatial_bin_ids, target_n)
    expression_quotas = proportional_quotas(expression_bin_ids, target_n)
    caps = expression_caps(
        expression_bin_ids,
        target_n,
        cap_multiplier=expression_cap_multiplier,
        cap_floor=expression_cap_floor,
    )

    indices_by_spatial: dict[Hashable, list[int]] = defaultdict(list)
    for index, bin_id in enumerate(spatial_bin_ids):
        indices_by_spatial[bin_id].append(index)

    representative_scores = _representative_scores(indices_by_spatial, features)

    selected: list[int] = []
    selected_set: set[int] = set()
    selected_expression_counts: Counter[Hashable] = Counter()
    selected_local_expression_counts: dict[Hashable, Counter[Hashable]] = defaultdict(Counter)
    n_base_selected = 0
    n_supplement_selected = 0
    n_cap_fallbacks = 0

    def add_index(index: int, source: str) -> None:
        nonlocal n_base_selected, n_supplement_selected
        selected.append(int(index))
        selected_set.add(int(index))
        spatial_bin_id = spatial_bin_ids[index]
        expression_bin_id = expression_bin_ids[index]
        selected_expression_counts[expression_bin_id] += 1
        selected_local_expression_counts[spatial_bin_id][expression_bin_id] += 1
        if source == "base":
            n_base_selected += 1
        else:
            n_supplement_selected += 1

    def score_candidates(candidate_indices: list[int], spatial_bin_id: Hashable):
        expr_scores = []
        local_scores = []
        cap_scores = []
        for index in candidate_indices:
            expr_bin_id = expression_bin_ids[index]
            expr_quota = max(1, int(expression_quotas[expr_bin_id]))
            expr_count = int(selected_expression_counts[expr_bin_id])
            expr_scores.append(max(0.0, (expr_quota - expr_count) / expr_quota))
            local_scores.append(
                1.0 if selected_local_expression_counts[spatial_bin_id][expr_bin_id] == 0 else 0.0
            )
            cap = max(1, int(caps[expr_bin_id]))
            cap_scores.append(max(0.0, (cap - expr_count) / cap))

        jitter = rng.random(len(candidate_indices))
        candidate_array = np.asarray(candidate_indices, dtype=int)
        return (
            expression_weight * np.asarray(expr_scores, dtype=float)
            + representative_weight * representative_scores[candidate_array]
            + local_diversity_weight * np.asarray(local_scores, dtype=float)
            + cap_room_weight * np.asarray(cap_scores, dtype=float)
            + jitter_weight * jitter
        )

    def take_best(candidate_indices: list[int], spatial_bin_id: Hashable) -> None:
        scores = score_candidates(candidate_indices, spatial_bin_id)
        best_position = int(np.argmax(scores))
        add_index(int(candidate_indices[best_position]), source="supplement")

    for spatial_bin_id, quota in spatial_quotas.items():
        if quota <= 0:
            continue
        available = [index for index in indices_by_spatial[spatial_bin_id] if index not in selected_set]
        if not available:
            continue
        base_quota, supplement_quota = split_quota(int(quota), base_fraction)
        n_base = min(base_quota, len(available))
        if n_base:
            base_indices = rng.choice(available, size=n_base, replace=False).astype(int).tolist()
            for index in base_indices:
                add_index(index, source="base")

        for _ in range(int(supplement_quota)):
            candidates = [index for index in indices_by_spatial[spatial_bin_id] if index not in selected_set]
            if not candidates:
                break
            capped = [
                index
                for index in candidates
                if selected_expression_counts[expression_bin_ids[index]] < caps[expression_bin_ids[index]]
            ]
            if capped:
                take_best(capped, spatial_bin_id)
            else:
                n_cap_fallbacks += 1
                take_best(candidates, spatial_bin_id)

    n_filled_shortfall = 0
    while len(selected) < target_n:
        candidates = [index for index in range(n_obs) if index not in selected_set]
        if not candidates:
            break
        capped = [
            index
            for index in candidates
            if selected_expression_counts[expression_bin_ids[index]] < caps[expression_bin_ids[index]]
        ]
        if capped:
            take_best(capped, spatial_bin_ids[capped[0]])
        else:
            n_cap_fallbacks += 1
            take_best(candidates, spatial_bin_ids[candidates[0]])
        n_filled_shortfall += 1

    selected = selected[:target_n]
    selected_spatial_bins = [spatial_bin_ids[index] for index in selected]
    selected_expression_bins = [expression_bin_ids[index] for index in selected]
    over_cap_bins = [
        str(bin_id)
        for bin_id, count in selected_expression_counts.items()
        if count > caps.get(bin_id, 0)
    ]
    report = {
        "n_selected": len(selected),
        "n_spatial_bins": len(set(spatial_bin_ids)),
        "n_expression_bins": len(set(expression_bin_ids)),
        "n_selected_spatial_bins": len(set(selected_spatial_bins)),
        "n_selected_expression_bins": len(set(selected_expression_bins)),
        "n_base_selected": int(n_base_selected),
        "n_supplement_selected": int(n_supplement_selected),
        "n_filled_shortfall": int(n_filled_shortfall),
        "n_cap_fallbacks": int(n_cap_fallbacks),
        "n_over_cap_expression_bins": len(over_cap_bins),
        "over_cap_expression_bins": over_cap_bins[:20],
        "base_fraction": float(base_fraction),
        "expression_cap_multiplier": float(expression_cap_multiplier),
        "expression_cap_floor": int(expression_cap_floor),
        "expression_weight": float(expression_weight),
        "representative_weight": float(representative_weight),
        "local_diversity_weight": float(local_diversity_weight),
        "cap_room_weight": float(cap_room_weight),
        "jitter_weight": float(jitter_weight),
    }
    return selected, report


def calibrate_sampling_weights(
    selected_spatial_bin_ids: list[Hashable],
    selected_expression_bin_ids: list[Hashable],
    original_spatial_counts: dict[Hashable, int],
    original_expression_counts: dict[Hashable, int],
    initial_weights: list[float] | None = None,
    n_iterations: int = 8,
    max_adjustment_factor: float = 5.0,
    max_weight_multiplier: float = 25.0,
) -> tuple[list[float], dict[str, object]]:
    """Calibrate selected-cell weights toward spatial and expression bin totals."""
    import numpy as np

    if len(selected_spatial_bin_ids) != len(selected_expression_bin_ids):
        raise ValueError("selected spatial and expression bin ids must have the same length.")
    n_selected = len(selected_spatial_bin_ids)
    if n_selected == 0:
        return [], {"n_selected": 0}
    if n_iterations < 0:
        raise ValueError("n_iterations must be non-negative.")
    if max_adjustment_factor < 1:
        raise ValueError("max_adjustment_factor must be at least 1.")
    if max_weight_multiplier < 1:
        raise ValueError("max_weight_multiplier must be at least 1.")

    total_original = float(sum(original_spatial_counts.values()))
    if total_original <= 0:
        total_original = float(sum(original_expression_counts.values()))
    if total_original <= 0:
        total_original = float(n_selected)

    if initial_weights is None:
        weights = np.full(n_selected, total_original / n_selected, dtype=float)
    else:
        weights = np.asarray(initial_weights, dtype=float).copy()
        if weights.shape[0] != n_selected:
            raise ValueError("initial_weights must match selected bin id length.")
        if float(weights.sum()) <= 0:
            raise ValueError("initial_weights must have a positive sum.")
        weights *= total_original / float(weights.sum())

    groups = []
    for bin_ids, original_counts in [
        (selected_spatial_bin_ids, original_spatial_counts),
        (selected_expression_bin_ids, original_expression_counts),
    ]:
        indices_by_bin: dict[Hashable, list[int]] = defaultdict(list)
        for index, bin_id in enumerate(bin_ids):
            indices_by_bin[bin_id].append(index)
        groups.append((indices_by_bin, original_counts))

    lower_factor = 1.0 / max_adjustment_factor
    upper_factor = max_adjustment_factor
    for _ in range(n_iterations):
        for indices_by_bin, original_counts in groups:
            for bin_id, indices in indices_by_bin.items():
                current = float(weights[indices].sum())
                target = float(original_counts.get(bin_id, 0))
                if current <= 0 or target <= 0:
                    continue
                factor = min(upper_factor, max(lower_factor, target / current))
                weights[indices] *= factor
        weights *= total_original / float(weights.sum())

    uniform_weight = total_original / n_selected
    weights = np.clip(weights, 0.0, uniform_weight * max_weight_multiplier)
    weights *= total_original / float(weights.sum())

    represented_spatial = set(selected_spatial_bin_ids)
    represented_expression = set(selected_expression_bin_ids)
    missing_spatial_mass = sum(
        count for bin_id, count in original_spatial_counts.items() if bin_id not in represented_spatial
    )
    missing_expression_mass = sum(
        count for bin_id, count in original_expression_counts.items() if bin_id not in represented_expression
    )
    report = {
        "n_selected": int(n_selected),
        "n_iterations": int(n_iterations),
        "max_adjustment_factor": float(max_adjustment_factor),
        "max_weight_multiplier": float(max_weight_multiplier),
        "weight_sum": float(weights.sum()),
        "min_weight": float(weights.min()),
        "max_weight": float(weights.max()),
        "n_missing_spatial_bins": int(len(set(original_spatial_counts) - represented_spatial)),
        "n_missing_expression_bins": int(len(set(original_expression_counts) - represented_expression)),
        "missing_spatial_mass_fraction": float(missing_spatial_mass / total_original),
        "missing_expression_mass_fraction": float(missing_expression_mass / total_original),
    }
    return weights.astype(float).tolist(), report
