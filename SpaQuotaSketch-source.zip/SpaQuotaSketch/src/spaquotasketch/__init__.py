"""SpaQuotaSketch package."""

from .framework import (
    DesignBasedEstimationError,
    FrameworkCompatibilityError,
    TaskAwareSampleResult,
    hajek_mean,
    horvitz_thompson_total,
    method_capabilities,
    recommend,
    resolve_method,
    sample,
)
from .safe_gate import (
    EQUAL_SAFE_DEFAULT,
    FINAL_SIMPLIFIED_GATE,
    LEGACY_FULL_FIVE_CONDITION_GATE,
    GateSpecification,
    SafeGateDecision,
    SafeGateThresholds,
    WeightedCandidateEvidence,
    choose_legacy_full_safe_mode,
    choose_safe_mode,
)

__version__ = "0.1.0"

__all__ = [
    "DesignBasedEstimationError",
    "EQUAL_SAFE_DEFAULT",
    "FINAL_SIMPLIFIED_GATE",
    "FrameworkCompatibilityError",
    "GateSpecification",
    "LEGACY_FULL_FIVE_CONDITION_GATE",
    "SafeGateDecision",
    "SafeGateThresholds",
    "TaskAwareSampleResult",
    "WeightedCandidateEvidence",
    "__version__",
    "choose_legacy_full_safe_mode",
    "choose_safe_mode",
    "hajek_mean",
    "horvitz_thompson_total",
    "method_capabilities",
    "recommend",
    "resolve_method",
    "sample",
]
