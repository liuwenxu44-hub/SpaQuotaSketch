"""Shared helpers for the planned SpaQuotaSketch sampling workflow."""

from __future__ import annotations

from typing import Hashable, Sequence

from .candidate_pool import expression_sample_indices
from .spatial_bins import candidate_coverage, candidate_quota_feasibility


def bin_ids_for_indices(indices: Sequence[int], all_bin_ids: Sequence[Hashable]) -> list[Hashable]:
    """Return the bin identifier for each selected observation index."""
    return [all_bin_ids[int(index)] for index in indices]


def build_candidates_until_quota_feasible(
    embedding,
    all_bin_ids: Sequence[Hashable],
    final_quotas: dict[Hashable, int],
    n_select_per_seed: int,
    seeds: Sequence[int],
    method: str,
    min_candidates_per_bin: int = 1,
    expression_fraction: float = 0.7,
    score_cap_quantile: float | None = None,
    candidate_strata: Sequence[Hashable] | None = None,
) -> tuple[
    list[int],
    dict[int, list[int]],
    list[dict[str, object]],
    dict[str, object],
    dict[str, object],
]:
    """Expand a candidate pool until every positive final quota is feasible."""
    selected_by_seed: dict[int, list[int]] = {}
    candidate_indices: list[int] = []
    seen: set[int] = set()
    history: list[dict[str, object]] = []
    coverage = candidate_coverage(list(all_bin_ids), [], min_candidates_per_bin=min_candidates_per_bin)
    quota_feasibility = candidate_quota_feasibility([], final_quotas)

    for seed in seeds:
        selected = expression_sample_indices(
            embedding,
            n_select_per_seed,
            seed=int(seed),
            method=method,
            expression_fraction=expression_fraction,
            score_cap_quantile=score_cap_quantile,
            strata=candidate_strata,
        )
        selected_by_seed[int(seed)] = selected
        for index in selected:
            if index not in seen:
                seen.add(index)
                candidate_indices.append(index)

        candidate_bin_ids = bin_ids_for_indices(candidate_indices, all_bin_ids)
        coverage = candidate_coverage(
            list(all_bin_ids),
            candidate_bin_ids,
            min_candidates_per_bin=min_candidates_per_bin,
        )
        quota_feasibility = candidate_quota_feasibility(candidate_bin_ids, final_quotas)
        history.append(
            {
                "seed": int(seed),
                "n_selected_this_seed": len(selected),
                "n_unique_candidates": len(candidate_indices),
                "candidate_spatial_coverage": coverage["candidate_spatial_coverage"],
                "n_insufficient_bins": coverage["n_insufficient_bins"],
                "candidate_quota_coverage": quota_feasibility["candidate_quota_coverage"],
                "n_quota_infeasible_bins": quota_feasibility["n_insufficient_bins"],
                "total_candidate_shortfall": quota_feasibility["total_candidate_shortfall"],
            }
        )
        if quota_feasibility["n_insufficient_bins"] == 0:
            break

    return candidate_indices, selected_by_seed, history, coverage, quota_feasibility


__all__ = ["bin_ids_for_indices", "build_candidates_until_quota_feasible"]
