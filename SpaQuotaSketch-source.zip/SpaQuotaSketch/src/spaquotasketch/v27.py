"""Fixed-margin local graph influence optimization for SpaQuotaSketch."""

from __future__ import annotations

from collections import Counter, defaultdict
from typing import Hashable, Sequence

import numpy as np


def fixed_margin_graph_influence_selection(
    source_selected_indices: Sequence[int],
    spatial_bin_ids: Sequence[Hashable],
    expression_bin_ids: Sequence[Hashable],
    normalized_features,
    knn_indices,
    state_ids: Sequence[Hashable] | None = None,
) -> tuple[list[int], dict[str, object]]:
    """Maximize graph influence without changing source spatial-expression quotas.

    Let ``q_(b,e[,s])`` be the number of source-selected observations in spatial
    bin ``b``, expression bin ``e``, and optionally unsupervised state ``s``.
    This function selects exactly the same number from every source stratum.
    The selected observations maximize the sum of their directed k-neighbor
    in-degrees independently in each stratum.
    """
    values = np.asarray(normalized_features, dtype=float)
    n_obs = len(spatial_bin_ids)
    if len(expression_bin_ids) != n_obs:
        raise ValueError("spatial_bin_ids and expression_bin_ids must have the same length.")
    if state_ids is not None and len(state_ids) != n_obs:
        raise ValueError("state_ids must have the same length as spatial_bin_ids.")
    if values.ndim != 2 or values.shape[0] != n_obs or not np.isfinite(values).all():
        raise ValueError("normalized_features must be finite and contain one row per observation.")
    neighbors = np.asarray(knn_indices, dtype=int)
    if neighbors.ndim != 2 or neighbors.shape[0] != n_obs or neighbors.shape[1] < 1:
        raise ValueError("knn_indices must be a non-empty two-dimensional array with one row per observation.")
    if neighbors.min(initial=0) < 0 or neighbors.max(initial=-1) >= n_obs:
        raise ValueError("knn_indices contains an invalid observation index.")

    source = sorted({int(index) for index in source_selected_indices})
    if not source or len(source) != len(source_selected_indices) or source[0] < 0 or source[-1] >= n_obs:
        raise ValueError("source_selected_indices must contain unique valid observation indices.")

    if state_ids is None:
        stratum_ids = list(zip(spatial_bin_ids, expression_bin_ids))
        margin_description = "spatial_expression"
    else:
        stratum_ids = list(zip(spatial_bin_ids, expression_bin_ids, state_ids))
        margin_description = "spatial_expression_state"
    quota_plan = Counter(stratum_ids[index] for index in source)
    indices_by_stratum: dict[tuple[Hashable, ...], list[int]] = defaultdict(list)
    for index, stratum in enumerate(stratum_ids):
        indices_by_stratum[stratum].append(index)

    indegree = np.bincount(neighbors.reshape(-1), minlength=n_obs).astype(int)
    selected: list[int] = []
    n_full_strata = 0
    for stratum, quota in quota_plan.items():
        candidates = np.asarray(indices_by_stratum[stratum], dtype=int)
        if quota > candidates.size:
            raise RuntimeError("A source spatial-expression quota exceeds its population.")
        if quota == candidates.size:
            selected.extend(candidates.tolist())
            n_full_strata += 1
            continue

        stratum_values = values[candidates]
        center = stratum_values.mean(axis=0, keepdims=True)
        center_distance = np.sum((stratum_values - center) ** 2, axis=1)
        # Lexicographic tie-break: graph influence, expression typicality, stable index.
        order = np.lexsort((candidates, center_distance, -indegree[candidates]))
        selected.extend(candidates[order[:quota]].tolist())

    selected = sorted(set(int(index) for index in selected))
    if len(selected) != len(source):
        raise RuntimeError("Fixed-margin graph influence selection changed the sample size.")
    selected_plan = Counter(stratum_ids[index] for index in selected)
    if selected_plan != quota_plan:
        raise RuntimeError("Fixed-margin graph influence selection changed a source quota.")

    selected_array = np.asarray(selected, dtype=int)
    selected_mask = np.zeros(n_obs, dtype=bool)
    selected_mask[selected_array] = True
    represented = selected_mask | selected_mask[neighbors].any(axis=1)
    source_array = np.asarray(source, dtype=int)
    return selected, {
        "n_selected": int(selected_array.size),
        "n_fixed_margin_strata": int(len(quota_plan)),
        "n_full_population_strata": int(n_full_strata),
        "preserved_spatial_expression_quotas": True,
        "preserved_fixed_margins": True,
        "fixed_margin_definition": margin_description,
        "source_mean_graph_indegree": float(indegree[source_array].mean()),
        "selected_mean_graph_indegree": float(indegree[selected_array].mean()),
        "source_graph_neighbor_coverage": float(
            (np.isin(np.arange(n_obs), source_array) | np.isin(neighbors, source_array).any(axis=1)).mean()
        ),
        "selected_graph_neighbor_coverage": float(represented.mean()),
        "selection_objective": "maximize_sum_directed_knn_indegree_with_fixed_spatial_expression_margins",
        "tie_break_order": "expression_distance_to_stratum_center_then_cell_index",
    }


__all__ = ["fixed_margin_graph_influence_selection"]
