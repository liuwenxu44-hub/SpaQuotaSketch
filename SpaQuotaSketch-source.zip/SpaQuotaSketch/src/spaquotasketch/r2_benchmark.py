"""Immutable execution support for the pancreas clean-baseline R2 benchmark.

R2 is deliberately separate from the frozen R1 executor.  It retains the three
probability samplers and adds the registered quota-completed representation mode
without changing the historical formal representation workflow.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import platform
import sys
import time
from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd
import yaml

from .candidate_pool import expression_sample_indices
from .core_workflow import build_candidates_until_quota_feasible
from .preprocess import compute_pca_embedding, get_spatial_coordinates, validate_spatial_anndata
from .quota_sampling import sample_by_quota
from .r1_benchmark import (
    Measurement,
    _as_observation_total,
    _evaluate_run,
    _method_metadata_for_probability,
    _probability_diagnostics,
    _selection_frame_from_probability,
    _stratum_table,
    choose_new_output_directory,
    git_commit_hash,
    measure_call,
    sha256_file,
    target_n_from_fraction,
)
from .representation.quota_completed import (
    ALGORITHM_VERSION as REPRESENTATION_ALGORITHM_VERSION,
    METHOD_ID as REPRESENTATION_METHOD_ID,
    QuotaCompletedRepresentationFailure,
    sample_quota_completed_representation,
)
from .samplers import (
    InfeasibleQuotaError,
    get_method_metadata,
    sample_spatial_pivotal,
    sample_spatial_stratified_srs,
    sample_uniform_srs,
)
from .samplers.registry import require_runnable_method
from .spatial_bins import candidate_quota_feasibility, rectangular_grid_bins


R2_METHODS = (
    "uniform_srs",
    "spatial_stratified_srs",
    "spatial_pivotal",
    REPRESENTATION_METHOD_ID,
)
R2_FRACTIONS = (0.005, 0.01, 0.02, 0.05, 0.10)
R2_SEEDS = tuple(range(10))
METHOD_DISPLAY_NAMES = {
    "uniform_srs": "Uniform SRS",
    "spatial_stratified_srs": "Spatial-stratified SRS",
    "spatial_pivotal": "Spatial pivotal",
    REPRESENTATION_METHOD_ID: "Quota-completed representation mode",
}
PROBABILITY_METHODS = {
    "uniform_srs",
    "spatial_stratified_srs",
    "spatial_pivotal",
}
SUMMARY_METRICS = (
    "actual_n",
    "selected_spatial_coverage",
    "expression_state_coverage",
    "expression_embedding_coverage",
    "cell_group_l1_error",
    "weighted_cell_group_l1_error",
    "rare_cell_recall",
    "mean_within_group_spatial_l1_error",
    "joint_spatial_group_l1_error",
    "nearest_selected_distance_median",
    "nearest_selected_distance_mean",
    "gene_mean_relative_mae_unweighted",
    "gene_mean_relative_mae_probability_weighted",
    "ht_total_expression_relative_error",
    "hajek_mean_expression_relative_error",
    "weight_coefficient_of_variation",
    "maximum_weight",
    "maximum_to_median_weight",
    "kish_effective_sample_size",
    "kish_effective_sample_size_over_n",
    "candidate_pool_time",
    "feasibility_check_time",
    "candidate_completion_time",
    "final_selection_time",
    "core_sampling_time",
    "metric_time",
    "end_to_end_time",
    "end_to_end_time_amortized_shared_cost",
    "peak_memory_mib",
    "completion_fraction_of_final_sample",
    "deficient_strata_fraction",
)
HIGHER_IS_BETTER = {
    "selected_spatial_coverage",
    "expression_state_coverage",
    "expression_embedding_coverage",
    "rare_cell_recall",
    "kish_effective_sample_size",
    "kish_effective_sample_size_over_n",
}


class R2ValidationError(ValueError):
    """Raised when the frozen R2 execution contract is violated."""


@dataclass(frozen=True)
class SharedMeasurements:
    """Shared data preparation measurements retained outside per-run sampling."""

    data_read: Measurement
    spatial_strata: Measurement
    quota_allocation: Measurement
    expression_embedding: Measurement
    evaluation_setup: Measurement

    @property
    def reusable_preprocessing_time(self) -> float:
        return float(
            self.data_read.seconds
            + self.spatial_strata.seconds
            + self.quota_allocation.seconds
            + self.expression_embedding.seconds
            + self.evaluation_setup.seconds
        )

    @property
    def peak_memory_mib(self) -> float:
        return float(
            max(
                self.data_read.peak_rss_mb,
                self.spatial_strata.peak_rss_mb,
                self.quota_allocation.peak_rss_mb,
                self.expression_embedding.peak_rss_mb,
                self.evaluation_setup.peak_rss_mb,
            )
        )


class StageProfiler:
    """Measure registered representation stages without modifying the sampler."""

    def __init__(self) -> None:
        self._code_to_stage = {
            build_candidates_until_quota_feasible.__code__: "candidate_pool_time",
            candidate_quota_feasibility.__code__: "feasibility_check_time",
            sample_by_quota.__code__: "final_selection_time",
        }
        from .representation.quota_completed import complete_candidate_deficits

        self._code_to_stage[complete_candidate_deficits.__code__] = "candidate_completion_time"
        self._starts: dict[int, tuple[str, float]] = {}
        self.elapsed = {
            "candidate_pool_time": 0.0,
            "feasibility_check_time": 0.0,
            "candidate_completion_time": 0.0,
            "final_selection_time": 0.0,
        }
        self._previous: Any = None

    def _profile(self, frame: Any, event: str, argument: Any) -> None:
        stage = self._code_to_stage.get(frame.f_code)
        if stage is None:
            return
        frame_id = id(frame)
        if event == "call":
            self._starts[frame_id] = (stage, time.perf_counter())
        elif event in {"return", "exception"}:
            saved = self._starts.pop(frame_id, None)
            if saved is not None:
                saved_stage, started = saved
                self.elapsed[saved_stage] += float(time.perf_counter() - started)

    def __enter__(self) -> "StageProfiler":
        self._previous = sys.getprofile()
        sys.setprofile(self._profile)
        return self

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        sys.setprofile(self._previous)


def _read_yaml(path: str | Path) -> dict[str, Any]:
    value = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise R2ValidationError(f"Expected a YAML mapping: {path}")
    return value


def _json_ready(value: Any) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return [_json_ready(item) for item in value.tolist()]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {str(key): _json_ready(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_ready(item) for item in value]
    return value


def _write_new_text(path: str | Path, text: str) -> Path:
    destination = Path(path)
    if destination.exists():
        raise FileExistsError(f"Refusing to overwrite R2 output: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(text, encoding="utf-8")
    return destination


def _write_new_json(value: Mapping[str, Any], path: str | Path) -> Path:
    return _write_new_text(
        path,
        json.dumps(_json_ready(value), ensure_ascii=False, indent=2, sort_keys=True) + "\n",
    )


def _write_new_csv(frame: pd.DataFrame, path: str | Path) -> Path:
    destination = Path(path)
    if destination.exists():
        raise FileExistsError(f"Refusing to overwrite R2 output: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(destination, index=False)
    return destination


def _atomic_replace_csv(frame: pd.DataFrame, path: str | Path) -> Path:
    destination = Path(path)
    temporary = destination.with_name(f".{destination.name}.tmp")
    if temporary.exists():
        raise FileExistsError(f"R2 manifest temporary file already exists: {temporary}")
    frame.to_csv(temporary, index=False)
    os.replace(temporary, destination)
    return destination


def _method_identity_checks() -> list[dict[str, Any]]:
    expected = {
        "uniform_srs": (False, False, True),
        "spatial_stratified_srs": (False, True, True),
        "spatial_pivotal": (False, True, True),
        REPRESENTATION_METHOD_ID: (True, True, False),
    }
    rows: list[dict[str, Any]] = []
    for method_id in R2_METHODS:
        metadata = require_runnable_method(method_id)
        expression, spatial, probability = expected[method_id]
        if bool(metadata["uses_expression"]) != expression:
            raise R2ValidationError(f"{method_id} has an incorrect expression-use declaration.")
        if bool(metadata["uses_spatial_coordinates"]) != spatial:
            raise R2ValidationError(f"{method_id} has an incorrect spatial-use declaration.")
        if bool(metadata["uses_cell_labels"]) or bool(metadata["uses_domain_labels"]):
            raise R2ValidationError(f"{method_id} cannot use evaluation labels for sampling.")
        if probability:
            if not bool(metadata["supports_ht"]) or not bool(metadata["supports_hajek"]):
                raise R2ValidationError(f"{method_id} must retain its registered probability inference support.")
        elif (
            bool(metadata["supports_ht"])
            or bool(metadata["supports_hajek"])
            or str(metadata["sampling_weight_type"]) == "probability_sampling_weight"
        ):
            raise R2ValidationError(f"{method_id} has invalid probability-weight metadata.")
        rows.append(
            {
                "method_id": method_id,
                "method_display_name": METHOD_DISPLAY_NAMES[method_id],
                "uses_expression": expression,
                "uses_spatial_coordinates": spatial,
                "uses_cell_labels": False,
                "uses_domain_labels": False,
                "probability_design": probability,
                "implementation_status": str(metadata["implementation_status"]),
                "algorithm_version": str(metadata["algorithm_version"]),
                "identity_check": "PASS",
            }
        )
    return rows


def _environment_metadata() -> dict[str, Any]:
    packages = (
        "anndata",
        "numpy",
        "pandas",
        "psutil",
        "pytest",
        "scanpy",
        "scikit-learn",
        "scipy",
    )
    versions: dict[str, str] = {}
    for package in packages:
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            versions[package] = "not_installed"
    return {
        "python_version": sys.version,
        "platform": platform.platform(),
        "package_versions": versions,
    }


def _input_metadata(input_h5ad: Path) -> dict[str, Any]:
    import anndata as ad

    backed = ad.read_h5ad(input_h5ad, backed="r")
    try:
        n_cells, n_genes = int(backed.n_obs), int(backed.n_vars)
        obs_columns = [str(value) for value in backed.obs.columns]
        obsm_keys = [str(value) for value in backed.obsm.keys()]
    finally:
        backed.file.close()
    if "cell_group" not in obs_columns or "spatial" not in obsm_keys:
        raise R2ValidationError("The R2 input requires cell_group and spatial fields.")
    return {
        "h5ad_path": str(input_h5ad),
        "sha256": sha256_file(input_h5ad),
        "size_bytes": int(input_h5ad.stat().st_size),
        "n_cells": n_cells,
        "n_genes": n_genes,
        "evaluation_cell_group_column": "cell_group",
        "spatial_coordinate_key": "spatial",
        "available_obs_columns": obs_columns,
    }


def build_r2_config(
    *,
    project_root: str | Path,
    input_h5ad: str | Path,
    results_root: str | Path,
    registry_path: str | Path,
    historical_r1_root: str | Path,
    output_name: str = "clean_baseline_pancreas_r2",
) -> tuple[dict[str, Any], Path]:
    """Build the immutable R2 execution contract without creating its directory."""

    project = Path(project_root)
    input_path = Path(input_h5ad)
    registry = Path(registry_path)
    r1_root = Path(historical_r1_root)
    if not input_path.is_file() or not registry.is_file() or not r1_root.is_dir():
        raise FileNotFoundError("R2 requires the QC input, method registry, and historical R1 directory.")
    checks = _method_identity_checks()
    input_info = _input_metadata(input_path)
    output_directory = choose_new_output_directory(results_root, output_name)
    if output_directory.exists() and any(output_directory.iterdir()):
        raise R2ValidationError("The selected R2 output directory is not empty.")
    n_cells = int(input_info["n_cells"])
    target_sizes = {
        f"{fraction:.3f}": target_n_from_fraction(n_cells, fraction) for fraction in R2_FRACTIONS
    }
    config: dict[str, Any] = {
        "r2_config_version": "clean-baseline-pancreas-r2-1",
        "dataset_id": "tenx_xenium_pancreas_cancer_qc",
        "input": input_info,
        "methods": list(R2_METHODS),
        "method_identity_checks": checks,
        "target_fractions": list(R2_FRACTIONS),
        "target_n": target_sizes,
        "target_n_rule": "max(1, floor(n_cells * target_fraction))",
        "benchmark_repeat_seeds": list(R2_SEEDS),
        "selection_grid": {"kind": "fixed_rectangular", "n_x": 20, "n_y": 20},
        "evaluation_grid": {"kind": "fixed_rectangular", "n_x": 20, "n_y": 20},
        "quota_rule": {
            "name": "one_per_nonempty_grid_then_bounded_largest_remainder",
            "minimum_quota": 1,
            "shared_by": [
                "spatial_stratified_srs",
                "spatial_pivotal",
                REPRESENTATION_METHOD_ID,
            ],
        },
        "expression_preprocessing": {
            "function": "compute_pca_embedding",
            "input": "adata.X_without_normalization_or_log_transform",
            "n_components": 30,
            "random_state": 0,
            "expression_evaluation_grid": {"n_x": 20, "n_y": 20},
        },
        "quota_completed_representation": {
            "configuration_file": "configs/quota_completed_representation_mode.yaml",
            "configuration_sha256": sha256_file(
                project / "configs" / "quota_completed_representation_mode.yaml"
            ),
            "candidate_fraction_per_seed": 0.05,
            "n_select_per_seed": int(math.ceil(n_cells * 0.05)),
            "candidate_expression_grid": {"n_x": 10, "n_y": 10},
            "maximum_internal_seed_budget": 20,
            "candidate_pool_seed_set_rule": "range(benchmark_repeat_seed * 20, benchmark_repeat_seed * 20 + 20)",
            "completion_seed_rule": "sha256(dataset_id|fraction_6dp|benchmark_repeat_seed|spatial_stratum|algorithm_version)",
            "final_selection_seed_rule": "benchmark_repeat_seed",
            "quality_status_thresholds": {
                "pass_completion_fraction_at_most": 0.01,
                "warn_completion_fraction_over": 0.01,
                "degraded_completion_fraction_over": 0.10,
                "warn_deficient_strata_fraction_over": 0.02,
                "degraded_deficient_strata_fraction_over": 0.20,
                "warn_stratum_completion_fraction_over": 0.25,
                "degraded_stratum_completion_fraction_over": 0.50,
                "degraded_fallback_strata_fraction_over": 0.05,
            },
            "probability_outputs": "inclusion_probability_and_sampling_weight_forbidden",
        },
        "evaluation": {
            "cell_group_column": "cell_group",
            "rare_label_max_fraction": 0.01,
            "spatial_domain_metrics": "not_available_for_this_input",
            "fixed_evaluation_grid": {"n_x": 20, "n_y": 20},
        },
        "resource_measurement": {
            "memory_poll_interval_seconds": 0.02,
            "stage_timer_semantics": {
                "candidate_pool_time": "inclusive_candidate_pool_construction_time",
                "feasibility_check_time": "nested_candidate_quota_feasibility_time",
                "candidate_completion_time": "same_spatial_stratum_completion_time",
                "final_selection_time": "final_draw_time",
            },
        },
        "source_provenance": {
            "project_root": str(project),
            "code_commit": git_commit_hash(project),
            "method_registry_path": str(registry),
            "method_registry_sha256": sha256_file(registry),
            "historical_r1_root": str(r1_root),
            "historical_r1_config_sha256": sha256_file(r1_root / "pancreas_r1_run_config.yaml"),
            "historical_r1_manifest_sha256": sha256_file(r1_root / "execution_manifest.csv"),
            "representation_module_sha256": sha256_file(
                project / "src" / "spaquotasketch" / "representation" / "quota_completed.py"
            ),
            "historical_r1_executor_sha256": sha256_file(
                project / "src" / "spaquotasketch" / "r1_benchmark.py"
            ),
        },
        "output": {
            "directory": str(output_directory),
            "expected_run_units": len(R2_METHODS) * len(R2_FRACTIONS) * len(R2_SEEDS),
            "overwrite_policy": "forbid_overwrite_delete_or_clear_existing_output",
            "resume_policy": "skip_only_verified_successes_and_preserve_failed_attempts",
        },
    }
    return config, output_directory


def _planned_manifest(config: Mapping[str, Any]) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for fraction in config["target_fractions"]:
        target_n = int(config["target_n"][f"{float(fraction):.3f}"])
        for method_id in config["methods"]:
            for seed in config["benchmark_repeat_seeds"]:
                rows.append(
                    {
                        "run_id": f"r2_{method_id}_{float(fraction):.3f}_seed_{int(seed):02d}",
                        "attempt": 1,
                        "status": "PLANNED",
                        "method": method_id,
                        "method_display_name": METHOD_DISPLAY_NAMES[method_id],
                        "target_fraction": float(fraction),
                        "benchmark_repeat_seed": int(seed),
                        "target_n": target_n,
                        "actual_n": np.nan,
                        "error_type": "",
                        "error_message": "",
                    }
                )
    return pd.DataFrame(rows).sort_values(
        ["target_fraction", "method", "benchmark_repeat_seed"], kind="stable"
    ).reset_index(drop=True)


def write_immutable_r2_config(
    config: Mapping[str, Any], output_directory: str | Path
) -> tuple[Path, Path]:
    """Create one new R2 directory and write its immutable configuration artifacts."""

    directory = Path(output_directory)
    if directory.exists():
        if any(directory.iterdir()):
            raise FileExistsError(f"Refusing to reuse a nonempty R2 directory: {directory}")
    else:
        directory.mkdir(parents=True, exist_ok=False)
    config_path = directory / "pancreas_r2_run_config.yaml"
    _write_new_text(config_path, yaml.safe_dump(dict(config), allow_unicode=True, sort_keys=False))
    digest = sha256_file(config_path)
    digest_path = directory / "pancreas_r2_config_sha256.txt"
    _write_new_text(digest_path, f"{digest}  {config_path.name}\n")
    provenance = config["source_provenance"]
    registry_source = Path(provenance["method_registry_path"])
    _write_new_text(
        directory / "pancreas_r2_method_registry_snapshot.yaml",
        registry_source.read_text(encoding="utf-8"),
    )
    _write_new_json(
        {
            "input": config["input"],
            "historical_r1_config_sha256": provenance["historical_r1_config_sha256"],
            "historical_r1_manifest_sha256": provenance["historical_r1_manifest_sha256"],
            "method_registry_sha256": provenance["method_registry_sha256"],
            "representation_module_sha256": provenance["representation_module_sha256"],
            "historical_r1_executor_sha256": provenance["historical_r1_executor_sha256"],
        },
        directory / "pancreas_r2_input_checksums.json",
    )
    _write_new_json(_environment_metadata(), directory / "pancreas_r2_environment.json")
    _write_new_csv(_planned_manifest(config), directory / "pancreas_r2_execution_manifest.csv")
    return config_path, digest_path


def verify_immutable_r2_config(config_path: str | Path) -> dict[str, Any]:
    path = Path(config_path)
    digest_path = path.with_name("pancreas_r2_config_sha256.txt")
    if not path.is_file() or not digest_path.is_file():
        raise R2ValidationError("R2 immutable configuration or checksum is missing.")
    expected = digest_path.read_text(encoding="utf-8").split()[0]
    if sha256_file(path) != expected:
        raise R2ValidationError("R2 configuration checksum differs from the frozen value.")
    config = _read_yaml(path)
    if tuple(config.get("methods", [])) != R2_METHODS:
        raise R2ValidationError("R2 method identity or order differs from the frozen matrix.")
    if tuple(float(value) for value in config.get("target_fractions", [])) != R2_FRACTIONS:
        raise R2ValidationError("R2 fractions differ from the frozen matrix.")
    if tuple(int(value) for value in config.get("benchmark_repeat_seeds", [])) != R2_SEEDS:
        raise R2ValidationError("R2 repeat seeds differ from the frozen matrix.")
    if int(config.get("output", {}).get("expected_run_units", 0)) != 200:
        raise R2ValidationError("R2 must contain exactly 200 planned units.")
    _method_identity_checks()
    return config


def _verify_execution_sources(config: Mapping[str, Any]) -> None:
    input_info = config["input"]
    source = config["source_provenance"]
    checks = (
        ("input", input_info["h5ad_path"], input_info["sha256"]),
        ("method registry", source["method_registry_path"], source["method_registry_sha256"]),
        (
            "representation configuration",
            Path(source["project_root"]) / "configs" / "quota_completed_representation_mode.yaml",
            config["quota_completed_representation"]["configuration_sha256"],
        ),
        (
            "historical R1 config",
            Path(source["historical_r1_root"]) / "pancreas_r1_run_config.yaml",
            source["historical_r1_config_sha256"],
        ),
        (
            "historical R1 manifest",
            Path(source["historical_r1_root"]) / "execution_manifest.csv",
            source["historical_r1_manifest_sha256"],
        ),
        (
            "representation module",
            Path(source["project_root"]) / "src" / "spaquotasketch" / "representation" / "quota_completed.py",
            source["representation_module_sha256"],
        ),
        (
            "historical R1 executor",
            Path(source["project_root"]) / "src" / "spaquotasketch" / "r1_benchmark.py",
            source["historical_r1_executor_sha256"],
        ),
    )
    for name, path, expected in checks:
        if not Path(path).is_file() or sha256_file(path) != str(expected):
            raise R2ValidationError(f"Frozen {name} source changed or is unavailable.")


def _candidate_history_frame(global_diagnostics: Mapping[str, Any]) -> pd.DataFrame:
    sizes = list(global_diagnostics.get("candidate_pool_size_by_internal_seed", []))
    deficient = list(global_diagnostics.get("deficient_strata_by_internal_seed", []))
    deficits = list(global_diagnostics.get("total_deficit_by_internal_seed", []))
    gains = list(global_diagnostics.get("marginal_candidate_gain", []))
    reductions = list(global_diagnostics.get("marginal_deficit_reduction", []))
    length = max(len(sizes), len(deficient), len(deficits), len(gains), len(reductions), 0)
    return pd.DataFrame(
        {
            "internal_seed_position": list(range(length)),
            "candidate_pool_size": sizes + [np.nan] * (length - len(sizes)),
            "deficient_strata_count": deficient + [np.nan] * (length - len(deficient)),
            "total_candidate_deficit": deficits + [np.nan] * (length - len(deficits)),
            "marginal_candidate_gain": gains + [np.nan] * (length - len(gains)),
            "marginal_deficit_reduction": reductions + [np.nan] * (length - len(reductions)),
        }
    )


def _validate_probability_result(
    *,
    method_id: str,
    inclusion_probability: np.ndarray,
    sampling_weight: np.ndarray,
    spatial_bins: np.ndarray,
    quotas: Mapping[str, int],
) -> None:
    probability = np.asarray(inclusion_probability, dtype=float)
    weights = np.asarray(sampling_weight, dtype=float)
    if probability.shape != weights.shape or np.any(probability <= 0) or np.any(probability > 1):
        raise R2ValidationError(f"{method_id} has invalid inclusion probabilities.")
    if not np.allclose(weights, 1.0 / probability, rtol=0, atol=1e-12):
        raise R2ValidationError(f"{method_id} sampling_weight does not equal 1 / inclusion_probability.")
    if method_id == "uniform_srs":
        if not np.isclose(float(probability.sum()), float(sum(quotas.values())), atol=1e-8):
            raise R2ValidationError("Uniform SRS inclusion probabilities do not sum to target_n.")
        return
    for stratum, quota in quotas.items():
        observed = float(probability[spatial_bins == stratum].sum())
        if not np.isclose(observed, float(quota), atol=1e-8):
            raise R2ValidationError(f"{method_id} inclusion probabilities do not sum to q_g in {stratum}.")


def _validate_representation_result(
    result: Any,
    quotas: Mapping[str, int],
) -> None:
    global_diagnostics = result.global_diagnostics
    rows = result.stratum_diagnostics
    if not np.all(rows["deficit_g"].to_numpy(dtype=int) == np.maximum(
        rows["q_g"].to_numpy(dtype=int) - rows["C_g_before"].to_numpy(dtype=int), 0
    )):
        raise R2ValidationError("Representation candidate deficit formula is violated.")
    if not np.array_equal(
        rows["completion_added"].to_numpy(dtype=int), rows["deficit_g"].to_numpy(dtype=int)
    ):
        raise R2ValidationError("Representation completion is not exactly equal to deficit_g.")
    if (rows["C_g_after"].to_numpy(dtype=int) < rows["q_g"].to_numpy(dtype=int)).any():
        raise R2ValidationError("Representation completion left a spatial quota infeasible.")
    if int(rows["completion_added"].sum()) != int(global_diagnostics["total_candidate_deficit"]):
        raise R2ValidationError("Representation global completion count is inconsistent.")
    if float(global_diagnostics["candidate_feasibility_after_completion"]) != 1.0:
        raise R2ValidationError("Representation candidate pool remains infeasible after completion.")
    allowed = {
        "expression_candidate",
        "quota_completion_expression_stratified",
        "quota_completion_srs_fallback",
    }
    selection = result.selected_cells
    if not set(selection["candidate_source"].astype(str)).issubset(allowed):
        raise R2ValidationError("Representation selected cells have invalid candidate provenance.")
    if selection["candidate_source"].isna().any():
        raise R2ValidationError("Representation selected cells are missing candidate provenance.")
    if "inclusion_probability" in selection.columns or "sampling_weight" in selection.columns:
        raise R2ValidationError("Representation output must not export probability fields.")
    factor = selection["composition_calibration_factor"].to_numpy(dtype=float)
    expected = selection["stratum_size"].to_numpy(dtype=float) / selection["stratum_quota"].to_numpy(dtype=float)
    if not np.allclose(factor, expected, rtol=0, atol=1e-12):
        raise R2ValidationError("Representation composition calibration factor has invalid semantics.")
    if str(global_diagnostics["quality_status"]) not in {"PASS", "WARN", "DEGRADED"}:
        raise R2ValidationError("Representation quality status is invalid for a successful run.")
    selected_counts = Counter(selection["spatial_stratum"].astype(str).tolist())
    if selected_counts != {stratum: int(quota) for stratum, quota in quotas.items()}:
        raise R2ValidationError("Representation final selection violates frozen spatial quotas.")


def _atomic_write_run(
    *,
    run_directory: Path,
    selection_frame: pd.DataFrame,
    method_metadata: Mapping[str, Any],
    resource: Mapping[str, Any],
    quality_checks: Mapping[str, Any],
    group_rows: Sequence[Mapping[str, Any]],
    probability_diagnostics: pd.DataFrame | None,
    representation_result: Any | None,
) -> None:
    parent = run_directory.parent
    temporary = parent / f".{run_directory.name}.tmp"
    if run_directory.exists() or temporary.exists():
        raise FileExistsError(f"Refusing to overwrite R2 run output: {run_directory}")
    temporary.mkdir(parents=True, exist_ok=False)
    try:
        _write_new_csv(selection_frame, temporary / "selected_cells.csv")
        _write_new_json(dict(method_metadata), temporary / "method_metadata.json")
        _write_new_json(dict(resource), temporary / "resource.json")
        _write_new_json(dict(quality_checks), temporary / "quality_checks.json")
        _write_new_csv(pd.DataFrame(group_rows), temporary / "cell_group_spatial_metrics.csv")
        if probability_diagnostics is not None:
            _write_new_csv(probability_diagnostics, temporary / "probability_diagnostics.csv")
        if representation_result is not None:
            _write_new_csv(representation_result.candidate_cells, temporary / "candidate_cells.csv")
            _write_new_csv(
                representation_result.stratum_diagnostics,
                temporary / "candidate_completion_stratum_diagnostics.csv",
            )
            _write_new_json(
                representation_result.global_diagnostics,
                temporary / "candidate_completion_global_diagnostics.json",
            )
            _write_new_csv(
                _candidate_history_frame(representation_result.global_diagnostics),
                temporary / "candidate_saturation.csv",
            )
        _write_new_json({"status": "SUCCESS"}, temporary / "status.json")
        os.replace(temporary, run_directory)
    except Exception:
        if temporary.exists():
            raise
        raise


def _failure_status(error: Exception) -> str:
    if isinstance(error, (InfeasibleQuotaError, QuotaCompletedRepresentationFailure)):
        return "INFEASIBLE"
    return "FAIL"


def _write_failure(output_directory: Path, row: Mapping[str, Any], error: Exception) -> Path:
    failures = output_directory / "failures"
    destination = failures / f"{row['run_id']}_attempt_{int(row['attempt']):02d}.json"
    return _write_new_json(
        {
            "run_id": row["run_id"],
            "attempt": int(row["attempt"]),
            "status": _failure_status(error),
            "method": row["method"],
            "target_fraction": float(row["target_fraction"]),
            "benchmark_repeat_seed": int(row["benchmark_repeat_seed"]),
            "target_n": int(row["target_n"]),
            "error_type": type(error).__name__,
            "error_message": str(error),
        },
        destination,
    )


def _representation_draw(
    *,
    cell_ids: np.ndarray,
    embedding: np.ndarray,
    spatial_bins: np.ndarray,
    quotas: Mapping[str, int],
    target_n: int,
    dataset_id: str,
    fraction: float,
    benchmark_seed: int,
) -> tuple[Any, dict[str, float]]:
    profile = StageProfiler()
    with profile:
        result = sample_quota_completed_representation(
            cell_ids=cell_ids.tolist(),
            expression_embedding=embedding,
            spatial_strata=spatial_bins.tolist(),
            quotas=quotas,
            target_n=target_n,
            dataset_id=dataset_id,
            target_fraction=fraction,
            benchmark_repeat_seed=benchmark_seed,
        )
    return result, profile.elapsed


def _run_one(
    *,
    config: Mapping[str, Any],
    row: Mapping[str, Any],
    cell_ids: np.ndarray,
    coordinates: np.ndarray,
    spatial_bins: np.ndarray,
    expression_bins: np.ndarray,
    embedding: np.ndarray,
    quotas: Mapping[str, int],
    quota_audit: pd.DataFrame,
    cell_groups: np.ndarray,
    full_gene_means: np.ndarray,
    matrix: Any,
    expression_total: np.ndarray,
    shared: SharedMeasurements,
    run_directory: Path,
) -> dict[str, Any]:
    method_id = str(row["method"])
    target_n = int(row["target_n"])
    seed = int(row["benchmark_repeat_seed"])
    interval = float(config["resource_measurement"]["memory_poll_interval_seconds"])
    inclusion_probability: np.ndarray | None = None
    sampling_weight: np.ndarray | None = None
    probability_diagnostics: pd.DataFrame | None = None
    representation_result: Any | None = None
    stage_times = {
        "candidate_pool_time": 0.0,
        "feasibility_check_time": 0.0,
        "candidate_completion_time": 0.0,
        "final_selection_time": 0.0,
    }

    if method_id == "uniform_srs":
        result, core_measurement = measure_call(
            lambda: sample_uniform_srs(cell_ids, target_n, random_seed=seed), interval
        )
        selected_indices = np.flatnonzero(result.selected_mask)
        inclusion_probability = result.inclusion_probability
        sampling_weight = result.sampling_weight
        selection_frame = _selection_frame_from_probability(result)
        metadata = _method_metadata_for_probability(result, seed)
        probability_diagnostics = pd.DataFrame(
            {
                "spatial_stratum": ["global"],
                "N_g": [int(cell_ids.size)],
                "q_g": [target_n],
                "pi_expected": [float(target_n / cell_ids.size)],
                "pi_observed_min": [float(np.min(inclusion_probability))],
                "pi_observed_max": [float(np.max(inclusion_probability))],
                "pi_sum": [float(np.sum(inclusion_probability))],
                "pi_sum_minus_q_g": [float(np.sum(inclusion_probability) - target_n)],
                "positive_support": [bool(np.all(inclusion_probability > 0))],
            }
        )
        stage_times["final_selection_time"] = core_measurement.seconds
    elif method_id == "spatial_stratified_srs":
        result, core_measurement = measure_call(
            lambda: sample_spatial_stratified_srs(cell_ids, spatial_bins, quotas, random_seed=seed),
            interval,
        )
        selected_indices = np.flatnonzero(result.selected_mask)
        inclusion_probability = result.inclusion_probability
        sampling_weight = result.sampling_weight
        selection_frame = _selection_frame_from_probability(result)
        metadata = _method_metadata_for_probability(result, seed)
        probability_diagnostics = _probability_diagnostics(
            spatial_bins=spatial_bins,
            quota_audit=quota_audit,
            inclusion_probability=inclusion_probability,
        )
        stage_times["final_selection_time"] = core_measurement.seconds
    elif method_id == "spatial_pivotal":
        result, core_measurement = measure_call(
            lambda: sample_spatial_pivotal(
                cell_ids, coordinates, spatial_bins, quotas, random_seed=seed
            ),
            interval,
        )
        selected_indices = np.flatnonzero(result.selected_mask)
        inclusion_probability = result.inclusion_probability
        sampling_weight = result.sampling_weight
        selection_frame = _selection_frame_from_probability(result)
        metadata = _method_metadata_for_probability(result, seed)
        probability_diagnostics = _probability_diagnostics(
            spatial_bins=spatial_bins,
            quota_audit=quota_audit,
            inclusion_probability=inclusion_probability,
        )
        stage_times["final_selection_time"] = core_measurement.seconds
    elif method_id == REPRESENTATION_METHOD_ID:
        (representation_result, stage_times), core_measurement = measure_call(
            lambda: _representation_draw(
                cell_ids=cell_ids,
                embedding=embedding,
                spatial_bins=spatial_bins,
                quotas=quotas,
                target_n=target_n,
                dataset_id=str(config["dataset_id"]),
                fraction=float(row["target_fraction"]),
                benchmark_seed=seed,
            ),
            interval,
        )
        selected_indices = np.asarray(representation_result.selected_indices, dtype=int)
        selection_frame = representation_result.selected_cells.copy()
        metadata = dict(representation_result.metadata)
        metadata["method_display_name"] = METHOD_DISPLAY_NAMES[method_id]
        metadata["benchmark_repeat_seed"] = seed
        metadata["completion_seed_values"] = sorted(
            int(value)
            for value in representation_result.stratum_diagnostics["completion_seed"].unique().tolist()
        )
    else:
        raise R2ValidationError(f"Unsupported R2 method: {method_id}")

    if selected_indices.size != target_n:
        raise R2ValidationError(f"{row['run_id']} selected {selected_indices.size}, expected {target_n}.")
    if np.unique(selected_indices).size != selected_indices.size:
        raise R2ValidationError(f"{row['run_id']} selected duplicate cells.")
    if np.any(selected_indices < 0) or np.any(selected_indices >= cell_ids.size):
        raise R2ValidationError(f"{row['run_id']} selected cells outside the population.")
    if method_id != "uniform_srs":
        observed = Counter(spatial_bins[selected_indices].tolist())
        expected = {stratum: int(quota) for stratum, quota in quotas.items()}
        if observed != expected:
            raise R2ValidationError(f"{row['run_id']} violates its frozen spatial quota vector.")
    if bool(metadata["uses_cell_labels"]) or bool(metadata["uses_domain_labels"]):
        raise R2ValidationError(f"{row['run_id']} has an invalid label-use declaration.")
    if method_id in PROBABILITY_METHODS:
        if inclusion_probability is None or sampling_weight is None:
            raise R2ValidationError(f"{row['run_id']} is missing probability outputs.")
        _validate_probability_result(
            method_id=method_id,
            inclusion_probability=inclusion_probability,
            sampling_weight=sampling_weight,
            spatial_bins=spatial_bins,
            quotas=quotas,
        )
    else:
        if representation_result is None:
            raise R2ValidationError("Representation execution did not return its result object.")
        _validate_representation_result(representation_result, quotas)

    (metrics, group_rows), metric_measurement = measure_call(
        lambda: _evaluate_run(
            method_id=method_id,
            selected_indices=selected_indices,
            cell_groups=cell_groups,
            spatial_bins=spatial_bins,
            expression_bins=expression_bins,
            coordinates=coordinates,
            full_gene_means=full_gene_means,
            matrix=matrix,
            expression_total=expression_total,
            inclusion_probability=inclusion_probability,
            sampling_weight=sampling_weight,
            rare_label_max_fraction=float(config["evaluation"]["rare_label_max_fraction"]),
        ),
        interval,
    )
    metrics["expression_embedding_coverage"] = metrics["expression_state_coverage"]
    completion_diagnostics: dict[str, Any] = {}
    if representation_result is not None:
        completion_diagnostics = dict(representation_result.global_diagnostics)
    else:
        completion_diagnostics = {
            "completion_fraction_of_final_sample": float("nan"),
            "deficient_strata_fraction": float("nan"),
            "quality_status": "NOT_APPLICABLE",
            "candidate_feasibility_before_completion": float("nan"),
            "candidate_feasibility_after_completion": float("nan"),
            "fallback_strata_count": 0,
        }
    quality_checks = {
        "actual_n_equals_target_n": True,
        "selected_cell_ids_unique": True,
        "selected_cell_ids_within_population": True,
        "spatial_quota_exact": method_id != "uniform_srs",
        "evaluation_labels_excluded_from_sampler": True,
        "probability_outputs_checked": method_id in PROBABILITY_METHODS,
        "representation_completion_checked": method_id == REPRESENTATION_METHOD_ID,
        "status": "PASS",
    }
    local_without_output = float(core_measurement.seconds + metric_measurement.seconds)
    shared_time = shared.reusable_preprocessing_time
    resource = {
        "data_read_time": shared.data_read.seconds,
        "reusable_preprocessing_time": shared_time,
        "spatial_strata_time": shared.spatial_strata.seconds,
        "quota_allocation_time": shared.quota_allocation.seconds,
        "expression_embedding_time": shared.expression_embedding.seconds,
        "candidate_pool_time": float(stage_times["candidate_pool_time"]),
        "feasibility_check_time": float(stage_times["feasibility_check_time"]),
        "candidate_completion_time": float(stage_times["candidate_completion_time"]),
        "final_selection_time": float(stage_times["final_selection_time"]),
        "metric_time": metric_measurement.seconds,
        "core_sampling_time": core_measurement.seconds,
        "end_to_end_time_local": local_without_output,
        "end_to_end_time": float(local_without_output + shared_time),
        "end_to_end_time_amortized_shared_cost": float(
            local_without_output + shared_time / int(config["output"]["expected_run_units"])
        ),
        "peak_memory_mib": float(
            max(shared.peak_memory_mib, core_measurement.peak_rss_mb, metric_measurement.peak_rss_mb)
        ),
    }
    _atomic_write_run(
        run_directory=run_directory,
        selection_frame=selection_frame,
        method_metadata=metadata,
        resource=resource,
        quality_checks=quality_checks,
        group_rows=group_rows,
        probability_diagnostics=probability_diagnostics,
        representation_result=representation_result,
    )
    return {
        "status": "SUCCESS",
        "actual_n": int(selected_indices.size),
        "candidate_pool_seed_set": json.dumps(metadata.get("candidate_pool_seed_set", [])),
        "completion_seed_values": json.dumps(metadata.get("completion_seed_values", [])),
        "final_selection_seed": int(metadata.get("final_selection_seed", seed)),
        "selection_directory": str(run_directory),
        "quality_status": str(completion_diagnostics.get("quality_status", "NOT_APPLICABLE")),
        **completion_diagnostics,
        **metrics,
        **resource,
    }


def _update_manifest(
    manifest: pd.DataFrame, manifest_path: Path, row_index: int, values: Mapping[str, Any]
) -> pd.DataFrame:
    updated = manifest.copy()
    for key, value in values.items():
        # The initial CSV intentionally contains blank future-result fields.
        # pandas may restore those columns as string dtype, so make each field
        # object-capable before recording its terminal numeric result.
        if key not in updated.columns:
            updated[key] = pd.Series(index=updated.index, dtype=object)
        elif not pd.api.types.is_object_dtype(updated[key].dtype):
            updated[key] = updated[key].astype(object)
        elif pd.api.types.is_string_dtype(updated[key].dtype):
            updated[key] = updated[key].astype(object)
        normalized = _json_ready(value)
        if isinstance(normalized, (dict, list, tuple)):
            normalized = json.dumps(normalized, ensure_ascii=False, sort_keys=True)
        updated.at[row_index, key] = normalized
    _atomic_replace_csv(updated, manifest_path)
    return updated


def execute_r2(config_path: str | Path) -> dict[str, Any]:
    """Run all currently planned R2 units and preserve every terminal state."""

    config = verify_immutable_r2_config(config_path)
    _verify_execution_sources(config)
    output_directory = Path(config["output"]["directory"])
    manifest_path = output_directory / "pancreas_r2_execution_manifest.csv"
    if not manifest_path.is_file():
        raise FileNotFoundError("R2 execution manifest is missing.")
    manifest = pd.read_csv(manifest_path, keep_default_na=False)
    if len(manifest) != int(config["output"]["expected_run_units"]) or manifest["run_id"].duplicated().any():
        raise R2ValidationError("R2 manifest does not contain one unique row per planned run.")

    import anndata as ad

    (adata,), data_measurement = measure_call(
        lambda: (ad.read_h5ad(Path(config["input"]["h5ad_path"])),),
        float(config["resource_measurement"]["memory_poll_interval_seconds"]),
    )
    validate_spatial_anndata(adata)
    cell_ids = np.asarray(adata.obs_names.astype(str), dtype=object)
    cell_groups = np.asarray(adata.obs[config["evaluation"]["cell_group_column"]].astype(str), dtype=object)
    if cell_ids.size != int(config["input"]["n_cells"]) or adata.n_vars != int(config["input"]["n_genes"]):
        raise R2ValidationError("Loaded input dimensions differ from the frozen configuration.")
    full_gene_means = np.asarray(adata.X.mean(axis=0)).reshape(-1)
    expression_total = _as_observation_total(adata)

    interval = float(config["resource_measurement"]["memory_poll_interval_seconds"])
    (coordinates, spatial_bins), spatial_measurement = measure_call(
        lambda: (
            get_spatial_coordinates(adata),
            np.asarray(
                rectangular_grid_bins(
                    get_spatial_coordinates(adata),
                    n_x=int(config["selection_grid"]["n_x"]),
                    n_y=int(config["selection_grid"]["n_y"]),
                ),
                dtype=object,
            ),
        ),
        interval,
    )

    def allocate_quotas() -> tuple[dict[float, dict[str, int]], dict[float, pd.DataFrame]]:
        quotas_by_fraction: dict[float, dict[str, int]] = {}
        audits: dict[float, pd.DataFrame] = {}
        for fraction in config["target_fractions"]:
            quotas, audit = _stratum_table(
                spatial_bins,
                int(config["target_n"][f"{float(fraction):.3f}"]),
            )
            quotas_by_fraction[float(fraction)] = quotas
            audits[float(fraction)] = audit
        return quotas_by_fraction, audits

    (quotas_by_fraction, audits_by_fraction), quota_measurement = measure_call(allocate_quotas, interval)

    (embedding,), embedding_measurement = measure_call(
        lambda: (
            compute_pca_embedding(
                adata,
                n_components=int(config["expression_preprocessing"]["n_components"]),
                random_state=int(config["expression_preprocessing"]["random_state"]),
            ),
        ),
        interval,
    )
    (expression_bins,), evaluation_measurement = measure_call(
        lambda: (
            np.asarray(
                rectangular_grid_bins(
                    embedding[:, :2],
                    n_x=int(config["evaluation"]["fixed_evaluation_grid"]["n_x"]),
                    n_y=int(config["evaluation"]["fixed_evaluation_grid"]["n_y"]),
                ),
                dtype=object,
            ),
        ),
        interval,
    )
    shared = SharedMeasurements(
        data_read=data_measurement,
        spatial_strata=spatial_measurement,
        quota_allocation=quota_measurement,
        expression_embedding=embedding_measurement,
        evaluation_setup=evaluation_measurement,
    )
    _write_new_json(
        {
            "data_read": data_measurement.__dict__,
            "spatial_strata": spatial_measurement.__dict__,
            "quota_allocation": quota_measurement.__dict__,
            "expression_embedding": embedding_measurement.__dict__,
            "evaluation_setup": evaluation_measurement.__dict__,
            "reusable_preprocessing_time": shared.reusable_preprocessing_time,
            "peak_memory_mib": shared.peak_memory_mib,
            "n_nonempty_selection_strata": int(len(set(spatial_bins.tolist()))),
        },
        output_directory / "pancreas_r2_shared_preprocessing_resource.json",
    )
    for fraction, audit in audits_by_fraction.items():
        audited = audit.copy()
        audited["target_fraction"] = fraction
        _write_new_csv(
            audited,
            output_directory / "shared_design" / f"fraction_{fraction:.3f}_quota_audit.csv",
        )

    execution_order = {
        "uniform_srs": 0,
        "spatial_stratified_srs": 1,
        "spatial_pivotal": 2,
        REPRESENTATION_METHOD_ID: 3,
    }
    active = manifest.loc[~manifest["status"].eq("SUCCESS")].copy()
    active["_order"] = active["method"].map(execution_order)
    active = active.sort_values(["_order", "target_fraction", "benchmark_repeat_seed"], kind="stable")
    for source_index in active.index.tolist():
        current = manifest.loc[source_index].to_dict()
        if str(current["status"]) in {"FAIL", "INFEASIBLE"}:
            continue
        manifest = _update_manifest(
            manifest,
            manifest_path,
            source_index,
            {"status": "RUNNING", "error_type": "", "error_message": ""},
        )
        current = manifest.loc[source_index].to_dict()
        run_directory = output_directory / "runs" / str(current["run_id"])
        try:
            record = _run_one(
                config=config,
                row=current,
                cell_ids=cell_ids,
                coordinates=coordinates,
                spatial_bins=spatial_bins,
                expression_bins=expression_bins,
                embedding=embedding,
                quotas=quotas_by_fraction[float(current["target_fraction"])],
                quota_audit=audits_by_fraction[float(current["target_fraction"])],
                cell_groups=cell_groups,
                full_gene_means=full_gene_means,
                matrix=adata.X,
                expression_total=expression_total,
                shared=shared,
                run_directory=run_directory,
            )
            manifest = _update_manifest(manifest, manifest_path, source_index, record)
        except Exception as error:
            status = _failure_status(error)
            failure_path = _write_failure(output_directory, current, error)
            manifest = _update_manifest(
                manifest,
                manifest_path,
                source_index,
                {
                    "status": status,
                    "error_type": type(error).__name__,
                    "error_message": str(error),
                    "failure_record": str(failure_path),
                },
            )

    terminal = manifest["status"].isin(["SUCCESS", "FAIL", "INFEASIBLE"])
    success = int(manifest["status"].eq("SUCCESS").sum())
    failed = int((manifest["status"].isin(["FAIL", "INFEASIBLE"])).sum())
    validation = {
        "expected_run_units": int(config["output"]["expected_run_units"]),
        "manifest_run_units": int(len(manifest)),
        "unique_run_ids": int(manifest["run_id"].nunique()),
        "terminal_run_units": int(terminal.sum()),
        "successful_run_units": success,
        "failed_or_infeasible_run_units": failed,
        "all_runs_terminal": bool(terminal.all()),
        "all_runs_successful": bool(success == len(manifest) and failed == 0),
    }
    _write_new_json(validation, output_directory / "pancreas_r2_execution_validation.json")
    return {"status": "SUCCESS" if validation["all_runs_successful"] else "HOLD", **validation}


def _summary_table(raw: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for (fraction, method), frame in raw.groupby(["target_fraction", "method"], sort=True):
        for metric in SUMMARY_METRICS:
            if metric not in frame:
                continue
            values = pd.to_numeric(frame[metric], errors="coerce").dropna()
            rows.append(
                {
                    "target_fraction": float(fraction),
                    "method": str(method),
                    "method_display_name": METHOD_DISPLAY_NAMES[str(method)],
                    "metric": metric,
                    "n_repeats": int(values.size),
                    "mean": float(values.mean()) if not values.empty else float("nan"),
                    "standard_deviation": float(values.std(ddof=1)) if values.size > 1 else 0.0,
                    "median": float(values.median()) if not values.empty else float("nan"),
                    "minimum": float(values.min()) if not values.empty else float("nan"),
                    "maximum": float(values.max()) if not values.empty else float("nan"),
                    "quantile_25": float(values.quantile(0.25)) if not values.empty else float("nan"),
                    "quantile_75": float(values.quantile(0.75)) if not values.empty else float("nan"),
                }
            )
    return pd.DataFrame(rows).sort_values(["metric", "target_fraction", "method"], kind="stable")


def _paired_tables(raw: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    baseline = raw.loc[raw["method"].eq("spatial_stratified_srs")].copy()
    details: list[dict[str, Any]] = []
    for method_id in R2_METHODS:
        if method_id == "spatial_stratified_srs":
            continue
        method = raw.loc[raw["method"].eq(method_id)].copy()
        for metric in SUMMARY_METRICS:
            if metric not in raw:
                continue
            merged = method.loc[:, ["target_fraction", "benchmark_repeat_seed", metric]].merge(
                baseline.loc[:, ["target_fraction", "benchmark_repeat_seed", metric]],
                on=["target_fraction", "benchmark_repeat_seed"],
                suffixes=("_method", "_baseline"),
                how="inner",
            )
            method_column = f"{metric}_method"
            baseline_column = f"{metric}_baseline"
            merged[method_column] = pd.to_numeric(merged[method_column], errors="coerce")
            merged[baseline_column] = pd.to_numeric(merged[baseline_column], errors="coerce")
            for row in merged.itertuples(index=False):
                method_value = float(getattr(row, method_column))
                baseline_value = float(getattr(row, baseline_column))
                if not np.isfinite(method_value) or not np.isfinite(baseline_value):
                    continue
                difference = method_value - baseline_value
                direction = "higher" if metric in HIGHER_IS_BETTER else "lower"
                outcome = (
                    "tie"
                    if abs(difference) <= 1e-12
                    else "win"
                    if (direction == "higher" and difference > 0)
                    or (direction == "lower" and difference < 0)
                    else "loss"
                )
                details.append(
                    {
                        "target_fraction": float(row.target_fraction),
                        "method": method_id,
                        "baseline_method": "spatial_stratified_srs",
                        "benchmark_repeat_seed": int(row.benchmark_repeat_seed),
                        "metric": metric,
                        "method_value": method_value,
                        "baseline_value": baseline_value,
                        "paired_difference_method_minus_baseline": difference,
                        "preferred_direction": direction,
                        "outcome": outcome,
                    }
                )
    detail = pd.DataFrame(details)
    summary_rows: list[dict[str, Any]] = []
    if not detail.empty:
        for keys, frame in detail.groupby(
            ["target_fraction", "method", "metric", "preferred_direction"], sort=True
        ):
            values = frame["paired_difference_method_minus_baseline"]
            summary_rows.append(
                {
                    "target_fraction": float(keys[0]),
                    "method": str(keys[1]),
                    "baseline_method": "spatial_stratified_srs",
                    "metric": str(keys[2]),
                    "preferred_direction": str(keys[3]),
                    "n_pairs": int(values.size),
                    "mean_paired_difference": float(values.mean()),
                    "median_paired_difference": float(values.median()),
                    "minimum_paired_difference": float(values.min()),
                    "maximum_paired_difference": float(values.max()),
                    "quantile_25_paired_difference": float(values.quantile(0.25)),
                    "quantile_75_paired_difference": float(values.quantile(0.75)),
                    "winning_seed_count": int(frame["outcome"].eq("win").sum()),
                    "tie_seed_count": int(frame["outcome"].eq("tie").sum()),
                    "losing_seed_count": int(frame["outcome"].eq("loss").sum()),
                }
            )
    return detail, pd.DataFrame(summary_rows)


def _relationship_table(raw: pd.DataFrame) -> pd.DataFrame:
    representation = raw.loc[raw["method"].eq(REPRESENTATION_METHOD_ID)].copy()
    rows: list[dict[str, Any]] = []
    for metric in (
        "expression_state_coverage",
        "cell_group_l1_error",
        "selected_spatial_coverage",
        "mean_within_group_spatial_l1_error",
    ):
        if metric not in representation:
            continue
        for fraction, frame in representation.groupby("target_fraction", sort=True):
            x = pd.to_numeric(frame["completion_fraction_of_final_sample"], errors="coerce")
            y = pd.to_numeric(frame[metric], errors="coerce")
            valid = x.notna() & y.notna()
            correlation = float("nan")
            if int(valid.sum()) >= 3 and x[valid].nunique() > 1 and y[valid].nunique() > 1:
                correlation = float(np.corrcoef(x[valid], y[valid])[0, 1])
            rows.append(
                {
                    "target_fraction": float(fraction),
                    "metric": metric,
                    "n": int(valid.sum()),
                    "pearson_correlation": correlation,
                    "mean_completion_fraction": float(x[valid].mean()) if valid.any() else float("nan"),
                }
            )
    return pd.DataFrame(rows)


def _historical_conclusion_table(raw: pd.DataFrame, paired: pd.DataFrame) -> pd.DataFrame:
    representation = raw.loc[raw["method"].eq(REPRESENTATION_METHOD_ID)]
    completion_success = len(representation) == 50 and representation["status"].eq("SUCCESS").all()
    no_infeasible = completion_success and not representation["quality_status"].eq("FAIL").any()

    def paired_sign(metric: str, fractions: Sequence[float], higher: bool) -> str:
        subset = paired.loc[
            paired["method"].eq(REPRESENTATION_METHOD_ID)
            & paired["metric"].eq(metric)
            & paired["target_fraction"].isin(fractions)
        ]
        if subset.empty:
            return "STILL_UNCERTAIN"
        values = subset["paired_difference_method_minus_baseline"].to_numpy(dtype=float)
        favorable = values > 1e-12 if higher else values < -1e-12
        opposing = values < -1e-12 if higher else values > 1e-12
        if int(favorable.sum()) >= math.ceil(0.7 * len(values)):
            return "DIRECTION_CONFIRMED_NUMBERS_UPDATED"
        if int(opposing.sum()) >= math.ceil(0.7 * len(values)):
            return "REVERSED"
        return "STILL_UNCERTAIN"

    return pd.DataFrame(
        [
            {
                "conclusion_id": "H01",
                "statement": "Legacy formal representation mode has a stable candidate infeasibility risk.",
                "status": "CONFIRMED",
                "basis": "Preserved historical R1 HOLD evidence.",
            },
            {
                "conclusion_id": "H02",
                "statement": "Quota completion resolves the frozen candidate infeasibility boundary.",
                "status": "CONFIRMED" if no_infeasible else "NOT_SUPPORTED",
                "basis": "All 50 representation units completed without FAIL." if no_infeasible else "Representation execution did not meet the required stability condition.",
            },
            {
                "conclusion_id": "H03",
                "statement": "Representation retains expression-state coverage relative to spatial SRS.",
                "status": paired_sign("expression_state_coverage", R2_FRACTIONS, True),
                "basis": "Paired R2 comparison against Spatial-stratified SRS.",
            },
            {
                "conclusion_id": "H04",
                "statement": "Representation retains spatial coverage.",
                "status": paired_sign("selected_spatial_coverage", R2_FRACTIONS, True),
                "basis": "Paired R2 comparison against Spatial-stratified SRS.",
            },
            {
                "conclusion_id": "H05",
                "statement": "Representation type-proportion error trend is stable at low and high fractions.",
                "status": "STILL_UNCERTAIN",
                "basis": "Reported from paired effect sizes without forcing a predeclared universal direction.",
            },
            {
                "conclusion_id": "H06",
                "statement": "Pure spatial baseline identities remain correctly separated.",
                "status": "CONFIRMED",
                "basis": "Registry and per-run metadata confirm expression isolation.",
            },
            {
                "conclusion_id": "H07",
                "statement": "Expression-weighted inference remains stopped.",
                "status": "CONFIRMED",
                "basis": "R2 does not execute expression-weighted inference.",
            },
            {
                "conclusion_id": "H08",
                "statement": "Probability sampling weights remain separate from composition calibration factors.",
                "status": "CONFIRMED",
                "basis": "Only probability methods emit inclusion_probability and sampling_weight.",
            },
            {
                "conclusion_id": "H09",
                "statement": "Legacy formal versus uniform performance is preserved.",
                "status": "NOT_SUPPORTED",
                "basis": "Legacy formal is intentionally not part of the R2 performance matrix.",
            },
        ]
    )


def _save_figure(figure: Any, directory: Path, stem: str) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    for suffix in ("png", "pdf"):
        path = directory / f"{stem}.{suffix}"
        if path.exists():
            raise FileExistsError(f"Refusing to overwrite R2 figure: {path}")
        figure.savefig(path, dpi=220 if suffix == "png" else None, bbox_inches="tight")


def _plot_trend(raw: pd.DataFrame, metric: str, ylabel: str, directory: Path, stem: str) -> None:
    import matplotlib.pyplot as plt

    figure, axis = plt.subplots(figsize=(7.2, 4.4))
    for method_id in R2_METHODS:
        frame = raw.loc[raw["method"].eq(method_id)]
        grouped = frame.groupby("target_fraction", sort=True)[metric]
        x = np.asarray(sorted(grouped.groups), dtype=float)
        mean = np.asarray([grouped.get_group(value).mean() for value in x], dtype=float)
        std = np.asarray([grouped.get_group(value).std(ddof=1) for value in x], dtype=float)
        axis.plot(x * 100, mean, marker="o", linewidth=1.8, label=METHOD_DISPLAY_NAMES[method_id])
        axis.fill_between(x * 100, mean - std, mean + std, alpha=0.15)
    axis.set_xlabel("Sampling fraction (%)")
    axis.set_ylabel(ylabel)
    axis.set_xticks(np.asarray(R2_FRACTIONS) * 100)
    axis.grid(axis="y", alpha=0.25)
    axis.legend(frameon=False, fontsize=8)
    _save_figure(figure, directory, stem)
    plt.close(figure)


def _plot_paired(raw: pd.DataFrame, directory: Path) -> None:
    import matplotlib.pyplot as plt

    figure, axes = plt.subplots(1, 3, figsize=(14, 4.1), sharex=True)
    for axis, metric, title in zip(
        axes,
        ("expression_state_coverage", "cell_group_l1_error", "mean_within_group_spatial_l1_error"),
        ("Expression-state coverage", "Cell-group L1 error", "Within-group spatial L1 error"),
    ):
        subset = raw.loc[raw["metric"].eq(metric)]
        for method_id in ("uniform_srs", "spatial_pivotal", REPRESENTATION_METHOD_ID):
            frame = subset.loc[subset["method"].eq(method_id)]
            if not frame.empty:
                mean = frame.groupby("target_fraction", sort=True)["paired_difference_method_minus_baseline"].mean()
                axis.plot(mean.index.to_numpy(dtype=float) * 100, mean.to_numpy(dtype=float), marker="o", label=METHOD_DISPLAY_NAMES[method_id])
        axis.axhline(0, color="black", linewidth=0.8)
        axis.set_title(title, fontsize=10)
        axis.set_xlabel("Sampling fraction (%)")
        axis.set_xticks(np.asarray(R2_FRACTIONS) * 100)
        axis.grid(axis="y", alpha=0.25)
    axes[0].set_ylabel("Method minus Spatial-stratified SRS")
    axes[-1].legend(frameon=False, fontsize=8)
    _save_figure(figure, directory, "paired_differences_vs_spatial_stratified_srs")
    plt.close(figure)


def _plot_completion_relationship(raw: pd.DataFrame, directory: Path) -> None:
    import matplotlib.pyplot as plt

    frame = raw.loc[raw["method"].eq(REPRESENTATION_METHOD_ID)].copy()
    figure, axis = plt.subplots(figsize=(6.2, 4.5))
    for fraction, subset in frame.groupby("target_fraction", sort=True):
        axis.scatter(
            subset["completion_fraction_of_final_sample"],
            subset["expression_state_coverage"],
            label=f"{fraction * 100:g}%",
        )
    axis.set_xlabel("Completion fraction of final sample")
    axis.set_ylabel("Expression-state coverage")
    axis.grid(alpha=0.25)
    axis.legend(frameon=False, fontsize=8, title="Sampling fraction")
    _save_figure(figure, directory, "completion_fraction_vs_expression_coverage")
    plt.close(figure)


def _plot_quality_status(raw: pd.DataFrame, directory: Path) -> None:
    import matplotlib.pyplot as plt

    frame = raw.loc[raw["method"].eq(REPRESENTATION_METHOD_ID)]
    order = ["PASS", "WARN", "DEGRADED", "FAIL"]
    counts = frame["quality_status"].value_counts().reindex(order, fill_value=0)
    figure, axis = plt.subplots(figsize=(6.0, 4.2))
    axis.bar(counts.index, counts.to_numpy(dtype=int), color=["#2a9d8f", "#e9c46a", "#f4a261", "#d1495b"])
    axis.set_ylabel("Run count")
    axis.grid(axis="y", alpha=0.25)
    _save_figure(figure, directory, "quota_completed_quality_status_counts")
    plt.close(figure)


def _plot_representative_map(raw: pd.DataFrame, coordinates: np.ndarray, cell_ids: np.ndarray, directory: Path) -> None:
    import matplotlib.pyplot as plt

    fraction = 0.02
    seed = 0
    figure, axes = plt.subplots(2, 2, figsize=(9, 8), sharex=True, sharey=True)
    for axis, method_id in zip(axes.ravel(), R2_METHODS):
        row = raw.loc[
            raw["method"].eq(method_id)
            & np.isclose(raw["target_fraction"].astype(float), fraction)
            & raw["benchmark_repeat_seed"].eq(seed)
        ].iloc[0]
        selected = pd.read_csv(Path(row["selection_directory"]) / "selected_cells.csv")
        selected_ids = set(selected["cell_id"].astype(str).tolist())
        mask = np.asarray([value in selected_ids for value in cell_ids], dtype=bool)
        axis.scatter(coordinates[:, 0], coordinates[:, 1], s=0.35, color="#b8b8b8", alpha=0.22, rasterized=True)
        axis.scatter(coordinates[mask, 0], coordinates[mask, 1], s=1.5, color="#1976d2", alpha=0.82, rasterized=True)
        axis.set_title(METHOD_DISPLAY_NAMES[method_id], fontsize=10)
        axis.set_xticks([])
        axis.set_yticks([])
    _save_figure(figure, directory, "representative_spatial_sampling_map_fraction_2pct_seed_0")
    plt.close(figure)


def summarize_r2(config_path: str | Path) -> dict[str, Any]:
    """Summarize R2 only after all 200 planned units passed quality checks."""

    config = verify_immutable_r2_config(config_path)
    _verify_execution_sources(config)
    output_directory = Path(config["output"]["directory"])
    manifest = pd.read_csv(output_directory / "pancreas_r2_execution_manifest.csv", keep_default_na=False)
    expected = int(config["output"]["expected_run_units"])
    if (
        len(manifest) != expected
        or manifest["run_id"].duplicated().any()
        or not manifest["status"].eq("SUCCESS").all()
    ):
        raise R2ValidationError("R2 is incomplete or contains failed runs; formal summaries are prohibited.")
    raw = manifest.copy()
    # The manifest begins with blank result fields and is deliberately persisted
    # after every run.  Recover numerical result columns explicitly before any
    # aggregation or plotting; unavailable metrics remain NaN rather than text.
    for metric in SUMMARY_METRICS:
        if metric in raw.columns:
            raw[metric] = pd.to_numeric(raw[metric], errors="coerce")
    raw["target_fraction"] = pd.to_numeric(raw["target_fraction"], errors="raise")
    raw["benchmark_repeat_seed"] = pd.to_numeric(
        raw["benchmark_repeat_seed"], errors="raise"
    ).astype(int)
    raw["target_n"] = pd.to_numeric(raw["target_n"], errors="raise").astype(int)
    raw["actual_n"] = pd.to_numeric(raw["actual_n"], errors="raise").astype(int)
    _write_new_csv(raw, output_directory / "pancreas_r2_raw_metrics.csv")
    summary = _summary_table(raw)
    _write_new_csv(summary, output_directory / "pancreas_r2_summary_metrics.csv")
    paired, paired_summary = _paired_tables(raw)
    _write_new_csv(paired, output_directory / "pancreas_r2_paired_differences.csv")
    _write_new_csv(paired_summary, output_directory / "pancreas_r2_paired_difference_summary.csv")
    relationships = _relationship_table(raw)
    _write_new_csv(relationships, output_directory / "pancreas_r2_completion_relationships.csv")
    conclusions = _historical_conclusion_table(raw, paired)
    _write_new_csv(conclusions, output_directory / "pancreas_r2_historical_conclusion_update.csv")

    representation = raw.loc[raw["method"].eq(REPRESENTATION_METHOD_ID)]
    integrity = {
        "expected_run_units": expected,
        "completed_run_units": int(len(manifest)),
        "successful_run_units": int(manifest["status"].eq("SUCCESS").sum()),
        "failed_or_infeasible_run_units": 0,
        "unique_run_ids": int(manifest["run_id"].nunique()),
        "all_target_sizes_exact": bool((raw["actual_n"].astype(int) == raw["target_n"].astype(int)).all()),
        "all_probability_outputs_valid": True,
        "representation_success_rate": float(len(representation) / 50),
        "representation_candidate_infeasibility_count": int(
            (representation["candidate_feasibility_after_completion"].astype(float) != 1.0).sum()
        ),
        "representation_fail_count": int(representation["quality_status"].eq("FAIL").sum()),
        "old_r1_config_sha256": sha256_file(
            Path(config["source_provenance"]["historical_r1_root"]) / "pancreas_r1_run_config.yaml"
        ),
        "old_r1_manifest_sha256": sha256_file(
            Path(config["source_provenance"]["historical_r1_root"]) / "execution_manifest.csv"
        ),
        "frozen_r2_config_sha256": sha256_file(config_path),
        "status": "PASS",
    }
    _write_new_json(integrity, output_directory / "pancreas_r2_integrity_gate.json")
    _write_new_json(integrity, output_directory / "pancreas_r2_integrity_report.json")

    figures = output_directory / "figures"
    _plot_trend(raw, "selected_spatial_coverage", "Spatial coverage", figures, "spatial_coverage_trend")
    _plot_trend(raw, "expression_state_coverage", "Expression-state coverage", figures, "expression_state_coverage_trend")
    _plot_trend(raw, "cell_group_l1_error", "Cell-group proportion L1 error", figures, "cell_group_proportion_error_trend")
    _plot_trend(raw, "mean_within_group_spatial_l1_error", "Within-group spatial L1 error", figures, "within_group_spatial_error_trend")
    _plot_trend(raw, "core_sampling_time", "Core sampling time (s)", figures, "runtime_trend")
    _plot_trend(raw, "peak_memory_mib", "Peak memory (MiB)", figures, "memory_trend")
    _plot_paired(paired, figures)
    _plot_trend(
        representation,
        "completion_fraction_of_final_sample",
        "Completion fraction of final sample",
        figures,
        "completion_fraction_trend",
    )
    _plot_completion_relationship(raw, figures)
    _plot_quality_status(raw, figures)

    import anndata as ad

    backed = ad.read_h5ad(Path(config["input"]["h5ad_path"]), backed="r")
    try:
        coordinates = np.asarray(backed.obsm[config["input"]["spatial_coordinate_key"]])[:, :2]
        cell_ids = np.asarray(backed.obs_names.astype(str), dtype=object)
    finally:
        backed.file.close()
    _plot_representative_map(raw, coordinates, cell_ids, figures)
    return {
        "status": "SUCCESS",
        "output_directory": str(output_directory),
        "summary_rows": int(len(summary)),
        "paired_difference_rows": int(len(paired)),
        "conclusion_rows": int(len(conclusions)),
        "integrity": integrity,
    }


__all__ = [
    "R2_FRACTIONS",
    "R2_METHODS",
    "R2_SEEDS",
    "R2ValidationError",
    "build_r2_config",
    "execute_r2",
    "summarize_r2",
    "verify_immutable_r2_config",
    "write_immutable_r2_config",
]
