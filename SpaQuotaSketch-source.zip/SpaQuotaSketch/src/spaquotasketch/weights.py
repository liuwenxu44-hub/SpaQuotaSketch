"""Sampling weight helpers."""

from __future__ import annotations

from collections import Counter
from typing import Hashable


def compute_sampling_weights(
    selected_bin_ids: list[Hashable],
    original_bin_counts: dict[Hashable, int],
) -> list[float]:
    """Compute original_bin_size / selected_bin_size for each selected observation."""
    selected_counts = Counter(selected_bin_ids)
    weights: list[float] = []
    for bin_id in selected_bin_ids:
        selected_n = selected_counts[bin_id]
        original_n = original_bin_counts.get(bin_id, 0)
        weights.append(float(original_n / selected_n) if selected_n else 0.0)
    return weights


def weights_table(selected_ids: list[Hashable], selected_bin_ids: list[Hashable], weights: list[float]):
    """Build records for a weights CSV file."""
    if not (len(selected_ids) == len(selected_bin_ids) == len(weights)):
        raise ValueError("selected_ids, selected_bin_ids, and weights must have the same length.")
    return [
        {"cell_id": cell_id, "bin_id": bin_id, "sampling_weight": weight}
        for cell_id, bin_id, weight in zip(selected_ids, selected_bin_ids, weights)
    ]
