"""Preprocessing helpers for expression matrices and spatial coordinates."""

from __future__ import annotations

from typing import Any


def validate_spatial_anndata(adata: Any) -> None:
    """Check that an AnnData object contains expression values and spatial coordinates."""
    if not hasattr(adata, "X") or adata.X is None:
        raise ValueError("AnnData object must contain an expression matrix in .X.")
    if not hasattr(adata, "obsm") or "spatial" not in adata.obsm:
        raise ValueError("AnnData object must contain spatial coordinates in .obsm['spatial'].")
    spatial = adata.obsm["spatial"]
    if getattr(spatial, "shape", (0, 0))[1] < 2:
        raise ValueError("Spatial coordinates must have at least two columns.")


def get_spatial_coordinates(adata: Any):
    """Return two-dimensional spatial coordinates as a NumPy array."""
    import numpy as np

    validate_spatial_anndata(adata)
    coords = np.asarray(adata.obsm["spatial"])
    return coords[:, :2]


def compute_pca_embedding(adata: Any, n_components: int = 50, random_state: int = 0):
    """Compute an expression embedding suitable for downstream sampling."""
    import numpy as np
    from scipy import sparse
    from sklearn.decomposition import PCA, TruncatedSVD

    validate_spatial_anndata(adata)
    n_components = min(n_components, min(adata.X.shape) - 1)
    if n_components < 1:
        raise ValueError("At least two observations and two variables are required for PCA.")

    if sparse.issparse(adata.X):
        return TruncatedSVD(n_components=n_components, random_state=random_state).fit_transform(adata.X)

    values = np.asarray(adata.X)
    return PCA(n_components=n_components, random_state=random_state).fit_transform(values)


def compute_normalized_pca_embedding(
    adata: Any,
    n_components: int = 50,
    random_state: int = 0,
    target_sum: float = 10000.0,
):
    """Compatibility wrapper for the dense/sparse-consistent normalized SVD path."""
    return compute_normalized_log1p_svd_embedding(
        adata,
        n_components=n_components,
        random_state=random_state,
        target_sum=target_sum,
    )


def _library_size_log1p_matrix(adata: Any, *, target_sum: float):
    """Return a library-size-normalized and log1p-transformed matrix.

    The result is CSR for both dense and sparse inputs so that representation
    calculations do not change merely because an identical matrix is stored in
    a different container.
    """
    import numpy as np
    from scipy import sparse
    from sklearn.utils.sparsefuncs import inplace_row_scale

    validate_spatial_anndata(adata)
    if target_sum <= 0:
        raise ValueError("target_sum must be positive.")

    if sparse.issparse(adata.X):
        values = adata.X.astype(float).tocsr(copy=True)
        totals = np.asarray(values.sum(axis=1)).reshape(-1)
        factors = np.divide(
            target_sum,
            totals,
            out=np.zeros_like(totals, dtype=float),
            where=totals > 0,
        )
        inplace_row_scale(values, factors)
        np.log1p(values.data, out=values.data)
    else:
        values = np.asarray(adata.X, dtype=float).copy()
        totals = values.sum(axis=1)
        factors = np.divide(
            target_sum,
            totals,
            out=np.zeros_like(totals, dtype=float),
            where=totals > 0,
        )
        values *= factors[:, None]
        np.log1p(values, out=values)
        values = sparse.csr_matrix(values)

    return values


def _fit_normalized_log1p_svd(
    adata: Any,
    *,
    n_components: int,
    random_state: int,
    target_sum: float,
):
    """Fit one deterministic sparse-compatible truncated-SVD representation."""
    from sklearn.decomposition import TruncatedSVD

    values = _library_size_log1p_matrix(adata, target_sum=target_sum)
    n_components = min(int(n_components), min(values.shape) - 1)
    if n_components < 1:
        raise ValueError("At least two observations and two variables are required for SVD.")

    # ARPACK is deterministic for an unchanged matrix and works on CSR input.
    # This makes the dense/sparse agreement check a real software invariant.
    model = TruncatedSVD(
        n_components=n_components,
        algorithm="arpack",
        random_state=random_state,
    )
    embedding = model.fit_transform(values)
    return embedding, model


def normalized_log1p_expression_matrix(
    adata: Any,
    *,
    target_sum: float = 10000.0,
):
    """Return the storage-format-invariant normalized expression matrix.

    This public helper is used when a sensitivity analysis changes only the
    representation used to define sampling probabilities while retaining the
    same normalized population target for evaluation.
    """
    return _library_size_log1p_matrix(adata, target_sum=target_sum)


def compute_raw_count_svd_representation(
    adata: Any,
    n_components: int = 50,
    random_state: int = 0,
):
    """Return deterministic raw-count SVD artifacts for sensitivity analysis.

    This function intentionally does *not* endorse raw-count SVD as the
    default. It creates a dense/sparse-identical comparator by first coercing
    both input formats to CSR and then applying the same deterministic
    truncated-SVD route as the normalized primary analysis.
    """
    import numpy as np
    from scipy import sparse
    from sklearn.decomposition import TruncatedSVD

    validate_spatial_anndata(adata)
    values = sparse.csr_matrix(adata.X, dtype=float)
    n_components = min(int(n_components), min(values.shape) - 1)
    if n_components < 1:
        raise ValueError("At least two observations and two variables are required for SVD.")
    model = TruncatedSVD(
        n_components=n_components,
        algorithm="arpack",
        random_state=random_state,
    )
    embedding = model.fit_transform(values)
    singular_values = np.asarray(model.singular_values_, dtype=float)
    safe_values = np.where(singular_values > np.finfo(float).eps, singular_values, 1.0)
    basis = np.asarray(embedding, dtype=float) / safe_values[None, :]
    basis[:, singular_values <= np.finfo(float).eps] = 0.0
    return embedding, basis


def compute_normalized_log1p_svd_representation(
    adata: Any,
    n_components: int = 50,
    random_state: int = 0,
    target_sum: float = 10000.0,
):
    """Fit the post-V1 expression representation once and return its artifacts.

    Returns the PC-score-like embedding, the corresponding left singular-vector
    basis used for leverage-score sampling, and the normalized log1p CSR
    matrix used for expression-fidelity calculations.  Dense and sparse inputs
    enter the same CSR/SVD route.
    """
    import numpy as np

    values = _library_size_log1p_matrix(adata, target_sum=target_sum)
    n_components = min(int(n_components), min(values.shape) - 1)
    if n_components < 1:
        raise ValueError("At least two observations and two variables are required for SVD.")

    from sklearn.decomposition import TruncatedSVD

    model = TruncatedSVD(
        n_components=n_components,
        algorithm="arpack",
        random_state=random_state,
    )
    embedding = model.fit_transform(values)
    singular_values = np.asarray(model.singular_values_, dtype=float)
    safe_values = np.where(singular_values > np.finfo(float).eps, singular_values, 1.0)
    basis = np.asarray(embedding, dtype=float) / safe_values[None, :]
    basis[:, singular_values <= np.finfo(float).eps] = 0.0
    return embedding, basis, values


def compute_normalized_log1p_svd_embedding(
    adata: Any,
    n_components: int = 50,
    random_state: int = 0,
    target_sum: float = 10000.0,
):
    """Compute a storage-format-invariant log-normalized expression embedding.

    This is the required preprocessing path for post-V1 confirmation analyses.
    It deliberately does not replace ``compute_pca_embedding``, which is kept
    unchanged to reproduce the frozen legacy V1 results.
    """
    embedding, _, _ = compute_normalized_log1p_svd_representation(
        adata,
        n_components=n_components,
        random_state=random_state,
        target_sum=target_sum,
    )
    return embedding


def compute_normalized_log1p_svd_basis(
    adata: Any,
    n_components: int = 50,
    random_state: int = 0,
    target_sum: float = 10000.0,
):
    """Return the left singular-vector basis used by leverage-score baselines."""
    _, basis, _ = compute_normalized_log1p_svd_representation(
        adata,
        n_components=n_components,
        random_state=random_state,
        target_sum=target_sum,
    )
    return basis
