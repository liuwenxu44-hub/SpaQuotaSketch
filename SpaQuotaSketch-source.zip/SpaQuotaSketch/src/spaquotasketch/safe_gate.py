"""Frozen safety-gate selection for fixed spatial-quota pivotal sampling.

Equal-probability fixed-quota pivotal sampling is the safe default.  The
current final gate conditionally enables bounded score weighting only from
pilot evidence: score--target alignment, mean pilot benefit, and worst pilot
loss.  Effective sample size is retained as an advisory diagnostic, rather
than as a hard decision condition.

The earlier five-condition rule remains available as an explicit legacy
reference so historical analyses can be reproduced without changing their
decision logic.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import isfinite
from typing import Iterable


EQUAL_SAFE_DEFAULT = "equal_probability_fixed_quota"


@dataclass(frozen=True)
class SafeGateThresholds:
    """Frozen pilot thresholds shared by the final and legacy gate rules."""

    minimum_alignment: float = 0.20
    minimum_ess_fraction: float = 0.50
    minimum_mean_relative_benefit: float = 0.02
    minimum_endpoint_relative_benefit: float = 0.00
    maximum_single_pilot_relative_loss: float = 0.02

    def __post_init__(self) -> None:
        if not -1.0 <= float(self.minimum_alignment) <= 1.0:
            raise ValueError("minimum_alignment must be between -1 and 1.")
        if not 0.0 < float(self.minimum_ess_fraction) <= 1.0:
            raise ValueError("minimum_ess_fraction must be in (0, 1].")
        if float(self.minimum_mean_relative_benefit) < 0.0:
            raise ValueError("minimum_mean_relative_benefit must be non-negative.")
        if float(self.maximum_single_pilot_relative_loss) < 0.0:
            raise ValueError("maximum_single_pilot_relative_loss must be non-negative.")


@dataclass(frozen=True)
class GateSpecification:
    """Named, frozen definition of which pilot checks decide a selection."""

    identifier: str
    required_checks: tuple[str, ...]
    ess_role: str


FINAL_SIMPLIFIED_GATE = GateSpecification(
    identifier="final_simplified_three_condition_gate_v1",
    required_checks=("alignment", "mean_benefit", "pilot_loss"),
    ess_role="advisory_diagnostic",
)

LEGACY_FULL_FIVE_CONDITION_GATE = GateSpecification(
    identifier="legacy_full_five_condition_gate_v1",
    required_checks=("alignment", "ess", "mean_benefit", "endpoint_benefit", "pilot_loss"),
    ess_role="hard_gate",
)


@dataclass(frozen=True)
class WeightedCandidateEvidence:
    """Pilot-only evidence for one bounded score-weighting candidate."""

    method_id: str
    max_weight_inflation: float
    pilot_alignment: float
    minimum_pilot_ess_fraction: float
    mean_pilot_relative_benefit: float
    minimum_endpoint_mean_relative_benefit: float
    worst_single_pilot_relative_benefit: float

    def __post_init__(self) -> None:
        values = (
            self.max_weight_inflation,
            self.pilot_alignment,
            self.minimum_pilot_ess_fraction,
            self.mean_pilot_relative_benefit,
            self.minimum_endpoint_mean_relative_benefit,
            self.worst_single_pilot_relative_benefit,
        )
        if not all(isfinite(float(value)) for value in values):
            raise ValueError("candidate evidence values must be finite.")
        if float(self.max_weight_inflation) < 1.0:
            raise ValueError("max_weight_inflation must be at least one.")


@dataclass(frozen=True)
class SafeGateDecision:
    """Selected mode, pilot-only reason trail, and ESS diagnostic."""

    selected_method_id: str
    selected_max_weight_inflation: float | None
    weighted_enabled: bool
    reason: str
    evaluated_candidates: int
    gate_identifier: str
    selected_minimum_pilot_ess_fraction: float | None
    ess_is_advisory: bool


def _failed_checks(
    candidate: WeightedCandidateEvidence,
    thresholds: SafeGateThresholds,
    specification: GateSpecification,
) -> list[str]:
    """Return failures for the checks named by one frozen specification."""

    failed: list[str] = []
    if (
        "alignment" in specification.required_checks
        and candidate.pilot_alignment < thresholds.minimum_alignment
    ):
        failed.append("alignment")
    if (
        "ess" in specification.required_checks
        and candidate.minimum_pilot_ess_fraction < thresholds.minimum_ess_fraction
    ):
        failed.append("ess")
    if (
        "mean_benefit" in specification.required_checks
        and candidate.mean_pilot_relative_benefit < thresholds.minimum_mean_relative_benefit
    ):
        failed.append("mean_benefit")
    if (
        "endpoint_benefit" in specification.required_checks
        and candidate.minimum_endpoint_mean_relative_benefit
        < thresholds.minimum_endpoint_relative_benefit
    ):
        failed.append("endpoint_benefit")
    if (
        "pilot_loss" in specification.required_checks
        and candidate.worst_single_pilot_relative_benefit
        < -thresholds.maximum_single_pilot_relative_loss
    ):
        failed.append("pilot_loss")
    return failed


def _choose_with_specification(
    candidates: Iterable[WeightedCandidateEvidence],
    thresholds: SafeGateThresholds,
    specification: GateSpecification,
) -> SafeGateDecision:
    ordered = sorted(
        list(candidates), key=lambda value: float(value.max_weight_inflation), reverse=True
    )
    failures: list[str] = []
    for candidate in ordered:
        failed = _failed_checks(candidate, thresholds, specification)
        if not failed:
            return SafeGateDecision(
                selected_method_id=str(candidate.method_id),
                selected_max_weight_inflation=float(candidate.max_weight_inflation),
                weighted_enabled=True,
                reason="all_frozen_decision_checks_passed",
                evaluated_candidates=len(ordered),
                gate_identifier=specification.identifier,
                selected_minimum_pilot_ess_fraction=float(
                    candidate.minimum_pilot_ess_fraction
                ),
                ess_is_advisory=specification.ess_role == "advisory_diagnostic",
            )
        failures.append(
            f"r={float(candidate.max_weight_inflation):g}:" + ",".join(failed)
        )
    return SafeGateDecision(
        selected_method_id=EQUAL_SAFE_DEFAULT,
        selected_max_weight_inflation=None,
        weighted_enabled=False,
        reason="fallback_equal;" + ";".join(failures),
        evaluated_candidates=len(ordered),
        gate_identifier=specification.identifier,
        selected_minimum_pilot_ess_fraction=None,
        ess_is_advisory=specification.ess_role == "advisory_diagnostic",
    )


def choose_safe_mode(
    candidates: Iterable[WeightedCandidateEvidence],
    thresholds: SafeGateThresholds,
) -> SafeGateDecision:
    """Apply the final three-condition gate with r=4 then r=2 precedence.

    Candidate evidence is pilot-only.  The descending weight-cap order is a
    frozen operational precedence, not a claim that r=4 is intrinsically
    better than r=2.  Effective sample size is reported in the decision, but
    does not decide pass or fail.
    """

    return _choose_with_specification(candidates, thresholds, FINAL_SIMPLIFIED_GATE)


def choose_legacy_full_safe_mode(
    candidates: Iterable[WeightedCandidateEvidence],
    thresholds: SafeGateThresholds,
) -> SafeGateDecision:
    """Reproduce the earlier five-condition decision rule for legacy analyses."""

    return _choose_with_specification(
        candidates, thresholds, LEGACY_FULL_FIVE_CONDITION_GATE
    )


__all__ = [
    "EQUAL_SAFE_DEFAULT",
    "FINAL_SIMPLIFIED_GATE",
    "LEGACY_FULL_FIVE_CONDITION_GATE",
    "GateSpecification",
    "SafeGateDecision",
    "SafeGateThresholds",
    "WeightedCandidateEvidence",
    "choose_legacy_full_safe_mode",
    "choose_safe_mode",
]
