"""Storage-independent conversion of algorithm outputs into immutable artifacts."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

from .result_storage import PublishResult, SSHFSAppendOnlyBackend, StagedAttempt


@dataclass(frozen=True)
class ResultArtifact:
    """One algorithm output expressed without a storage-backend dependency."""

    relative_path: str
    content: bytes | str | Path


class AppendOnlyRunPublisher:
    """Stage algorithm artifacts locally and publish them through the selected backend."""

    def __init__(self, backend: SSHFSAppendOnlyBackend) -> None:
        self.backend = backend

    def begin(
        self,
        *,
        run_id: str,
        method_id: str,
        config_hash: str,
        code_commit: str,
    ) -> StagedAttempt:
        return self.backend.begin_attempt(
            run_id=run_id,
            method_id=method_id,
            config_hash=config_hash,
            code_commit=code_commit,
        )

    def stage(self, attempt: StagedAttempt, artifacts: Mapping[str, bytes | str | Path]) -> None:
        """Write arbitrary algorithm artifacts to local staging, never to the remote backend."""

        for relative_path, value in artifacts.items():
            if isinstance(value, Path):
                self.backend.stage_copy(attempt, relative_path, value)
            elif isinstance(value, bytes):
                self.backend.stage_bytes(attempt, relative_path, value)
            elif isinstance(value, str):
                self.backend.stage_text(attempt, relative_path, value)
            else:
                raise TypeError(f"Unsupported result artifact type for {relative_path}: {type(value).__name__}")

    def publish(self, attempt: StagedAttempt) -> PublishResult:
        self.backend.mark_running(attempt)
        return self.backend.publish(attempt)


__all__ = ["AppendOnlyRunPublisher", "ResultArtifact"]
