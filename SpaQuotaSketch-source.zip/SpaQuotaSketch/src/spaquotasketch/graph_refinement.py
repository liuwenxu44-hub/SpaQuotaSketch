"""Graph-guarded refinement for spatial transcriptomics sketches."""

from __future__ import annotations

from collections import Counter
from typing import Hashable, Mapping, Sequence

from .constrained_exchange import (
    finite_population_inclusion_probability,
    stratified_expression_intervals,
)
from .soft_balance import proportional_quotas


def shifted_rectangular_grid_bins(
    coords,
    n_x: int = 20,
    n_y: int = 20,
    shift_fraction: float = 0.5,
) -> list[str]:
    """Assign coordinates to a half-cell-shifted rectangular grid."""
    import numpy as np

    points = np.asarray(coords, dtype=float)
    if points.ndim != 2 or points.shape[1] < 2:
        raise ValueError("coords must be two-dimensional with at least two columns.")
    if n_x < 1 or n_y < 1:
        raise ValueError("n_x and n_y must be positive.")
    if not (0 <= shift_fraction < 1):
        raise ValueError("shift_fraction must be in [0, 1).")
    if not np.isfinite(points[:, :2]).all():
        raise ValueError("coords must not contain NaN or infinite values.")

    values = []
    for axis, n_bins in ((0, n_x), (1, n_y)):
        current = points[:, axis]
        lower = float(current.min())
        upper = float(current.max())
        width = (upper - lower) / n_bins if upper > lower else 1.0
        values.append(np.floor((current - lower) / width - shift_fraction).astype(int))
    return [f"{int(x)}_{int(y)}" for x, y in zip(values[0], values[1])]


def build_knn_indices(
    features,
    n_neighbors: int = 15,
    seed: int = 0,
    n_jobs: int = 4,
):
    """Build a high-dimensional approximate nearest-neighbor index."""
    import numpy as np

    values = np.asarray(features, dtype=np.float32)
    if values.ndim != 2:
        raise ValueError("features must be a two-dimensional array.")
    if values.shape[0] < 2:
        raise ValueError("At least two observations are required for a neighbor graph.")
    if n_neighbors < 1:
        raise ValueError("n_neighbors must be positive.")
    if n_jobs == 0 or n_jobs < -1:
        raise ValueError("n_jobs must be -1 or a positive integer.")
    n_neighbors = min(int(n_neighbors), values.shape[0])

    if values.shape[0] <= 2000:
        from sklearn.neighbors import NearestNeighbors

        model = NearestNeighbors(n_neighbors=n_neighbors, metric="euclidean", n_jobs=n_jobs)
        return model.fit(values).kneighbors(return_distance=False).astype(int)

    from pynndescent import NNDescent

    index = NNDescent(
        values,
        n_neighbors=n_neighbors,
        metric="euclidean",
        random_state=seed,
        n_jobs=n_jobs,
        low_memory=True,
    )
    indices, _ = index.neighbor_graph
    return np.asarray(indices, dtype=int)


def build_laplacian_spectrum(knn_indices, n_components: int = 31):
    """Return low normalized-Laplacian eigenpairs from a symmetrized kNN graph."""
    import numpy as np
    from scipy import sparse
    from scipy.sparse.linalg import eigsh

    neighbors = np.asarray(knn_indices, dtype=int)
    if neighbors.ndim != 2 or neighbors.shape[0] < 3:
        raise ValueError("knn_indices must contain at least three observations.")
    n_obs, n_neighbors = neighbors.shape
    if neighbors.size and (neighbors.min() < 0 or neighbors.max() >= n_obs):
        raise ValueError("knn_indices contains an invalid observation index.")
    n_components = min(int(n_components), n_obs - 1)
    if n_components < 3:
        raise ValueError("n_components must allow at least three eigenpairs.")

    rows = np.repeat(np.arange(n_obs, dtype=int), n_neighbors)
    columns = neighbors.reshape(-1)
    keep = rows != columns
    adjacency = sparse.csr_matrix(
        (
            np.ones(int(keep.sum()), dtype=np.float32),
            (rows[keep], columns[keep]),
        ),
        shape=(n_obs, n_obs),
    )
    adjacency.sum_duplicates()
    adjacency.data[:] = 1
    adjacency = adjacency.maximum(adjacency.T).tocsr()
    degree = np.asarray(adjacency.sum(axis=1)).reshape(-1)
    inverse_sqrt_degree = np.divide(
        1.0,
        np.sqrt(degree),
        out=np.zeros_like(degree, dtype=float),
        where=degree > 0,
    )
    normalized_adjacency = (
        sparse.diags(inverse_sqrt_degree)
        @ adjacency
        @ sparse.diags(inverse_sqrt_degree)
    )
    adjacency_values, eigenvectors = eigsh(
        normalized_adjacency,
        k=n_components,
        which="LA",
        tol=1e-3,
        maxiter=5000,
    )
    laplacian_values = 1.0 - adjacency_values
    order = np.argsort(laplacian_values)
    return (
        laplacian_values[order].astype(float),
        eigenvectors[:, order].astype(np.float32),
        degree.astype(np.float32),
    )


def local_geometry_features(features, knn_indices, chunk_size: int = 2_000):
    """Summarize unlabeled local density, centrality, and boundary-like displacement."""
    import numpy as np

    values = np.asarray(features, dtype=float)
    neighbors = np.asarray(knn_indices, dtype=int)
    if values.ndim != 2 or neighbors.ndim != 2 or values.shape[0] != neighbors.shape[0]:
        raise ValueError("features and knn_indices must have matching observation rows.")
    if chunk_size < 1:
        raise ValueError("chunk_size must be positive.")
    n_obs = values.shape[0]
    if neighbors.size and (neighbors.min() < 0 or neighbors.max() >= n_obs):
        raise ValueError("knn_indices contains an invalid observation index.")

    indegree = np.bincount(neighbors.reshape(-1), minlength=n_obs).astype(float)
    mean_neighbor_distance = np.zeros(n_obs, dtype=float)
    centroid_displacement = np.zeros(n_obs, dtype=float)
    for start in range(0, n_obs, chunk_size):
        stop = min(n_obs, start + chunk_size)
        points = values[start:stop]
        local_neighbors = neighbors[start:stop]
        nearby = values[local_neighbors]
        nonself = local_neighbors != np.arange(start, stop)[:, None]
        counts = nonself.sum(axis=1)
        distances = np.linalg.norm(nearby - points[:, None, :], axis=2)
        mean_neighbor_distance[start:stop] = np.divide(
            (distances * nonself).sum(axis=1),
            counts,
            out=np.zeros(stop - start, dtype=float),
            where=counts > 0,
        )
        neighbor_centroid = np.divide(
            (nearby * nonself[:, :, None]).sum(axis=1),
            counts[:, None],
            out=np.zeros_like(points),
            where=counts[:, None] > 0,
        )
        centroid_displacement[start:stop] = np.linalg.norm(
            points - neighbor_centroid,
            axis=1,
        )
    return np.column_stack(
        [
            np.log1p(mean_neighbor_distance),
            np.log1p(indegree),
            np.log1p(centroid_displacement),
        ]
    )


def graph_coverage(selected_indices: Sequence[int], knn_indices) -> float:
    """Return the fraction of observations represented by a selected closed neighbor."""
    import numpy as np

    neighbors = np.asarray(knn_indices, dtype=int)
    n_obs = neighbors.shape[0]
    selected = np.zeros(n_obs, dtype=bool)
    selected[np.asarray(selected_indices, dtype=int)] = True
    represented = selected | np.any(selected[neighbors], axis=1)
    return float(represented.mean()) if n_obs else 0.0


def select_spectral_rank(laplacian_eigenvalues, minimum_rank: int = 2) -> int:
    """Select the low-frequency graph rank at the largest observed eigengap."""
    import numpy as np

    values = np.asarray(laplacian_eigenvalues, dtype=float).reshape(-1)
    if minimum_rank < 2:
        raise ValueError("minimum_rank must be at least 2.")
    if values.size < minimum_rank + 1:
        raise ValueError("At least minimum_rank + 1 eigenvalues are required.")
    if not np.isfinite(values).all() or np.any(np.diff(values) < -1e-10):
        raise ValueError("Laplacian eigenvalues must be finite and nondecreasing.")
    gaps = np.diff(values)
    eligible = gaps[minimum_rank - 1 :]
    return int(np.argmax(eligible) + minimum_rank)


def rank_adaptive_spectral_probabilities(
    spatial_bin_ids: Sequence[Hashable],
    target_n: int,
    spectral_basis,
):
    """Mix uniform and leverage probabilities using one graph-rank draw per mode."""
    import numpy as np

    basis = np.asarray(spectral_basis, dtype=float)
    n_obs = len(spatial_bin_ids)
    if basis.ndim != 2 or basis.shape[0] != n_obs or basis.shape[1] < 2:
        raise ValueError("spectral_basis must have one row per observation and two columns.")
    if not np.isfinite(basis).all():
        raise ValueError("spectral_basis must contain finite values.")
    target_n = min(max(int(target_n), 0), n_obs)
    quotas = proportional_quotas(list(spatial_bin_ids), target_n)
    labels = list(dict.fromkeys(spatial_bin_ids))
    leverage = np.sum(basis * basis, axis=1)
    probabilities = np.zeros(n_obs, dtype=float)
    expected_spectral_draws = 0.0
    n_uniform_fallback_bins = 0
    alpha_by_bin: dict[str, float] = {}
    indices_by_label: dict[Hashable, list[int]] = {label: [] for label in labels}
    for index, label in enumerate(spatial_bin_ids):
        indices_by_label[label].append(index)

    for label in labels:
        indices = np.asarray(indices_by_label[label], dtype=int)
        quota = int(quotas.get(label, 0))
        if indices.size == 0 or quota <= 0:
            continue
        alpha = min(1.0, basis.shape[1] / quota)
        local_leverage = leverage[indices]
        if float(local_leverage.sum()) > 0:
            leverage_probability = local_leverage / local_leverage.sum()
        else:
            leverage_probability = np.full(indices.size, 1.0 / indices.size)
            n_uniform_fallback_bins += 1
        uniform_probability = np.full(indices.size, 1.0 / indices.size)
        probabilities[indices] = (
            (1.0 - alpha) * uniform_probability
            + alpha * leverage_probability
        )
        expected_spectral_draws += alpha * quota
        alpha_by_bin[str(label)] = float(alpha)

    report = {
        "spectral_rank": int(basis.shape[1]),
        "expected_spectral_draws": float(expected_spectral_draws),
        "expected_spectral_fraction": float(
            expected_spectral_draws / target_n if target_n else 0.0
        ),
        "n_uniform_fallback_bins": int(n_uniform_fallback_bins),
        "minimum_bin_mixture": float(min(alpha_by_bin.values(), default=0.0)),
        "maximum_bin_mixture": float(max(alpha_by_bin.values(), default=0.0)),
    }
    return probabilities, report


def spectral_community_labels(spectral_basis, n_communities: int, seed: int = 0):
    """Cluster row-normalized low-frequency graph coordinates without labels."""
    import numpy as np
    from sklearn.cluster import KMeans

    basis = np.asarray(spectral_basis, dtype=float)
    if basis.ndim != 2 or basis.shape[0] < 2 or basis.shape[1] < 2:
        raise ValueError("spectral_basis must be a two-dimensional matrix.")
    if not np.isfinite(basis).all():
        raise ValueError("spectral_basis must contain finite values.")
    if not (2 <= n_communities <= basis.shape[0]):
        raise ValueError("n_communities must be between 2 and the row count.")
    informative = basis[:, 1:] if basis.shape[1] > 2 else basis
    norms = np.linalg.norm(informative, axis=1)
    normalized = np.divide(
        informative,
        norms[:, None],
        out=np.zeros_like(informative),
        where=norms[:, None] > 0,
    )
    return KMeans(
        n_clusters=int(n_communities),
        random_state=seed,
        n_init=10,
    ).fit_predict(normalized).astype(int)


def _encode(values: Sequence[Hashable]) -> tuple[list[Hashable], object]:
    import numpy as np

    labels = list(dict.fromkeys(values))
    lookup = {label: code for code, label in enumerate(labels)}
    return labels, np.asarray([lookup[value] for value in values], dtype=int)


def _stratified_auxiliary_stats(spatial_codes, indices_by_spatial, quotas, auxiliary):
    import numpy as np

    target = np.zeros(auxiliary.shape[1], dtype=float)
    variance = np.zeros(auxiliary.shape[1], dtype=float)
    for spatial_code, indices in enumerate(indices_by_spatial):
        quota = int(quotas[spatial_code])
        population_size = int(indices.size)
        if quota <= 0 or population_size <= 0:
            continue
        local = auxiliary[indices]
        target += quota * local.mean(axis=0)
        if population_size > 1:
            variance += (
                quota
                * (population_size - quota)
                / (population_size - 1)
                * local.var(axis=0)
            )
    inverse_variance = np.zeros_like(variance)
    active = variance > np.finfo(float).eps
    inverse_variance[active] = 1.0 / variance[active]
    return target, inverse_variance, int(active.sum())


def _design_weighted_gene_mean_error(
    matrix,
    selected_mask,
    spatial_codes,
    spatial_sizes,
    quotas,
    reference_mean,
) -> float:
    import numpy as np
    from scipy import sparse

    indices = np.flatnonzero(selected_mask)
    weights_by_spatial = np.divide(
        spatial_sizes,
        quotas,
        out=np.zeros_like(spatial_sizes, dtype=float),
        where=quotas > 0,
    )
    weights = weights_by_spatial[spatial_codes[indices]]
    total = float(weights.sum())
    if sparse.issparse(matrix):
        observed = np.asarray(matrix[indices].T.dot(weights) / total).reshape(-1)
    else:
        observed = np.average(np.asarray(matrix)[indices], axis=0, weights=weights)
    scale = float(np.mean(np.abs(reference_mean))) + 1e-12
    return float(np.mean(np.abs(observed - reference_mean)) / scale)


def graph_guarded_refine_sample(
    initial_selected_indices: Sequence[int],
    spatial_bin_ids: list[Hashable],
    expression_bin_ids: list[Hashable],
    features,
    knn_indices,
    secondary_spatial_bin_ids: Mapping[str, Sequence[Hashable]] | None = None,
    gene_matrix=None,
    confidence_level: float = 0.95,
    covariance_variance_fraction: float = 0.90,
    minimum_covariance_components: int = 10,
    gene_guard_mode: str = "resolution",
    graph_objective: str = "coverage",
    spectral_basis=None,
    seed: int = 0,
) -> tuple[list[int], dict[str, object]]:
    """Refine V6 using a guarded graph coverage or graph spectrum objective."""
    import numpy as np
    from scipy import sparse

    values = np.asarray(features, dtype=float)
    neighbors = np.asarray(knn_indices, dtype=int)
    n_obs = len(spatial_bin_ids)
    if len(expression_bin_ids) != n_obs or values.shape[0] != n_obs:
        raise ValueError("All observation-level inputs must have the same row count.")
    if values.ndim != 2 or not np.isfinite(values).all():
        raise ValueError("features must be a finite two-dimensional array.")
    if neighbors.ndim != 2 or neighbors.shape[0] != n_obs:
        raise ValueError("knn_indices must have one row per observation.")
    if neighbors.size and (neighbors.min() < 0 or neighbors.max() >= n_obs):
        raise ValueError("knn_indices contains an invalid observation index.")
    if not (0 < confidence_level < 1):
        raise ValueError("confidence_level must be in (0, 1).")
    if not (0 < covariance_variance_fraction <= 1):
        raise ValueError("covariance_variance_fraction must be in (0, 1].")
    if minimum_covariance_components < 2:
        raise ValueError("minimum_covariance_components must be at least 2.")
    if gene_guard_mode not in {"strict", "resolution", "report_only"}:
        raise ValueError("gene_guard_mode must be strict, resolution, or report_only.")
    if graph_objective not in {"coverage", "spectral"}:
        raise ValueError("graph_objective must be coverage or spectral.")
    basis = None if spectral_basis is None else np.asarray(spectral_basis, dtype=float)
    if graph_objective == "spectral":
        if basis is None or basis.ndim != 2 or basis.shape[0] != n_obs:
            raise ValueError("spectral_basis must have one row per observation.")
        if basis.shape[1] < 2 or not np.isfinite(basis).all():
            raise ValueError("spectral_basis must contain at least two finite columns.")
    if gene_matrix is not None and gene_matrix.shape[0] != n_obs:
        raise ValueError("gene_matrix must have one row per observation.")

    selected_mask = np.zeros(n_obs, dtype=bool)
    selected_mask[np.asarray(initial_selected_indices, dtype=int)] = True
    target_n = int(selected_mask.sum())
    if target_n == 0:
        return [], {"n_selected": 0, "n_graph_exchanges": 0}

    spatial_labels, spatial_codes = _encode(spatial_bin_ids)
    expression_labels, expression_codes = _encode(expression_bin_ids)
    n_spatial = len(spatial_labels)
    n_expression = len(expression_labels)
    indices_by_spatial = [np.flatnonzero(spatial_codes == code) for code in range(n_spatial)]
    spatial_sizes = np.asarray([indices.size for indices in indices_by_spatial], dtype=int)
    quotas = np.bincount(spatial_codes[selected_mask], minlength=n_spatial).astype(int)
    quota_by_label = {label: int(quotas[code]) for code, label in enumerate(spatial_labels)}

    selected_by_spatial = [
        np.flatnonzero(selected_mask & (spatial_codes == code)).astype(int).tolist()
        for code in range(n_spatial)
    ]
    expression_counts = np.bincount(
        expression_codes[selected_mask], minlength=n_expression
    ).astype(int)
    pair_population_counts = np.zeros((n_spatial, n_expression), dtype=int)
    pair_selected_counts = np.zeros((n_spatial, n_expression), dtype=int)
    np.add.at(pair_population_counts, (spatial_codes, expression_codes), 1)
    np.add.at(
        pair_selected_counts,
        (spatial_codes[selected_mask], expression_codes[selected_mask]),
        1,
    )

    intervals = stratified_expression_intervals(
        spatial_bin_ids,
        expression_bin_ids,
        quota_by_label,
        confidence_level=confidence_level,
    )
    expected_counts = np.asarray(
        [float(intervals[label]["expected_count"]) for label in expression_labels]
    )
    count_variance = np.asarray(
        [float(intervals[label]["variance"]) for label in expression_labels]
    )
    lower_bounds = np.asarray(
        [int(intervals[label]["lower_bound"]) for label in expression_labels]
    )
    upper_bounds = np.asarray(
        [int(intervals[label]["upper_bound"]) for label in expression_labels]
    )
    count_inverse_variance = np.zeros(n_expression, dtype=float)
    active_count = count_variance > np.finfo(float).eps
    count_inverse_variance[active_count] = 1.0 / count_variance[active_count]

    local_detectable = np.zeros((n_spatial, n_expression), dtype=bool)
    for spatial_code in range(n_spatial):
        for expression_code in np.flatnonzero(pair_population_counts[spatial_code] > 0):
            probability = finite_population_inclusion_probability(
                int(spatial_sizes[spatial_code]),
                int(pair_population_counts[spatial_code, expression_code]),
                int(quotas[spatial_code]),
            )
            local_detectable[spatial_code, expression_code] = probability >= confidence_level

    feature_mean = values.mean(axis=0)
    feature_scale = values.std(axis=0)
    feature_scale[feature_scale <= np.finfo(float).eps] = 1.0
    standardized = (values - feature_mean) / feature_scale
    auxiliary = np.concatenate([standardized, standardized * standardized], axis=1)
    auxiliary_target, auxiliary_inverse_variance, n_aux_terms = _stratified_auxiliary_stats(
        spatial_codes,
        indices_by_spatial,
        quotas,
        auxiliary,
    )
    auxiliary_sum = auxiliary[selected_mask].sum(axis=0)
    n_balance_terms = max(1, int(active_count.sum() + n_aux_terms))

    def balance_numerator() -> float:
        expression_residual = expression_counts - expected_counts
        auxiliary_residual = auxiliary_sum - auxiliary_target
        return float(
            np.dot(expression_residual * expression_residual, count_inverse_variance)
            + np.dot(auxiliary_residual * auxiliary_residual, auxiliary_inverse_variance)
        )

    current_balance_numerator = balance_numerator()
    baseline_balance_numerator = float(current_balance_numerator)

    explained = values.var(axis=0)
    cumulative = np.cumsum(explained) / max(float(explained.sum()), np.finfo(float).eps)
    covariance_components = int(np.searchsorted(cumulative, covariance_variance_fraction) + 1)
    covariance_components = min(
        max(int(minimum_covariance_components), covariance_components),
        values.shape[1],
    )
    covariance_values = standardized[:, :covariance_components]
    covariance_target = np.zeros((covariance_components, covariance_components), dtype=float)
    for spatial_code, indices in enumerate(indices_by_spatial):
        if quotas[spatial_code] <= 0:
            continue
        local = covariance_values[indices]
        covariance_target += quotas[spatial_code] * (local.T @ local) / len(indices)
    covariance_sum = covariance_values[selected_mask].T @ covariance_values[selected_mask]
    covariance_residual = covariance_sum - covariance_target
    current_covariance_numerator = float(np.sum(covariance_residual * covariance_residual))
    baseline_covariance_numerator = float(current_covariance_numerator)

    secondary_states: list[dict[str, object]] = []
    for name, labels in (secondary_spatial_bin_ids or {}).items():
        if len(labels) != n_obs:
            raise ValueError(f"Secondary spatial scale {name!r} has the wrong length.")
        category_labels, category_codes = _encode(list(labels))
        category_intervals = stratified_expression_intervals(
            spatial_bin_ids,
            list(labels),
            quota_by_label,
            confidence_level=confidence_level,
        )
        selected_counts = np.bincount(
            category_codes[selected_mask], minlength=len(category_labels)
        ).astype(int)
        lower = np.asarray(
            [int(category_intervals[label]["lower_bound"]) for label in category_labels]
        )
        upper = np.asarray(
            [int(category_intervals[label]["upper_bound"]) for label in category_labels]
        )
        variance = np.asarray(
            [float(category_intervals[label]["variance"]) for label in category_labels]
        )
        scale = np.maximum(1.0, np.sqrt(variance))

        def slack_value(counts=selected_counts, low=lower, high=upper, denom=scale):
            violation = np.maximum(0, low - counts) + np.maximum(0, counts - high)
            return float(np.sum((violation / denom) ** 2))

        secondary_states.append(
            {
                "name": str(name),
                "labels": category_labels,
                "codes": category_codes,
                "counts": selected_counts,
                "lower": lower,
                "upper": upper,
                "scale": scale,
                "slack": slack_value(),
                "baseline_slack": slack_value(),
                "initial_coverage": int(np.sum(selected_counts > 0)),
            }
        )

    rows = np.repeat(np.arange(n_obs, dtype=int), neighbors.shape[1] + 1)
    columns = np.concatenate(
        [np.arange(n_obs, dtype=int)[:, None], neighbors], axis=1
    ).reshape(-1)
    adjacency = sparse.csr_matrix(
        (np.ones(rows.size, dtype=np.int8), (rows, columns)),
        shape=(n_obs, n_obs),
    )
    adjacency.sum_duplicates()
    adjacency.data[:] = 1
    reverse_adjacency = adjacency.tocsc()
    graph_counts = np.asarray(adjacency.dot(selected_mask.astype(np.int16))).reshape(-1)
    initial_graph_coverage_count = int(np.sum(graph_counts > 0))
    design_weights_by_spatial = np.divide(
        spatial_sizes,
        quotas,
        out=np.zeros_like(spatial_sizes, dtype=float),
        where=quotas > 0,
    )

    spectral_target = None
    spectral_residual = None
    initial_spectral_loss = None
    current_spectral_loss = None
    if graph_objective == "spectral":
        spectral_target = basis.T @ basis
        spectral_selected = np.flatnonzero(selected_mask)
        spectral_weights = design_weights_by_spatial[spatial_codes[spectral_selected]]
        spectral_matrix = (basis[spectral_selected].T * spectral_weights) @ basis[
            spectral_selected
        ]
        spectral_residual = spectral_matrix - spectral_target
        initial_spectral_loss = float(np.sum(spectral_residual * spectral_residual))
        current_spectral_loss = float(initial_spectral_loss)

    def reverse_neighbors(index: int):
        start = reverse_adjacency.indptr[index]
        end = reverse_adjacency.indptr[index + 1]
        return reverse_adjacency.indices[start:end]

    def graph_delta(incoming: int, outgoing: int) -> int:
        incoming_reverse = reverse_neighbors(incoming)
        outgoing_reverse = reverse_neighbors(outgoing)
        affected = np.unique(np.concatenate([incoming_reverse, outgoing_reverse]))
        changes = np.zeros(affected.size, dtype=int)
        changes[np.searchsorted(affected, incoming_reverse)] += 1
        changes[np.searchsorted(affected, outgoing_reverse)] -= 1
        before = graph_counts[affected] > 0
        after = graph_counts[affected] + changes > 0
        return int(after.sum() - before.sum())

    def spectral_loss_delta(incoming: int, outgoing: int) -> float:
        spatial_code = int(spatial_codes[incoming])
        design_weight = float(design_weights_by_spatial[spatial_code])
        delta_matrix = design_weight * (
            np.outer(basis[incoming], basis[incoming])
            - np.outer(basis[outgoing], basis[outgoing])
        )
        return float(
            2.0 * np.sum(spectral_residual * delta_matrix)
            + np.sum(delta_matrix * delta_matrix)
        )

    def expression_balance_delta(in_code: int, out_code: int) -> float:
        if in_code == out_code:
            return 0.0
        delta = 0.0
        for code, change in ((in_code, 1), (out_code, -1)):
            residual = expression_counts[code] - expected_counts[code]
            delta += ((residual + change) ** 2 - residual**2) * count_inverse_variance[code]
        return float(delta)

    def auxiliary_balance_delta(incoming: int, outgoing: int) -> float:
        difference = auxiliary[incoming] - auxiliary[outgoing]
        residual = auxiliary_sum - auxiliary_target
        return float(
            2.0 * np.dot(difference * auxiliary_inverse_variance, residual)
            + np.dot(difference * difference, auxiliary_inverse_variance)
        )

    def covariance_delta(incoming: int, outgoing: int) -> float:
        incoming_value = covariance_values[incoming]
        outgoing_value = covariance_values[outgoing]
        linear = 2.0 * (
            incoming_value @ covariance_residual @ incoming_value
            - outgoing_value @ covariance_residual @ outgoing_value
        )
        quadratic = (
            float(np.dot(incoming_value, incoming_value)) ** 2
            + float(np.dot(outgoing_value, outgoing_value)) ** 2
            - 2.0 * float(np.dot(incoming_value, outgoing_value)) ** 2
        )
        return float(linear + quadratic)

    def secondary_deltas(incoming: int, outgoing: int):
        deltas = []
        for state in secondary_states:
            codes = state["codes"]
            in_code = int(codes[incoming])
            out_code = int(codes[outgoing])
            if in_code == out_code:
                deltas.append(0.0)
                continue
            counts = state["counts"]
            lower = state["lower"]
            upper = state["upper"]
            scale = state["scale"]
            if counts[out_code] <= 1:
                return None
            current = 0.0
            next_value = 0.0
            for code, change in ((in_code, 1), (out_code, -1)):
                violation = max(0, lower[code] - counts[code]) + max(
                    0, counts[code] - upper[code]
                )
                changed_count = counts[code] + change
                changed_violation = max(0, lower[code] - changed_count) + max(
                    0, changed_count - upper[code]
                )
                current += (violation / scale[code]) ** 2
                next_value += (changed_violation / scale[code]) ** 2
            delta = float(next_value - current)
            if float(state["slack"]) + delta > float(state["baseline_slack"]) + 1e-12:
                return None
            deltas.append(delta)
        return deltas

    def apply_swap(
        incoming: int,
        outgoing: int,
        objective_delta_value: float,
        balance_delta_value: float,
        covariance_delta_value: float,
        scale_deltas,
    ) -> None:
        nonlocal auxiliary_sum, covariance_residual
        nonlocal current_balance_numerator, current_covariance_numerator
        nonlocal spectral_residual, current_spectral_loss
        spatial_code = int(spatial_codes[incoming])
        in_code = int(expression_codes[incoming])
        out_code = int(expression_codes[outgoing])
        selected_mask[incoming] = True
        selected_mask[outgoing] = False
        position = selected_by_spatial[spatial_code].index(outgoing)
        selected_by_spatial[spatial_code][position] = incoming
        expression_counts[in_code] += 1
        expression_counts[out_code] -= 1
        pair_selected_counts[spatial_code, in_code] += 1
        pair_selected_counts[spatial_code, out_code] -= 1
        auxiliary_sum = auxiliary_sum + auxiliary[incoming] - auxiliary[outgoing]
        current_balance_numerator += balance_delta_value
        incoming_covariance = covariance_values[incoming]
        outgoing_covariance = covariance_values[outgoing]
        covariance_residual = (
            covariance_residual
            + np.outer(incoming_covariance, incoming_covariance)
            - np.outer(outgoing_covariance, outgoing_covariance)
        )
        current_covariance_numerator += covariance_delta_value
        for state, delta in zip(secondary_states, scale_deltas):
            codes = state["codes"]
            state["counts"][int(codes[incoming])] += 1
            state["counts"][int(codes[outgoing])] -= 1
            state["slack"] = float(state["slack"]) + float(delta)
        incoming_reverse = reverse_neighbors(incoming)
        outgoing_reverse = reverse_neighbors(outgoing)
        graph_counts[incoming_reverse] += 1
        graph_counts[outgoing_reverse] -= 1
        if graph_objective == "spectral":
            design_weight = float(design_weights_by_spatial[spatial_code])
            spectral_residual = spectral_residual + design_weight * (
                np.outer(basis[incoming], basis[incoming])
                - np.outer(basis[outgoing], basis[outgoing])
            )
            current_spectral_loss += float(objective_delta_value)

    reference_gene_mean = None
    initial_gene_mean_error = None
    current_gene_mean_error = None
    current_gene_weighted_sum = None
    gene_total_weight = None
    gene_guard_relative_tolerance = 1.0 / np.sqrt(target_n)
    if gene_matrix is not None:
        reference_gene_mean = np.asarray(gene_matrix.mean(axis=0)).reshape(-1)
        initial_gene_mean_error = _design_weighted_gene_mean_error(
            gene_matrix,
            selected_mask,
            spatial_codes,
            spatial_sizes,
            quotas,
            reference_gene_mean,
        )
        selected_indices = np.flatnonzero(selected_mask)
        selected_weights = design_weights_by_spatial[spatial_codes[selected_indices]]
        gene_total_weight = float(selected_weights.sum())
        if sparse.issparse(gene_matrix):
            current_gene_weighted_sum = np.asarray(
                gene_matrix[selected_indices].T.dot(selected_weights)
            ).reshape(-1)
        else:
            current_gene_weighted_sum = (
                np.asarray(gene_matrix)[selected_indices] * selected_weights[:, None]
            ).sum(axis=0)
        current_gene_mean_error = float(initial_gene_mean_error)

    def gene_row(index: int):
        if sparse.issparse(gene_matrix):
            return np.asarray(
                gene_matrix.getrow(index).toarray(), dtype=float
            ).reshape(-1)
        return np.asarray(gene_matrix[index], dtype=float).reshape(-1)

    rng = np.random.default_rng(seed)
    tie_break = rng.random(n_obs)
    accepted_swaps: list[tuple[int, int]] = []
    n_passes = 0
    n_gene_guard_rejections = 0
    n_incoming_candidates = 0
    n_incoming_evaluated = 0
    n_incoming_pruned_by_upper_bound = 0
    n_exchange_pairs_evaluated = 0
    graph_coverage_resolution = 1.0 / np.sqrt(n_obs)
    spectral_loss_resolution = 1.0 / np.sqrt(n_obs)
    pass_summaries: list[dict[str, object]] = []
    stopped_reason = "no_legal_improvement"

    while True:
        n_pass_swaps = 0
        n_passes += 1
        graph_coverage_before_pass = int(np.sum(graph_counts > 0))
        spectral_loss_before_pass = current_spectral_loss
        for spatial_code, indices in enumerate(indices_by_spatial):
            incoming_candidates = indices[~selected_mask[indices]]
            if incoming_candidates.size == 0:
                continue
            if graph_objective == "coverage":
                potential = np.asarray(
                    [
                        np.sum(graph_counts[reverse_neighbors(int(index))] == 0)
                        for index in incoming_candidates
                    ]
                )
                incoming_candidates = incoming_candidates[potential > 0]
                potential = potential[potential > 0]
                if incoming_candidates.size == 0:
                    continue
                order = np.lexsort((tie_break[incoming_candidates], -potential))
            else:
                potential = np.full(incoming_candidates.size, np.inf)
                order = np.argsort(tie_break[incoming_candidates], kind="stable")
            incoming_candidates = incoming_candidates[order]
            potential = potential[order]
            n_incoming_candidates += int(incoming_candidates.size)

            candidate_options = []
            best_graph_gain_for_bin = 0
            for candidate_position, (incoming, potential_upper_bound) in enumerate(
                zip(incoming_candidates, potential)
            ):
                # Adding this cell cannot cover more previously uncovered graph
                # rows than potential_upper_bound. The candidates are sorted by
                # that bound, so the remaining search can be pruned exactly.
                if (
                    graph_objective == "coverage"
                    and
                    gene_guard_mode == "report_only"
                    and best_graph_gain_for_bin > int(potential_upper_bound)
                ):
                    n_incoming_pruned_by_upper_bound += int(
                        incoming_candidates.size - candidate_position
                    )
                    break
                n_incoming_evaluated += 1
                in_code = int(expression_codes[incoming])
                incoming_best = None
                for outgoing in tuple(selected_by_spatial[spatial_code]):
                    n_exchange_pairs_evaluated += 1
                    out_code = int(expression_codes[outgoing])
                    if in_code != out_code:
                        if expression_counts[in_code] + 1 > upper_bounds[in_code]:
                            continue
                        if expression_counts[out_code] - 1 < lower_bounds[out_code]:
                            continue
                        if expression_counts[out_code] <= 1:
                            continue
                        if local_detectable[spatial_code, out_code] and pair_selected_counts[
                            spatial_code, out_code
                        ] <= 1:
                            continue

                    scale_deltas = secondary_deltas(int(incoming), int(outgoing))
                    if scale_deltas is None:
                        continue
                    if graph_objective == "coverage":
                        graph_gain = graph_delta(int(incoming), int(outgoing))
                        if graph_gain <= 0:
                            continue
                        objective_delta_value = -float(graph_gain)
                    else:
                        objective_delta_value = spectral_loss_delta(
                            int(incoming), int(outgoing)
                        )
                        spectral_tolerance = 1e-12 * max(
                            1.0, float(current_spectral_loss)
                        )
                        if objective_delta_value >= -spectral_tolerance:
                            continue
                    balance_delta_value = expression_balance_delta(
                        in_code, out_code
                    ) + auxiliary_balance_delta(int(incoming), int(outgoing))
                    next_balance = current_balance_numerator + balance_delta_value
                    balance_tolerance = 1e-10 * max(1.0, baseline_balance_numerator)
                    if next_balance > baseline_balance_numerator + balance_tolerance:
                        continue
                    covariance_delta_value = covariance_delta(int(incoming), int(outgoing))
                    next_covariance = current_covariance_numerator + covariance_delta_value
                    covariance_tolerance = 1e-10 * max(1.0, baseline_covariance_numerator)
                    if next_covariance > baseline_covariance_numerator + covariance_tolerance:
                        continue
                    key = (
                        float(objective_delta_value),
                        float(next_balance / n_balance_terms),
                        float(next_covariance),
                        float(tie_break[incoming]),
                        int(incoming),
                        int(outgoing),
                    )
                    if incoming_best is None or key < incoming_best[0]:
                        incoming_best = (
                            key,
                            int(incoming),
                            int(outgoing),
                            float(objective_delta_value),
                            float(balance_delta_value),
                            float(covariance_delta_value),
                            list(scale_deltas),
                        )
                if incoming_best is not None:
                    if gene_guard_mode == "report_only":
                        if not candidate_options or incoming_best[0] < candidate_options[0][0]:
                            candidate_options = [incoming_best]
                            if graph_objective == "coverage":
                                best_graph_gain_for_bin = int(-incoming_best[0][0])
                    else:
                        candidate_options.append(incoming_best)

            candidate_options.sort(key=lambda option: option[0])
            accepted_option = None
            accepted_gene_sum = None
            accepted_gene_error = None
            for option in candidate_options:
                (
                    _,
                    incoming,
                    outgoing,
                    objective_delta_value,
                    balance_delta_value,
                    covariance_delta_value,
                    scale_deltas,
                ) = option
                next_gene_sum = None
                next_gene_error = None
                if gene_matrix is not None:
                    design_weight = design_weights_by_spatial[spatial_code]
                    next_gene_sum = current_gene_weighted_sum + design_weight * (
                        gene_row(incoming) - gene_row(outgoing)
                    )
                    next_gene_mean = next_gene_sum / gene_total_weight
                    gene_scale = float(np.mean(np.abs(reference_gene_mean))) + 1e-12
                    next_gene_error = float(
                        np.mean(np.abs(next_gene_mean - reference_gene_mean)) / gene_scale
                    )
                    if gene_guard_mode == "strict":
                        gene_guard_limit = float(initial_gene_mean_error)
                    else:
                        gene_guard_limit = float(initial_gene_mean_error) * (
                            1.0 + gene_guard_relative_tolerance
                        )
                    tolerance = 1e-12 * max(1.0, gene_guard_limit)
                    if (
                        gene_guard_mode != "report_only"
                        and next_gene_error > gene_guard_limit + tolerance
                    ):
                        n_gene_guard_rejections += 1
                        continue
                accepted_option = option
                accepted_gene_sum = next_gene_sum
                accepted_gene_error = next_gene_error
                break

            if accepted_option is not None:
                (
                    _,
                    incoming,
                    outgoing,
                    objective_delta_value,
                    balance_delta_value,
                    covariance_delta_value,
                    scale_deltas,
                ) = accepted_option
                apply_swap(
                    incoming,
                    outgoing,
                    objective_delta_value,
                    balance_delta_value,
                    covariance_delta_value,
                    scale_deltas,
                )
                if gene_matrix is not None:
                    current_gene_weighted_sum = accepted_gene_sum
                    current_gene_mean_error = accepted_gene_error
                n_pass_swaps += 1
                accepted_swaps.append((incoming, outgoing))

        graph_coverage_after_pass = int(np.sum(graph_counts > 0))
        if graph_objective == "coverage":
            pass_gain = graph_coverage_after_pass - graph_coverage_before_pass
            pass_gain_fraction = pass_gain / n_obs
            pass_summary = {
                "pass": int(n_passes),
                "n_swaps": int(n_pass_swaps),
                "graph_coverage_gain_count": int(pass_gain),
                "graph_coverage_gain_fraction": float(pass_gain_fraction),
            }
            gain_below_resolution = pass_gain_fraction < graph_coverage_resolution
        else:
            pass_gain = float(spectral_loss_before_pass - current_spectral_loss)
            pass_gain_fraction = pass_gain / max(
                float(initial_spectral_loss), np.finfo(float).eps
            )
            pass_summary = {
                "pass": int(n_passes),
                "n_swaps": int(n_pass_swaps),
                "spectral_loss_reduction": float(pass_gain),
                "spectral_relative_reduction": float(pass_gain_fraction),
            }
            gain_below_resolution = pass_gain_fraction < spectral_loss_resolution
        pass_summaries.append(pass_summary)
        if n_pass_swaps == 0:
            stopped_reason = "no_legal_improvement"
            break
        if gain_below_resolution:
            stopped_reason = "gain_below_statistical_resolution"
            break

    selected = np.flatnonzero(selected_mask).astype(int).tolist()
    final_gene_mean_error = current_gene_mean_error
    final_graph_coverage_count = int(np.sum(graph_counts > 0))
    report = {
        "n_selected": len(selected),
        "n_neighbors": int(neighbors.shape[1]),
        "n_graph_exchanges": len(accepted_swaps),
        "n_optimization_passes": int(n_passes),
        "n_incoming_candidates": int(n_incoming_candidates),
        "n_incoming_evaluated": int(n_incoming_evaluated),
        "n_incoming_pruned_by_upper_bound": int(n_incoming_pruned_by_upper_bound),
        "n_exchange_pairs_evaluated": int(n_exchange_pairs_evaluated),
        "n_gene_guard_rejections": int(n_gene_guard_rejections),
        "graph_objective": str(graph_objective),
        "graph_coverage_resolution": float(graph_coverage_resolution),
        "spectral_loss_resolution": float(spectral_loss_resolution),
        "spectral_rank": None if basis is None else int(basis.shape[1]),
        "initial_spectral_loss": initial_spectral_loss,
        "final_spectral_loss": current_spectral_loss,
        "stopped_reason": str(stopped_reason),
        "pass_summaries": pass_summaries,
        "initial_graph_coverage": float(initial_graph_coverage_count / n_obs),
        "final_graph_coverage": float(final_graph_coverage_count / n_obs),
        "graph_coverage_gain": float(
            (final_graph_coverage_count - initial_graph_coverage_count) / n_obs
        ),
        "initial_balance_loss": float(baseline_balance_numerator / n_balance_terms),
        "final_balance_loss": float(current_balance_numerator / n_balance_terms),
        "covariance_components": int(covariance_components),
        "covariance_variance_fraction": float(covariance_variance_fraction),
        "minimum_covariance_components": int(minimum_covariance_components),
        "initial_covariance_loss": float(baseline_covariance_numerator),
        "final_covariance_loss": float(current_covariance_numerator),
        "initial_design_weighted_gene_mean_error": initial_gene_mean_error,
        "final_design_weighted_gene_mean_error": final_gene_mean_error,
        "gene_guard_relative_tolerance": float(gene_guard_relative_tolerance),
        "gene_guard_mode": str(gene_guard_mode),
        "gene_guard_error_limit": (
            None
            if initial_gene_mean_error is None
            else float(initial_gene_mean_error) * (1.0 + gene_guard_relative_tolerance)
        ),
        "expression_state_coverage": float(np.sum(expression_counts > 0) / n_expression),
        "n_expression_bins_below_bound": int(np.sum(expression_counts < lower_bounds)),
        "n_expression_bins_above_bound": int(np.sum(expression_counts > upper_bounds)),
        "secondary_spatial_scales": {
            str(state["name"]): {
                "n_bins": len(state["labels"]),
                "initial_coverage": int(state["initial_coverage"]),
                "final_coverage": int(np.sum(state["counts"] > 0)),
                "initial_slack_loss": float(state["baseline_slack"]),
                "final_slack_loss": float(state["slack"]),
            }
            for state in secondary_states
        },
        "objective_order": [
            "preserve exact fine-grid spatial quotas",
            "preserve expression confidence bounds and coverage",
            "preserve detectable local expression states",
            "do not worsen multiscale spatial slack or coverage",
            "do not exceed V6 moment and covariance guardrails",
            (
                "strictly reduce weighted graph spectral information loss"
                if graph_objective == "spectral"
                else "strictly increase high-dimensional neighbor coverage"
            ),
            "keep design-weighted gene mean error within its statistical guard",
        ],
    }
    return selected, report


__all__ = [
    "build_knn_indices",
    "build_laplacian_spectrum",
    "local_geometry_features",
    "graph_coverage",
    "graph_guarded_refine_sample",
    "rank_adaptive_spectral_probabilities",
    "select_spectral_rank",
    "spectral_community_labels",
    "shifted_rectangular_grid_bins",
]
