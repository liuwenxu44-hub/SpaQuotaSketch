"""Synthetic end-to-end validation for append-only SSHFS result persistence."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from .result_persistence import AppendOnlyRunPublisher
from .result_storage import (
    ChecksumMismatchError,
    EventWriteError,
    OperationAudit,
    PublishError,
    SSHFSAppendOnlyBackend,
    StorageConfig,
)


@dataclass
class FailOnce:
    """Test-only deterministic fault injector for one named storage operation."""

    operation: str
    occurrence: int = 1
    calls: int = 0

    def __call__(self, operation: str) -> None:
        if operation != self.operation:
            return
        self.calls += 1
        if self.calls == self.occurrence:
            raise OSError(f"synthetic interruption at {operation}")


def _publish_small_result(
    publisher: AppendOnlyRunPublisher,
    *,
    run_id: str,
    config_hash: str,
    code_commit: str,
    value: int,
):
    attempt = publisher.begin(
        run_id=run_id,
        method_id="synthetic_storage_validation",
        config_hash=config_hash,
        code_commit=code_commit,
    )
    publisher.stage(
        attempt,
        {
            "result.json": (
                "{\n"
                f'  "run_id": "{run_id}",\n'
                f'  "value": {value}\n'
                "}\n"
            ),
            "metrics/summary.txt": f"synthetic metric {value}\n",
        },
    )
    return attempt, publisher.publish(attempt)


def run_synthetic_sshfs_validation(
    config: StorageConfig,
    *,
    config_hash: str,
    code_commit: str,
    sequential_run_count: int = 20,
) -> dict[str, Any]:
    """Run required storage scenarios using only small synthetic result files."""

    if config.backend != "sshfs_append_only":
        raise ValueError("Synthetic SSHFS validation requires backend=sshfs_append_only")
    audit = OperationAudit()
    backend = SSHFSAppendOnlyBackend(config, audit=audit)
    publisher = AppendOnlyRunPublisher(backend)

    successful_run_ids: list[str] = []
    for value in range(sequential_run_count):
        run_id = f"synthetic_run_{value:02d}"
        _, result = _publish_small_result(
            publisher,
            run_id=run_id,
            config_hash=config_hash,
            code_commit=code_commit,
            value=value,
        )
        if result.status != "SUCCESS" or not backend.has_verified_success(run_id):
            raise AssertionError(f"Verified publish failed for {run_id}")
        successful_run_ids.append(run_id)

    reference_attempt = backend.begin_attempt(
        run_id="existing_checksum_case",
        method_id="synthetic_storage_validation",
        config_hash=config_hash,
        code_commit=code_commit,
    )
    reference_source = backend.stage_text(reference_attempt, "reference.txt", "same bytes\n")
    reference_destination = config.remote_results_root / "existing_checksum_case" / "reference.txt"
    first_copy = backend.copy_verified_file(reference_source, reference_destination)
    repeated_copy = backend.copy_verified_file(reference_source, reference_destination)
    mismatch_source = backend.stage_text(reference_attempt, "different.txt", "different bytes\n")
    mismatch_rejected = False
    try:
        backend.copy_verified_file(mismatch_source, reference_destination)
    except ChecksumMismatchError:
        mismatch_rejected = True
    if first_copy != "copied_verified" or repeated_copy != "already_present_verified" or not mismatch_rejected:
        raise AssertionError("Existing-file checksum handling is incorrect")

    copy_fault = FailOnce("copy", occurrence=2)
    failed_copy_backend = SSHFSAppendOnlyBackend(
        config,
        audit=audit,
        fault_injector=copy_fault,
    )
    failed_copy_publisher = AppendOnlyRunPublisher(failed_copy_backend)
    failed_attempt = failed_copy_publisher.begin(
        run_id="copy_interrupted",
        method_id="synthetic_storage_validation",
        config_hash=config_hash,
        code_commit=code_commit,
    )
    failed_copy_publisher.stage(
        failed_attempt,
        {"result.json": "{\"copy\": 1}\n", "metrics/summary.txt": "copy fault\n"},
    )
    copy_failure_observed = False
    try:
        failed_copy_publisher.publish(failed_attempt)
    except PublishError:
        copy_failure_observed = True
    if not copy_failure_observed or (failed_attempt.remote_directory / "_SUCCESS.json").exists():
        raise AssertionError("Interrupted copy was incorrectly finalized")
    retry_attempt = failed_copy_backend.retry_from_staging(failed_attempt)
    retry_result = AppendOnlyRunPublisher(failed_copy_backend).publish(retry_attempt)
    if retry_attempt.attempt_id <= failed_attempt.attempt_id or retry_result.status != "SUCCESS":
        raise AssertionError("Retry did not create a new verified attempt")
    successful_run_ids.append("copy_interrupted")

    event_fault = FailOnce("event:SUCCESS")
    event_failure_backend = SSHFSAppendOnlyBackend(
        config,
        audit=audit,
        fault_injector=event_fault,
    )
    event_failure_publisher = AppendOnlyRunPublisher(event_failure_backend)
    event_attempt = event_failure_publisher.begin(
        run_id="event_interrupted",
        method_id="synthetic_storage_validation",
        config_hash=config_hash,
        code_commit=code_commit,
    )
    event_failure_publisher.stage(event_attempt, {"result.json": "{\"event\": 1}\n"})
    event_failure_observed = False
    try:
        event_failure_publisher.publish(event_attempt)
    except EventWriteError:
        event_failure_observed = True
    recovered_after_event_failure = SSHFSAppendOnlyBackend(config, audit=audit).replay_events()
    event_is_not_success = recovered_after_event_failure["event_interrupted"]["status"] != "SUCCESS"
    if not event_failure_observed or not event_is_not_success:
        raise AssertionError("Interrupted event write was incorrectly counted as success")

    interrupted_backend = SSHFSAppendOnlyBackend(config, audit=audit)
    interrupted_attempt = interrupted_backend.begin_attempt(
        run_id="running_interrupted",
        method_id="synthetic_storage_validation",
        config_hash=config_hash,
        code_commit=code_commit,
    )
    interrupted_backend.stage_text(interrupted_attempt, "result.json", "not published\n")
    interrupted_backend.mark_running(interrupted_attempt)
    recovered = SSHFSAppendOnlyBackend(config, audit=audit).replay_events()
    if recovered["running_interrupted"]["status"] != "INTERRUPTED":
        raise AssertionError("RUNNING attempt was not recovered as interrupted")

    snapshot, snapshot_checksum, state = SSHFSAppendOnlyBackend(config, audit=audit).rebuild_snapshot()
    if not snapshot.is_file() or not snapshot_checksum.is_file():
        raise AssertionError("Snapshot reconstruction did not produce immutable files")
    if not all(SSHFSAppendOnlyBackend(config, audit=audit).has_verified_success(run_id) for run_id in successful_run_ids):
        raise AssertionError("A successful run lacks a valid marker or success event")

    if audit.os_replace_calls != 0 or audit.directory_rename_calls != 0:
        raise AssertionError("SSHFS validation used a forbidden replacement or directory rename")
    if audit.cross_filesystem_move_calls != 0 or audit.target_file_overwrite_calls != 0:
        raise AssertionError("Copy/mismatch audit counters are inconsistent")
    if audit.overwrite_refusals < 1:
        raise AssertionError("Existing-file mismatch was not recorded as a refused overwrite")
    if audit.verified_file_copies < sequential_run_count * 2:
        raise AssertionError("Not every synthetic result file received post-copy verification")
    remote_event_count = len(list((config.remote_results_root / "events").glob("*.json")))
    expected_remote_event_count = sequential_run_count * 3 + 12
    if remote_event_count != expected_remote_event_count:
        raise AssertionError(
            f"Unexpected event count: expected {expected_remote_event_count}, got {remote_event_count}"
        )

    return {
        "status": "PASS",
        "sequential_run_count": sequential_run_count,
        "successful_run_ids": successful_run_ids,
        "retry_attempt_ids": {
            "copy_interrupted_first": failed_attempt.attempt_id,
            "copy_interrupted_retry": retry_attempt.attempt_id,
        },
        "copy_failure_observed": copy_failure_observed,
        "event_failure_observed": event_failure_observed,
        "event_failure_not_success": event_is_not_success,
        "running_recovery_status": recovered["running_interrupted"]["status"],
        "snapshot": str(snapshot),
        "snapshot_checksum": str(snapshot_checksum),
        "remote_event_count": remote_event_count,
        "expected_remote_event_count": expected_remote_event_count,
        "replayed_state": state,
        "operation_audit": audit.as_dict(),
        "remote_results_root": str(config.remote_results_root),
        "local_staging_root": str(config.local_staging_root),
    }


__all__ = ["FailOnce", "run_synthetic_sshfs_validation"]
