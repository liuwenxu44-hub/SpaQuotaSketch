"""Quota-completed representation sampling with a frozen legacy candidate stage.

This module implements only the preregistered representation mode. It never
changes the legacy formal representation workflow and it does not provide
probability-sampling weights or design-based inference.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
import hashlib
import math
from typing import Any, Hashable, Mapping, Sequence

import numpy as np
import pandas as pd

from ..core_workflow import bin_ids_for_indices, build_candidates_until_quota_feasible
from ..preprocess import compute_pca_embedding
from ..quota_sampling import sample_by_quota
from ..spatial_bins import rectangular_grid_bins


METHOD_ID = "quota_completed_representation_mode"
ALGORITHM_VERSION = "quota_completed_representation_v1"
CANDIDATE_FRACTION_PER_SEED = 0.05
MAXIMUM_INTERNAL_SEED_BUDGET = 20
EXPRESSION_GRID_N_X = 10
EXPRESSION_GRID_N_Y = 10
PRIMARY_COMPLETION_STRATEGY = "quota_completion_expression_stratified"
FALLBACK_COMPLETION_STRATEGY = "quota_completion_srs_fallback"


class QuotaCompletedRepresentationFailure(RuntimeError):
    """An explicit preregistered failure rather than a silently relaxed sample."""

    def __init__(self, status: str, message: str, diagnostics: Mapping[str, Any] | None = None):
        super().__init__(message)
        self.status = str(status)
        self.diagnostics = dict(diagnostics or {})


@dataclass(frozen=True)
class CompletionResult:
    """Candidate-pool completion outputs before final quota sampling."""

    completed_candidate_indices: list[int]
    candidate_source_by_index: dict[int, str]
    stratum_diagnostics: pd.DataFrame
    global_diagnostics: dict[str, Any]


@dataclass(frozen=True)
class QuotaCompletedRepresentationResult:
    """Outputs of the preregistered representation-mode draw."""

    selected_indices: np.ndarray
    completed_candidate_indices: np.ndarray
    selected_cells: pd.DataFrame
    candidate_cells: pd.DataFrame
    stratum_diagnostics: pd.DataFrame
    global_diagnostics: dict[str, Any]
    metadata: dict[str, Any]


def _normalise_labels(values: Sequence[Hashable], name: str) -> np.ndarray:
    labels = np.asarray([str(value) for value in values], dtype=object)
    if labels.ndim != 1 or labels.size == 0:
        raise ValueError(f"{name} must be a non-empty one-dimensional sequence.")
    if any(value.strip().lower() in {"", "nan", "none", "na"} for value in labels.tolist()):
        raise ValueError(f"{name} must not contain missing labels.")
    return labels


def _normalise_quotas(
    spatial_strata: np.ndarray,
    quotas: Mapping[Hashable, int],
    target_n: int,
) -> dict[str, int]:
    counts = Counter(spatial_strata.tolist())
    normalised = {str(key): int(value) for key, value in quotas.items()}
    if set(normalised) != set(counts):
        missing = sorted(set(counts) - set(normalised))
        extra = sorted(set(normalised) - set(counts))
        raise QuotaCompletedRepresentationFailure(
            "infeasible_positive_quota_budget",
            "Every nonempty spatial stratum must have one positive frozen quota.",
            {"missing_quota_strata": missing, "extra_quota_strata": extra},
        )
    if any(value < 1 for value in normalised.values()):
        raise QuotaCompletedRepresentationFailure(
            "infeasible_positive_quota_budget",
            "The preregistered representation mode requires positive spatial quotas.",
            {"quotas": normalised},
        )
    if int(target_n) != sum(normalised.values()):
        raise QuotaCompletedRepresentationFailure(
            "infeasible_positive_quota_budget",
            "The frozen spatial quotas must sum exactly to target_n.",
            {"target_n": int(target_n), "quota_sum": int(sum(normalised.values()))},
        )
    if int(target_n) < len(counts):
        raise QuotaCompletedRepresentationFailure(
            "infeasible_positive_quota_budget",
            "target_n is smaller than the number of positive spatial strata.",
            {"target_n": int(target_n), "positive_strata": int(len(counts))},
        )
    too_large = {
        stratum: {"q_g": int(normalised[stratum]), "N_g": int(count)}
        for stratum, count in counts.items()
        if int(normalised[stratum]) > int(count)
    }
    if too_large:
        raise QuotaCompletedRepresentationFailure(
            "infeasible_positive_quota_budget",
            "A spatial quota exceeds the original number of cells in that stratum.",
            {"invalid_strata": too_large},
        )
    return normalised


def frozen_expression_strata(expression_embedding: Any) -> np.ndarray:
    """Build the exact global 10 x 10 expression strata used by legacy formal R1."""
    embedding = np.asarray(expression_embedding, dtype=float)
    if embedding.ndim != 2 or embedding.shape[1] < 2:
        raise ValueError("The frozen expression embedding requires at least two dimensions.")
    if embedding.shape[0] < 1 or not np.isfinite(embedding).all():
        raise ValueError("The frozen expression embedding must be finite and non-empty.")
    return np.asarray(
        rectangular_grid_bins(
            embedding[:, :2],
            n_x=EXPRESSION_GRID_N_X,
            n_y=EXPRESSION_GRID_N_Y,
        ),
        dtype=object,
    )


def candidate_pool_seed_set(benchmark_repeat_seed: int) -> list[int]:
    """Return the frozen disjoint 20-seed candidate schedule for one repeat."""
    repeat = int(benchmark_repeat_seed)
    if repeat < 0:
        raise ValueError("benchmark_repeat_seed must be non-negative.")
    start = repeat * MAXIMUM_INTERNAL_SEED_BUDGET
    return list(range(start, start + MAXIMUM_INTERNAL_SEED_BUDGET))


def derive_completion_seed(
    dataset_id: str,
    target_fraction: float,
    benchmark_repeat_seed: int,
    spatial_stratum: Hashable,
    algorithm_version: str = ALGORITHM_VERSION,
) -> int:
    """Derive the preregistered deterministic seed for one spatial-stratum completion."""
    if not str(dataset_id).strip():
        raise ValueError("dataset_id must be non-empty.")
    fraction = float(target_fraction)
    if not np.isfinite(fraction) or not 0 < fraction <= 1:
        raise ValueError("target_fraction must lie in (0, 1].")
    payload = (
        f"{dataset_id}|{fraction:.6f}|{int(benchmark_repeat_seed)}|"
        f"{str(spatial_stratum)}|{algorithm_version}"
    )
    digest = hashlib.sha256(payload.encode("utf-8")).digest()
    return int.from_bytes(digest[:8], byteorder="big", signed=False) % (2**32)


def _derive_expression_subseed(completion_seed: int, expression_stratum: Hashable) -> int:
    payload = f"{int(completion_seed)}|{str(expression_stratum)}|{ALGORITHM_VERSION}"
    digest = hashlib.sha256(payload.encode("utf-8")).digest()
    return int.from_bytes(digest[:8], byteorder="big", signed=False) % (2**32)


def _validate_indices(indices: Sequence[int], n_cells: int, name: str) -> list[int]:
    values = [int(value) for value in indices]
    if len(set(values)) != len(values):
        raise ValueError(f"{name} must not contain duplicate indices.")
    if any(value < 0 or value >= int(n_cells) for value in values):
        raise ValueError(f"{name} contains an index outside the population.")
    return values


def _expression_completion_allocation(
    remaining_indices: Sequence[int],
    expression_strata: Sequence[Hashable] | None,
    deficit: int,
) -> dict[str, int]:
    """Allocate a deficit proportionally by bounded largest remainder."""
    if expression_strata is None:
        raise ValueError("Expression strata are unavailable.")
    labels = _normalise_labels(expression_strata, "expression_strata")
    if len(labels) <= max(remaining_indices, default=-1):
        raise ValueError("Expression strata do not cover every remaining cell.")
    groups: dict[str, list[int]] = defaultdict(list)
    for index in remaining_indices:
        groups[str(labels[int(index)])].append(int(index))
    if not groups:
        raise ValueError("No nonempty expression stratum is available.")
    total_remaining = len(remaining_indices)
    ideal = {
        stratum: float(deficit) * len(indices) / total_remaining
        for stratum, indices in groups.items()
    }
    quotas = {
        stratum: min(len(groups[stratum]), int(math.floor(value)))
        for stratum, value in ideal.items()
    }
    remaining_quota = int(deficit) - sum(quotas.values())
    order = sorted(
        groups,
        key=lambda stratum: (-(ideal[stratum] - math.floor(ideal[stratum])), str(stratum)),
    )
    for stratum in order:
        if remaining_quota == 0:
            break
        if quotas[stratum] < len(groups[stratum]):
            quotas[stratum] += 1
            remaining_quota -= 1
    if remaining_quota != 0:
        raise ValueError("Bounded largest-remainder allocation could not fill the deficit.")
    return quotas


def _complete_one_stratum(
    *,
    remaining_indices: Sequence[int],
    expression_strata: Sequence[Hashable] | None,
    deficit: int,
    completion_seed: int,
) -> tuple[list[int], str, str | None]:
    """Complete one deficient spatial stratum with the registered fallback."""
    remaining = [int(value) for value in remaining_indices]
    if len(remaining) < int(deficit):
        raise QuotaCompletedRepresentationFailure(
            "insufficient_remaining_cells_for_strict_quota_completion",
            "The same spatial stratum has fewer remaining cells than its candidate deficit.",
            {"remaining_cells": len(remaining), "deficit_g": int(deficit)},
        )
    if int(deficit) == 0:
        return [], "not_required", None
    try:
        allocation = _expression_completion_allocation(remaining, expression_strata, int(deficit))
        labels = _normalise_labels(expression_strata, "expression_strata")
        selected: list[int] = []
        for stratum in sorted(allocation):
            quota = int(allocation[stratum])
            if quota == 0:
                continue
            positions = [index for index in remaining if str(labels[index]) == stratum]
            rng = np.random.default_rng(_derive_expression_subseed(completion_seed, stratum))
            selected.extend(int(value) for value in rng.choice(positions, size=quota, replace=False).tolist())
        if len(selected) != int(deficit) or len(set(selected)) != len(selected):
            raise ValueError("Expression-stratified completion did not produce the requested unique count.")
        return selected, PRIMARY_COMPLETION_STRATEGY, None
    except QuotaCompletedRepresentationFailure:
        raise
    except (TypeError, ValueError, IndexError) as error:
        rng = np.random.default_rng(int(completion_seed))
        selected = [int(value) for value in rng.choice(remaining, size=int(deficit), replace=False).tolist()]
        return selected, FALLBACK_COMPLETION_STRATEGY, f"{type(error).__name__}: {error}"


def complete_candidate_deficits(
    *,
    candidate_indices: Sequence[int],
    cell_ids: Sequence[Hashable],
    spatial_strata: Sequence[Hashable],
    quotas: Mapping[Hashable, int],
    expression_strata: Sequence[Hashable] | None,
    dataset_id: str,
    target_fraction: float,
    benchmark_repeat_seed: int,
    target_n: int,
) -> CompletionResult:
    """Add only exact within-stratum candidate deficits required by frozen quotas."""
    ids = [str(value) for value in cell_ids]
    if len(ids) == 0 or len(set(ids)) != len(ids):
        raise ValueError("cell_ids must be non-empty and unique.")
    spatial = _normalise_labels(spatial_strata, "spatial_strata")
    if len(spatial) != len(ids):
        raise ValueError("spatial_strata must have one entry per cell_id.")
    frozen_quotas = _normalise_quotas(spatial, quotas, int(target_n))
    original_candidates = _validate_indices(candidate_indices, len(ids), "candidate_indices")
    candidate_set = set(original_candidates)
    candidate_sources = {index: "expression_candidate" for index in original_candidates}
    counts = Counter(spatial.tolist())
    positive_strata = sorted(frozen_quotas)
    diagnostic_rows: list[dict[str, Any]] = []
    additions: list[int] = []
    before_feasible = 0
    total_deficit = 0
    maximum_deficit = 0
    fallback_strata_count = 0

    for stratum in positive_strata:
        population_indices = np.flatnonzero(spatial == stratum).astype(int).tolist()
        before = sum(index in candidate_set for index in population_indices)
        quota = int(frozen_quotas[stratum])
        deficit = max(quota - before, 0)
        if deficit == 0:
            before_feasible += 1
        total_deficit += deficit
        maximum_deficit = max(maximum_deficit, deficit)
        completion_seed = derive_completion_seed(
            dataset_id,
            target_fraction,
            int(benchmark_repeat_seed),
            stratum,
        )
        strategy_used = "not_required"
        fallback_reason: str | None = None
        added: list[int] = []
        if deficit:
            remaining = [index for index in population_indices if index not in candidate_set]
            added, strategy_used, fallback_reason = _complete_one_stratum(
                remaining_indices=remaining,
                expression_strata=expression_strata,
                deficit=deficit,
                completion_seed=completion_seed,
            )
            source = (
                PRIMARY_COMPLETION_STRATEGY
                if strategy_used == PRIMARY_COMPLETION_STRATEGY
                else FALLBACK_COMPLETION_STRATEGY
            )
            for index in added:
                candidate_set.add(index)
                candidate_sources[index] = source
            additions.extend(added)
            if strategy_used == FALLBACK_COMPLETION_STRATEGY:
                fallback_strata_count += 1
        after = before + len(added)
        if after < quota:
            raise QuotaCompletedRepresentationFailure(
                "post_completion_quota_violation",
                "Candidate completion did not satisfy a positive spatial quota.",
                {"stratum_id": stratum, "C_g_after": int(after), "q_g": quota},
            )
        diagnostic_rows.append(
            {
                "stratum_id": stratum,
                "N_g": int(counts[stratum]),
                "q_g": quota,
                "C_g_before": int(before),
                "deficit_g": int(deficit),
                "completion_added": int(len(added)),
                "C_g_after": int(after),
                "completion_fraction_within_stratum": float(len(added) / after) if after else 0.0,
                "completion_strategy_requested": PRIMARY_COMPLETION_STRATEGY,
                "completion_strategy_used": strategy_used,
                "completion_strategy": strategy_used,
                "fallback_reason": fallback_reason,
                "fallback_cell_count": int(len(added)) if strategy_used == FALLBACK_COMPLETION_STRATEGY else 0,
                "completion_seed": int(completion_seed),
            }
        )

    completed = original_candidates + additions
    if len(completed) != len(set(completed)):
        raise QuotaCompletedRepresentationFailure(
            "candidate_provenance_violation",
            "Candidate completion produced a duplicate cell.",
        )
    if len(additions) != int(total_deficit):
        raise QuotaCompletedRepresentationFailure(
            "candidate_completion_count_violation",
            "The global completion count differs from the total candidate deficit.",
            {"completion_cell_count": len(additions), "total_candidate_deficit": int(total_deficit)},
        )

    stratum_diagnostics = pd.DataFrame(diagnostic_rows)
    global_diagnostics: dict[str, Any] = {
        "original_candidate_pool_size": int(len(original_candidates)),
        "completed_candidate_pool_size": int(len(completed)),
        "original_candidate_fraction": float(len(original_candidates) / len(ids)),
        "completion_cell_count": int(len(additions)),
        "completion_fraction_of_candidate_pool": float(len(additions) / len(completed)) if completed else 0.0,
        "deficient_strata_count": int(sum(row["deficit_g"] > 0 for row in diagnostic_rows)),
        "deficient_strata_fraction": float(
            sum(row["deficit_g"] > 0 for row in diagnostic_rows) / len(positive_strata)
        ),
        "total_candidate_deficit": int(total_deficit),
        "maximum_stratum_deficit": int(maximum_deficit),
        "fallback_strata_count": int(fallback_strata_count),
        "fallback_strata_fraction": float(fallback_strata_count / len(positive_strata)),
        "candidate_feasibility_before_completion": float(before_feasible / len(positive_strata)),
        "candidate_feasibility_after_completion": 1.0,
    }
    return CompletionResult(
        completed_candidate_indices=completed,
        candidate_source_by_index=candidate_sources,
        stratum_diagnostics=stratum_diagnostics,
        global_diagnostics=global_diagnostics,
    )


def _quality_status(
    global_diagnostics: Mapping[str, Any],
    stratum_diagnostics: pd.DataFrame,
) -> str:
    """Apply the frozen FAIL, DEGRADED, WARN, PASS order without performance metrics."""
    if float(global_diagnostics["candidate_feasibility_after_completion"]) != 1.0:
        return "FAIL"
    maximum = float(stratum_diagnostics["completion_fraction_within_stratum"].max())
    candidate_fraction = float(global_diagnostics["completion_fraction_of_candidate_pool"])
    final_fraction = float(global_diagnostics["completion_fraction_of_final_sample"])
    deficient_fraction = float(global_diagnostics["deficient_strata_fraction"])
    fallback_fraction = float(global_diagnostics["fallback_strata_fraction"])
    fallback_count = int(global_diagnostics["fallback_strata_count"])
    if (
        candidate_fraction > 0.10
        or final_fraction > 0.10
        or deficient_fraction > 0.20
        or maximum > 0.50
        or fallback_fraction > 0.05
    ):
        return "DEGRADED"
    if (
        candidate_fraction > 0.01
        or final_fraction > 0.01
        or deficient_fraction > 0.02
        or maximum > 0.25
        or fallback_count > 0
    ):
        return "WARN"
    return "PASS"


def sample_quota_completed_representation(
    *,
    cell_ids: Sequence[Hashable],
    expression_embedding: Any,
    spatial_strata: Sequence[Hashable],
    quotas: Mapping[Hashable, int],
    target_n: int,
    dataset_id: str,
    target_fraction: float,
    benchmark_repeat_seed: int,
) -> QuotaCompletedRepresentationResult:
    """Run the preregistered legacy candidate stage, completion, and quota draw."""
    ids = [str(value) for value in cell_ids]
    embedding = np.asarray(expression_embedding, dtype=float)
    if embedding.ndim != 2 or embedding.shape[0] != len(ids):
        raise ValueError("expression_embedding must have one row per cell_id.")
    spatial = _normalise_labels(spatial_strata, "spatial_strata")
    if len(spatial) != len(ids):
        raise ValueError("spatial_strata must have one entry per cell_id.")
    frozen_quotas = _normalise_quotas(spatial, quotas, int(target_n))
    expression_strata = frozen_expression_strata(embedding)
    seeds = candidate_pool_seed_set(int(benchmark_repeat_seed))
    per_seed = int(math.ceil(len(ids) * CANDIDATE_FRACTION_PER_SEED))

    candidates, selected_by_seed, history, _, feasibility = build_candidates_until_quota_feasible(
        embedding=embedding,
        all_bin_ids=spatial.tolist(),
        final_quotas=frozen_quotas,
        n_select_per_seed=per_seed,
        seeds=seeds,
        method="stratified",
        candidate_strata=expression_strata.tolist(),
    )
    completion = complete_candidate_deficits(
        candidate_indices=candidates,
        cell_ids=ids,
        spatial_strata=spatial.tolist(),
        quotas=frozen_quotas,
        expression_strata=expression_strata.tolist(),
        dataset_id=dataset_id,
        target_fraction=float(target_fraction),
        benchmark_repeat_seed=int(benchmark_repeat_seed),
        target_n=int(target_n),
    )
    completed = completion.completed_candidate_indices
    completed_bins = bin_ids_for_indices(completed, spatial.tolist())
    selected, quota_report = sample_by_quota(
        completed,
        completed_bins,
        frozen_quotas,
        seed=int(benchmark_repeat_seed),
    )
    if quota_report["n_insufficient_bins"] or len(selected) != int(target_n):
        raise QuotaCompletedRepresentationFailure(
            "final_quota_sampling_failure",
            "Final quota sampling did not satisfy the preregistered exact sample size.",
            {"quota_report": quota_report, "target_n": int(target_n)},
        )
    selected_indices = np.asarray(selected, dtype=int)
    if selected_indices.size != np.unique(selected_indices).size:
        raise QuotaCompletedRepresentationFailure(
            "final_duplicate_cell_id",
            "Final quota sampling returned duplicate cells.",
        )

    diagnostics = completion.stratum_diagnostics.set_index("stratum_id")
    selected_rows: list[dict[str, Any]] = []
    for index in selected_indices.tolist():
        stratum = str(spatial[index])
        row = diagnostics.loc[stratum]
        source = completion.candidate_source_by_index[index]
        selected_rows.append(
            {
                "cell_id": ids[index],
                "selected": True,
                "spatial_stratum": stratum,
                "stratum_size": int(row["N_g"]),
                "stratum_quota": int(row["q_g"]),
                "C_g_before": int(row["C_g_before"]),
                "deficit_g": int(row["deficit_g"]),
                "C_g_after": int(row["C_g_after"]),
                "candidate_source": source,
                "was_original_expression_candidate": bool(source == "expression_candidate"),
                "was_quota_completion": bool(source != "expression_candidate"),
                "completion_strategy": str(row["completion_strategy"]),
                "benchmark_repeat_seed": int(benchmark_repeat_seed),
                "completion_seed": int(row["completion_seed"]),
                "final_selection_seed": int(benchmark_repeat_seed),
                "method_id": METHOD_ID,
                "algorithm_version": ALGORITHM_VERSION,
                "composition_calibration_factor": float(row["N_g"] / row["q_g"]),
            }
        )
    selected_cells = pd.DataFrame(selected_rows)
    candidate_cells = pd.DataFrame(
        [
            {
                "cell_id": ids[index],
                "candidate_source": completion.candidate_source_by_index[index],
                "spatial_stratum": str(spatial[index]),
                "method_id": METHOD_ID,
                "algorithm_version": ALGORITHM_VERSION,
            }
            for index in completed
        ]
    )
    global_diagnostics = dict(completion.global_diagnostics)
    global_diagnostics.update(
        {
            "completion_fraction_of_final_sample": float(selected_cells["was_quota_completion"].mean())
            if not selected_cells.empty
            else 0.0,
            "maximum_internal_seed_budget": MAXIMUM_INTERNAL_SEED_BUDGET,
            "internal_seed_count_used": int(len(selected_by_seed)),
            "candidate_pool_size_by_internal_seed": [
                int(row["n_unique_candidates"]) for row in history
            ],
            "deficient_strata_by_internal_seed": [
                int(row["n_quota_infeasible_bins"]) for row in history
            ],
            "total_deficit_by_internal_seed": [
                int(row["total_candidate_shortfall"]) for row in history
            ],
            "marginal_candidate_gain": [
                int(history[position]["n_unique_candidates"])
                - (int(history[position - 1]["n_unique_candidates"]) if position else 0)
                for position in range(len(history))
            ],
            "marginal_deficit_reduction": [
                int(history[position - 1]["total_candidate_shortfall"])
                - int(history[position]["total_candidate_shortfall"]
                )
                if position
                else 0
                for position in range(len(history))
            ],
            "saturation_status": (
                "feasible_before_budget"
                if feasibility["n_insufficient_bins"] == 0
                and len(selected_by_seed) < MAXIMUM_INTERNAL_SEED_BUDGET
                else "feasible_at_budget"
                if feasibility["n_insufficient_bins"] == 0
                else "unresolved_at_budget"
            ),
        }
    )
    global_diagnostics["quality_status"] = _quality_status(
        global_diagnostics,
        completion.stratum_diagnostics,
    )
    metadata = {
        "method_id": METHOD_ID,
        "algorithm_version": ALGORITHM_VERSION,
        "method_family": "representation",
        "uses_expression": True,
        "uses_spatial_coordinates": True,
        "uses_cell_labels": False,
        "uses_domain_labels": False,
        "uses_evaluation_labels": False,
        "probability_sampling_design": False,
        "inclusion_probability": None,
        "sampling_weight": None,
        "supports_ht": False,
        "supports_hajek": False,
        "supports_design_based_variance": False,
        "composition_calibration_factor_semantics": (
            "descriptive_spatial_composition_calibration_factor_only; not an inverse inclusion probability"
        ),
        "candidate_pool_seed_set": seeds,
        "final_selection_seed": int(benchmark_repeat_seed),
    }
    return QuotaCompletedRepresentationResult(
        selected_indices=selected_indices,
        completed_candidate_indices=np.asarray(completed, dtype=int),
        selected_cells=selected_cells,
        candidate_cells=candidate_cells,
        stratum_diagnostics=completion.stratum_diagnostics.copy(),
        global_diagnostics=global_diagnostics,
        metadata=metadata,
    )


def sample_quota_completed_representation_from_adata(
    *,
    adata: Any,
    spatial_strata: Sequence[Hashable],
    quotas: Mapping[Hashable, int],
    target_n: int,
    dataset_id: str,
    target_fraction: float,
    benchmark_repeat_seed: int,
) -> QuotaCompletedRepresentationResult:
    """Compute the frozen embedding from an AnnData-like input before sampling."""
    cell_ids = [str(value) for value in adata.obs_names]
    embedding = compute_pca_embedding(adata, n_components=30, random_state=0)
    return sample_quota_completed_representation(
        cell_ids=cell_ids,
        expression_embedding=embedding,
        spatial_strata=spatial_strata,
        quotas=quotas,
        target_n=target_n,
        dataset_id=dataset_id,
        target_fraction=target_fraction,
        benchmark_repeat_seed=benchmark_repeat_seed,
    )


__all__ = [
    "ALGORITHM_VERSION",
    "CANDIDATE_FRACTION_PER_SEED",
    "FALLBACK_COMPLETION_STRATEGY",
    "MAXIMUM_INTERNAL_SEED_BUDGET",
    "METHOD_ID",
    "PRIMARY_COMPLETION_STRATEGY",
    "CompletionResult",
    "QuotaCompletedRepresentationFailure",
    "QuotaCompletedRepresentationResult",
    "candidate_pool_seed_set",
    "complete_candidate_deficits",
    "derive_completion_seed",
    "frozen_expression_strata",
    "sample_quota_completed_representation",
    "sample_quota_completed_representation_from_adata",
]
