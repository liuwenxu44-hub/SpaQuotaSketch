"""Spatial binning utilities."""

from __future__ import annotations

from collections import Counter
from typing import Any, Hashable


def rectangular_grid_edges(coords: Any, n_x: int = 20, n_y: int = 20) -> tuple[Any, Any]:
    """Build rectangular grid edges for two-dimensional coordinates."""
    import numpy as np

    points = np.asarray(coords)
    if points.ndim != 2 or points.shape[1] < 2:
        raise ValueError("coords must be a two-dimensional array with at least two columns.")
    if n_x < 1 or n_y < 1:
        raise ValueError("n_x and n_y must be positive integers.")
    if not np.isfinite(points[:, :2]).all():
        raise ValueError("coords must not contain NaN or infinite values.")

    x = points[:, 0]
    y = points[:, 1]
    x_min, x_max = float(np.min(x)), float(np.max(x))
    y_min, y_max = float(np.min(y)), float(np.max(y))
    if x_min == x_max:
        x_max = x_min + 1.0
    if y_min == y_max:
        y_max = y_min + 1.0

    return np.linspace(x_min, x_max, n_x + 1), np.linspace(y_min, y_max, n_y + 1)


def rectangular_grid_indices(coords: Any, n_x: int = 20, n_y: int = 20) -> tuple[Any, Any, Any, Any]:
    """Assign coordinates to rectangular grid x/y indices and return grid edges."""
    import numpy as np

    points = np.asarray(coords)
    x_edges, y_edges = rectangular_grid_edges(points, n_x=n_x, n_y=n_y)
    x = points[:, 0]
    y = points[:, 1]
    x_idx = np.clip(np.searchsorted(x_edges, x, side="right") - 1, 0, n_x - 1)
    y_idx = np.clip(np.searchsorted(y_edges, y, side="right") - 1, 0, n_y - 1)
    return x_idx.astype(int), y_idx.astype(int), x_edges, y_edges


def rectangular_grid_bins(coords: Any, n_x: int = 20, n_y: int = 20) -> list[str]:
    """Assign two-dimensional coordinates to rectangular grid bins."""
    x_idx, y_idx, _, _ = rectangular_grid_indices(coords, n_x=n_x, n_y=n_y)
    return [f"{int(ix)}_{int(iy)}" for ix, iy in zip(x_idx, y_idx)]


def rectangular_grid_bins_by_block(
    coords: Any,
    block_ids: Any,
    n_x: int = 20,
    n_y: int = 20,
) -> list[str]:
    """Build independent rectangular grids for non-contiguous spatial blocks.

    A block can be a tissue slice, slide, field of view, or specimen. Coordinates
    from different blocks are never compared, so independently measured slides are
    not accidentally treated as adjacent tissue.
    """
    import numpy as np

    points = np.asarray(coords)
    blocks = np.asarray(block_ids, dtype=object).reshape(-1)
    if points.ndim != 2 or points.shape[1] < 2:
        raise ValueError("coords must be a two-dimensional array with at least two columns.")
    if blocks.shape[0] != points.shape[0]:
        raise ValueError("block_ids must contain exactly one value per coordinate row.")

    normalized_blocks = np.asarray([str(value) for value in blocks], dtype=object)
    if any(value.strip().lower() in {"", "nan", "none", "na"} for value in normalized_blocks):
        raise ValueError("block_ids must not contain missing values.")

    output = [""] * points.shape[0]
    seen: set[str] = set()
    ordered_blocks: list[str] = []
    for block_id in normalized_blocks.tolist():
        if block_id not in seen:
            seen.add(block_id)
            ordered_blocks.append(block_id)
    for block_id in ordered_blocks:
        positions = np.flatnonzero(normalized_blocks == block_id)
        local_bins = rectangular_grid_bins(points[positions], n_x=n_x, n_y=n_y)
        for position, local_bin in zip(positions.tolist(), local_bins):
            output[position] = f"{block_id}::{local_bin}"
    return output


def budget_adaptive_grid_bins_by_block(
    coords: Any,
    block_ids: Any,
    target_n: int,
    max_n_x: int = 20,
    max_n_y: int = 20,
) -> tuple[list[str], dict[str, object]]:
    """Use the finest per-block grid whose occupied cells fit the sample budget.

    Each block first receives its exact proportional sample quota. The grid is then
    made as fine as possible while keeping its number of occupied cells no larger
    than that quota. Therefore every occupied *selection* cell can receive at
    least one observation. A separate, fixed grid should still be used to compare
    spatial coverage between methods.
    """
    import numpy as np

    from .soft_balance import proportional_quotas

    points = np.asarray(coords)
    blocks = np.asarray(block_ids, dtype=object).reshape(-1)
    if points.ndim != 2 or points.shape[1] < 2:
        raise ValueError("coords must be a two-dimensional array with at least two columns.")
    if blocks.shape[0] != points.shape[0]:
        raise ValueError("block_ids must contain exactly one value per coordinate row.")
    if not 1 <= int(target_n) <= points.shape[0]:
        raise ValueError("target_n must be between 1 and the number of coordinate rows.")
    if max_n_x < 1 or max_n_y < 1:
        raise ValueError("max_n_x and max_n_y must be positive integers.")

    normalized_blocks = np.asarray([str(value) for value in blocks], dtype=object)
    if any(value.strip().lower() in {"", "nan", "none", "na"} for value in normalized_blocks):
        raise ValueError("block_ids must not contain missing values.")

    seen: set[str] = set()
    ordered_blocks: list[str] = []
    for block_id in normalized_blocks.tolist():
        if block_id not in seen:
            seen.add(block_id)
            ordered_blocks.append(block_id)
    block_quotas = proportional_quotas(normalized_blocks.tolist(), int(target_n))
    largest_axis = max(max_n_x, max_n_y)
    candidate_shapes = {
        (
            max(1, int(round(max_n_x * step / largest_axis))),
            max(1, int(round(max_n_y * step / largest_axis))),
        )
        for step in range(1, largest_axis + 1)
    }
    candidate_shapes = sorted(candidate_shapes, key=lambda shape: (shape[0] * shape[1], shape[0], shape[1]), reverse=True)

    output = [""] * points.shape[0]
    block_reports: list[dict[str, object]] = []
    for block_id in ordered_blocks:
        positions = np.flatnonzero(normalized_blocks == block_id)
        local_points = points[positions]
        quota = int(block_quotas[block_id])
        chosen_shape = (1, 1)
        chosen_bins = rectangular_grid_bins(local_points, n_x=1, n_y=1)
        if quota > 0:
            for n_x, n_y in candidate_shapes:
                candidate_bins = rectangular_grid_bins(local_points, n_x=n_x, n_y=n_y)
                if len(set(candidate_bins)) <= quota:
                    chosen_shape = (n_x, n_y)
                    chosen_bins = candidate_bins
                    break
        for position, local_bin in zip(positions.tolist(), chosen_bins):
            output[position] = f"{block_id}::{local_bin}"
        occupied = len(set(chosen_bins))
        block_reports.append(
            {
                "block_id": block_id,
                "n_observations": int(positions.size),
                "target_quota": quota,
                "n_x": int(chosen_shape[0]),
                "n_y": int(chosen_shape[1]),
                "n_occupied_selection_bins": int(occupied),
                "mean_quota_per_occupied_selection_bin": float(quota / occupied) if occupied else 0.0,
            }
        )
    return output, {
        "grid_mode": "budget_adaptive_exact_coverage",
        "max_n_x": int(max_n_x),
        "max_n_y": int(max_n_y),
        "target_n": int(target_n),
        "blocks": block_reports,
    }


def summarize_bins(bin_ids: list[Hashable]) -> list[dict[str, object]]:
    """Count observations per spatial bin."""
    counts = Counter(bin_ids)
    return [{"bin_id": bin_id, "n_observations": count} for bin_id, count in sorted(counts.items())]


def bin_counts(bin_ids: list[Hashable]) -> dict[Hashable, int]:
    """Return observation counts per bin."""
    return dict(Counter(bin_ids))


def candidate_coverage(
    original_bin_ids: list[Hashable],
    candidate_bin_ids: list[Hashable],
    min_candidates_per_bin: int = 1,
) -> dict[str, object]:
    """Summarize candidate coverage over original non-empty bins."""
    if min_candidates_per_bin < 1:
        raise ValueError("min_candidates_per_bin must be at least 1.")

    original_counts = Counter(original_bin_ids)
    candidate_counts = Counter(candidate_bin_ids)
    insufficient = [
        {
            "bin_id": bin_id,
            "original_count": int(original_count),
            "candidate_count": int(candidate_counts.get(bin_id, 0)),
        }
        for bin_id, original_count in sorted(original_counts.items())
        if candidate_counts.get(bin_id, 0) < min_candidates_per_bin
    ]
    n_original_bins = len(original_counts)
    n_candidate_bins = sum(1 for bin_id in original_counts if candidate_counts.get(bin_id, 0) > 0)
    return {
        "n_original_bins": n_original_bins,
        "n_candidate_bins": n_candidate_bins,
        "candidate_spatial_coverage": n_candidate_bins / n_original_bins if n_original_bins else 0.0,
        "min_candidates_per_bin": int(min_candidates_per_bin),
        "n_insufficient_bins": len(insufficient),
        "insufficient_bins": insufficient,
    }


def candidate_quota_feasibility(
    candidate_bin_ids: list[Hashable],
    quotas: dict[Hashable, int],
) -> dict[str, object]:
    """Check whether a candidate pool can satisfy every final spatial quota."""
    if any(int(quota) < 0 for quota in quotas.values()):
        raise ValueError("quotas must be non-negative.")
    candidate_counts = Counter(candidate_bin_ids)
    required_bins = {bin_id: int(quota) for bin_id, quota in quotas.items() if int(quota) > 0}
    insufficient = [
        {
            "bin_id": bin_id,
            "quota": quota,
            "candidate_count": int(candidate_counts.get(bin_id, 0)),
            "shortfall": int(quota - candidate_counts.get(bin_id, 0)),
        }
        for bin_id, quota in sorted(required_bins.items())
        if candidate_counts.get(bin_id, 0) < quota
    ]
    feasible_bins = len(required_bins) - len(insufficient)
    return {
        "n_quota_bins": int(len(required_bins)),
        "n_quota_feasible_bins": int(feasible_bins),
        "candidate_quota_coverage": float(feasible_bins / len(required_bins)) if required_bins else 1.0,
        "n_insufficient_bins": int(len(insufficient)),
        "total_candidate_shortfall": int(sum(item["shortfall"] for item in insufficient)),
        "insufficient_bins": insufficient,
    }
