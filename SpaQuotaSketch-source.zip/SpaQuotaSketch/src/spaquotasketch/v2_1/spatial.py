"""Deterministic budget-adaptive regular spatial stratification for Version 2.1."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Sequence

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class AdaptiveSpatialPartition:
    """A target-size-specific regular spatial partition and complete audit tables."""

    stratum_ids: np.ndarray
    n_x: int
    n_y: int
    x_edges: np.ndarray
    y_edges: np.ndarray
    candidate_audit: pd.DataFrame
    grid_cell_audit: pd.DataFrame
    stratum_audit: pd.DataFrame
    selection_reason: str


def _validate_coordinates(coordinates: Sequence[Sequence[float]]) -> np.ndarray:
    values = np.asarray(coordinates, dtype=float)
    if values.ndim != 2 or values.shape[1] < 2 or values.shape[0] == 0:
        raise ValueError("coordinates must contain at least one two-dimensional point.")
    if not np.isfinite(values[:, :2]).all():
        raise ValueError("coordinates must not contain missing or infinite values.")
    return values[:, :2]


def _edges(values: np.ndarray, n_x: int, n_y: int) -> tuple[np.ndarray, np.ndarray]:
    x_min, x_max = float(values[:, 0].min()), float(values[:, 0].max())
    y_min, y_max = float(values[:, 1].min()), float(values[:, 1].max())
    if x_min == x_max:
        x_max = x_min + 1.0
    if y_min == y_max:
        y_max = y_min + 1.0
    return np.linspace(x_min, x_max, int(n_x) + 1), np.linspace(y_min, y_max, int(n_y) + 1)


def _indices(values: np.ndarray, n_x: int, n_y: int) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    x_edges, y_edges = _edges(values, n_x, n_y)
    x_index = np.clip(np.searchsorted(x_edges, values[:, 0], side="right") - 1, 0, n_x - 1)
    y_index = np.clip(np.searchsorted(y_edges, values[:, 1], side="right") - 1, 0, n_y - 1)
    return x_index.astype(int), y_index.astype(int), x_edges, y_edges


def _stratum_name(x_index: int, y_index: int) -> str:
    return f"x{x_index:02d}_y{y_index:02d}"


def candidate_shapes(max_n_x: int, max_n_y: int) -> list[tuple[int, int]]:
    """Return all regular-grid candidates in a seed-independent canonical order."""
    if max_n_x < 1 or max_n_y < 1:
        raise ValueError("maximum grid dimensions must be positive.")
    return [(n_x, n_y) for n_x in range(1, max_n_x + 1) for n_y in range(1, max_n_y + 1)]


def _candidate_record(
    values: np.ndarray,
    n_x: int,
    n_y: int,
    target_n: int,
    minimum_quota: int,
) -> dict[str, object]:
    x_index, y_index, _, _ = _indices(values, n_x, n_y)
    flat = x_index * n_y + y_index
    counts = np.bincount(flat, minlength=n_x * n_y)
    occupied = counts[counts > 0]
    x_span = float(values[:, 0].max() - values[:, 0].min())
    y_span = float(values[:, 1].max() - values[:, 1].min())
    x_span = x_span if x_span > 0 else 1.0
    y_span = y_span if y_span > 0 else 1.0
    tissue_aspect = x_span / y_span
    grid_aspect = n_x / n_y
    aspect_distance = abs(float(np.log(grid_aspect / tissue_aspect)))
    n_occupied = int(occupied.size)
    capacity_ok = bool(occupied.size and int(occupied.min()) >= minimum_quota)
    budget_ok = bool(n_occupied * minimum_quota <= target_n)
    return {
        "n_x": int(n_x),
        "n_y": int(n_y),
        "total_grid_cells": int(n_x * n_y),
        "n_nonempty_strata": n_occupied,
        "n_empty_grid_cells": int(n_x * n_y - n_occupied),
        "minimum_population_cells_in_nonempty_stratum": int(occupied.min()) if occupied.size else 0,
        "maximum_population_cells_in_nonempty_stratum": int(occupied.max()) if occupied.size else 0,
        "grid_aspect_ratio": float(grid_aspect),
        "tissue_bounding_box_aspect_ratio": float(tissue_aspect),
        "aspect_distance": aspect_distance,
        "budget_feasible": budget_ok,
        "capacity_feasible": capacity_ok,
        "feasible": bool(budget_ok and capacity_ok),
        "selection_rank": np.nan,
    }


def _grid_cell_audit(values: np.ndarray, n_x: int, n_y: int) -> tuple[np.ndarray, np.ndarray, np.ndarray, pd.DataFrame]:
    x_index, y_index, x_edges, y_edges = _indices(values, n_x, n_y)
    flat = x_index * n_y + y_index
    counts = np.bincount(flat, minlength=n_x * n_y)
    records: list[dict[str, object]] = []
    for x_value in range(n_x):
        for y_value in range(n_y):
            index = x_value * n_y + y_value
            n_cells = int(counts[index])
            x_min, x_max = float(x_edges[x_value]), float(x_edges[x_value + 1])
            y_min, y_max = float(y_edges[y_value]), float(y_edges[y_value + 1])
            records.append(
                {
                    "spatial_stratum": _stratum_name(x_value, y_value),
                    "x_index": int(x_value),
                    "y_index": int(y_value),
                    "x_min": x_min,
                    "x_max": x_max,
                    "y_min": y_min,
                    "y_max": y_max,
                    "area": float((x_max - x_min) * (y_max - y_min)),
                    "N_g": n_cells,
                    "is_nonempty": bool(n_cells > 0),
                }
            )
    return x_index, y_index, x_edges, y_edges, pd.DataFrame.from_records(records)


def choose_adaptive_regular_partition(
    coordinates: Sequence[Sequence[float]],
    target_n: int,
    *,
    minimum_quota: int = 1,
    max_n_x: int = 20,
    max_n_y: int = 20,
    shapes: Iterable[tuple[int, int]] | None = None,
) -> AdaptiveSpatialPartition:
    """Choose the finest feasible regular partition using only coordinates and budget.

    Ranking is fixed before any sampling outcome exists: maximize nonempty strata,
    then minimize grid/tissue aspect mismatch, then use ascending `(n_x, n_y)`.
    """
    values = _validate_coordinates(coordinates)
    target_n = int(target_n)
    minimum_quota = int(minimum_quota)
    if not 1 <= target_n <= values.shape[0]:
        raise ValueError("target_n must lie between one and the population size.")
    if minimum_quota < 1:
        raise ValueError("minimum_quota must be at least one.")
    supplied_shapes = candidate_shapes(max_n_x, max_n_y) if shapes is None else list(shapes)
    canonical_shapes = sorted({(int(n_x), int(n_y)) for n_x, n_y in supplied_shapes})
    if not canonical_shapes or any(n_x < 1 or n_y < 1 for n_x, n_y in canonical_shapes):
        raise ValueError("candidate shapes must be nonempty positive integer pairs.")

    records = [
        _candidate_record(values, n_x, n_y, target_n, minimum_quota)
        for n_x, n_y in canonical_shapes
    ]
    audit = pd.DataFrame.from_records(records)
    feasible = audit.loc[audit["feasible"]].copy()
    if feasible.empty:
        raise ValueError(
            "No regular spatial partition satisfies the target budget and minimum quota."
        )
    feasible = feasible.sort_values(
        ["n_nonempty_strata", "aspect_distance", "n_x", "n_y"],
        ascending=[False, True, True, True],
        kind="stable",
    ).reset_index(drop=True)
    feasible["selection_rank"] = np.arange(1, len(feasible) + 1, dtype=int)
    audit = audit.drop(columns="selection_rank").merge(
        feasible[["n_x", "n_y", "selection_rank"]],
        on=["n_x", "n_y"],
        how="left",
    ).sort_values(["n_x", "n_y"], kind="stable").reset_index(drop=True)
    chosen = feasible.iloc[0]
    n_x, n_y = int(chosen["n_x"]), int(chosen["n_y"])
    x_index, y_index, x_edges, y_edges, all_cells = _grid_cell_audit(values, n_x, n_y)
    stratum_ids = np.asarray(
        [_stratum_name(x_value, y_value) for x_value, y_value in zip(x_index, y_index)],
        dtype=object,
    )
    strata = all_cells.loc[all_cells["is_nonempty"]].copy()
    strata["cell_density"] = strata["N_g"] / strata["area"]
    strata = strata.sort_values(["x_index", "y_index"], kind="stable").reset_index(drop=True)
    reason = (
        "maximized nonempty strata under G * minimum_quota <= target_n; "
        "then minimized grid/tissue bounding-box aspect mismatch; "
        "then selected ascending (n_x, n_y) deterministically"
    )
    return AdaptiveSpatialPartition(
        stratum_ids=stratum_ids,
        n_x=n_x,
        n_y=n_y,
        x_edges=x_edges,
        y_edges=y_edges,
        candidate_audit=audit,
        grid_cell_audit=all_cells,
        stratum_audit=strata,
        selection_reason=reason,
    )
