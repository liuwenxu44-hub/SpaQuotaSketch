"""Probability calibration, minimal inference checks, and pilot reporting for Version 2.1."""

from __future__ import annotations

import json
import math
import time
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Mapping

import numpy as np
import pandas as pd

from .pilot import PilotContext, peak_memory_mib, plans
from .sampling import SamplingPlan, draw_fixed_size_sample


def _atomic_csv(frame: pd.DataFrame, path: Path) -> None:
    if path.exists():
        raise FileExistsError(f"refusing to overwrite existing result: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temporary, index=False)
    temporary.replace(path)


def _atomic_json(payload: Mapping[str, Any], path: Path) -> None:
    if path.exists():
        raise FileExistsError(f"refusing to overwrite existing result: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def _wilson_interval(successes: np.ndarray, draws: int, z_value: float = 1.959963984540054) -> tuple[np.ndarray, np.ndarray]:
    draws = int(draws)
    frequency = np.asarray(successes, dtype=float) / draws
    denominator = 1.0 + z_value**2 / draws
    center = (frequency + z_value**2 / (2 * draws)) / denominator
    radius = z_value * np.sqrt(
        frequency * (1 - frequency) / draws + z_value**2 / (4 * draws**2)
    ) / denominator
    return np.clip(center - radius, 0, 1), np.clip(center + radius, 0, 1)


def _probability_bins(probability: np.ndarray, n_bins: int = 5) -> pd.Series:
    ranks = pd.Series(probability).rank(method="first")
    return pd.qcut(ranks, q=min(n_bins, len(probability)), duplicates="drop").astype(str)


def _calibration_cell_metrics(plan: SamplingPlan, hits: np.ndarray, draws: int) -> pd.DataFrame:
    probability = plan.inclusion_probability
    empirical = hits / int(draws)
    standard_error = np.sqrt(probability * (1 - probability) / int(draws))
    standardized = np.divide(
        empirical - probability,
        standard_error,
        out=np.zeros_like(probability),
        where=standard_error > 0,
    )
    lower, upper = _wilson_interval(hits, draws)
    zero_probability = np.power(1.0 - probability, int(draws))
    return pd.DataFrame(
        {
            "cell_index": np.arange(probability.size, dtype=int),
            "method": plan.method,
            "draws": int(draws),
            "theoretical_inclusion_probability": probability,
            "empirical_frequency": empirical,
            "signed_error": empirical - probability,
            "absolute_error": np.abs(empirical - probability),
            "squared_error": np.square(empirical - probability),
            "standard_error": standard_error,
            "standardized_error": standardized,
            "wilson_lower": lower,
            "wilson_upper": upper,
            "wilson_covers_probability": (probability >= lower) & (probability <= upper),
            "selection_count": hits,
            "zero_selection_probability_under_design": zero_probability,
            "probability_quantile_bin": _probability_bins(probability),
        }
    )


def _calibration_summary(metrics: pd.DataFrame, *, zero_tail_probability: float) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows: list[dict[str, object]] = []
    strata: list[dict[str, object]] = []
    for method, frame in metrics.groupby("method", sort=True):
        probability = frame["theoretical_inclusion_probability"].to_numpy(float)
        empirical = frame["empirical_frequency"].to_numpy(float)
        errors = frame["signed_error"].to_numpy(float)
        standardized = frame["standardized_error"].to_numpy(float)
        slope, intercept = np.polyfit(probability, empirical, deg=1)
        predicted = intercept + slope * probability
        total = float(np.square(empirical - empirical.mean()).sum())
        residual = float(np.square(empirical - predicted).sum())
        r_squared = float(1.0 - residual / total) if total > 0 else float("nan")
        impossible_zero = (frame["selection_count"] == 0) & (
            frame["zero_selection_probability_under_design"] < zero_tail_probability
        )
        rows.append(
            {
                "method": method,
                "draws": int(frame["draws"].iloc[0]),
                "mean_signed_error": float(errors.mean()),
                "mean_absolute_error": float(np.abs(errors).mean()),
                "rmse": float(np.sqrt(np.square(errors).mean())),
                "maximum_absolute_error": float(np.abs(errors).max()),
                "median_absolute_error": float(np.median(np.abs(errors))),
                "absolute_error_q95": float(np.quantile(np.abs(errors), 0.95)),
                "mean_standardized_error": float(standardized.mean()),
                "mean_absolute_standardized_error": float(np.abs(standardized).mean()),
                "standardized_error_abs_gt_2_fraction": float(np.mean(np.abs(standardized) > 2)),
                "standardized_error_abs_gt_3_fraction": float(np.mean(np.abs(standardized) > 3)),
                "wilson_95_coverage": float(frame["wilson_covers_probability"].mean()),
                "frequency_regression_intercept": float(intercept),
                "frequency_regression_slope": float(slope),
                "frequency_regression_r_squared": r_squared,
                "zero_selected_cells": int((frame["selection_count"] == 0).sum()),
                "zero_selected_cells_incompatible_with_design": int(impossible_zero.sum()),
            }
        )
        for bin_name, subset in frame.groupby("probability_quantile_bin", sort=True):
            values = subset["signed_error"].to_numpy(float)
            strata.append(
                {
                    "method": method,
                    "probability_quantile_bin": str(bin_name),
                    "n_cells": int(len(subset)),
                    "probability_min": float(subset["theoretical_inclusion_probability"].min()),
                    "probability_max": float(subset["theoretical_inclusion_probability"].max()),
                    "mean_signed_error": float(values.mean()),
                    "mean_absolute_error": float(np.abs(values).mean()),
                    "rmse": float(np.sqrt(np.square(values).mean())),
                    "wilson_95_coverage": float(subset["wilson_covers_probability"].mean()),
                    "mean_standardized_error": float(subset["standardized_error"].mean()),
                }
            )
    return pd.DataFrame(rows), pd.DataFrame(strata)


def _target_values(context: PilotContext) -> tuple[dict[str, tuple[str, np.ndarray, float]], pd.DataFrame]:
    matrix = np.asarray(context.expression.toarray(), dtype=float)
    gene_means = matrix.mean(axis=0)
    ordered = np.argsort(gene_means, kind="stable")
    low_gene, middle_gene, high_gene = int(ordered[0]), int(ordered[len(ordered) // 2]), int(ordered[-1])
    correlations = []
    for gene in range(matrix.shape[1]):
        value = np.corrcoef(context.transformed_expression_importance, matrix[:, gene])[0, 1]
        correlations.append(0.0 if not np.isfinite(value) else float(value))
    correlated_gene = int(np.argmax(np.abs(correlations)))
    weak_gene = int(np.argmin(np.abs(correlations)))
    targets: dict[str, tuple[str, np.ndarray, float]] = {
        "global_expression_total": ("total", matrix.sum(axis=1), float(matrix.sum())),
        "global_expression_mean": ("mean", matrix.mean(axis=1), float(matrix.mean())),
        "high_feature_detection_proportion": (
            "proportion",
            (matrix[:, high_gene] > 0).astype(float),
            float(np.mean(matrix[:, high_gene] > 0)),
        ),
        "low_expression_feature": ("mean", matrix[:, low_gene], float(matrix[:, low_gene].mean())),
        "middle_expression_feature": ("mean", matrix[:, middle_gene], float(matrix[:, middle_gene].mean())),
        "high_expression_feature": ("mean", matrix[:, high_gene], float(matrix[:, high_gene].mean())),
        "importance_correlated_feature": (
            "mean",
            matrix[:, correlated_gene],
            float(matrix[:, correlated_gene].mean()),
        ),
        "weakly_related_feature": ("mean", matrix[:, weak_gene], float(matrix[:, weak_gene].mean())),
    }
    table = pd.DataFrame(
        [
            {"target": name, "target_kind": kind, "reference_value": reference}
            for name, (kind, _, reference) in targets.items()
        ]
    )
    feature_rows = [
        ("low_expression_feature", low_gene),
        ("middle_expression_feature", middle_gene),
        ("high_expression_feature", high_gene),
        ("importance_correlated_feature", correlated_gene),
        ("weakly_related_feature", weak_gene),
    ]
    feature_table = pd.DataFrame(
        {
            "target": [name for name, _ in feature_rows],
            "feature_index": [index for _, index in feature_rows],
            "population_feature_mean": [float(gene_means[index]) for _, index in feature_rows],
            "importance_correlation": [float(correlations[index]) for _, index in feature_rows],
        }
    )
    return targets, table.merge(feature_table, on="target", how="left")


def _estimate_values(
    selected: np.ndarray,
    plan: SamplingPlan,
    targets: Mapping[str, tuple[str, np.ndarray, float]],
) -> list[tuple[str, str, float, float, str]]:
    output: list[tuple[str, str, float, float, str]] = []
    n_total = int(plan.inclusion_probability.size)
    weights = plan.sampling_weight[selected]
    for target, (kind, values, reference) in targets.items():
        selected_values = values[selected]
        weighted_mean = float(np.sum(weights * selected_values) / weights.sum())
        if kind == "total":
            estimates = {
                "unweighted": float(n_total / selected.size * selected_values.sum()),
                "HT": float(np.sum(selected_values / plan.inclusion_probability[selected])),
                "Hajek": float(n_total * weighted_mean),
            }
        else:
            estimates = {
                "unweighted": float(selected_values.mean()),
                "HT": float(np.sum(selected_values / plan.inclusion_probability[selected]) / n_total),
                "Hajek": weighted_mean,
            }
        output.extend((target, estimator, estimate, reference, kind) for estimator, estimate in estimates.items())
    return output


def _spatial_repeat_metrics(context: PilotContext, selected: np.ndarray, medium_values: np.ndarray) -> dict[str, float]:
    from scipy.spatial import cKDTree

    fixed_grid = context.fixed_evaluation_grid
    coordinates = context.coordinates
    chosen = coordinates[selected]
    coverage = len(set(fixed_grid[selected].tolist())) / len(set(fixed_grid.tolist()))
    if chosen.shape[0] > 1:
        distance, _ = cKDTree(chosen).query(chosen, k=2)
        nearest_neighbor_median = float(np.median(distance[:, 1]))
    else:
        nearest_neighbor_median = float("nan")
    x_min, x_max = float(coordinates[:, 0].min()), float(coordinates[:, 0].max())
    y_min, y_max = float(coordinates[:, 1].min()), float(coordinates[:, 1].max())
    x_span, y_span = max(x_max - x_min, 1e-12), max(y_max - y_min, 1e-12)
    full_edge = (
        (coordinates[:, 0] - x_min <= 0.05 * x_span)
        | (x_max - coordinates[:, 0] <= 0.05 * x_span)
        | (coordinates[:, 1] - y_min <= 0.05 * y_span)
        | (y_max - coordinates[:, 1] <= 0.05 * y_span)
    )
    edge_retention = float(full_edge[selected].mean())
    x_edges = np.linspace(x_min, x_max, 11)
    full_bin = np.clip(np.searchsorted(x_edges, coordinates[:, 0], side="right") - 1, 0, 9)
    selected_bin = full_bin[selected]
    full_means = np.asarray([medium_values[full_bin == item].mean() for item in range(10)], dtype=float)
    selected_means = np.asarray(
        [medium_values[selected[selected_bin == item]].mean() if np.any(selected_bin == item) else np.nan for item in range(10)],
        dtype=float,
    )
    valid = np.isfinite(selected_means)
    scale = float(np.mean(np.abs(full_means[valid]))) + 1e-12 if valid.any() else float("nan")
    gradient_error = (
        float(np.sqrt(np.mean(np.square(selected_means[valid] - full_means[valid]))) / scale)
        if valid.any()
        else float("nan")
    )
    return {
        "fixed_20x20_coverage": float(coverage),
        "nearest_neighbor_median_distance": nearest_neighbor_median,
        "edge_cell_fraction_selected": edge_retention,
        "edge_cell_fraction_population": float(full_edge.mean()),
        "gradient_relative_rmse": gradient_error,
        "gradient_evaluation_bins_covered": int(valid.sum()),
    }


def _weight_diagnostics(plan: SamplingPlan, selected_weight_values: list[np.ndarray]) -> dict[str, object]:
    probability = plan.inclusion_probability
    selected_weights = np.concatenate(selected_weight_values)
    median = float(np.median(selected_weights))
    sorted_weights = np.sort(selected_weights)
    def top_share(fraction: float) -> float:
        count = max(1, int(math.ceil(sorted_weights.size * fraction)))
        return float(sorted_weights[-count:].sum() / sorted_weights.sum())
    return {
        "method": plan.method,
        "inclusion_probability_min": float(probability.min()),
        "inclusion_probability_max": float(probability.max()),
        "sampling_weight_min": float(selected_weights.min()),
        "sampling_weight_median": median,
        "sampling_weight_max": float(selected_weights.max()),
        "weight_max_to_median": float(selected_weights.max() / median),
        "sampling_weight_mean": float(selected_weights.mean()),
        "sampling_weight_standard_deviation": float(selected_weights.std(ddof=0)),
        "sampling_weight_coefficient_of_variation": float(selected_weights.std(ddof=0) / selected_weights.mean()),
        "Kish_effective_sample_size_mean": float(np.mean([w.sum() ** 2 / np.square(w).sum() for w in selected_weight_values])),
        "Kish_effective_sample_size_fraction_mean": float(np.mean([w.sum() ** 2 / np.square(w).sum() / w.size for w in selected_weight_values])),
        "top_1pct_weight_share": top_share(0.01),
        "top_5pct_weight_share": top_share(0.05),
        "top_10pct_weight_share": top_share(0.10),
        "probability_hits_lower_bound_fraction": float(np.mean(np.isclose(probability, plan.lower_probability_bound, atol=1e-10, rtol=0))),
        "probability_hits_upper_bound_fraction": float(np.mean(np.isclose(probability, plan.upper_probability_bound, atol=1e-10, rtol=0))),
        "importance_probability_correlation": float(np.corrcoef(plan.expression_importance, probability)[0, 1]),
    }


def run_calibration(context: PilotContext, draws: int) -> dict[str, Any]:
    """Run matched calibration draws for coordinate-only and inference plans."""
    draws = int(draws)
    if draws < 1:
        raise ValueError("draws must be positive.")
    targets, target_table = _target_values(context)
    medium_values = targets["middle_expression_feature"][1]
    hit_counts = {plan.method: np.zeros(context.coordinates.shape[0], dtype=int) for plan in plans(context)}
    estimate_records: list[tuple[object, ...]] = []
    spatial_records: list[dict[str, object]] = []
    selected_weights: dict[str, list[np.ndarray]] = defaultdict(list)
    core_times: dict[str, float] = defaultdict(float)
    peak = peak_memory_mib()
    started = time.perf_counter()
    for repeat in range(draws):
        random_seed = int(context.config["calibration_seed_base"]) + repeat
        for plan in plans(context):
            sample_started = time.perf_counter()
            selected = draw_fixed_size_sample(plan, random_seed=random_seed)
            core_times[plan.method] += time.perf_counter() - sample_started
            expected_counts = Counter(plan.spatial_strata[selected].tolist())
            if selected.size != int(context.config["target_n"]) or np.unique(selected).size != selected.size:
                raise RuntimeError("calibration sample violates global fixed-size constraints.")
            if any(expected_counts.get(item, 0) != quota for item, quota in plan.quotas.items()):
                raise RuntimeError("calibration sample violates a strict spatial quota.")
            hit_counts[plan.method][selected] += 1
            selected_weights[plan.method].append(plan.sampling_weight[selected])
            for target, estimator, estimate, reference, target_kind in _estimate_values(selected, plan, targets):
                estimate_records.append(
                    (plan.method, repeat, random_seed, target, target_kind, estimator, reference, estimate)
                )
            spatial_records.append(
                {
                    "method": plan.method,
                    "repeat": repeat,
                    "random_seed": random_seed,
                    **_spatial_repeat_metrics(context, selected, medium_values),
                }
            )
        if repeat % 100 == 0:
            peak = max(peak, peak_memory_mib())
    elapsed = time.perf_counter() - started
    peak = max(peak, peak_memory_mib())
    cell_metrics = pd.concat(
        [_calibration_cell_metrics(plan, hit_counts[plan.method], draws) for plan in plans(context)],
        ignore_index=True,
    )
    summary, strata_summary = _calibration_summary(
        cell_metrics,
        zero_tail_probability=float(context.config["calibration"]["zero_count_tail_probability"]),
    )
    estimate_frame = pd.DataFrame.from_records(
        estimate_records,
        columns=["method", "repeat", "random_seed", "target", "target_kind", "estimator", "reference_value", "estimate"],
    )
    estimate_frame["signed_error"] = estimate_frame["estimate"] - estimate_frame["reference_value"]
    estimate_frame["absolute_error"] = estimate_frame["signed_error"].abs()
    estimate_rows: list[dict[str, object]] = []
    group_columns = ["method", "target", "target_kind", "estimator", "reference_value"]
    for keys, subset in estimate_frame.groupby(group_columns, sort=True):
        method, target, target_kind, estimator, reference = keys
        signed = subset["signed_error"].to_numpy(float)
        estimate = subset["estimate"].to_numpy(float)
        estimate_rows.append(
            {
                "method": method,
                "target": target,
                "target_kind": target_kind,
                "estimator": estimator,
                "reference_value": float(reference),
                "mean_estimate": float(estimate.mean()),
                "relative_bias": float(signed.mean() / (abs(float(reference)) + 1e-12)),
                "absolute_bias": float(abs(signed.mean())),
                "empirical_variance": float(estimate.var(ddof=1)),
                "rmse": float(np.sqrt(np.mean(np.square(signed)))),
                "monte_carlo_standard_error": float(estimate.std(ddof=1) / np.sqrt(len(estimate))),
            }
        )
    estimate_summary = pd.DataFrame.from_records(estimate_rows)
    spatial_frame = pd.DataFrame.from_records(spatial_records)
    spatial_summary = spatial_frame.groupby("method", as_index=False).agg(
        fixed_20x20_coverage_mean=("fixed_20x20_coverage", "mean"),
        fixed_20x20_coverage_std=("fixed_20x20_coverage", "std"),
        nearest_neighbor_median_distance_mean=("nearest_neighbor_median_distance", "mean"),
        edge_cell_fraction_selected_mean=("edge_cell_fraction_selected", "mean"),
        edge_cell_fraction_population=("edge_cell_fraction_population", "mean"),
        gradient_relative_rmse_mean=("gradient_relative_rmse", "mean"),
        gradient_evaluation_bins_covered_mean=("gradient_evaluation_bins_covered", "mean"),
    )
    weights = pd.DataFrame.from_records(
        [_weight_diagnostics(plan, selected_weights[plan.method]) for plan in plans(context)]
    )
    resources = pd.DataFrame.from_records(
        [
            {
                "stage": f"calibration_{draws}",
                "method": plan.method,
                "draws": draws,
                "candidate_search_seconds_reusable": context.preparation_seconds["candidate_search_and_partition_seconds"],
                "quota_allocation_seconds_reusable": context.preparation_seconds["quota_allocation_seconds"],
                "expression_importance_seconds_reusable": context.preparation_seconds["expression_importance_seconds"],
                "inclusion_probability_seconds_reusable": context.preparation_seconds["inclusion_probability_construction_seconds"],
                "core_sampling_seconds_total": core_times[plan.method],
                "core_sampling_seconds_per_draw": core_times[plan.method] / draws,
                "calibration_wall_seconds_total": elapsed,
                "peak_memory_mib": peak,
            }
            for plan in plans(context)
        ]
    )
    return {
        "draws": draws,
        "cell_metrics": cell_metrics,
        "summary": summary,
        "strata_summary": strata_summary,
        "estimates": estimate_frame,
        "estimate_summary": estimate_summary,
        "spatial_repeats": spatial_frame,
        "spatial_summary": spatial_summary,
        "weight_diagnostics": weights,
        "resources": resources,
        "target_table": target_table,
    }


def fast_gate(result: Mapping[str, Any], config: Mapping[str, Any]) -> dict[str, Any]:
    """Gate only obvious implementation failures; low-probability zero hits are not errors."""
    summary = result["summary"]
    gate = config["calibration"]["fast_gate"]
    checks: list[dict[str, object]] = []
    for _, row in summary.iterrows():
        checks.extend(
            [
                {"method": row["method"], "check": "no_impossible_zero_count", "passed": bool(row["zero_selected_cells_incompatible_with_design"] == 0)},
                {"method": row["method"], "check": "mean_standardized_error", "passed": bool(abs(row["mean_standardized_error"]) <= float(gate["maximum_absolute_mean_standardized_error"]))},
                {"method": row["method"], "check": "wilson_coverage", "passed": bool(row["wilson_95_coverage"] >= float(gate["minimum_wilson_coverage"]))},
            ]
        )
    return {
        "draws": int(result["draws"]),
        "passed": bool(all(item["passed"] for item in checks)),
        "checks": checks,
        "interpretation": "A zero empirical count is only a failure when its exact design probability is below the frozen tail threshold; a positive pi alone does not make zero hits impossible at 500 draws.",
    }


def write_calibration_outputs(result: Mapping[str, Any], output_dir: Path, *, stage: str, gate: Mapping[str, Any] | None = None) -> None:
    output_dir = Path(output_dir)
    prefix = f"calibration_{stage}"
    _atomic_csv(result["cell_metrics"], output_dir / f"{prefix}_cell_metrics.csv")
    _atomic_csv(result["summary"], output_dir / f"{prefix}_summary.csv")
    _atomic_csv(result["strata_summary"], output_dir / f"{prefix}_probability_strata.csv")
    _atomic_csv(result["estimate_summary"], output_dir / f"{prefix}_estimator_summary.csv")
    _atomic_csv(result["spatial_summary"], output_dir / f"{prefix}_spatial_summary.csv")
    _atomic_csv(result["weight_diagnostics"], output_dir / f"{prefix}_weight_diagnostics.csv")
    _atomic_csv(result["resources"], output_dir / f"{prefix}_resources.csv")
    _atomic_csv(result["target_table"], output_dir / f"{prefix}_inference_targets.csv")
    if stage == "confirmation":
        _atomic_csv(result["estimates"], output_dir / f"{prefix}_repeat_estimates.csv")
        _atomic_csv(result["spatial_repeats"], output_dir / f"{prefix}_spatial_repeats.csv")
    if gate is not None:
        _atomic_json(gate, output_dir / f"{prefix}_gate.json")


def write_pilot_report(output_dir: Path, report_path: Path) -> None:
    """Write a final factual report after the 10,000-draw confirmation exists."""
    output_dir, report_path = Path(output_dir), Path(report_path)
    if report_path.exists():
        raise FileExistsError("refusing to overwrite the Version 2.1 feasibility pilot report.")
    audit = json.loads((output_dir / "pilot_audit.json").read_text(encoding="utf-8"))
    fast = json.loads((output_dir / "calibration_fast_gate.json").read_text(encoding="utf-8"))
    summary = pd.read_csv(output_dir / "calibration_confirmation_summary.csv")
    estimates = pd.read_csv(output_dir / "calibration_confirmation_estimator_summary.csv")
    weights = pd.read_csv(output_dir / "calibration_confirmation_weight_diagnostics.csv")
    spatial = pd.read_csv(output_dir / "calibration_confirmation_spatial_summary.csv")
    quotas = pd.read_csv(output_dir / "selection_strata_quota_audit.csv")
    candidate = pd.read_csv(output_dir / "grid_candidate_audit.csv")
    inference = summary.loc[summary["method"] == "v2_1_inference"].iloc[0]
    coordinate = summary.loc[summary["method"] == "v2_1_coordinate_only"].iloc[0]
    inference_ht = estimates.loc[(estimates["method"] == "v2_1_inference") & (estimates["estimator"] == "HT")]
    inference_hajek = estimates.loc[(estimates["method"] == "v2_1_inference") & (estimates["estimator"] == "Hajek")]
    coordinate_ht = estimates.loc[(estimates["method"] == "v2_1_coordinate_only") & (estimates["estimator"] == "HT")]
    coordinate_hajek = estimates.loc[(estimates["method"] == "v2_1_coordinate_only") & (estimates["estimator"] == "Hajek")]
    systematic_bias = bool(
        (inference_ht["relative_bias"].abs() > 0.05).any()
        or (inference_hajek["relative_bias"].abs() > 0.05).any()
        or (coordinate_ht["relative_bias"].abs() > 0.05).any()
        or (coordinate_hajek["relative_bias"].abs() > 0.05).any()
    )
    inference_weight = weights.loc[weights["method"] == "v2_1_inference"].iloc[0]
    conditions = {
        "adaptive_partition_feasible": audit["final_n_nonempty_strata"] <= audit["target_n"],
        "exact_quotas": int(quotas["q_g"].sum()) == int(audit["target_n"]) and bool((quotas["q_g"] >= 1).all()) and bool((quotas["q_g"] <= quotas["N_g"]).all()),
        "fast_gate_passed": bool(fast["passed"]),
        "coordinate_calibration_passed": bool(coordinate["zero_selected_cells_incompatible_with_design"] == 0),
        "inference_calibration_passed": bool(inference["zero_selected_cells_incompatible_with_design"] == 0),
        "no_large_estimator_bias": not systematic_bias,
        "acceptable_inference_ess": float(inference_weight["Kish_effective_sample_size_fraction_mean"]) >= 0.5,
    }
    decision = "CONDITIONAL GO" if all(conditions.values()) else "HOLD"
    lines = [
        "# SpaQuotaSketch Version 2.1 Feasibility Pilot Report",
        "",
        "This report covers only frozen S01, 20,000 cells, 0.25%, and n=50. It is a feasibility and calibration report, not evidence of broad method superiority.",
        "",
        "## Partition Audit",
        "",
        f"- Candidate regular grids searched: {len(candidate)}.",
        f"- Final selection grid: {audit['final_grid_n_x']} x {audit['final_grid_n_y']}.",
        f"- Final nonempty spatial strata: {audit['final_n_nonempty_strata']}.",
        f"- Target sample size: {audit['target_n']}.",
        f"- Final quota sum: {audit['quota_sum']}.",
        f"- Fixed 20 x 20 grid is evaluation-only; it is not the Version 2.1 selection partition.",
        "",
        "## Probability Calibration",
        "",
        f"- Fast 500-draw gate passed: {fast['passed']}.",
        f"- Coordinate-only confirmation: mean absolute error {coordinate['mean_absolute_error']:.6f}, RMSE {coordinate['rmse']:.6f}, Wilson coverage {coordinate['wilson_95_coverage']:.3f}.",
        f"- Inference confirmation: mean absolute error {inference['mean_absolute_error']:.6f}, RMSE {inference['rmse']:.6f}, Wilson coverage {inference['wilson_95_coverage']:.3f}.",
        f"- Maximum absolute errors are descriptive only: coordinate-only {coordinate['maximum_absolute_error']:.6f}, inference {inference['maximum_absolute_error']:.6f}. They are interpreted with probability-specific Monte Carlo error and multiple-cell comparison.",
        "",
        "## Weight and Spatial Diagnostics",
        "",
        f"- Inference mean effective sample-size fraction: {inference_weight['Kish_effective_sample_size_fraction_mean']:.3f}.",
        f"- Inference maximum-to-median selected weight ratio: {inference_weight['weight_max_to_median']:.3f}.",
        f"- Fixed 20 x 20 coverage is reported in `calibration_confirmation_spatial_summary.csv`; 100% final adaptive-stratum coverage is a construction property and is not claimed as a spatial advantage.",
        "",
        "## Minimal Inference Check",
        "",
        f"- Any large repeated-estimate systematic bias by the predeclared 5% audit rule: {systematic_bias}.",
        "- Estimator summaries contain unweighted, Horvitz-Thompson, and Hajek estimates for global total, global mean, proportion, low/middle/high expression features, an importance-correlated feature, and a weakly related feature.",
        "- A single S01 scenario cannot establish that inference is superior to coordinate-only; all favorable and unfavorable target-level results remain in the machine-readable estimator table.",
        "",
        "## Final Answers",
        "",
        f"* S01低比例结构性不可行是否解决：{conditions['adaptive_partition_feasible'] and conditions['exact_quotas']}。",
        f"* 最终选择空间网格：{audit['final_grid_n_x']} x {audit['final_grid_n_y']}。",
        f"* 非空空间层数量G：{audit['final_n_nonempty_strata']}。",
        f"* 目标样本数n：{audit['target_n']}。",
        f"* 严格空间配额是否成立：{conditions['exact_quotas']}。",
        "* 所有细胞正包含概率是否成立：见完整细胞抽样框和确认校准；本报告仅在概率范围与校准检查均通过时作肯定结论。",
        f"* coordinate-only概率校准是否通过：{conditions['coordinate_calibration_passed']}。",
        f"* inference概率校准是否通过：{conditions['inference_calibration_passed']}。",
        f"* HT估计是否存在系统偏差：{systematic_bias}。",
        f"* Hájek估计是否存在系统偏差：{systematic_bias}。",
        f"* inference权重代价：平均ESS/n={inference_weight['Kish_effective_sample_size_fraction_mean']:.3f}，最大权重/中位数权重={inference_weight['weight_max_to_median']:.3f}。",
        "* 自适应空间分辨率代价：选择分层低于固定20x20评估网格；详见空间映射和空间汇总表。",
        "* inference相对coordinate-only是否已经显示实际收益：单一S01可行性场景不足以作此声明；仅保留逐目标估计结果。",
        f"* 是否满足扩展到其他比例的条件：{all(conditions.values())}。",
        f"* 最终决策：{decision}。",
        "* 下一阶段唯一最高优先级任务：仅在本报告全部条件通过时，预注册并实现其他抽样比例的Version 2.1最小扩展；否则修复校准或可行性问题，不进入跨平台验证。",
    ]
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


__all__ = [
    "fast_gate",
    "run_calibration",
    "write_calibration_outputs",
    "write_pilot_report",
]
