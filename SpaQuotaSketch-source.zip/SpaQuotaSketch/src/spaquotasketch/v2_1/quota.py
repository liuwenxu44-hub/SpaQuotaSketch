"""Deterministic exact quota allocation for Version 2.1 spatial strata."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class QuotaAllocation:
    quotas: dict[str, int]
    audit: pd.DataFrame


def allocate_largest_remainder_quotas(
    strata: pd.DataFrame,
    target_n: int,
    *,
    minimum_quota: int = 1,
) -> QuotaAllocation:
    """Allocate exact integer quotas with a deterministic largest-remainder rule."""
    required = {"spatial_stratum", "N_g"}
    if not required.issubset(strata.columns):
        raise ValueError("strata must contain spatial_stratum and N_g columns.")
    frame = strata.loc[:, ["spatial_stratum", "N_g"]].copy()
    frame["N_g"] = frame["N_g"].astype(int)
    frame = frame.sort_values("spatial_stratum", kind="stable").reset_index(drop=True)
    target_n, minimum_quota = int(target_n), int(minimum_quota)
    if frame.empty or (frame["N_g"] < 1).any():
        raise ValueError("quota allocation requires only nonempty strata.")
    if minimum_quota < 1:
        raise ValueError("minimum_quota must be at least one.")
    if (frame["N_g"] < minimum_quota).any():
        raise ValueError("a stratum cannot support the configured minimum quota.")
    n_strata = len(frame)
    total_capacity = int(frame["N_g"].sum())
    if not minimum_quota * n_strata <= target_n <= total_capacity:
        raise ValueError("target_n is incompatible with stratum capacities and minimum quotas.")

    remaining = target_n - minimum_quota * n_strata
    frame["ideal_continuous_quota"] = minimum_quota + remaining * frame["N_g"] / total_capacity
    frame["additional_ideal"] = frame["ideal_continuous_quota"] - minimum_quota
    frame["base_quota"] = minimum_quota + np.floor(frame["additional_ideal"]).astype(int)
    frame["base_quota"] = np.minimum(frame["base_quota"], frame["N_g"])
    frame["largest_remainder"] = frame["additional_ideal"] - np.floor(frame["additional_ideal"])
    frame["q_g"] = frame["base_quota"].astype(int)

    remaining_after_base = target_n - int(frame["q_g"].sum())
    while remaining_after_base:
        eligible = frame.loc[frame["q_g"] < frame["N_g"]].copy()
        if eligible.empty:
            raise ValueError("quota allocation exhausted all capacities before target_n.")
        eligible = eligible.sort_values(
            ["largest_remainder", "N_g", "spatial_stratum"],
            ascending=[False, False, True],
            kind="stable",
        )
        chosen_index = int(eligible.index[0])
        frame.loc[chosen_index, "q_g"] += 1
        frame.loc[chosen_index, "largest_remainder"] -= 1.0
        remaining_after_base -= 1

    frame["remaining_capacity"] = frame["N_g"] - frame["q_g"]
    frame["quota_sum_error"] = int(frame["q_g"].sum()) - target_n
    if int(frame["q_g"].sum()) != target_n or (frame["q_g"] < minimum_quota).any() or (frame["q_g"] > frame["N_g"]).any():
        raise RuntimeError("deterministic quota allocator violated a hard constraint.")
    quotas = dict(zip(frame["spatial_stratum"], frame["q_g"].astype(int)))
    return QuotaAllocation(quotas=quotas, audit=frame)
