"""Independent Version 2.1 feasibility-pilot implementation."""

from .spatial import AdaptiveSpatialPartition, choose_adaptive_regular_partition
from .quota import QuotaAllocation, allocate_largest_remainder_quotas
from .sampling import SamplingPlan, build_sampling_plan, draw_fixed_size_sample

__all__ = [
    "AdaptiveSpatialPartition",
    "QuotaAllocation",
    "SamplingPlan",
    "allocate_largest_remainder_quotas",
    "build_sampling_plan",
    "choose_adaptive_regular_partition",
    "draw_fixed_size_sample",
]
