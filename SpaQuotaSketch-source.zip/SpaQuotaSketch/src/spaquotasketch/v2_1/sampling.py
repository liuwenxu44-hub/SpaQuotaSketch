"""Fixed-size probability sampling plans for independent Version 2.1 pilot runs."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping, Sequence

import numpy as np

from ..v2.inference import _local_edges, local_pivotal_sample


@dataclass(frozen=True)
class SamplingPlan:
    method: str
    spatial_strata: np.ndarray
    quotas: dict[str, int]
    inclusion_probability: np.ndarray
    sampling_weight: np.ndarray
    expression_importance: np.ndarray
    lower_probability_bound: np.ndarray
    upper_probability_bound: np.ndarray
    positions_by_stratum: dict[str, np.ndarray]
    local_edges_by_stratum: dict[str, list[tuple[float, int, int]]]
    embedding: np.ndarray
    probability_solver: str


def bounded_expression_probabilities(
    expression_importance: Sequence[float],
    quota: int,
    *,
    max_weight_inflation: float,
    tolerance: float = 1e-12,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Project positive importance values onto exact bounded inclusion probabilities."""
    scores = np.asarray(expression_importance, dtype=float).reshape(-1)
    quota, n_cells = int(quota), int(scores.size)
    if not 1 <= quota <= n_cells:
        raise ValueError("quota must lie between one and the stratum population size.")
    if not np.isfinite(scores).all() or np.any(scores <= 0):
        raise ValueError("expression importance must be finite and strictly positive.")
    inflation = float(max_weight_inflation)
    if not np.isfinite(inflation) or inflation < 1:
        raise ValueError("max_weight_inflation must be finite and at least one.")
    if quota == n_cells:
        one = np.ones(n_cells, dtype=float)
        return one, one, one
    lower_value = quota / (inflation * n_cells)
    upper_value = 1.0 - (n_cells - quota) / (inflation * n_cells)
    lower = np.full(n_cells, lower_value, dtype=float)
    upper = np.full(n_cells, upper_value, dtype=float)
    raw = quota * scores / scores.sum()

    def projected_total(scale: float) -> float:
        return float(np.clip(scale * raw, lower, upper).sum())

    low, high = 0.0, 1.0
    while projected_total(high) < quota:
        high *= 2.0
        if high > 1e16:
            raise RuntimeError("failed to bracket bounded probability projection.")
    for _ in range(120):
        midpoint = (low + high) / 2.0
        if projected_total(midpoint) < quota:
            low = midpoint
        else:
            high = midpoint
    probability = np.clip(((low + high) / 2.0) * raw, lower, upper)
    residual = float(quota - probability.sum())
    if abs(residual) > tolerance:
        free = np.flatnonzero((probability > lower + tolerance) & (probability < upper - tolerance))
        if free.size == 0:
            free = np.flatnonzero(probability < upper - tolerance if residual > 0 else probability > lower + tolerance)
        if free.size == 0:
            raise RuntimeError("bounded probability projection has no cell available for residual correction.")
        probability[free] += residual / free.size
        probability = np.clip(probability, lower, upper)
    if not np.isclose(probability.sum(), quota, atol=1e-9, rtol=0):
        raise RuntimeError("within-stratum inclusion probabilities do not sum to quota.")
    if np.any(probability <= 0) or np.any(probability > 1):
        raise RuntimeError("bounded probability projection left the valid probability range.")
    return probability, lower, upper


def build_sampling_plan(
    spatial_strata: Sequence[str],
    quotas: Mapping[str, int],
    embedding: np.ndarray,
    expression_importance: Sequence[float],
    *,
    method: str,
    max_weight_inflation: float = 4.0,
) -> SamplingPlan:
    """Build one complete fixed-size plan without excluding any population cell."""
    strata = np.asarray(spatial_strata, dtype=object)
    importance = np.asarray(expression_importance, dtype=float).reshape(-1)
    values = np.asarray(embedding, dtype=float)
    if strata.size != importance.size or values.shape[0] != strata.size:
        raise ValueError("spatial strata, embedding, and expression importance must align.")
    if method not in {"v2_1_coordinate_only", "v2_1_inference"}:
        raise ValueError("method must be v2_1_coordinate_only or v2_1_inference.")
    positions_by_stratum = {
        stratum: np.flatnonzero(strata == stratum)
        for stratum in sorted(set(strata.tolist()))
    }
    if set(positions_by_stratum) != set(quotas):
        raise ValueError("quota keys must exactly equal the nonempty spatial strata.")
    inclusion = np.zeros(strata.size, dtype=float)
    lower = np.zeros(strata.size, dtype=float)
    upper = np.zeros(strata.size, dtype=float)
    local_edges: dict[str, list[tuple[float, int, int]]] = {}
    for stratum in sorted(positions_by_stratum):
        positions = positions_by_stratum[stratum]
        quota = int(quotas[stratum])
        n_g = int(positions.size)
        if not 1 <= quota <= n_g:
            raise ValueError("every nonempty stratum must have a quota between one and N_g.")
        if method == "v2_1_coordinate_only":
            probability = np.full(n_g, quota / n_g, dtype=float)
            local_lower = probability.copy()
            local_upper = probability.copy()
            solver = "equal_probability_within_stratum"
        else:
            probability, local_lower, local_upper = bounded_expression_probabilities(
                importance[positions], quota, max_weight_inflation=max_weight_inflation
            )
            solver = "bounded_expression_importance_projection"
        inclusion[positions] = probability
        lower[positions] = local_lower
        upper[positions] = local_upper
        if quota > 1 and quota < n_g:
            local_edges[stratum] = _local_edges(values[positions], n_neighbors=8)
        else:
            local_edges[stratum] = []
    if not np.all(inclusion > 0) or not np.all(inclusion <= 1):
        raise RuntimeError("the complete population must have valid positive probabilities.")
    weights = 1.0 / inclusion
    return SamplingPlan(
        method=method,
        spatial_strata=strata,
        quotas={stratum: int(quotas[stratum]) for stratum in sorted(quotas)},
        inclusion_probability=inclusion,
        sampling_weight=weights,
        expression_importance=importance,
        lower_probability_bound=lower,
        upper_probability_bound=upper,
        positions_by_stratum=positions_by_stratum,
        local_edges_by_stratum=local_edges,
        embedding=values,
        probability_solver=solver,
    )


def _local_seed(seed: int, stratum_order: int) -> int:
    return int(np.random.SeedSequence([int(seed), int(stratum_order)]).generate_state(1)[0])


def draw_fixed_size_sample(plan: SamplingPlan, *, random_seed: int) -> np.ndarray:
    """Draw a legal fixed-size sample from a complete Version 2.1 plan.

    A quota of one uses categorical selection. This is exactly the fixed-size
    design for a singleton sample because the selected-cell probability equals
    the prescribed first-order inclusion probability. Larger quotas use the
    local pivotal routine with cached neighbor edges.
    """
    selected_parts: list[np.ndarray] = []
    master_rng = np.random.default_rng(int(random_seed))
    for order, stratum in enumerate(sorted(plan.positions_by_stratum)):
        positions = plan.positions_by_stratum[stratum]
        probability = plan.inclusion_probability[positions]
        quota = int(plan.quotas[stratum])
        seed = _local_seed(random_seed, order)
        if quota == positions.size:
            local = np.arange(positions.size, dtype=int)
        elif quota == 1:
            local = np.asarray([master_rng.choice(positions.size, p=probability)], dtype=int)
        else:
            local = local_pivotal_sample(
                probability,
                plan.embedding[positions],
                seed=seed,
                n_neighbors=8,
                edge_order=plan.local_edges_by_stratum[stratum],
            )
        if local.size != quota:
            raise RuntimeError("local fixed-size sampler did not satisfy the stratum quota.")
        selected_parts.append(positions[local])
    selected = np.sort(np.concatenate(selected_parts)) if selected_parts else np.asarray([], dtype=int)
    expected = int(sum(plan.quotas.values()))
    if selected.size != expected or np.unique(selected).size != selected.size:
        raise RuntimeError("global fixed-size sampling constraints were violated.")
    return selected
