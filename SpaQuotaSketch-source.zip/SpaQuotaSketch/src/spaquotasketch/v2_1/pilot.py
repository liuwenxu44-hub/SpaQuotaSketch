"""Single-scenario Version 2.1 feasibility-pilot preparation and diagnostics."""

from __future__ import annotations

import hashlib
import json
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

import numpy as np
import pandas as pd

from ..spatial_bins import rectangular_grid_bins
from ..project_paths import frozen_simulation_design_path
from ..v2.expression import normalized_svd
from ..v2.simulation_stress import generate_population
from .quota import QuotaAllocation, allocate_largest_remainder_quotas
from .sampling import SamplingPlan, build_sampling_plan, draw_fixed_size_sample
from .spatial import AdaptiveSpatialPartition, choose_adaptive_regular_partition


PILOT_SCENARIO_ID = "S01"
PILOT_N_CELLS = 20_000
PILOT_FRACTION = 0.0025
PILOT_TARGET_N = 50
PILOT_POPULATION_SEED = 20_082_001
PILOT_DRAW_SEED = 260_101
CALIBRATION_SEED_BASE = 270_001


@dataclass(frozen=True)
class PilotContext:
    config: dict[str, Any]
    expression: Any
    coordinates: np.ndarray
    embedding: np.ndarray
    raw_expression_score: np.ndarray
    transformed_expression_importance: np.ndarray
    partition: AdaptiveSpatialPartition
    allocation: QuotaAllocation
    coordinate_plan: SamplingPlan
    inference_plan: SamplingPlan
    fixed_evaluation_grid: np.ndarray
    preparation_seconds: dict[str, float]


def canonical_hash(payload: Mapping[str, Any]) -> str:
    content = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def _read_frozen_s01(project_root: Path) -> tuple[dict[str, Any], str]:
    design_path = frozen_simulation_design_path(project_root)
    design = json.loads(design_path.read_text(encoding="utf-8"))
    design_hash = str(design["design_sha256"])
    scenario = next(item for item in design["scenarios"] if item["scenario_id"] == PILOT_SCENARIO_ID)
    return dict(scenario), design_hash


def build_pilot_config(project_root: Path) -> dict[str, Any]:
    """Return the immutable configuration for the only approved Version 2.1 pilot."""
    scenario, design_hash = _read_frozen_s01(project_root)
    config = {
        "schema_version": "spaquotasketch-v2_1-feasibility-pilot-1",
        "purpose": "Validate the Version 2.1 low-fraction feasibility redesign only.",
        "scenario": scenario,
        "n_cells": PILOT_N_CELLS,
        "sampling_fraction": PILOT_FRACTION,
        "target_n": PILOT_TARGET_N,
        "population_seed": PILOT_POPULATION_SEED,
        "single_draw_seed": PILOT_DRAW_SEED,
        "calibration_seed_base": CALIBRATION_SEED_BASE,
        "candidate_grid": {
            "max_n_x": 20,
            "max_n_y": 20,
            "minimum_quota": 1,
            "selection_order": [
                "maximize_n_nonempty_strata",
                "minimize_grid_to_tissue_aspect_distance",
                "ascending_n_x_then_n_y",
            ],
        },
        "expression": {
            "n_components": 30,
            "random_state": 0,
            "score_quantiles": [0.01, 0.99],
            "importance_transform": "winsorized_svd_leverage_divided_by_global_median",
            "max_weight_inflation": 4.0,
        },
        "methods": ["v2_1_coordinate_only", "v2_1_inference"],
        "evaluation_grid": {"n_x": 20, "n_y": 20},
        "calibration": {
            "fast_draws": 500,
            "confirmation_draws": 10_000,
            "wilson_confidence_level": 0.95,
            "zero_count_tail_probability": 1e-6,
            "fast_gate": {
                "minimum_wilson_coverage": 0.85,
                "maximum_absolute_mean_standardized_error": 0.5,
            },
        },
        "source_v2_design_sha256": design_hash,
    }
    config["config_sha256"] = canonical_hash(config)
    return config


def _validate_config(config: Mapping[str, Any]) -> None:
    stored = str(config.get("config_sha256", ""))
    content = dict(config)
    content.pop("config_sha256", None)
    if stored != canonical_hash(content):
        raise RuntimeError("Version 2.1 pilot configuration hash mismatch.")
    if (
        config["scenario"]["scenario_id"] != PILOT_SCENARIO_ID
        or int(config["n_cells"]) != PILOT_N_CELLS
        or int(config["target_n"]) != PILOT_TARGET_N
        or float(config["sampling_fraction"]) != PILOT_FRACTION
    ):
        raise RuntimeError("The Version 2.1 pilot is restricted to frozen S01 / 20,000 / 0.25% / n=50.")


def prepare_context(config: Mapping[str, Any]) -> PilotContext:
    """Deterministically rebuild the frozen S01 population and Version 2.1 plans."""
    _validate_config(config)
    timings: dict[str, float] = {}
    started = time.perf_counter()
    population = generate_population(
        config["scenario"], int(config["n_cells"]), seed=int(config["population_seed"])
    )
    timings["population_reconstruction_seconds"] = time.perf_counter() - started
    coordinates = np.asarray(population.coordinates, dtype=float)

    grid_config = config["candidate_grid"]
    started = time.perf_counter()
    partition = choose_adaptive_regular_partition(
        coordinates,
        int(config["target_n"]),
        minimum_quota=int(grid_config["minimum_quota"]),
        max_n_x=int(grid_config["max_n_x"]),
        max_n_y=int(grid_config["max_n_y"]),
    )
    timings["candidate_search_and_partition_seconds"] = time.perf_counter() - started

    started = time.perf_counter()
    allocation = allocate_largest_remainder_quotas(
        partition.stratum_audit,
        int(config["target_n"]),
        minimum_quota=int(grid_config["minimum_quota"]),
    )
    timings["quota_allocation_seconds"] = time.perf_counter() - started

    expression_config = config["expression"]
    started = time.perf_counter()
    representation = normalized_svd(
        population.expression,
        n_components=int(expression_config["n_components"]),
        random_state=int(expression_config["random_state"]),
        score_quantiles=tuple(float(value) for value in expression_config["score_quantiles"]),
    )
    timings["expression_importance_seconds"] = time.perf_counter() - started
    raw_score = np.asarray(representation.expression_score, dtype=float)
    transformed = raw_score / float(np.median(raw_score))
    if not np.all(np.isfinite(transformed)) or np.any(transformed <= 0):
        raise RuntimeError("deterministic expression-importance transformation must stay positive.")

    started = time.perf_counter()
    coordinate_plan = build_sampling_plan(
        partition.stratum_ids,
        allocation.quotas,
        representation.embedding,
        transformed,
        method="v2_1_coordinate_only",
        max_weight_inflation=float(expression_config["max_weight_inflation"]),
    )
    inference_plan = build_sampling_plan(
        partition.stratum_ids,
        allocation.quotas,
        representation.embedding,
        transformed,
        method="v2_1_inference",
        max_weight_inflation=float(expression_config["max_weight_inflation"]),
    )
    timings["inclusion_probability_construction_seconds"] = time.perf_counter() - started
    fixed_grid = np.asarray(
        rectangular_grid_bins(coordinates, n_x=20, n_y=20), dtype=object
    )
    return PilotContext(
        config=dict(config),
        expression=population.expression,
        coordinates=coordinates,
        embedding=np.asarray(representation.embedding, dtype=float),
        raw_expression_score=raw_score,
        transformed_expression_importance=transformed,
        partition=partition,
        allocation=allocation,
        coordinate_plan=coordinate_plan,
        inference_plan=inference_plan,
        fixed_evaluation_grid=fixed_grid,
        preparation_seconds=timings,
    )


def plans(context: PilotContext) -> tuple[SamplingPlan, SamplingPlan]:
    return context.coordinate_plan, context.inference_plan


def _atomic_csv(frame: pd.DataFrame, path: Path) -> None:
    if path.exists():
        raise FileExistsError(f"refusing to overwrite existing result: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temporary, index=False)
    temporary.replace(path)


def _atomic_json(payload: Mapping[str, Any], path: Path) -> None:
    if path.exists():
        raise FileExistsError(f"refusing to overwrite existing result: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def _stratum_lookup(context: PilotContext) -> pd.DataFrame:
    quota = context.allocation.audit.loc[
        :, [
            "spatial_stratum",
            "N_g",
            "ideal_continuous_quota",
            "base_quota",
            "largest_remainder",
            "q_g",
            "remaining_capacity",
            "quota_sum_error",
        ]
    ]
    return context.partition.stratum_audit.merge(
        quota,
        on=["spatial_stratum", "N_g"],
        how="left",
        validate="one_to_one",
    )


def cell_sampling_frame(
    context: PilotContext,
    plan: SamplingPlan,
    selected: np.ndarray,
    random_seed: int,
) -> pd.DataFrame:
    """Return every population cell with complete method-specific sampling metadata."""
    lookup = _stratum_lookup(context).set_index("spatial_stratum")
    strata = plan.spatial_strata.astype(str)
    frame = pd.DataFrame(
        {
            "cell_id": [f"S01_{index:05d}" for index in range(strata.size)],
            "selected": False,
            "spatial_stratum": strata,
            "fixed_evaluation_grid": context.fixed_evaluation_grid.astype(str),
            "x_coordinate": context.coordinates[:, 0],
            "y_coordinate": context.coordinates[:, 1],
            "N_g": [int(lookup.loc[item, "N_g"]) for item in strata],
            "q_g": [int(lookup.loc[item, "q_g"]) for item in strata],
            "inclusion_probability": plan.inclusion_probability,
            "sampling_weight": plan.sampling_weight,
            "raw_expression_importance": context.raw_expression_score,
            "expression_importance": plan.expression_importance,
            "probability_lower_bound": plan.lower_probability_bound,
            "probability_upper_bound": plan.upper_probability_bound,
            "probability_hits_lower_bound": np.isclose(
                plan.inclusion_probability, plan.lower_probability_bound, atol=1e-10, rtol=0
            ),
            "probability_hits_upper_bound": np.isclose(
                plan.inclusion_probability, plan.upper_probability_bound, atol=1e-10, rtol=0
            ),
            "method": plan.method,
            "random_seed": int(random_seed),
            "probability_solver": plan.probability_solver,
        }
    )
    frame.loc[selected, "selected"] = True
    return frame


def _selection_to_evaluation_audit(context: PilotContext) -> pd.DataFrame:
    frame = pd.DataFrame(
        {
            "spatial_stratum": context.partition.stratum_ids.astype(str),
            "fixed_evaluation_grid": context.fixed_evaluation_grid.astype(str),
        }
    )
    mapping = (
        frame.groupby("spatial_stratum", as_index=False)["fixed_evaluation_grid"]
        .nunique()
        .rename(columns={"fixed_evaluation_grid": "n_fixed_evaluation_grids_overlapped"})
    )
    return _stratum_lookup(context).merge(mapping, on="spatial_stratum", how="left")


def write_pilot_outputs(context: PilotContext, output_dir: Path) -> dict[str, object]:
    """Write the immutable machine-readable outputs for the one approved draw."""
    output_dir = Path(output_dir)
    completed_marker = output_dir / "pilot_audit.json"
    if completed_marker.exists():
        raise FileExistsError("Version 2.1 pilot is already complete; refusing to overwrite it.")
    output_dir.mkdir(parents=True, exist_ok=True)
    config_path = output_dir / "pilot_config.json"
    resuming_partial_output = config_path.exists()
    if resuming_partial_output:
        existing = json.loads(config_path.read_text(encoding="utf-8"))
        if existing.get("config_sha256") != context.config.get("config_sha256"):
            raise RuntimeError("partial pilot directory has a different frozen configuration.")
    else:
        _atomic_json(context.config, config_path)
    outputs = [
        (context.partition.candidate_audit, output_dir / "grid_candidate_audit.csv"),
        (context.partition.grid_cell_audit, output_dir / "final_grid_cell_audit.csv"),
        (_stratum_lookup(context), output_dir / "selection_strata_quota_audit.csv"),
        (_selection_to_evaluation_audit(context), output_dir / "selection_to_evaluation_grid_audit.csv"),
    ]
    for frame, path in outputs:
        if not path.exists():
            _atomic_csv(frame, path)

    method_frames: list[pd.DataFrame] = []
    selected_frames: list[pd.DataFrame] = []
    sampling_seconds: dict[str, float] = {}
    for plan in plans(context):
        started = time.perf_counter()
        selected = draw_fixed_size_sample(plan, random_seed=int(context.config["single_draw_seed"]))
        sampling_seconds[plan.method] = time.perf_counter() - started
        frame = cell_sampling_frame(context, plan, selected, int(context.config["single_draw_seed"]))
        method_frames.append(frame)
        selected_frames.append(frame.loc[frame["selected"]].copy())
    cell_frame_path = output_dir / "cell_sampling_frame.csv"
    if not cell_frame_path.exists():
        _atomic_csv(pd.concat(method_frames, ignore_index=True), cell_frame_path)
    selected_path = output_dir / "single_draw_selected_cells.csv"
    if not selected_path.exists():
        _atomic_csv(pd.concat(selected_frames, ignore_index=True), selected_path)

    bounds = {
        "x_min": float(context.coordinates[:, 0].min()),
        "x_max": float(context.coordinates[:, 0].max()),
        "y_min": float(context.coordinates[:, 1].min()),
        "y_max": float(context.coordinates[:, 1].max()),
    }
    audit = {
        "scenario_id": PILOT_SCENARIO_ID,
        "N": int(context.coordinates.shape[0]),
        "target_n": int(context.config["target_n"]),
        "sampling_fraction": float(context.config["sampling_fraction"]),
        "coordinate_bounds": bounds,
        "candidate_grid_count": int(len(context.partition.candidate_audit)),
        "final_grid_n_x": int(context.partition.n_x),
        "final_grid_n_y": int(context.partition.n_y),
        "final_n_nonempty_strata": int(len(context.partition.stratum_audit)),
        "final_n_empty_grid_cells": int((~context.partition.grid_cell_audit["is_nonempty"]).sum()),
        "selection_reason": context.partition.selection_reason,
        "quota_sum": int(sum(context.allocation.quotas.values())),
        "preparation_seconds": context.preparation_seconds,
        "single_draw_sampling_seconds": sampling_seconds,
        "sampling_weight_definition": "1 / inclusion_probability",
        "fixed_20x20_grid_role": "evaluation_only",
    }
    recovery_path = output_dir / "pilot_execution_recovery.json"
    if resuming_partial_output and not recovery_path.exists():
        _atomic_json(
            {
                "status": "resumed_after_precompletion_output_error",
                "reason": "The first write attempt stopped before pilot_audit.json due to a Pandas merge-argument compatibility error. Existing files were retained and configuration hash was checked before resuming.",
                "config_sha256": context.config["config_sha256"],
            },
            recovery_path,
        )
    _atomic_json(audit, completed_marker)
    return audit


def peak_memory_mib() -> float:
    try:
        import psutil

        return float(psutil.Process(os.getpid()).memory_info().rss / (1024 * 1024))
    except Exception:
        return float("nan")


__all__ = [
    "CALIBRATION_SEED_BASE",
    "PILOT_DRAW_SEED",
    "PILOT_FRACTION",
    "PILOT_N_CELLS",
    "PILOT_POPULATION_SEED",
    "PILOT_SCENARIO_ID",
    "PILOT_TARGET_N",
    "PilotContext",
    "build_pilot_config",
    "cell_sampling_frame",
    "peak_memory_mib",
    "plans",
    "prepare_context",
    "write_pilot_outputs",
]
