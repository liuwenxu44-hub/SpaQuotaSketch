"""Preregistered inference utility-boundary helpers for Version 2.1."""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass, replace
from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd

from ..spatial_bins import rectangular_grid_bins
from ..v2.expression import normalized_svd
from ..v2.inference import _pivotal_update
from ..v2.simulation_stress import generate_population
from .quota import QuotaAllocation, allocate_largest_remainder_quotas
from .sampling import SamplingPlan, build_sampling_plan
from .spatial import AdaptiveSpatialPartition, choose_adaptive_regular_partition


@dataclass(frozen=True)
class UtilityPopulation:
    expression: Any
    coordinates: np.ndarray
    true_state: np.ndarray
    rare_mask: np.ndarray
    gradient: np.ndarray
    library_factor: np.ndarray
    technical_noise_score: np.ndarray
    gene_roles: tuple[str, ...]
    metadata: dict[str, Any]


@dataclass(frozen=True)
class TargetPanel:
    names: tuple[str, ...]
    target_groups: tuple[str, ...]
    numerators: np.ndarray
    domains: np.ndarray
    reference_totals: np.ndarray
    reference_means: np.ndarray
    metadata: pd.DataFrame


@dataclass(frozen=True)
class PreparedUtilityScenario:
    population: UtilityPopulation
    embedding: np.ndarray
    raw_expression_score: np.ndarray
    expression_importance: np.ndarray
    target_panel: TargetPanel
    fixed_evaluation_grid: np.ndarray
    fixed_evaluation_grid_codes: np.ndarray
    n_fixed_evaluation_grids: int
    state_names: tuple[str, ...]
    state_codes: np.ndarray
    state_proportions: np.ndarray
    state_grid_proportions: np.ndarray
    gene_zero: np.ndarray
    population_gradient_correlation: float


def canonical_hash(payload: Mapping[str, Any]) -> str:
    content = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def target_size(n_cells: int, fraction: float) -> int:
    return max(1, min(int(n_cells), int(round(int(n_cells) * float(fraction)))))


def validate_design(design: Mapping[str, Any]) -> None:
    content = dict(design)
    stored = str(content.pop("design_sha256", ""))
    if stored != canonical_hash(content):
        raise RuntimeError("Frozen utility-boundary design hash mismatch.")
    if int(design["n_cells"]) != 20_000:
        raise RuntimeError("The utility-boundary pilot is restricted to N=20,000.")
    if [float(value) for value in design["sampling_fractions"]] != [0.0025, 0.01, 0.05]:
        raise RuntimeError("Only 0.25%, 1%, and 5% are permitted in this pilot.")
    if [float(value) for value in design["lambdas"]] != [0.0, 0.25, 0.5, 0.75, 1.0]:
        raise RuntimeError("The preregistered lambda grid has changed.")
    expected = {"U0", "E1", "E2", "E3_scattered", "E3_multicluster", "E4_weak", "E4_strong"}
    observed = {str(row["scenario_id"]) for row in design["scenarios"]}
    if observed != expected:
        raise RuntimeError("The preregistered utility-boundary scenarios have changed.")
    if int(design["repeats"]["screening"]) < 500 or int(design["repeats"]["confirmation"]) < 5_000:
        raise RuntimeError("The preregistered repeat counts are too small.")


def _exact_labels(
    n_cells: int,
    probabilities: Sequence[float],
    rng: np.random.Generator,
) -> np.ndarray:
    probabilities = np.asarray(probabilities, dtype=float)
    probabilities = probabilities / probabilities.sum()
    counts = np.floor(probabilities * n_cells).astype(int)
    counts[: n_cells - int(counts.sum())] += 1
    labels = np.concatenate(
        [np.full(count, f"state_{index}", dtype=object) for index, count in enumerate(counts)]
    )
    return labels[rng.permutation(n_cells)]


def _clustered_state_labels(
    coordinates: np.ndarray,
    probabilities: Sequence[float],
    rng: np.random.Generator,
) -> np.ndarray:
    n_cells = coordinates.shape[0]
    probabilities = np.asarray(probabilities, dtype=float)
    probabilities = probabilities / probabilities.sum()
    counts = np.floor(probabilities * n_cells).astype(int)
    counts[: n_cells - int(counts.sum())] += 1
    minority_count = int(counts[-1])
    centers = np.asarray([[0.25, 0.30], [0.76, 0.70]], dtype=float)
    distance = np.square(coordinates[:, None, :] - centers[None, :, :]).sum(axis=2).min(axis=1)
    score = np.exp(-distance / 0.018)
    clustered_count = int(round(0.70 * minority_count))
    jitter = rng.uniform(0.0, 1e-10, n_cells)
    clustered = np.argsort(-(score + jitter), kind="stable")[:clustered_count]
    remaining = np.setdiff1d(np.arange(n_cells), clustered, assume_unique=False)
    scattered = rng.choice(remaining, size=minority_count - clustered_count, replace=False)
    minority = np.concatenate([clustered, scattered])
    labels = np.empty(n_cells, dtype=object)
    labels[minority] = f"state_{len(counts) - 1}"
    remainder = np.setdiff1d(np.arange(n_cells), minority, assume_unique=False)
    other = np.concatenate(
        [np.full(count, f"state_{index}", dtype=object) for index, count in enumerate(counts[:-1])]
    )
    labels[remainder] = other[rng.permutation(other.size)]
    return labels


def _rare_positions(
    coordinates: np.ndarray,
    count: int,
    structure: str,
    rng: np.random.Generator,
) -> np.ndarray:
    n_cells = coordinates.shape[0]
    selected = np.sort(rng.choice(n_cells, size=count, replace=False))
    if structure == "scattered":
        return selected
    if structure == "multiple_clusters":
        centers = np.asarray([[0.18, 0.24], [0.80, 0.27], [0.31, 0.78], [0.76, 0.73]])
        assignment = rng.integers(0, centers.shape[0], size=count)
        coordinates[selected] = np.clip(
            centers[assignment] + rng.normal(0.0, 0.012, size=(count, 2)), 0.0001, 0.9999
        )
        return selected
    raise ValueError(f"Unsupported rare spatial structure: {structure}")


def _gene_roles(n_genes: int, scenario: Mapping[str, Any]) -> tuple[str, ...]:
    roles = np.asarray(["ubiquitous"] * n_genes, dtype=object)
    roles[12:20] = "weak_or_noise"
    if str(scenario["scenario_id"]).startswith("E4"):
        roles[:8] = "spatial_gradient"
    elif str(scenario["scenario_id"]).startswith("E3"):
        roles[:8] = "rare_state_signal"
        roles[8:12] = "rare_state_inverse_signal"
    elif str(scenario["scenario_id"]) in {"E1", "E2"}:
        roles[:12] = "common_state_signal"
    return tuple(str(value) for value in roles)


def _generate_custom_population(
    scenario: Mapping[str, Any], n_cells: int, seed: int
) -> UtilityPopulation:
    from scipy import sparse

    rng = np.random.default_rng(int(seed))
    n_genes = int(scenario["n_genes"])
    coordinates = rng.uniform(0.0, 1.0, size=(n_cells, 2)).astype(np.float32)
    scenario_id = str(scenario["scenario_id"])
    state_probabilities = scenario.get("state_probabilities", [1.0])
    if scenario_id == "E2":
        true_state = _clustered_state_labels(coordinates, state_probabilities, rng)
    elif scenario_id.startswith("E4"):
        true_state = np.full(n_cells, "continuous", dtype=object)
    else:
        true_state = _exact_labels(n_cells, state_probabilities, rng)

    rare_mask = np.zeros(n_cells, dtype=bool)
    rare_frequency = float(scenario.get("rare_frequency", 0.0))
    if rare_frequency:
        rare_count = int(round(n_cells * rare_frequency))
        rare_index = _rare_positions(
            coordinates,
            rare_count,
            str(scenario["rare_spatial_structure"]),
            rng,
        )
        rare_mask[rare_index] = True
        true_state[rare_mask] = "rare"

    base = rng.normal(0.15, 0.18, n_genes).astype(np.float32)
    log_rate = np.broadcast_to(base, (n_cells, n_genes)).copy()
    state_strength = float(scenario.get("state_effect_strength", 0.0))
    nonrare_states = sorted(set(true_state[~rare_mask].tolist()))
    for state_index, state in enumerate(nonrare_states):
        if state == "continuous":
            continue
        mask = true_state == state
        start = (state_index * 3) % 12
        log_rate[mask, start : start + 4] += state_strength
        inverse_start = 16 + (state_index * 2) % max(2, n_genes - 18)
        log_rate[mask, inverse_start : min(inverse_start + 2, n_genes)] -= 0.35 * state_strength

    gradient_axis = str(scenario.get("gradient_axis", "linear_x"))
    if gradient_axis == "nonlinear_arc":
        gradient = np.sin(np.pi * coordinates[:, 0]) * (0.35 + 0.65 * coordinates[:, 1])
    else:
        gradient = coordinates[:, 0]
    gradient = (gradient - gradient.mean()) / (gradient.std() + 1e-12)
    gradient_strength = float(scenario.get("gradient_strength", 0.0))
    if gradient_strength:
        loadings = np.linspace(1.0, 0.35, 8, dtype=np.float32)
        log_rate[:, :8] += gradient_strength * gradient[:, None] * loadings[None, :]

    rare_strength = float(scenario.get("rare_separation_strength", 0.0))
    if rare_mask.any():
        log_rate[rare_mask, :8] += rare_strength
        log_rate[rare_mask, 8:12] -= 0.55 * rare_strength

    technical_noise_score = rng.normal(0.0, float(scenario["technical_noise_sd"]), n_cells)
    feature_noise = rng.normal(
        0.0,
        float(scenario["technical_noise_sd"]),
        size=(n_cells, n_genes),
    ).astype(np.float32)
    log_rate += feature_noise
    library_factor = rng.lognormal(0.0, float(scenario["library_log_sd"]), n_cells).astype(np.float32)
    rates = np.exp(np.clip(log_rate, -4.0, 3.8)) * library_factor[:, None]
    counts = rng.poisson(rates).astype(np.int32, copy=False)
    dropout = float(scenario["dropout_probability"])
    if dropout:
        remove = rng.random(counts.shape) < dropout * counts / (counts + 1.0)
        counts[remove] = 0
    expression = sparse.csr_matrix(counts)
    roles = _gene_roles(n_genes, scenario)
    metadata = {
        "scenario_id": scenario_id,
        "n_cells": int(n_cells),
        "n_genes": int(n_genes),
        "rare_count": int(rare_mask.sum()),
        "rare_frequency_realized": float(rare_mask.mean()),
        "population_seed": int(seed),
        "generator": "utility_boundary_custom_v1",
    }
    return UtilityPopulation(
        expression=expression,
        coordinates=np.asarray(coordinates, dtype=float),
        true_state=true_state,
        rare_mask=rare_mask,
        gradient=np.asarray(gradient, dtype=float),
        library_factor=np.asarray(library_factor, dtype=float),
        technical_noise_score=np.asarray(technical_noise_score, dtype=float),
        gene_roles=roles,
        metadata=metadata,
    )


def generate_utility_population(
    scenario: Mapping[str, Any],
    n_cells: int,
    *,
    seed: int,
    source_s01: Mapping[str, Any] | None = None,
) -> UtilityPopulation:
    """Generate one frozen utility-boundary population without using labels in sampling."""
    if str(scenario["scenario_id"]) != "U0":
        return _generate_custom_population(scenario, n_cells, seed)
    if source_s01 is None:
        raise ValueError("U0 requires the frozen S01 scenario definition.")
    source = generate_population(source_s01, n_cells, seed=int(seed))
    total = np.asarray(source.expression.sum(axis=1)).reshape(-1).astype(float)
    centered = np.log1p(total) - np.log1p(total).mean()
    metadata = dict(source.metadata)
    metadata.update({"scenario_id": "U0", "generator": "frozen_S01_exact"})
    return UtilityPopulation(
        expression=source.expression,
        coordinates=np.asarray(source.coordinates, dtype=float),
        true_state=np.asarray(source.true_state, dtype=object),
        rare_mask=np.asarray(source.rare_mask, dtype=bool),
        gradient=np.asarray(source.gradient, dtype=float),
        library_factor=np.exp(centered),
        technical_noise_score=np.zeros(n_cells, dtype=float),
        gene_roles=tuple(["weak_or_noise"] * source.expression.shape[1]),
        metadata=metadata,
    )


def _safe_correlation(first: np.ndarray, second: np.ndarray) -> float:
    first = np.asarray(first, dtype=float)
    second = np.asarray(second, dtype=float)
    if first.size < 2 or first.std() == 0 or second.std() == 0:
        return 0.0
    value = float(np.corrcoef(first, second)[0, 1])
    return value if np.isfinite(value) else 0.0


def build_target_panel(
    population: UtilityPopulation,
    importance: np.ndarray,
    fixed_genes: Sequence[int],
) -> TargetPanel:
    matrix = population.expression
    n_cells, n_genes = matrix.shape
    names: list[str] = []
    groups: list[str] = []
    numerators: list[np.ndarray] = []
    domains: list[np.ndarray] = []
    records: list[dict[str, Any]] = []
    all_cells = np.ones(n_cells, dtype=float)

    def add(name: str, group: str, numerator: np.ndarray, domain: np.ndarray, feature: int | None = None) -> None:
        numerator = np.asarray(numerator, dtype=float).reshape(-1)
        domain = np.asarray(domain, dtype=float).reshape(-1)
        correlation = _safe_correlation(importance, numerator)
        names.append(name)
        groups.append(group)
        numerators.append(numerator)
        domains.append(domain)
        records.append(
            {
                "target": name,
                "target_group": group,
                "feature_index": feature,
                "importance_contribution_correlation": correlation,
                "reference_total": float(numerator.sum()),
                "reference_mean": float(numerator.sum() / max(domain.sum(), 1.0)),
            }
        )

    total = np.asarray(matrix.sum(axis=1)).reshape(-1).astype(float)
    detected = np.asarray((matrix > 0).sum(axis=1)).reshape(-1).astype(float)
    add("cell_total_expression", "technical_total", total, all_cells)
    add("detected_feature_count", "technical_total", detected, all_cells)
    for gene in sorted({int(value) for value in fixed_genes if 0 <= int(value) < n_genes}):
        values = np.asarray(matrix[:, gene].toarray()).reshape(-1).astype(float)
        add(f"gene_{gene:03d}_mean", population.gene_roles[gene], values, all_cells, gene)
    for state in sorted(set(population.true_state.tolist())):
        indicator = (population.true_state == state).astype(float)
        group = "rare_state_proportion" if state == "rare" else "state_proportion"
        add(f"proportion_{state}", group, indicator, all_cells)
    if str(population.metadata["scenario_id"]).startswith("E4"):
        gene = 0
        values = np.asarray(matrix[:, gene].toarray()).reshape(-1).astype(float)
        low = (population.gradient <= np.median(population.gradient)).astype(float)
        high = 1.0 - low
        add("gradient_gene_000_low_domain_mean", "spatial_gradient_local", values * low, low, gene)
        add("gradient_gene_000_high_domain_mean", "spatial_gradient_local", values * high, high, gene)

    frame = pd.DataFrame.from_records(records)
    absolute = frame["importance_contribution_correlation"].abs().to_numpy(float)
    lower, upper = np.quantile(absolute, [1 / 3, 2 / 3]) if absolute.size else (0.0, 0.0)
    frame["importance_relationship_group"] = np.where(
        absolute <= lower,
        "weak_or_none",
        np.where(absolute <= upper, "moderate", "high"),
    )
    numerator_array = np.vstack(numerators)
    domain_array = np.vstack(domains)
    return TargetPanel(
        names=tuple(names),
        target_groups=tuple(groups),
        numerators=numerator_array,
        domains=domain_array,
        reference_totals=numerator_array.sum(axis=1),
        reference_means=np.divide(
            numerator_array.sum(axis=1),
            domain_array.sum(axis=1),
            out=np.full(len(names), np.nan),
            where=domain_array.sum(axis=1) > 0,
        ),
        metadata=frame,
    )


def prepare_utility_scenario(
    design: Mapping[str, Any], scenario: Mapping[str, Any]
) -> PreparedUtilityScenario:
    source_s01 = design["source_s01"] if str(scenario["scenario_id"]) == "U0" else None
    population = generate_utility_population(
        scenario,
        int(design["n_cells"]),
        seed=int(scenario["population_seed"]),
        source_s01=source_s01,
    )
    expression = design["expression_importance"]
    representation = normalized_svd(
        population.expression,
        n_components=int(expression["n_components"]),
        random_state=int(expression["random_state"]),
        score_quantiles=tuple(float(value) for value in expression["score_quantiles"]),
    )
    raw = np.asarray(representation.expression_score, dtype=float)
    importance = raw / float(np.median(raw))
    if not np.isfinite(importance).all() or np.any(importance <= 0):
        raise RuntimeError("Expression importance must stay finite and positive.")
    panel = build_target_panel(population, importance, design["target_panel"]["fixed_genes"])
    fixed_grid = np.asarray(
        rectangular_grid_bins(population.coordinates, n_x=20, n_y=20), dtype=object
    )
    fixed_names, fixed_codes = np.unique(fixed_grid, return_inverse=True)
    state_names, state_codes = np.unique(population.true_state, return_inverse=True)
    state_counts = np.bincount(state_codes, minlength=state_names.size).astype(float)
    state_proportions = state_counts / state_counts.sum()
    state_grid = np.zeros((state_names.size, fixed_names.size), dtype=float)
    for state_index in range(state_names.size):
        counts = np.bincount(
            fixed_codes[state_codes == state_index], minlength=fixed_names.size
        ).astype(float)
        state_grid[state_index] = counts / counts.sum()
    gene_zero = np.asarray(population.expression[:, 0].toarray()).reshape(-1).astype(float)
    return PreparedUtilityScenario(
        population=population,
        embedding=np.asarray(representation.embedding, dtype=float),
        raw_expression_score=raw,
        expression_importance=importance,
        target_panel=panel,
        fixed_evaluation_grid=fixed_grid,
        fixed_evaluation_grid_codes=fixed_codes.astype(int),
        n_fixed_evaluation_grids=int(fixed_names.size),
        state_names=tuple(str(value) for value in state_names),
        state_codes=state_codes.astype(int),
        state_proportions=state_proportions,
        state_grid_proportions=state_grid,
        gene_zero=gene_zero,
        population_gradient_correlation=_safe_correlation(population.gradient, gene_zero),
    )


def prepare_partition_and_full_plan(
    prepared: PreparedUtilityScenario,
    target_n: int,
    *,
    max_weight_inflation: float,
) -> tuple[AdaptiveSpatialPartition, QuotaAllocation, SamplingPlan]:
    partition = choose_adaptive_regular_partition(
        prepared.population.coordinates,
        int(target_n),
        minimum_quota=1,
        max_n_x=20,
        max_n_y=20,
    )
    allocation = allocate_largest_remainder_quotas(partition.stratum_audit, int(target_n))
    full = build_sampling_plan(
        partition.stratum_ids,
        allocation.quotas,
        prepared.embedding,
        prepared.expression_importance,
        method="v2_1_inference",
        max_weight_inflation=float(max_weight_inflation),
    )
    return partition, allocation, full


def _correct_probability_sum(
    probability: np.ndarray,
    lower: np.ndarray,
    upper: np.ndarray,
    target: int,
) -> np.ndarray:
    output = np.asarray(probability, dtype=float).copy()
    residual = float(target - output.sum())
    if abs(residual) <= 1e-12:
        return output
    room = upper - output if residual > 0 else output - lower
    for index in np.argsort(-room, kind="stable"):
        adjustment = math.copysign(min(abs(residual), float(room[index])), residual)
        output[index] += adjustment
        residual -= adjustment
        if abs(residual) <= 1e-12:
            break
    if abs(residual) > 1e-9:
        raise RuntimeError("Unable to correct a mixed probability vector to its exact quota.")
    return output


def mixed_sampling_plan(full_plan: SamplingPlan, mixing_lambda: float) -> SamplingPlan:
    """Mix uniform and full-expression probabilities within each fixed stratum.

    For stratum g, u_i=q_g/N_g and e_i is the bounded full-expression
    probability. The sensitivity plan is p_i(lambda)=(1-lambda)u_i+lambda e_i.
    Both endpoints sum to q_g, so the convex mixture also sums to q_g. Only a
    deterministic floating-point residual correction is applied.
    """
    value = float(mixing_lambda)
    if not 0.0 <= value <= 1.0:
        raise ValueError("mixing_lambda must lie in [0, 1].")
    inclusion = np.zeros_like(full_plan.inclusion_probability)
    lower = np.zeros_like(inclusion)
    upper = np.zeros_like(inclusion)
    for stratum in sorted(full_plan.positions_by_stratum):
        positions = full_plan.positions_by_stratum[stratum]
        quota = int(full_plan.quotas[stratum])
        uniform = np.full(positions.size, quota / positions.size, dtype=float)
        expression = full_plan.inclusion_probability[positions]
        local_lower = (1.0 - value) * uniform + value * full_plan.lower_probability_bound[positions]
        local_upper = (1.0 - value) * uniform + value * full_plan.upper_probability_bound[positions]
        probability = (1.0 - value) * uniform + value * expression
        probability = _correct_probability_sum(probability, local_lower, local_upper, quota)
        inclusion[positions] = probability
        lower[positions] = local_lower
        upper[positions] = local_upper
        if not np.isclose(probability.sum(), quota, atol=1e-9, rtol=0):
            raise RuntimeError("Mixed inclusion probabilities do not sum to the stratum quota.")
    if np.any(inclusion <= 0) or np.any(inclusion > 1):
        raise RuntimeError("Mixed inclusion probabilities left the valid range.")
    label = f"lambda_{value:.2f}".replace(".", "p")
    return replace(
        full_plan,
        method=label,
        inclusion_probability=inclusion,
        sampling_weight=1.0 / inclusion,
        lower_probability_bound=lower,
        upper_probability_bound=upper,
        probability_solver="convex_uniform_expression_probability_mixture",
    )


def _equivalent_local_pivotal_sample(
    probability: np.ndarray,
    edge_order: Sequence[tuple[float, int, int]],
    *,
    seed: int,
    tolerance: float = 1e-10,
) -> np.ndarray:
    """Return the same pivotal draw while stopping after all useful edges.

    The historical routine scans every cached edge even after fewer than two
    fractional probabilities remain. Those trailing checks cannot update a
    probability or consume randomness. Tracking the active count is therefore
    bitwise equivalent for a fixed seed.
    """
    original = np.asarray(probability, dtype=float).reshape(-1)
    target = int(round(float(original.sum())))
    if not np.isclose(original.sum(), target, atol=1e-9, rtol=0):
        raise RuntimeError("Pivotal sampling requires an integer probability sum.")
    work = original.copy()
    rng = np.random.default_rng(int(seed))

    def active(index: int) -> bool:
        return tolerance < work[index] < 1.0 - tolerance

    active_count = int(np.sum((work > tolerance) & (work < 1.0 - tolerance)))
    for _, first, second in edge_order:
        if active_count < 2:
            break
        if active(first) and active(second):
            before = int(active(first)) + int(active(second))
            _pivotal_update(work, first, second, rng, tolerance)
            after = int(active(first)) + int(active(second))
            active_count += after - before

    remaining = [index for index in range(work.size) if active(index)]
    while len(remaining) >= 2:
        first, second = remaining[0], remaining[1]
        _pivotal_update(work, first, second, rng, tolerance)
        remaining = [index for index in remaining if active(index)]
    if remaining:
        index = remaining[0]
        if work[index] <= tolerance:
            work[index] = 0.0
        elif work[index] >= 1.0 - tolerance:
            work[index] = 1.0
        else:
            raise RuntimeError("One unresolved pivotal probability remained.")
    work[work <= tolerance] = 0.0
    work[work >= 1.0 - tolerance] = 1.0
    selected = np.flatnonzero(work == 1.0)
    if selected.size != target:
        raise RuntimeError("Equivalent pivotal sampling violated the fixed sample size.")
    return selected.astype(int)


def draw_fixed_size_sample_equivalent(plan: SamplingPlan, *, random_seed: int) -> np.ndarray:
    """Draw the exact historical sample with an equivalent early-stop check."""
    selected_parts: list[np.ndarray] = []
    master_rng = np.random.default_rng(int(random_seed))
    for order, stratum in enumerate(sorted(plan.positions_by_stratum)):
        positions = plan.positions_by_stratum[stratum]
        probability = plan.inclusion_probability[positions]
        quota = int(plan.quotas[stratum])
        local_seed = int(
            np.random.SeedSequence([int(random_seed), int(order)]).generate_state(1)[0]
        )
        if quota == positions.size:
            local = np.arange(positions.size, dtype=int)
        elif quota == 1:
            local = np.asarray(
                [master_rng.choice(positions.size, p=probability)], dtype=int
            )
        else:
            local = _equivalent_local_pivotal_sample(
                probability,
                plan.local_edges_by_stratum[stratum],
                seed=local_seed,
            )
        if local.size != quota:
            raise RuntimeError("Equivalent sampler violated a local spatial quota.")
        selected_parts.append(positions[local])
    selected = np.sort(np.concatenate(selected_parts))
    if selected.size != int(sum(plan.quotas.values())) or np.unique(selected).size != selected.size:
        raise RuntimeError("Equivalent sampler violated the global fixed sample size.")
    return selected


def estimate_target_panel(
    selected: np.ndarray,
    plan: SamplingPlan,
    panel: TargetPanel,
) -> dict[str, np.ndarray]:
    selected = np.asarray(selected, dtype=int)
    weights = plan.sampling_weight[selected]
    numerator = panel.numerators[:, selected]
    domain = panel.domains[:, selected]
    unweighted_denominator = domain.sum(axis=1)
    weighted_denominator = domain @ weights
    return {
        "unweighted_mean": np.divide(
            numerator.sum(axis=1),
            unweighted_denominator,
            out=np.full(len(panel.names), np.nan),
            where=unweighted_denominator > 0,
        ),
        "HT_total": numerator @ weights,
        "Hajek_mean": np.divide(
            numerator @ weights,
            weighted_denominator,
            out=np.full(len(panel.names), np.nan),
            where=weighted_denominator > 0,
        ),
    }


def _top_weight_share(weights: np.ndarray, fraction: float) -> float:
    count = max(1, int(math.ceil(weights.size * fraction)))
    ordered = np.sort(weights)
    return float(ordered[-count:].sum() / ordered.sum())


def _state_spatial_error(prepared: PreparedUtilityScenario, selected: np.ndarray) -> float:
    errors: list[float] = []
    selected_states = prepared.state_codes[selected]
    selected_grids = prepared.fixed_evaluation_grid_codes[selected]
    for state_index in range(len(prepared.state_names)):
        sampled = selected_states == state_index
        if not np.any(sampled):
            errors.append(1.0)
            continue
        sample_count = np.bincount(
            selected_grids[sampled], minlength=prepared.n_fixed_evaluation_grids
        ).astype(float)
        sample_count /= sample_count.sum()
        errors.append(float(np.abs(prepared.state_grid_proportions[state_index] - sample_count).sum()))
    return float(np.mean(errors)) if errors else 0.0


def repeat_diagnostics(
    prepared: PreparedUtilityScenario,
    plan: SamplingPlan,
    selected: np.ndarray,
) -> dict[str, float]:
    population = prepared.population
    weights = plan.sampling_weight[selected]
    median = float(np.median(weights))
    selected_states = prepared.state_codes[selected]
    sample_proportions = np.bincount(
        selected_states, minlength=len(prepared.state_names)
    ).astype(float) / selected.size
    weighted_proportions = np.bincount(
        selected_states, weights=weights, minlength=len(prepared.state_names)
    ).astype(float) / weights.sum()
    state_l1 = float(np.abs(sample_proportions - prepared.state_proportions).sum())
    weighted_state_l1 = float(np.abs(weighted_proportions - prepared.state_proportions).sum())
    sample_gradient_correlation = _safe_correlation(
        population.gradient[selected], prepared.gene_zero[selected]
    )
    return {
        "selected_n": int(selected.size),
        "expression_state_coverage": float(
            np.unique(selected_states).size / len(prepared.state_names)
        ),
        "rare_selected_count": int(population.rare_mask[selected].sum()),
        "rare_state_retained": float(population.rare_mask[selected].any()),
        "fixed_20x20_grid_coverage": float(
            np.unique(prepared.fixed_evaluation_grid_codes[selected]).size
            / prepared.n_fixed_evaluation_grids
        ),
        "same_state_spatial_distribution_error": _state_spatial_error(prepared, selected),
        "state_proportion_l1_unweighted": float(state_l1),
        "state_proportion_l1_hajek": float(weighted_state_l1),
        "gradient_correlation_absolute_error": float(
            abs(sample_gradient_correlation - prepared.population_gradient_correlation)
        ),
        "weight_max": float(weights.max()),
        "weight_cv": float(weights.std(ddof=0) / weights.mean()),
        "weight_max_to_median": float(weights.max() / median),
        "kish_ess": float(weights.sum() ** 2 / np.square(weights).sum()),
        "ess_over_n": float(weights.sum() ** 2 / np.square(weights).sum() / weights.size),
        "top_1pct_weight_share": _top_weight_share(weights, 0.01),
        "top_5pct_weight_share": _top_weight_share(weights, 0.05),
        "top_10pct_weight_share": _top_weight_share(weights, 0.10),
    }


def probability_diagnostics(
    plan: SamplingPlan,
    mixing_lambda: float,
    scenario_id: str,
    fraction: float,
) -> dict[str, Any]:
    probability = plan.inclusion_probability
    weights = plan.sampling_weight
    return {
        "scenario_id": scenario_id,
        "sampling_fraction": float(fraction),
        "target_n": int(sum(plan.quotas.values())),
        "lambda": float(mixing_lambda),
        "method": plan.method,
        "inclusion_probability_min": float(probability.min()),
        "inclusion_probability_q01": float(np.quantile(probability, 0.01)),
        "inclusion_probability_median": float(np.median(probability)),
        "inclusion_probability_q99": float(np.quantile(probability, 0.99)),
        "inclusion_probability_max": float(probability.max()),
        "population_weight_max": float(weights.max()),
        "population_weight_cv": float(weights.std(ddof=0) / weights.mean()),
        "population_weight_max_to_median": float(weights.max() / np.median(weights)),
        "lower_bound_hit_fraction": float(
            np.mean(np.isclose(probability, plan.lower_probability_bound, atol=1e-10, rtol=0))
        ),
        "upper_bound_hit_fraction": float(
            np.mean(np.isclose(probability, plan.upper_probability_bound, atol=1e-10, rtol=0))
        ),
        "minimum_local_probability_sum_error": float(
            min(
                abs(probability[pos].sum() - plan.quotas[stratum])
                for stratum, pos in plan.positions_by_stratum.items()
            )
        ),
        "maximum_local_probability_sum_error": float(
            max(
                abs(probability[pos].sum() - plan.quotas[stratum])
                for stratum, pos in plan.positions_by_stratum.items()
            )
        ),
    }


def _eta_squared(values: np.ndarray, groups: np.ndarray) -> float:
    grand = float(values.mean())
    total = float(np.square(values - grand).sum())
    if total <= 0:
        return 0.0
    between = 0.0
    for group in sorted(set(groups.tolist())):
        subset = values[groups == group]
        between += subset.size * float(subset.mean() - grand) ** 2
    return float(between / total)


def _rare_auc(values: np.ndarray, rare: np.ndarray) -> float:
    if not rare.any() or rare.all():
        return float("nan")
    from scipy.stats import rankdata

    ranks = rankdata(values, method="average")
    positive = int(rare.sum())
    negative = int((~rare).sum())
    return float((ranks[rare].sum() - positive * (positive + 1) / 2) / (positive * negative))


def population_and_importance_diagnostics(
    prepared: PreparedUtilityScenario,
    scenario_id: str,
) -> tuple[dict[str, Any], pd.DataFrame]:
    from sklearn.neighbors import NearestNeighbors

    population = prepared.population
    matrix = population.expression
    dense_means = np.asarray(matrix.mean(axis=0)).reshape(-1).astype(float)
    dense_squared = np.asarray(matrix.power(2).mean(axis=0)).reshape(-1).astype(float)
    variances = np.maximum(dense_squared - np.square(dense_means), 0.0)
    neighbors = NearestNeighbors(n_neighbors=9).fit(population.coordinates)
    indices = neighbors.kneighbors(return_distance=False)[:, 1:]
    same = (population.true_state[indices] == population.true_state[:, None]).mean()
    state_frequency = pd.Series(population.true_state).value_counts(normalize=True)
    random_same = float(np.square(state_frequency.to_numpy(float)).sum())
    embedding_coordinate = max(
        abs(_safe_correlation(prepared.embedding[:, component], population.coordinates[:, axis]))
        for component in range(min(8, prepared.embedding.shape[1]))
        for axis in range(2)
    )
    importance = prepared.expression_importance
    total = np.asarray(matrix.sum(axis=1)).reshape(-1).astype(float)
    detected = np.asarray((matrix > 0).sum(axis=1)).reshape(-1).astype(float)
    high_importance = importance >= np.quantile(importance, 0.99)
    technical_anomaly = (total >= np.quantile(total, 0.99)) | (detected >= np.quantile(detected, 0.99))
    diagnostics = {
        **population.metadata,
        "scenario_id": scenario_id,
        "state_proportions_json": json.dumps(state_frequency.sort_index().to_dict(), sort_keys=True),
        "expression_separation_eta_squared": _eta_squared(importance, population.true_state),
        "spatial_same_state_neighbor_excess": float(same - random_same),
        "maximum_embedding_coordinate_absolute_correlation": float(embedding_coordinate),
        "expression_sparsity": float(1.0 - matrix.nnz / (matrix.shape[0] * matrix.shape[1])),
        "feature_variance_min": float(variances.min()),
        "feature_variance_q25": float(np.quantile(variances, 0.25)),
        "feature_variance_median": float(np.median(variances)),
        "feature_variance_q75": float(np.quantile(variances, 0.75)),
        "feature_variance_max": float(variances.max()),
        "importance_min": float(importance.min()),
        "importance_q01": float(np.quantile(importance, 0.01)),
        "importance_q25": float(np.quantile(importance, 0.25)),
        "importance_median": float(np.median(importance)),
        "importance_q75": float(np.quantile(importance, 0.75)),
        "importance_q99": float(np.quantile(importance, 0.99)),
        "importance_max": float(importance.max()),
        "importance_cv": float(importance.std(ddof=0) / importance.mean()),
        "importance_state_eta_squared": _eta_squared(importance, population.true_state),
        "importance_rare_auc": _rare_auc(importance, population.rare_mask),
        "rare_to_nonrare_importance_mean_ratio": float(
            importance[population.rare_mask].mean() / importance[~population.rare_mask].mean()
        ) if population.rare_mask.any() else float("nan"),
        "importance_total_expression_correlation": _safe_correlation(importance, total),
        "importance_detected_feature_correlation": _safe_correlation(importance, detected),
        "importance_library_factor_correlation": _safe_correlation(importance, population.library_factor),
        "importance_technical_noise_correlation": _safe_correlation(
            importance, population.technical_noise_score
        ),
        "top_importance_technical_anomaly_fraction": float(technical_anomaly[high_importance].mean()),
        "population_technical_anomaly_fraction": float(technical_anomaly.mean()),
    }
    cells = pd.DataFrame(
        {
            "scenario_id": scenario_id,
            "cell_index": np.arange(matrix.shape[0], dtype=int),
            "true_state": population.true_state,
            "is_rare": population.rare_mask,
            "gradient": population.gradient,
            "expression_importance": importance,
            "total_expression": total,
            "detected_features": detected,
            "library_factor": population.library_factor,
            "technical_noise_score": population.technical_noise_score,
        }
    )
    return diagnostics, cells


def within_stratum_importance_diagnostics(
    importance: np.ndarray,
    partition: AdaptiveSpatialPartition,
    scenario_id: str,
    fraction: float,
) -> dict[str, Any]:
    cvs = []
    for stratum in sorted(set(partition.stratum_ids.tolist())):
        values = importance[partition.stratum_ids == stratum]
        cvs.append(float(values.std(ddof=0) / values.mean()))
    return {
        "scenario_id": scenario_id,
        "sampling_fraction": float(fraction),
        "selection_grid_n_x": int(partition.n_x),
        "selection_grid_n_y": int(partition.n_y),
        "n_nonempty_strata": int(len(partition.stratum_audit)),
        "within_stratum_importance_cv_min": float(np.min(cvs)),
        "within_stratum_importance_cv_q25": float(np.quantile(cvs, 0.25)),
        "within_stratum_importance_cv_median": float(np.median(cvs)),
        "within_stratum_importance_cv_q75": float(np.quantile(cvs, 0.75)),
        "within_stratum_importance_cv_max": float(np.max(cvs)),
    }


__all__ = [
    "PreparedUtilityScenario",
    "TargetPanel",
    "UtilityPopulation",
    "build_target_panel",
    "canonical_hash",
    "estimate_target_panel",
    "draw_fixed_size_sample_equivalent",
    "generate_utility_population",
    "mixed_sampling_plan",
    "population_and_importance_diagnostics",
    "prepare_partition_and_full_plan",
    "prepare_utility_scenario",
    "probability_diagnostics",
    "repeat_diagnostics",
    "target_size",
    "validate_design",
    "within_stratum_importance_diagnostics",
]
