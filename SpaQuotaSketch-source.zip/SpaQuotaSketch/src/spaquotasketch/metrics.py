"""Benchmark metric helpers."""

from __future__ import annotations

from collections import Counter
from typing import Any, Hashable


def spatial_coverage(original_bin_ids: list[Hashable], selected_bin_ids: list[Hashable]) -> float:
    """Compute the fraction of original non-empty bins represented in the selection."""
    original_bins = set(original_bin_ids)
    if not original_bins:
        return 0.0
    return len(original_bins.intersection(selected_bin_ids)) / len(original_bins)


def composition_error(
    original_labels: list[Hashable],
    selected_labels: list[Hashable],
    selected_weights: list[float] | None = None,
) -> float:
    """Compute total absolute difference between original and selected label proportions."""
    original_counts = Counter(original_labels)
    original_total = sum(original_counts.values())
    if original_total == 0:
        return 0.0

    if selected_weights is None:
        selected_counts = Counter(selected_labels)
    else:
        if len(selected_labels) != len(selected_weights):
            raise ValueError("selected_labels and selected_weights must have the same length.")
        selected_counts = Counter()
        for label, weight in zip(selected_labels, selected_weights):
            selected_counts[label] += float(weight)

    selected_total = sum(selected_counts.values())
    if selected_total == 0:
        return 1.0

    labels = set(original_counts) | set(selected_counts)
    return sum(
        abs(original_counts[label] / original_total - selected_counts[label] / selected_total)
        for label in labels
    )


def rare_cell_recall(
    original_labels: list[Hashable],
    selected_labels: list[Hashable],
    max_fraction: float = 0.01,
) -> float:
    """Compute how many rare labels in the original data appear in the selection."""
    original_counts = Counter(original_labels)
    total = sum(original_counts.values())
    if total == 0:
        return 0.0
    rare_labels = {label for label, count in original_counts.items() if count / total <= max_fraction}
    if not rare_labels:
        return 1.0
    selected_set = set(selected_labels)
    return len(rare_labels.intersection(selected_set)) / len(rare_labels)


def _as_1d(values: Any):
    import numpy as np

    return np.asarray(values).reshape(-1)


def matrix_column_mean(matrix: Any):
    """Compute one mean value per gene or feature."""
    return _as_1d(matrix.mean(axis=0))


def matrix_column_detection_rate(matrix: Any):
    """Compute the fraction of cells with a positive value for each gene or feature."""
    from scipy import sparse

    if sparse.issparse(matrix):
        return _as_1d((matrix > 0).mean(axis=0))
    return _as_1d((matrix > 0).mean(axis=0))


def matrix_column_variance(matrix: Any):
    """Compute one variance value per gene or feature."""
    from scipy import sparse

    mean = matrix_column_mean(matrix)
    if sparse.issparse(matrix):
        mean_square = _as_1d(matrix.multiply(matrix).mean(axis=0))
    else:
        mean_square = _as_1d((matrix * matrix).mean(axis=0))
    variance = mean_square - mean * mean
    variance[variance < 0] = 0.0
    return variance


def weighted_column_mean(matrix: Any, weights: Any):
    """Compute weighted mean values per gene or feature."""
    import numpy as np
    from scipy import sparse

    w = np.asarray(weights, dtype=float).reshape(-1)
    if matrix.shape[0] != w.shape[0]:
        raise ValueError("matrix row count and weights length must match.")
    total = float(w.sum())
    if total <= 0:
        raise ValueError("weights must have a positive sum.")
    if sparse.issparse(matrix):
        return _as_1d(matrix.T.dot(w) / total)
    return _as_1d(np.average(matrix, axis=0, weights=w))


def weighted_column_detection_rate(matrix: Any, weights: Any):
    """Compute weighted positive-value rates per gene or feature."""
    import numpy as np
    from scipy import sparse

    w = np.asarray(weights, dtype=float).reshape(-1)
    if matrix.shape[0] != w.shape[0]:
        raise ValueError("matrix row count and weights length must match.")
    total = float(w.sum())
    if total <= 0:
        raise ValueError("weights must have a positive sum.")
    if sparse.issparse(matrix):
        return _as_1d((matrix > 0).T.dot(w) / total)
    return _as_1d(np.average(matrix > 0, axis=0, weights=w))


def weighted_column_variance(matrix: Any, weights: Any):
    """Compute weighted variance values per gene or feature."""
    import numpy as np
    from scipy import sparse

    w = np.asarray(weights, dtype=float).reshape(-1)
    if matrix.shape[0] != w.shape[0]:
        raise ValueError("matrix row count and weights length must match.")
    total = float(w.sum())
    if total <= 0:
        raise ValueError("weights must have a positive sum.")
    mean = weighted_column_mean(matrix, w)
    if sparse.issparse(matrix):
        mean_square = _as_1d(matrix.multiply(matrix).T.dot(w) / total)
    else:
        mean_square = _as_1d(np.average(matrix * matrix, axis=0, weights=w))
    variance = mean_square - mean * mean
    variance[variance < 0] = 0.0
    return variance


def safe_pearson_correlation(reference: Any, observed: Any) -> float:
    """Compute Pearson correlation and return NaN when it is undefined."""
    import numpy as np

    ref = _as_1d(reference).astype(float)
    obs = _as_1d(observed).astype(float)
    if ref.shape != obs.shape:
        raise ValueError("reference and observed arrays must have the same shape.")
    if ref.size < 2 or float(np.std(ref)) == 0.0 or float(np.std(obs)) == 0.0:
        return float("nan")
    return float(np.corrcoef(ref, obs)[0, 1])


def relative_mean_absolute_error(reference: Any, observed: Any, eps: float = 1e-12) -> float:
    """Compute mean absolute error relative to the average reference magnitude."""
    import numpy as np

    ref = _as_1d(reference).astype(float)
    obs = _as_1d(observed).astype(float)
    if ref.shape != obs.shape:
        raise ValueError("reference and observed arrays must have the same shape.")
    scale = float(np.mean(np.abs(ref))) + eps
    return float(np.mean(np.abs(ref - obs)) / scale)


def top_k_overlap(reference_scores: Any, observed_scores: Any, k: int = 50) -> float:
    """Compute overlap fraction between top-k reference and observed feature sets."""
    import numpy as np

    ref = _as_1d(reference_scores).astype(float)
    obs = _as_1d(observed_scores).astype(float)
    if ref.shape != obs.shape:
        raise ValueError("reference_scores and observed_scores arrays must have the same shape.")
    k = min(max(int(k), 1), ref.size)
    ref_top = set(np.argsort(-ref)[:k].tolist())
    obs_top = set(np.argsort(-obs)[:k].tolist())
    return float(len(ref_top.intersection(obs_top)) / k)
