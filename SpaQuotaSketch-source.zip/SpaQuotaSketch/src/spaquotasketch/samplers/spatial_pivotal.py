"""Coordinate-only local pivotal sampling under frozen spatial quotas."""

from __future__ import annotations

from typing import Hashable, Mapping, Sequence

import numpy as np

from ..v2.inference import local_pivotal_sample
from .base import (
    SamplingValidationError,
    build_probability_result,
    derive_stratum_seed,
    prepare_stratified_design,
)
from .registry import get_method_metadata, validate_sampler_callable


def _as_two_dimensional_coordinates(
    spatial_coordinates: Sequence[Sequence[float]], n_cells: int
) -> np.ndarray:
    coordinates = np.asarray(spatial_coordinates, dtype=float)
    if coordinates.ndim != 2 or coordinates.shape[0] != n_cells or coordinates.shape[1] < 2:
        raise SamplingValidationError(
            "spatial_coordinates must contain one finite two-dimensional coordinate per cell."
        )
    if not np.isfinite(coordinates[:, :2]).all():
        raise SamplingValidationError("spatial_coordinates must be finite.")
    return coordinates[:, :2]


def sample_spatial_pivotal(
    cell_ids: Sequence[Hashable],
    spatial_coordinates: Sequence[Sequence[float]],
    spatial_strata: Sequence[Hashable],
    quotas: Mapping[Hashable, int],
    *,
    random_seed: int = 0,
    n_neighbors: int = 8,
):
    """Draw a coordinate-defined local pivotal sample with fixed stratum quotas."""
    metadata = get_method_metadata("spatial_pivotal")
    validate_sampler_callable(metadata, sample_spatial_pivotal)
    design = prepare_stratified_design(cell_ids, spatial_strata, quotas)
    coordinates = _as_two_dimensional_coordinates(spatial_coordinates, design.cell_ids.size)
    probability = np.zeros(design.cell_ids.size, dtype=float)
    selected_parts: list[np.ndarray] = []
    zero_quota_population_strata: list[str] = []
    pivotal_strata: list[str] = []
    singleton_srs_strata: list[str] = []
    for order, (stratum, positions) in enumerate(design.positions_by_stratum.items()):
        quota = int(design.quota_by_stratum[stratum])
        n_stratum = int(positions.size)
        probability[positions] = quota / n_stratum
        if quota == 0:
            zero_quota_population_strata.append(str(stratum))
            continue
        if quota == n_stratum:
            selected_parts.append(positions)
            continue
        local_seed = derive_stratum_seed(random_seed, order)
        if quota == 1:
            local_rng = np.random.default_rng(local_seed)
            selected_parts.append(
                np.asarray([local_rng.choice(positions)], dtype=int)
            )
            singleton_srs_strata.append(str(stratum))
            continue
        local_probability = probability[positions]
        local_selected = local_pivotal_sample(
            local_probability,
            coordinates[positions],
            seed=local_seed,
            n_neighbors=n_neighbors,
        )
        selected_parts.append(positions[local_selected])
        pivotal_strata.append(str(stratum))
    selected = (
        np.sort(np.concatenate(selected_parts))
        if selected_parts
        else np.asarray([], dtype=int)
    )
    warnings: list[str] = []
    if zero_quota_population_strata:
        warnings.append(
            "Zero-quota population strata are retained with pi_i = 0 and are outside "
            "positive-support design-based inference."
        )
    return build_probability_result(
        design=design,
        selected_indices=selected,
        inclusion_probability=probability,
        metadata=metadata.values,
        random_seed=random_seed,
        warnings=warnings,
        diagnostics={
            "design": "coordinate_defined_local_pivotal_sampling",
            "coordinate_dependency": "local pairing is built only from spatial_coordinates",
            "pivotal_strata": pivotal_strata,
            "singleton_srs_strata": singleton_srs_strata,
            "zero_quota_population_strata": zero_quota_population_strata,
        },
    )
