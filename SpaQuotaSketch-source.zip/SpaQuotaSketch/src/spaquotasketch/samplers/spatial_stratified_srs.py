"""Pure spatial fixed-quota simple random sampling without replacement."""

from __future__ import annotations

from dataclasses import replace
from typing import Hashable, Mapping, Sequence

import numpy as np

from ..v2_1.quota import allocate_largest_remainder_quotas
from ..v2_1.spatial import choose_adaptive_regular_partition
from .base import (
    StratifiedDesign,
    build_probability_result,
    derive_stratum_seed,
    prepare_stratified_design,
    resolve_target_n,
)
from .registry import get_method_metadata, validate_sampler_callable


def sample_spatial_stratified_srs(
    cell_ids: Sequence[Hashable],
    spatial_strata: Sequence[Hashable],
    quotas: Mapping[Hashable, int],
    *,
    random_seed: int = 0,
):
    """Draw within-stratum SRS samples using only fixed strata and integer quotas."""
    metadata = get_method_metadata("spatial_stratified_srs")
    validate_sampler_callable(metadata, sample_spatial_stratified_srs)
    design = prepare_stratified_design(cell_ids, spatial_strata, quotas)
    probability = np.zeros(design.cell_ids.size, dtype=float)
    selected_parts: list[np.ndarray] = []
    zero_quota_population_strata: list[str] = []
    for order, (stratum, positions) in enumerate(design.positions_by_stratum.items()):
        quota = int(design.quota_by_stratum[stratum])
        n_stratum = int(positions.size)
        probability[positions] = quota / n_stratum
        if quota == 0:
            zero_quota_population_strata.append(str(stratum))
            continue
        if quota == n_stratum:
            selected_parts.append(positions)
            continue
        local_rng = np.random.default_rng(derive_stratum_seed(random_seed, order))
        selected_parts.append(
            np.sort(local_rng.choice(positions, size=quota, replace=False).astype(int))
        )
    selected = (
        np.sort(np.concatenate(selected_parts))
        if selected_parts
        else np.asarray([], dtype=int)
    )
    warnings: list[str] = []
    if zero_quota_population_strata:
        warnings.append(
            "Zero-quota population strata are retained with pi_i = 0 and are outside "
            "positive-support design-based inference."
        )
    return build_probability_result(
        design=design,
        selected_indices=selected,
        inclusion_probability=probability,
        metadata=metadata.values,
        random_seed=random_seed,
        warnings=warnings,
        diagnostics={
            "design": "pure_spatial_stratified_simple_random_sampling_without_replacement",
            "zero_quota_population_strata": zero_quota_population_strata,
        },
    )


def sample_size_aware_spatial_srs(
    cell_ids: Sequence[Hashable],
    spatial_coordinates: Sequence[Sequence[float]],
    target_n: int,
    *,
    random_seed: int = 0,
    minimum_quota: int = 1,
    max_n_x: int = 20,
    max_n_y: int = 20,
):
    """Build a feasible coordinate-only partition, then apply pure spatial SRS."""
    metadata = get_method_metadata("sample_size_aware_spatial_srs")
    validate_sampler_callable(metadata, sample_size_aware_spatial_srs)
    n_target = resolve_target_n(len(cell_ids), target_n=target_n)
    if n_target == 0:
        raise ValueError("sample_size_aware_spatial_srs requires target_n of at least one.")
    partition = choose_adaptive_regular_partition(
        spatial_coordinates,
        n_target,
        minimum_quota=minimum_quota,
        max_n_x=max_n_x,
        max_n_y=max_n_y,
    )
    allocation = allocate_largest_remainder_quotas(
        partition.stratum_audit,
        n_target,
        minimum_quota=minimum_quota,
    )
    base_result = sample_spatial_stratified_srs(
        cell_ids,
        partition.stratum_ids,
        allocation.quotas,
        random_seed=random_seed,
    )
    return replace(
        base_result,
        method_id=str(metadata["method_id"]),
        method_display_name=str(metadata["method_display_name"]),
        method_family=str(metadata["method_family"]),
        analysis_goal=str(metadata["analysis_goal"]),
        uses_expression=bool(metadata["uses_expression"]),
        uses_spatial_coordinates=bool(metadata["uses_spatial_coordinates"]),
        uses_cell_labels=bool(metadata["uses_cell_labels"]),
        uses_domain_labels=bool(metadata["uses_domain_labels"]),
        within_stratum_sampler=str(metadata["within_stratum_sampler"]),
        inclusion_probability_definition=str(metadata["inclusion_probability_definition"]),
        algorithm_version=str(metadata["algorithm_version"]),
        diagnostics={
            **base_result.diagnostics,
            "partition_shape": [int(partition.n_x), int(partition.n_y)],
            "partition_selection_reason": partition.selection_reason,
            "n_nonempty_strata": int(len(partition.stratum_audit)),
        },
    )
