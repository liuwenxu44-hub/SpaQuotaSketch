"""Explicit runnable entry points for preregistered clean baseline samplers."""

from __future__ import annotations

from typing import Any

from .legacy_expression_assisted_pivotal import sample_legacy_expression_assisted_pivotal
from .registry import MethodUnavailableError, require_runnable_method
from .spatial_pivotal import sample_spatial_pivotal
from .spatial_stratified_srs import (
    sample_size_aware_spatial_srs,
    sample_spatial_stratified_srs,
)
from .uniform_srs import sample_uniform_srs


_RUNNERS = {
    "uniform_srs": sample_uniform_srs,
    "spatial_stratified_srs": sample_spatial_stratified_srs,
    "sample_size_aware_spatial_srs": sample_size_aware_spatial_srs,
    "spatial_pivotal": sample_spatial_pivotal,
    "legacy_expression_assisted_pivotal": sample_legacy_expression_assisted_pivotal,
}


def run_clean_baseline(method_id: str, /, **kwargs: Any):
    """Run only an explicitly implemented clean-baseline sampler by method_id."""
    require_runnable_method(method_id)
    try:
        sampler = _RUNNERS[method_id]
    except KeyError as error:
        raise MethodUnavailableError(
            f"{method_id} is registered but has no clean-baseline runnable entry."
        ) from error
    return sampler(**kwargs)
