"""Load and validate the preregistered clean-baseline method registry."""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any, Callable, Mapping
import inspect

import yaml


class RegistryValidationError(ValueError):
    """Raised when registry metadata conflicts with its declared method identity."""


class MethodUnavailableError(RuntimeError):
    """Raised when a reserved or not-yet-implemented method is requested."""


class _UniqueKeyLoader(yaml.SafeLoader):
    pass


def _construct_unique_mapping(loader: yaml.SafeLoader, node: yaml.Node, deep: bool = False) -> dict[Any, Any]:
    mapping: dict[Any, Any] = {}
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        if key in mapping:
            raise RegistryValidationError(f"Duplicate YAML key in method registry: {key!r}.")
        mapping[key] = loader.construct_object(value_node, deep=deep)
    return mapping


_UniqueKeyLoader.add_constructor(
    yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG,
    _construct_unique_mapping,
)


@dataclass(frozen=True)
class MethodMetadata:
    """Validated method identity read directly from the frozen YAML registry."""

    values: Mapping[str, Any]

    def __getitem__(self, key: str) -> Any:
        return self.values[key]

    @property
    def method_id(self) -> str:
        return str(self.values["method_id"])


_REQUIRED_METHOD_FIELDS = {
    "method_id",
    "method_display_name",
    "method_family",
    "analysis_goal",
    "required_inputs",
    "uses_expression",
    "uses_spatial_coordinates",
    "uses_cell_labels",
    "uses_domain_labels",
    "uses_true_simulation_state",
    "stratum_definition",
    "quota_rule",
    "within_stratum_sampler",
    "inclusion_probability_definition",
    "has_positive_inclusion_probability",
    "sampling_weight_type",
    "sampling_weight_definition",
    "supports_ht",
    "supports_hajek",
    "supports_design_based_variance",
    "algorithm_version",
    "legacy_aliases",
}

_REQUIRED_FRAMEWORK_FIELDS = {
    "supported_modes",
    "uses_coordinates",
    "uses_labels",
    "probability_design",
    "returns_sampling_weight",
    "supports_candidate_completion",
    "legacy_status",
    "recommended_use",
    "known_limitations",
}


def default_registry_path() -> Path:
    """Return the tracked preregistration registry without using machine-specific paths."""
    return Path(__file__).resolve().parents[3] / "configs" / "clean_baseline_method_registry.yaml"


def load_method_registry(path: str | Path | None = None) -> dict[str, MethodMetadata]:
    """Load the registry and reject internally inconsistent method definitions."""
    registry_path = default_registry_path() if path is None else Path(path)
    return _load_method_registry_cached(str(registry_path.resolve()))


@lru_cache(maxsize=8)
def _load_method_registry_cached(registry_path_text: str) -> dict[str, MethodMetadata]:
    """Parse one immutable registry path once per Python process."""
    registry_path = Path(registry_path_text)
    try:
        raw = yaml.load(registry_path.read_text(encoding="utf-8"), Loader=_UniqueKeyLoader)
    except OSError as error:
        raise RegistryValidationError(f"Cannot read method registry: {registry_path}") from error
    if not isinstance(raw, Mapping) or not isinstance(raw.get("methods"), Mapping):
        raise RegistryValidationError("Method registry must contain a mapping named methods.")
    framework_capabilities = raw.get("framework_capabilities")
    if not isinstance(framework_capabilities, Mapping):
        raise RegistryValidationError(
            "Method registry must contain one framework_capabilities mapping."
        )
    methods: dict[str, MethodMetadata] = {}
    for registry_key, value in raw["methods"].items():
        if not isinstance(value, Mapping):
            raise RegistryValidationError(f"Method {registry_key!r} must be a mapping.")
        capability = framework_capabilities.get(registry_key)
        if not isinstance(capability, Mapping):
            raise RegistryValidationError(
                f"Method {registry_key!r} must have one framework capability record."
            )
        merged_values = {**dict(value), **dict(capability)}
        metadata = MethodMetadata(merged_values)
        if registry_key != metadata.method_id:
            raise RegistryValidationError(
                f"Registry key {registry_key!r} does not equal method_id {metadata.method_id!r}."
            )
        if metadata.method_id in methods:
            raise RegistryValidationError(f"Duplicate method_id: {metadata.method_id!r}.")
        _validate_method_metadata(metadata)
        methods[metadata.method_id] = metadata
    return methods


def get_method_metadata(method_id: str, *, path: str | Path | None = None) -> MethodMetadata:
    """Return one validated method definition by its stable identifier."""
    methods = load_method_registry(path)
    try:
        return methods[method_id]
    except KeyError as error:
        raise RegistryValidationError(f"Unknown method_id: {method_id!r}.") from error


def validate_sampler_callable(metadata: MethodMetadata, sampler: Callable[..., Any]) -> None:
    """Check that a public sampler signature agrees with its metadata identity."""
    parameter_names = set(inspect.signature(sampler).parameters)
    identifier = metadata.method_id
    if not metadata["uses_expression"] and any(
        "expression" in name or "embedding" in name for name in parameter_names
    ):
        raise RegistryValidationError(
            f"{identifier} is registered without expression use but accepts expression input."
        )
    if not metadata["uses_spatial_coordinates"] and any(
        name in {"spatial_coordinates", "coordinates"} for name in parameter_names
    ):
        raise RegistryValidationError(
            f"{identifier} is registered without coordinates but accepts coordinate input."
        )
    if not metadata["uses_cell_labels"] and any("label" in name for name in parameter_names):
        raise RegistryValidationError(
            f"{identifier} is registered without cell labels but accepts label input."
        )
    if metadata["uses_expression"] is False and identifier == "spatial_stratified_srs":
        required = {"cell_ids", "spatial_strata", "quotas", "random_seed"}
        if not required.issubset(parameter_names):
            raise RegistryValidationError(
                "spatial_stratified_srs must expose only its frozen spatial design inputs."
            )


def require_runnable_method(method_id: str) -> MethodMetadata:
    """Reject reserved external methods before a caller can invoke them silently."""
    metadata = get_method_metadata(method_id)
    status = str(metadata.values.get("implementation_status", ""))
    if "not_implemented" in status or status.startswith("reserved_"):
        raise MethodUnavailableError(
            f"{method_id} is reserved in the preregistration registry and has no runnable entry."
        )
    return metadata


def _validate_method_metadata(metadata: MethodMetadata) -> None:
    missing = sorted(_REQUIRED_METHOD_FIELDS - set(metadata.values))
    if missing:
        raise RegistryValidationError(
            f"{metadata.method_id} is missing required metadata fields: {missing!r}."
        )
    missing_framework = sorted(_REQUIRED_FRAMEWORK_FIELDS - set(metadata.values))
    if missing_framework:
        raise RegistryValidationError(
            f"{metadata.method_id} is missing framework capability fields: {missing_framework!r}."
        )
    for key in (
        "uses_expression",
        "uses_spatial_coordinates",
        "uses_cell_labels",
        "uses_domain_labels",
        "uses_true_simulation_state",
        "has_positive_inclusion_probability",
        "supports_ht",
        "supports_hajek",
        "supports_design_based_variance",
        "uses_coordinates",
        "uses_labels",
        "returns_sampling_weight",
        "supports_candidate_completion",
    ):
        if not isinstance(metadata[key], bool):
            raise RegistryValidationError(f"{metadata.method_id}.{key} must be Boolean.")
    if bool(metadata["uses_coordinates"]) != bool(metadata["uses_spatial_coordinates"]):
        raise RegistryValidationError(
            f"{metadata.method_id}.uses_coordinates must match uses_spatial_coordinates."
        )
    expected_uses_labels = bool(metadata["uses_cell_labels"] or metadata["uses_domain_labels"])
    if bool(metadata["uses_labels"]) != expected_uses_labels:
        raise RegistryValidationError(
            f"{metadata.method_id}.uses_labels must match registered label use."
        )
    if bool(metadata["returns_sampling_weight"]) != (
        str(metadata["sampling_weight_type"]).startswith("probability_sampling_weight")
    ):
        raise RegistryValidationError(
            f"{metadata.method_id}.returns_sampling_weight conflicts with sampling_weight_type."
        )
    if not isinstance(metadata["supported_modes"], list) or any(
        value not in {"representation", "inference"} for value in metadata["supported_modes"]
    ):
        raise RegistryValidationError(
            f"{metadata.method_id}.supported_modes must be a list of public modes."
        )
    if not isinstance(metadata["known_limitations"], list):
        raise RegistryValidationError(f"{metadata.method_id}.known_limitations must be a list.")
    required_inputs = [str(value) for value in metadata["required_inputs"]]
    joined_inputs = " ".join(required_inputs).lower()
    if not metadata["uses_expression"] and ("expression" in joined_inputs or "embedding" in joined_inputs):
        raise RegistryValidationError(
            f"{metadata.method_id} forbids expression use but requires expression input."
        )
    if not metadata["uses_spatial_coordinates"] and "spatial_coordinates" in joined_inputs:
        raise RegistryValidationError(
            f"{metadata.method_id} forbids coordinate use but requires spatial_coordinates."
        )
    if not metadata["uses_cell_labels"] and "cell_label" in joined_inputs:
        raise RegistryValidationError(
            f"{metadata.method_id} forbids cell labels but requires cell labels."
        )
    if not metadata["uses_domain_labels"] and "domain_label" in joined_inputs:
        raise RegistryValidationError(
            f"{metadata.method_id} forbids domain labels but requires domain labels."
        )
    active_names = " ".join(
        [metadata.method_id, str(metadata["method_display_name"])]
    ).lower()
    if any(token in active_names for token in ("coordinate_only", "spatial_only", "pure_spatial")) and metadata[
        "uses_expression"
    ]:
        raise RegistryValidationError(
            f"{metadata.method_id} uses expression and cannot use a pure-spatial active name."
        )
    if metadata["method_family"] == "representation" and metadata["sampling_weight_type"] == "probability_sampling_weight":
        raise RegistryValidationError(
            f"Representation method {metadata.method_id} cannot claim probability sampling_weight."
        )
    inclusion = str(metadata["inclusion_probability_definition"]).lower()
    if (metadata["supports_ht"] or metadata["supports_hajek"]) and (
        inclusion.startswith("not_") or inclusion == "none"
    ):
        raise RegistryValidationError(
            f"{metadata.method_id} claims design-based estimation without a defined first-order probability."
        )
    is_legacy = metadata.method_id.startswith("legacy_") or metadata.values.get(
        "comparison_role"
    ) == "historical_compatibility"
    if is_legacy and not metadata.method_id.startswith("legacy_"):
        raise RegistryValidationError("Historical methods must have a legacy_ method_id.")
    if is_legacy and not metadata["legacy_aliases"]:
        raise RegistryValidationError("Historical methods must retain at least one legacy alias.")
