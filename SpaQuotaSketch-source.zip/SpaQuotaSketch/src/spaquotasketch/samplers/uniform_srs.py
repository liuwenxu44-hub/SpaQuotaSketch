"""Global simple random sampling without replacement."""

from __future__ import annotations

from typing import Hashable, Sequence

import numpy as np

from .base import (
    StratifiedDesign,
    as_unique_cell_ids,
    build_probability_result,
    resolve_target_n,
)
from .registry import get_method_metadata, validate_sampler_callable


def sample_uniform_srs(
    cell_ids: Sequence[Hashable],
    target_n: int,
    *,
    random_seed: int = 0,
):
    """Draw a fixed-size global simple random sample without replacement."""
    ids = as_unique_cell_ids(cell_ids)
    n_population = int(ids.size)
    n_target = resolve_target_n(n_population, target_n=target_n)
    metadata = get_method_metadata("uniform_srs")
    validate_sampler_callable(metadata, sample_uniform_srs)
    if n_population == 0:
        design = StratifiedDesign(
            cell_ids=ids,
            stratum_id=np.asarray([], dtype=object),
            positions_by_stratum={},
            quota_by_stratum={},
            stratum_size=np.asarray([], dtype=int),
            stratum_quota=np.asarray([], dtype=int),
            empty_zero_quota_strata=(),
        )
        return build_probability_result(
            design=design,
            selected_indices=np.asarray([], dtype=int),
            inclusion_probability=np.asarray([], dtype=float),
            metadata=metadata.values,
            random_seed=random_seed,
            warnings=("The population is empty; no sampling draw was performed.",),
        )
    rng = np.random.default_rng(int(random_seed))
    selected = (
        np.sort(rng.choice(n_population, size=n_target, replace=False).astype(int))
        if n_target
        else np.asarray([], dtype=int)
    )
    probability = np.full(n_population, n_target / n_population, dtype=float)
    design = StratifiedDesign(
        cell_ids=ids,
        stratum_id=np.full(n_population, "global", dtype=object),
        positions_by_stratum={"global": np.arange(n_population, dtype=int)},
        quota_by_stratum={"global": n_target},
        stratum_size=np.full(n_population, n_population, dtype=int),
        stratum_quota=np.full(n_population, n_target, dtype=int),
        empty_zero_quota_strata=(),
    )
    warnings = () if n_target else ("target_n is zero; no cell has positive inclusion probability.",)
    return build_probability_result(
        design=design,
        selected_indices=selected,
        inclusion_probability=probability,
        metadata=metadata.values,
        random_seed=random_seed,
        warnings=warnings,
        diagnostics={"design": "global_simple_random_sampling_without_replacement"},
    )
