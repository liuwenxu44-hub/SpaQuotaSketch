"""Small-synthetic probability calibration utilities for sampler correctness tests."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np

from .base import SamplingResult


@dataclass(frozen=True)
class CalibrationReport:
    """Empirical versus declared first-order inclusion probability diagnostics."""

    n_draws: int
    mean_signed_error: float
    mean_absolute_error: float
    rmse: float
    maximum_absolute_error: float
    regression_slope: float | None
    regression_intercept: float | None
    constant_probability: bool

    def to_dict(self) -> dict[str, float | int | bool | None]:
        return {
            "n_draws": self.n_draws,
            "mean_signed_error": self.mean_signed_error,
            "mean_absolute_error": self.mean_absolute_error,
            "rmse": self.rmse,
            "maximum_absolute_error": self.maximum_absolute_error,
            "regression_slope": self.regression_slope,
            "regression_intercept": self.regression_intercept,
            "constant_probability": self.constant_probability,
        }


def empirical_inclusion_calibration(
    draw: Callable[[int], SamplingResult],
    theoretical_probability: np.ndarray,
    *,
    n_draws: int,
) -> CalibrationReport:
    """Estimate first-order inclusion frequencies over independent deterministic seeds."""
    if n_draws < 1:
        raise ValueError("n_draws must be positive.")
    probability = np.asarray(theoretical_probability, dtype=float).reshape(-1)
    counts = np.zeros(probability.size, dtype=int)
    for seed in range(int(n_draws)):
        result = draw(seed)
        if result.selected_mask.size != probability.size:
            raise ValueError("Draw result does not align with theoretical_probability.")
        if result.inclusion_probability is None or not np.allclose(
            result.inclusion_probability, probability, atol=1e-12, rtol=0
        ):
            raise ValueError("Draw result does not retain the declared inclusion probabilities.")
        counts += result.selected_mask.astype(int)
    empirical = counts / float(n_draws)
    error = empirical - probability
    support = probability > 0
    if not np.any(support):
        raise ValueError("Calibration requires at least one positive inclusion probability.")
    expected = probability[support]
    observed = empirical[support]
    unique_probability = np.unique(expected)
    if unique_probability.size < 2:
        slope: float | None = None
        intercept: float | None = float(observed.mean())
        constant = True
    else:
        slope_value, intercept_value = np.polyfit(expected, observed, deg=1)
        slope = float(slope_value)
        intercept = float(intercept_value)
        constant = False
    return CalibrationReport(
        n_draws=int(n_draws),
        mean_signed_error=float(error[support].mean()),
        mean_absolute_error=float(np.abs(error[support]).mean()),
        rmse=float(np.sqrt(np.mean(np.square(error[support])))),
        maximum_absolute_error=float(np.abs(error[support]).max(initial=0.0)),
        regression_slope=slope,
        regression_intercept=intercept,
        constant_probability=constant,
    )
