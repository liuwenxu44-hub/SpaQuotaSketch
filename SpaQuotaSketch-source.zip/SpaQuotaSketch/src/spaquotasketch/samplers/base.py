"""Shared data structures and validation for clean baseline samplers."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Hashable, Mapping, Sequence
import json

import numpy as np
import pandas as pd


class SamplingValidationError(ValueError):
    """Raised when an input cannot define a valid sampling design."""


class InfeasibleQuotaError(SamplingValidationError):
    """Raised when an integer stratum quota exceeds available population cells."""


def resolve_target_n(
    population_size: int,
    *,
    target_n: int | None = None,
    target_fraction: float | None = None,
) -> int:
    """Resolve an explicit count or a positive fraction to one fixed target size."""
    population_size = int(population_size)
    if population_size < 0:
        raise SamplingValidationError("population_size must be non-negative.")
    if (target_n is None) == (target_fraction is None):
        raise SamplingValidationError("Specify exactly one of target_n or target_fraction.")
    if target_n is not None:
        resolved = int(target_n)
        if resolved != target_n:
            raise SamplingValidationError("target_n must be an integer.")
    else:
        fraction = float(target_fraction)
        if not np.isfinite(fraction) or not 0.0 <= fraction <= 1.0:
            raise SamplingValidationError("target_fraction must lie in [0, 1].")
        resolved = 0 if fraction == 0.0 else max(1, int(np.floor(population_size * fraction)))
    if not 0 <= resolved <= population_size:
        raise SamplingValidationError(
            "target sample size must lie between zero and the population size."
        )
    return resolved


def as_unique_cell_ids(cell_ids: Sequence[Hashable]) -> np.ndarray:
    """Return one-dimensional unique cell identifiers in their input order."""
    values = np.asarray(list(cell_ids), dtype=object).reshape(-1)
    try:
        unique_count = len(set(values.tolist()))
    except TypeError as error:
        raise SamplingValidationError("Every cell_id must be hashable.") from error
    if unique_count != values.size:
        raise SamplingValidationError("cell_id values must be unique.")
    return values


def _stable_key(value: Hashable) -> tuple[str, str]:
    return type(value).__name__, repr(value)


def derive_stratum_seed(random_seed: int, stratum_order: int) -> int:
    """Derive deterministic independent random streams from one master seed."""
    return int(
        np.random.SeedSequence([int(random_seed), int(stratum_order)]).generate_state(1)[0]
    )


@dataclass(frozen=True)
class StratifiedDesign:
    """A validated fixed-quota spatial stratified design before drawing samples."""

    cell_ids: np.ndarray
    stratum_id: np.ndarray
    positions_by_stratum: Mapping[Hashable, np.ndarray]
    quota_by_stratum: Mapping[Hashable, int]
    stratum_size: np.ndarray
    stratum_quota: np.ndarray
    empty_zero_quota_strata: tuple[Hashable, ...]

    @property
    def target_n(self) -> int:
        return int(sum(self.quota_by_stratum.values()))


def prepare_stratified_design(
    cell_ids: Sequence[Hashable],
    spatial_strata: Sequence[Hashable],
    quotas: Mapping[Hashable, int],
) -> StratifiedDesign:
    """Validate strata and quotas without reading coordinates or expression data."""
    ids = as_unique_cell_ids(cell_ids)
    strata = np.asarray(list(spatial_strata), dtype=object).reshape(-1)
    if strata.size != ids.size:
        raise SamplingValidationError("cell_ids and spatial_strata must have equal length.")
    if not isinstance(quotas, Mapping):
        raise SamplingValidationError("quotas must be a mapping from stratum_id to integer quota.")

    positions: dict[Hashable, list[int]] = {}
    for index, stratum in enumerate(strata.tolist()):
        try:
            positions.setdefault(stratum, []).append(index)
        except TypeError as error:
            raise SamplingValidationError("Every spatial stratum identifier must be hashable.") from error
    positions_by_stratum = {
        stratum: np.asarray(positions[stratum], dtype=int)
        for stratum in sorted(positions, key=_stable_key)
    }

    quota_by_stratum: dict[Hashable, int] = {}
    for stratum, value in quotas.items():
        try:
            quota = int(value)
        except (TypeError, ValueError) as error:
            raise SamplingValidationError("Every quota must be an integer.") from error
        if quota != value or quota < 0:
            raise SamplingValidationError("Every quota must be a non-negative integer.")
        quota_by_stratum[stratum] = quota

    population_strata = set(positions_by_stratum)
    quota_strata = set(quota_by_stratum)
    missing = population_strata - quota_strata
    if missing:
        raise SamplingValidationError(
            f"Missing quota for nonempty spatial strata: {sorted(missing, key=_stable_key)!r}."
        )
    unknown_nonzero = {
        stratum: quota
        for stratum, quota in quota_by_stratum.items()
        if stratum not in population_strata and quota != 0
    }
    if unknown_nonzero:
        raise InfeasibleQuotaError(
            "A nonzero quota cannot be assigned to an empty spatial stratum: "
            f"{unknown_nonzero!r}."
        )

    for stratum, indices in positions_by_stratum.items():
        quota = quota_by_stratum[stratum]
        if quota > indices.size:
            raise InfeasibleQuotaError(
                f"Quota q_g={quota} exceeds N_g={indices.size} for stratum {stratum!r}."
            )

    stratum_size = np.zeros(ids.size, dtype=int)
    stratum_quota = np.zeros(ids.size, dtype=int)
    for stratum, indices in positions_by_stratum.items():
        stratum_size[indices] = int(indices.size)
        stratum_quota[indices] = int(quota_by_stratum[stratum])
    empty_zero = tuple(
        stratum
        for stratum in sorted(quota_strata - population_strata, key=_stable_key)
        if quota_by_stratum[stratum] == 0
    )
    return StratifiedDesign(
        cell_ids=ids,
        stratum_id=strata,
        positions_by_stratum=positions_by_stratum,
        quota_by_stratum={
            stratum: quota_by_stratum[stratum]
            for stratum in sorted(quota_by_stratum, key=_stable_key)
        },
        stratum_size=stratum_size,
        stratum_quota=stratum_quota,
        empty_zero_quota_strata=empty_zero,
    )


@dataclass(frozen=True)
class SamplingResult:
    """One complete clean-baseline sampling result over the full population."""

    population_cell_ids: np.ndarray
    selected_cell_ids: np.ndarray
    selected_mask: np.ndarray
    method_id: str
    method_display_name: str
    method_family: str
    analysis_goal: str
    target_n: int
    actual_n: int
    random_seed: int
    stratum_id: np.ndarray
    stratum_size: np.ndarray
    stratum_quota: np.ndarray
    inclusion_probability: np.ndarray | None
    sampling_weight: np.ndarray | None
    composition_calibration_factor: np.ndarray | None
    uses_expression: bool
    uses_spatial_coordinates: bool
    uses_cell_labels: bool
    uses_domain_labels: bool
    within_stratum_sampler: str
    inclusion_probability_definition: str
    algorithm_version: str
    warnings: tuple[str, ...]
    diagnostics: Mapping[str, Any]

    def __post_init__(self) -> None:
        population_ids = np.asarray(self.population_cell_ids, dtype=object).reshape(-1)
        selected = np.asarray(self.selected_cell_ids, dtype=object).reshape(-1)
        mask = np.asarray(self.selected_mask, dtype=bool).reshape(-1)
        stratum_id = np.asarray(self.stratum_id, dtype=object).reshape(-1)
        stratum_size = np.asarray(self.stratum_size, dtype=int).reshape(-1)
        stratum_quota = np.asarray(self.stratum_quota, dtype=int).reshape(-1)
        n_population = mask.size
        if population_ids.size != n_population:
            raise SamplingValidationError("population_cell_ids must cover the full population.")
        if any(values.size != n_population for values in (stratum_id, stratum_size, stratum_quota)):
            raise SamplingValidationError("Result population-level fields must have equal length.")
        if selected.size != int(mask.sum()) or selected.size != int(self.actual_n):
            raise SamplingValidationError("selected_cell_ids, selected_mask, and actual_n disagree.")
        if not np.array_equal(selected, population_ids[mask]):
            raise SamplingValidationError(
                "selected_cell_ids must equal population_cell_ids selected by selected_mask."
            )
        if self.actual_n > self.target_n:
            raise SamplingValidationError("actual_n cannot exceed target_n.")
        if len(set(selected.tolist())) != selected.size:
            raise SamplingValidationError("selected_cell_ids must not contain duplicates.")

        if self.inclusion_probability is None:
            if self.sampling_weight is not None:
                raise SamplingValidationError(
                    "sampling_weight requires a defined inclusion_probability."
                )
        else:
            probability = np.asarray(self.inclusion_probability, dtype=float).reshape(-1)
            if probability.size != n_population:
                raise SamplingValidationError("inclusion_probability must cover the full population.")
            if not np.isfinite(probability).all() or np.any(probability < 0) or np.any(probability > 1):
                raise SamplingValidationError("inclusion_probability values must lie in [0, 1].")
            if np.any(probability[mask] <= 0):
                raise SamplingValidationError("Every selected cell must have positive inclusion probability.")
            if self.sampling_weight is None:
                raise SamplingValidationError(
                    "A defined probability design must emit sampling_weight = 1 / pi."
                )
            weight = np.asarray(self.sampling_weight, dtype=float).reshape(-1)
            if weight.size != n_population:
                raise SamplingValidationError("sampling_weight must cover the full population.")
            positive = probability > 0
            if not np.all(np.isfinite(weight[positive])) or not np.allclose(
                weight[positive], 1.0 / probability[positive], atol=1e-12, rtol=0
            ):
                raise SamplingValidationError("sampling_weight must equal 1 / inclusion_probability.")
            if np.any(~np.isnan(weight[~positive])):
                raise SamplingValidationError(
                    "Cells with zero inclusion probability must have missing sampling_weight."
                )

        if self.composition_calibration_factor is not None:
            factor = np.asarray(self.composition_calibration_factor, dtype=float).reshape(-1)
            if factor.size != n_population:
                raise SamplingValidationError(
                    "composition_calibration_factor must cover the full population."
                )
            if self.sampling_weight is not None and np.array_equal(
                np.nan_to_num(factor, nan=-999999.0),
                np.nan_to_num(np.asarray(self.sampling_weight), nan=-999999.0),
            ):
                raise SamplingValidationError(
                    "composition_calibration_factor must not duplicate sampling_weight values."
                )

        object.__setattr__(self, "population_cell_ids", population_ids)
        object.__setattr__(self, "selected_cell_ids", selected)
        object.__setattr__(self, "selected_mask", mask)
        object.__setattr__(self, "stratum_id", stratum_id)
        object.__setattr__(self, "stratum_size", stratum_size)
        object.__setattr__(self, "stratum_quota", stratum_quota)
        if self.inclusion_probability is not None:
            object.__setattr__(
                self,
                "inclusion_probability",
                np.asarray(self.inclusion_probability, dtype=float).reshape(-1),
            )
            object.__setattr__(
                self,
                "sampling_weight",
                np.asarray(self.sampling_weight, dtype=float).reshape(-1),
            )
        if self.composition_calibration_factor is not None:
            object.__setattr__(
                self,
                "composition_calibration_factor",
                np.asarray(self.composition_calibration_factor, dtype=float).reshape(-1),
            )

    def to_frame(self) -> pd.DataFrame:
        """Return a cell-level table suitable for CSV serialization."""
        return pd.DataFrame(
            {
                "cell_id": self._population_cell_ids(),
                "selected": self.selected_mask,
                "stratum_id": self.stratum_id,
                "stratum_size": self.stratum_size,
                "stratum_quota": self.stratum_quota,
                "inclusion_probability": self.inclusion_probability,
                "sampling_weight": self.sampling_weight,
                "composition_calibration_factor": self.composition_calibration_factor,
            }
        )

    def _population_cell_ids(self) -> np.ndarray:
        return self.population_cell_ids

    def metadata_dict(self) -> dict[str, Any]:
        """Return JSON-ready method-level metadata and diagnostics."""
        return {
            "method_id": self.method_id,
            "method_display_name": self.method_display_name,
            "method_family": self.method_family,
            "analysis_goal": self.analysis_goal,
            "target_n": int(self.target_n),
            "actual_n": int(self.actual_n),
            "random_seed": int(self.random_seed),
            "uses_expression": bool(self.uses_expression),
            "uses_spatial_coordinates": bool(self.uses_spatial_coordinates),
            "uses_cell_labels": bool(self.uses_cell_labels),
            "uses_domain_labels": bool(self.uses_domain_labels),
            "within_stratum_sampler": self.within_stratum_sampler,
            "inclusion_probability_definition": self.inclusion_probability_definition,
            "algorithm_version": self.algorithm_version,
            "warnings": list(self.warnings),
            "diagnostics": _json_ready(self.diagnostics),
        }


def build_probability_result(
    *,
    design: StratifiedDesign,
    selected_indices: Sequence[int],
    inclusion_probability: Sequence[float],
    metadata: Mapping[str, Any],
    random_seed: int,
    warnings: Sequence[str] = (),
    diagnostics: Mapping[str, Any] | None = None,
) -> SamplingResult:
    """Build a validated result where weights are exactly inverse probabilities."""
    probability = np.asarray(inclusion_probability, dtype=float).reshape(-1)
    if probability.size != design.cell_ids.size:
        raise SamplingValidationError("inclusion_probability must align with cell_ids.")
    selected = np.sort(np.asarray(selected_indices, dtype=int).reshape(-1))
    if selected.size and (selected.min() < 0 or selected.max() >= design.cell_ids.size):
        raise SamplingValidationError("selected_indices contains an out-of-range position.")
    if np.unique(selected).size != selected.size:
        raise SamplingValidationError("selected_indices must not contain duplicates.")
    selected_mask = np.zeros(design.cell_ids.size, dtype=bool)
    selected_mask[selected] = True
    weight = np.full(design.cell_ids.size, np.nan, dtype=float)
    positive = probability > 0
    weight[positive] = 1.0 / probability[positive]
    warning_values = list(warnings)
    if np.any(~positive):
        warning_values.append(
            "Some cells have zero inclusion probability because their stratum quota is zero; "
            "they are outside the positive-support inference population."
        )
    details = {
        "n_population": int(design.cell_ids.size),
        "n_nonempty_strata": int(len(design.positions_by_stratum)),
        "quota_total": int(design.target_n),
        "empty_zero_quota_strata": [str(value) for value in design.empty_zero_quota_strata],
    }
    if diagnostics:
        details.update(diagnostics)
    return SamplingResult(
        population_cell_ids=design.cell_ids,
        selected_cell_ids=design.cell_ids[selected],
        selected_mask=selected_mask,
        method_id=str(metadata["method_id"]),
        method_display_name=str(metadata["method_display_name"]),
        method_family=str(metadata["method_family"]),
        analysis_goal=str(metadata["analysis_goal"]),
        target_n=design.target_n,
        actual_n=int(selected.size),
        random_seed=int(random_seed),
        stratum_id=design.stratum_id,
        stratum_size=design.stratum_size,
        stratum_quota=design.stratum_quota,
        inclusion_probability=probability,
        sampling_weight=weight,
        composition_calibration_factor=None,
        uses_expression=bool(metadata["uses_expression"]),
        uses_spatial_coordinates=bool(metadata["uses_spatial_coordinates"]),
        uses_cell_labels=bool(metadata["uses_cell_labels"]),
        uses_domain_labels=bool(metadata["uses_domain_labels"]),
        within_stratum_sampler=str(metadata["within_stratum_sampler"]),
        inclusion_probability_definition=str(metadata["inclusion_probability_definition"]),
        algorithm_version=str(metadata["algorithm_version"]),
        warnings=tuple(warning_values),
        diagnostics=details,
    )


def serialize_sampling_result(
    result: SamplingResult,
    output_directory: str | Path,
    *,
    prefix: str,
) -> tuple[Path, Path]:
    """Write one cell-level CSV and one method-level JSON file."""
    destination = Path(output_directory)
    destination.mkdir(parents=True, exist_ok=True)
    selection_path = destination / f"{prefix}_selection.csv"
    metadata_path = destination / f"{prefix}_metadata.json"
    if selection_path.exists() or metadata_path.exists():
        raise FileExistsError(
            f"Refusing to overwrite existing sampling output: {selection_path} or {metadata_path}."
        )
    result.to_frame().to_csv(selection_path, index=False)
    metadata_path.write_text(
        json.dumps(result.metadata_dict(), ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    return selection_path, metadata_path


def _json_ready(value: Any) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return [_json_ready(item) for item in value.tolist()]
    if isinstance(value, Mapping):
        return {str(key): _json_ready(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_ready(item) for item in value]
    return value
