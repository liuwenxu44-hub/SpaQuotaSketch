"""Compatibility wrapper for the frozen historical expression-assisted sampler."""

from __future__ import annotations

from typing import Hashable, Mapping, Sequence

import numpy as np

from ..v2_1.sampling import build_sampling_plan, draw_fixed_size_sample
from .base import InfeasibleQuotaError, build_probability_result, prepare_stratified_design
from .registry import get_method_metadata, validate_sampler_callable


def sample_legacy_expression_assisted_pivotal(
    cell_ids: Sequence[Hashable],
    spatial_coordinates: Sequence[Sequence[float]],
    expression_embedding: np.ndarray,
    spatial_strata: Sequence[Hashable],
    quotas: Mapping[Hashable, int],
    *,
    random_seed: int = 0,
):
    """Run frozen historical logic without calling it a pure spatial method.

    For ``q_g = 1`` historical code performs an equal-probability categorical
    draw and the embedding does not alter that stratum's sample. For
    ``1 < q_g < N_g`` it constructs local pivotal edges from expression
    embedding, which changes the joint sample structure despite equal first-
    order probabilities.
    """
    metadata = get_method_metadata("legacy_expression_assisted_pivotal")
    validate_sampler_callable(metadata, sample_legacy_expression_assisted_pivotal)
    design = prepare_stratified_design(cell_ids, spatial_strata, quotas)
    if any(quota == 0 for quota in design.quota_by_stratum.values()):
        raise InfeasibleQuotaError(
            "Historical v2_1_coordinate_only logic requires 1 <= q_g <= N_g for every "
            "nonempty stratum and cannot represent a zero quota without changing history."
        )
    values = np.asarray(expression_embedding, dtype=float)
    if values.ndim != 2 or values.shape[0] != design.cell_ids.size:
        raise ValueError("expression_embedding must have one row per cell_id.")
    if not np.isfinite(values).all():
        raise ValueError("expression_embedding must be finite.")
    historical_plan = build_sampling_plan(
        design.stratum_id,
        design.quota_by_stratum,
        values,
        np.ones(design.cell_ids.size, dtype=float),
        method="v2_1_coordinate_only",
    )
    selected = draw_fixed_size_sample(historical_plan, random_seed=random_seed)
    singleton = [
        stratum
        for stratum, positions in design.positions_by_stratum.items()
        if design.quota_by_stratum[stratum] == 1 and design.quota_by_stratum[stratum] < positions.size
    ]
    expression_assisted = [
        stratum
        for stratum, positions in design.positions_by_stratum.items()
        if 1 < design.quota_by_stratum[stratum] < positions.size
    ]
    return build_probability_result(
        design=design,
        selected_indices=selected,
        inclusion_probability=historical_plan.inclusion_probability,
        metadata=metadata.values,
        random_seed=random_seed,
        warnings=(
            "Legacy compatibility method: it uses expression embedding for local pivotal "
            "pairing when 1 < q_g < N_g and must not be described as coordinate-only, "
            "spatial-only, or pure spatial.",
        ),
        diagnostics={
            "historical_method_id": "v2_1_coordinate_only",
            "q_g_equals_one_behavior": "equal-probability categorical draw; embedding does not change this stratum",
            "q_g_greater_than_one_behavior": "expression embedding defines local pivotal edges and can change joint samples",
            "singleton_strata": [str(value) for value in singleton],
            "expression_assisted_strata": [str(value) for value in expression_assisted],
            "legacy_aliases": list(metadata["legacy_aliases"]),
        },
    )
