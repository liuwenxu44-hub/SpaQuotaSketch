"""V15 hierarchical-state, multi-scale candidate generation and selection."""

from __future__ import annotations

from collections import Counter, defaultdict
from typing import Hashable, Sequence

import numpy as np

from .soft_balance import proportional_quotas


def _l1_error(reference: Sequence[Hashable], selected: Sequence[Hashable]) -> float:
    reference_counts = Counter(reference)
    selected_counts = Counter(selected)
    labels = set(reference_counts) | set(selected_counts)
    n_reference = max(1, sum(reference_counts.values()))
    n_selected = max(1, sum(selected_counts.values()))
    return float(
        sum(
            abs(reference_counts.get(label, 0) / n_reference - selected_counts.get(label, 0) / n_selected)
            for label in labels
        )
    )


def _state_quotas(labels: Sequence[Hashable], target_n: int, minimum_one: bool = False) -> dict[Hashable, int]:
    quotas = proportional_quotas(list(labels), target_n)
    if not minimum_one or target_n <= 0:
        return quotas
    counts = Counter(labels)
    active = [label for label, count in counts.items() if count > 0]
    if target_n < len(active):
        return quotas
    deficits = [label for label in active if quotas[label] == 0]
    for label in deficits:
        donors = [candidate for candidate in active if quotas[candidate] > 1]
        if not donors:
            break
        donor = max(donors, key=lambda candidate: (quotas[candidate], counts[candidate]))
        quotas[donor] -= 1
        quotas[label] += 1
    return quotas


def hierarchical_expression_states(
    features,
    n_coarse_states: int = 8,
    n_fine_states: int = 32,
    seed: int = 0,
) -> tuple[list[str], list[str], dict[str, object]]:
    """Learn global fine states, then group their centers into coarse states.

    Fine states are deliberately learned on the full dataset before they are
    grouped.  This keeps their meaning global rather than allowing a tiny
    spatial region to redefine an expression state locally.
    """
    from sklearn.cluster import MiniBatchKMeans

    values = np.asarray(features, dtype=float)
    if values.ndim != 2 or values.shape[0] < 2 or not np.isfinite(values).all():
        raise ValueError("features must be a finite two-dimensional array with at least two rows.")
    n_obs = values.shape[0]
    n_fine_states = min(max(1, int(n_fine_states)), n_obs)
    n_coarse_states = min(max(1, int(n_coarse_states)), n_fine_states)
    fine_model = MiniBatchKMeans(
        n_clusters=n_fine_states,
        batch_size=min(4096, n_obs),
        n_init=3,
        max_iter=100,
        random_state=seed,
    )
    fine_codes = fine_model.fit_predict(values).astype(int)
    if n_coarse_states == 1:
        coarse_by_fine = np.zeros(n_fine_states, dtype=int)
    else:
        coarse_model = MiniBatchKMeans(
            n_clusters=n_coarse_states,
            batch_size=n_fine_states,
            n_init=3,
            max_iter=100,
            random_state=seed + 1,
        )
        coarse_by_fine = coarse_model.fit_predict(fine_model.cluster_centers_).astype(int)
    coarse_codes = coarse_by_fine[fine_codes]
    coarse_labels = [f"c{code}" for code in coarse_codes]
    fine_labels = [f"c{coarse_by_fine[code]}_f{code}" for code in fine_codes]
    return coarse_labels, fine_labels, {
        "n_coarse_states": int(n_coarse_states),
        "requested_fine_states": int(n_fine_states),
        "realized_fine_states": int(len(set(fine_codes.tolist()))),
        "state_hierarchy": "global_fine_mini_batch_kmeans_then_fine_center_coarsening",
    }


def _fine_spatial_quotas(
    fine_bin_ids: Sequence[Hashable],
    target_n: int,
    min_population: int,
) -> tuple[dict[Hashable, int], dict[str, int]]:
    """Allocate a local quota while protecting reachable fine spatial bins."""
    counts = Counter(fine_bin_ids)
    target_n = min(max(int(target_n), 0), sum(counts.values()))
    quotas = {label: 0 for label in counts}
    eligible = [label for label, count in counts.items() if count >= min_population]
    chosen = sorted(eligible, key=lambda label: (-counts[label], str(label)))[:target_n]
    for label in chosen:
        quotas[label] = 1
    remaining_n = target_n - len(chosen)
    if remaining_n > 0:
        residual_labels: list[Hashable] = []
        for label, count in counts.items():
            residual_labels.extend([label] * max(0, count - quotas[label]))
        additional = proportional_quotas(residual_labels, remaining_n)
        for label, quota in additional.items():
            quotas[label] += quota
    if sum(quotas.values()) != target_n:
        raise RuntimeError("Fine spatial quotas did not reach the requested local target.")
    return quotas, {
        "n_occupied_fine_bins": int(len(counts)),
        "n_reachable_fine_bins": int(len(eligible)),
        "n_reachable_fine_bins_protected": int(len(chosen)),
    }


def _hierarchical_state_quotas(
    coarse_state_ids: Sequence[Hashable],
    fine_state_ids: Sequence[Hashable],
    target_n: int,
) -> tuple[dict[Hashable, int], dict[Hashable, int]]:
    """Allocate exact nested global state quotas for a requested sample size."""
    coarse_quotas = _state_quotas(coarse_state_ids, target_n, minimum_one=True)
    by_coarse: dict[Hashable, list[Hashable]] = defaultdict(list)
    for coarse_state, fine_state in zip(coarse_state_ids, fine_state_ids):
        by_coarse[coarse_state].append(fine_state)
    fine_quotas: dict[Hashable, int] = {}
    for coarse_state, local_fine_states in by_coarse.items():
        local_quotas = _state_quotas(
            local_fine_states,
            int(coarse_quotas[coarse_state]),
            minimum_one=True,
        )
        fine_quotas.update(local_quotas)
    if sum(fine_quotas.values()) != target_n:
        raise RuntimeError("Hierarchical state quotas did not reach the requested target.")
    return coarse_quotas, fine_quotas


def _maximum_flow(
    row_quotas: dict[Hashable, int],
    state_quotas: dict[Hashable, int],
    pair_counts: dict[tuple[Hashable, Hashable], int],
) -> tuple[dict[tuple[Hashable, Hashable], int], int]:
    """Solve the row-by-state integer allocation with a small Dinic flow solver."""
    from collections import deque

    rows = list(row_quotas)
    states = list(state_quotas)
    row_nodes = {label: position + 1 for position, label in enumerate(rows)}
    state_start = 1 + len(rows)
    state_nodes = {label: state_start + position for position, label in enumerate(states)}
    source = 0
    sink = state_start + len(states)
    graph: list[list[list[int]]] = [[] for _ in range(sink + 1)]

    def add_edge(start: int, end: int, capacity: int) -> int:
        forward = [end, len(graph[end]), int(capacity), int(capacity)]
        backward = [start, len(graph[start]), 0, 0]
        graph[start].append(forward)
        graph[end].append(backward)
        return len(graph[start]) - 1

    for row, quota in row_quotas.items():
        add_edge(source, row_nodes[row], quota)
    edge_refs: dict[tuple[Hashable, Hashable], tuple[int, int]] = {}
    for (row, state), count in pair_counts.items():
        if row_quotas.get(row, 0) <= 0 or state_quotas.get(state, 0) <= 0 or count <= 0:
            continue
        node = row_nodes[row]
        edge_refs[(row, state)] = (node, add_edge(node, state_nodes[state], count))
    for state, quota in state_quotas.items():
        add_edge(state_nodes[state], sink, quota)

    def build_levels() -> list[int] | None:
        levels = [-1] * len(graph)
        levels[source] = 0
        queue = deque([source])
        while queue:
            node = queue.popleft()
            for edge in graph[node]:
                if edge[2] > 0 and levels[edge[0]] < 0:
                    levels[edge[0]] = levels[node] + 1
                    queue.append(edge[0])
        return levels if levels[sink] >= 0 else None

    def push(node: int, limit: int, levels: list[int], work: list[int]) -> int:
        if node == sink:
            return limit
        while work[node] < len(graph[node]):
            edge = graph[node][work[node]]
            if edge[2] > 0 and levels[edge[0]] == levels[node] + 1:
                moved = push(edge[0], min(limit, edge[2]), levels, work)
                if moved > 0:
                    edge[2] -= moved
                    graph[edge[0]][edge[1]][2] += moved
                    return moved
            work[node] += 1
        return 0

    total_flow = 0
    while (levels := build_levels()) is not None:
        work = [0] * len(graph)
        while True:
            moved = push(source, 10**12, levels, work)
            if moved <= 0:
                break
            total_flow += moved
    allocation = {
        pair: graph[node][edge_position][3] - graph[node][edge_position][2]
        for pair, (node, edge_position) in edge_refs.items()
        if graph[node][edge_position][3] > graph[node][edge_position][2]
    }
    return allocation, int(total_flow)


def _minimum_cost_joint_allocation(
    row_quotas: dict[Hashable, int],
    state_quotas: dict[Hashable, int],
    pair_counts: dict[tuple[Hashable, Hashable], int],
) -> tuple[dict[tuple[Hashable, Hashable], int], int, int | None]:
    """Match both margins while staying close to each row's original state mix.

    The flow has exact fine-spatial row quotas and exact global fine-state
    column quotas.  Its piecewise costs reward counts up to each cell's
    original proportional expectation, then prefer the largest remaining
    fractions before accepting larger deviations.
    """
    import networkx as nx

    target_n = int(sum(row_quotas.values()))
    source = ("source",)
    sink = ("sink",)
    graph = nx.DiGraph()
    graph.add_node(source, demand=-target_n)
    graph.add_node(sink, demand=target_n)
    row_nodes = {row: ("row", row) for row in row_quotas}
    state_nodes = {state: ("state", state) for state in state_quotas}
    for row, quota in row_quotas.items():
        graph.add_node(row_nodes[row], demand=0)
        graph.add_edge(source, row_nodes[row], capacity=int(quota), weight=0)
    for state, quota in state_quotas.items():
        graph.add_node(state_nodes[state], demand=0)
        graph.add_edge(state_nodes[state], sink, capacity=int(quota), weight=0)

    row_populations: Counter[Hashable] = Counter()
    for (row, _), count in pair_counts.items():
        row_populations[row] += int(count)
    segment_pairs: dict[Hashable, tuple[Hashable, Hashable]] = {}
    segment_id = 0
    for (row, state), count in pair_counts.items():
        capacity = min(int(count), int(row_quotas.get(row, 0)))
        if capacity <= 0 or state_quotas.get(state, 0) <= 0:
            continue
        expected = int(row_quotas[row]) * int(count) / max(1, int(row_populations[row]))
        lower = min(capacity, int(np.floor(expected)))
        fractional = float(expected - lower)
        segments: list[tuple[int, int]] = []
        if lower > 0:
            segments.append((lower, -1_000_000))
        if lower < capacity and fractional > 0:
            segments.append((1, -int(round(fractional * 1_000))))
            lower += 1
        if lower < capacity:
            segments.append((capacity - lower, 1_000_000))
        for segment_capacity, cost in segments:
            if segment_capacity <= 0:
                continue
            segment = ("segment", segment_id)
            segment_id += 1
            segment_pairs[segment] = (row, state)
            graph.add_node(segment, demand=0)
            graph.add_edge(row_nodes[row], segment, capacity=segment_capacity, weight=cost)
            graph.add_edge(segment, state_nodes[state], capacity=segment_capacity, weight=0)

    try:
        cost, flow = nx.network_simplex(graph)
    except nx.NetworkXUnfeasible:
        allocation, flow_units = _maximum_flow(row_quotas, state_quotas, pair_counts)
        return allocation, flow_units, None
    allocation: dict[tuple[Hashable, Hashable], int] = Counter()
    for segment, pair in segment_pairs.items():
        row = pair[0]
        amount = int(flow[row_nodes[row]].get(segment, 0))
        if amount > 0:
            allocation[pair] += amount
    flow_units = int(sum(allocation.values()))
    return dict(allocation), flow_units, int(cost)


def multiscale_hierarchical_candidate(
    primary_spatial_bin_ids: Sequence[Hashable],
    fine_spatial_bin_ids: Sequence[Hashable],
    coarse_state_ids: Sequence[Hashable],
    fine_state_ids: Sequence[Hashable],
    target_n: int,
    fine_min_population: int = 20,
    seed: int = 0,
) -> tuple[list[int], dict[str, object]]:
    """Draw one candidate using joint fine-spatial and global-state quotas.

    The primary spatial quota is hard.  Fine spatial coverage is protected
    inside each primary bin, while coarse and fine expression quotas are
    matched globally through an integer flow allocation.  These constraints
    are solved together instead of applying expression quotas separately in
    every small spatial bin.
    """
    n_obs = len(primary_spatial_bin_ids)
    if not (
        len(fine_spatial_bin_ids) == len(coarse_state_ids) == len(fine_state_ids) == n_obs
    ):
        raise ValueError("All label sequences must have the same length.")
    target_n = min(max(int(target_n), 0), n_obs)
    if target_n == 0:
        return [], {"n_selected": 0}

    primary_quotas = proportional_quotas(list(primary_spatial_bin_ids), target_n)
    by_primary: dict[Hashable, list[int]] = defaultdict(list)
    for index, label in enumerate(primary_spatial_bin_ids):
        by_primary[label].append(index)
    rng = np.random.default_rng(seed)
    fine_summary = {"n_occupied_fine_bins": 0, "n_reachable_fine_bins": 0, "n_reachable_fine_bins_protected": 0}
    fine_quotas: dict[Hashable, int] = {}
    for primary_label, local_indices_list in by_primary.items():
        local_indices = np.asarray(local_indices_list, dtype=int)
        primary_quota = int(primary_quotas[primary_label])
        if primary_quota <= 0:
            continue
        local_fine_bins = [fine_spatial_bin_ids[index] for index in local_indices]
        local_fine_quotas, local_summary = _fine_spatial_quotas(
            local_fine_bins, primary_quota, min_population=fine_min_population
        )
        fine_quotas.update(local_fine_quotas)
        for key in fine_summary:
            fine_summary[key] += local_summary[key]
    if sum(fine_quotas.values()) != target_n:
        raise RuntimeError("Fine spatial quotas did not reach the requested target.")

    _, state_quotas = _hierarchical_state_quotas(
        coarse_state_ids,
        fine_state_ids,
        target_n,
    )
    pair_indices: dict[tuple[Hashable, Hashable], list[int]] = defaultdict(list)
    for index, (fine_bin, fine_state) in enumerate(zip(fine_spatial_bin_ids, fine_state_ids)):
        pair_indices[(fine_bin, fine_state)].append(index)
    pair_counts = {pair: len(indices) for pair, indices in pair_indices.items()}
    planned_counts, flow_units, flow_cost = _minimum_cost_joint_allocation(
        fine_quotas,
        state_quotas,
        pair_counts,
    )

    # A small dataset can make all requested margins mutually impossible.
    # Keep the spatial quotas exact and fill only the unresolved row capacity;
    # the report exposes this relaxation instead of concealing it.
    allocated_by_fine = Counter()
    allocated_by_state = Counter()
    for (fine_bin, fine_state), count in planned_counts.items():
        allocated_by_fine[fine_bin] += count
        allocated_by_state[fine_state] += count
    if flow_units < target_n:
        for fine_bin, quota in fine_quotas.items():
            remaining = int(quota) - int(allocated_by_fine[fine_bin])
            if remaining <= 0:
                continue
            available = [
                state
                for (candidate_bin, state), indices in pair_indices.items()
                if candidate_bin == fine_bin
                and len(indices) > int(planned_counts.get((candidate_bin, state), 0))
            ]
            while remaining > 0 and available:
                state = max(
                    available,
                    key=lambda candidate: (
                        int(state_quotas[candidate]) - int(allocated_by_state[candidate]),
                        len(pair_indices[(fine_bin, candidate)])
                        - int(planned_counts.get((fine_bin, candidate), 0)),
                        str(candidate),
                    ),
                )
                key = (fine_bin, state)
                planned_counts[key] = int(planned_counts.get(key, 0)) + 1
                allocated_by_fine[fine_bin] += 1
                allocated_by_state[state] += 1
                remaining -= 1
                if planned_counts[key] >= len(pair_indices[key]):
                    available.remove(state)
            if remaining:
                raise RuntimeError("Could not fill a fine spatial quota after state-quota relaxation.")

    selected: list[int] = []
    for pair, count in planned_counts.items():
        if count <= 0:
            continue
        available = np.asarray(pair_indices[pair], dtype=int)
        chosen = available if count >= available.size else rng.choice(available, size=count, replace=False)
        selected.extend(chosen.astype(int).tolist())
    selected = sorted(selected)
    if len(selected) != target_n:
        raise RuntimeError(f"V15 candidate selected {len(selected)}, expected {target_n}.")
    selected_primary = [primary_spatial_bin_ids[index] for index in selected]
    selected_primary_counts = Counter(selected_primary)
    if any(selected_primary_counts.get(label, 0) != quota for label, quota in primary_quotas.items()):
        raise RuntimeError("V15 candidate did not preserve exact primary spatial quotas.")
    return selected, {
        "n_selected": int(len(selected)),
        "n_primary_spatial_bins": int(len(by_primary)),
        "state_flow_units": int(flow_units),
        "state_flow_feasible": bool(flow_units == target_n),
        "state_quota_relaxation_cells": int(target_n - flow_units),
        "joint_allocation_cost": flow_cost,
        "fine_state_quota_l1": _l1_error(
            fine_state_ids,
            [fine_state_ids[index] for index in selected],
        ),
        **fine_summary,
        "candidate_construction": "primary_spatial_quota_then_minimum_cost_joint_fine_spatial_hierarchical_state_flow",
    }


def candidate_metrics(
    primary_spatial_bin_ids: Sequence[Hashable],
    fine_spatial_bin_ids: Sequence[Hashable],
    coarse_state_ids: Sequence[Hashable],
    fine_state_ids: Sequence[Hashable],
    selected_indices: Sequence[int],
    expression_features,
    gene_view_a_mean_error: float = 0.0,
    gene_view_b_mean_error: float = 0.0,
) -> dict[str, float]:
    """Unlabeled candidate metrics used by V15 rank-based selection."""
    selected = np.asarray(selected_indices, dtype=int)
    values = np.asarray(expression_features, dtype=float)
    reference_mean = values.mean(axis=0)
    reference_variance = values.var(axis=0)
    sample_mean = values[selected].mean(axis=0)
    sample_variance = values[selected].var(axis=0)
    scale = np.sqrt(np.maximum(reference_variance, 1e-12))
    moment_loss = float(
        np.mean(((sample_mean - reference_mean) / scale) ** 2)
        + np.mean(((sample_variance - reference_variance) / np.maximum(reference_variance, 1e-12)) ** 2)
    )
    selected_fine_spatial = [fine_spatial_bin_ids[index] for index in selected]
    return {
        "moment_loss": moment_loss,
        "coarse_state_l1": _l1_error(coarse_state_ids, [coarse_state_ids[index] for index in selected]),
        "fine_state_l1": _l1_error(fine_state_ids, [fine_state_ids[index] for index in selected]),
        "fine_spatial_l1": _l1_error(fine_spatial_bin_ids, selected_fine_spatial),
        "fine_spatial_coverage_penalty": 1.0
        - len(set(fine_spatial_bin_ids).intersection(selected_fine_spatial)) / len(set(fine_spatial_bin_ids)),
        "gene_view_a_mean_error": float(gene_view_a_mean_error),
        "gene_view_b_mean_error": float(gene_view_b_mean_error),
    }


def select_stable_candidate(
    candidate_rows: list[dict[str, object]],
    metric_names: Sequence[str] | None = None,
) -> tuple[int, list[dict[str, object]]]:
    """Pick the lowest mean rank over independent unlabeled structure metrics."""
    if not candidate_rows:
        raise ValueError("candidate_rows must not be empty.")
    if metric_names is None:
        metric_names = [
            "moment_loss",
            "coarse_state_l1",
            "fine_state_l1",
            "fine_spatial_l1",
            "fine_spatial_coverage_penalty",
            "gene_view_a_mean_error",
            "gene_view_b_mean_error",
        ]
    if not metric_names:
        raise ValueError("metric_names must contain at least one metric.")
    missing = [
        metric
        for metric in metric_names
        if any(metric not in row for row in candidate_rows)
    ]
    if missing:
        raise ValueError(f"Candidate rows are missing metrics: {missing}")
    scored = [dict(row) for row in candidate_rows]
    for metric in metric_names:
        ordered = sorted(range(len(scored)), key=lambda index: (float(scored[index][metric]), int(scored[index]["seed"])))
        for rank, index in enumerate(ordered, start=1):
            scored[index][f"rank_{metric}"] = rank
    for row in scored:
        row["mean_rank"] = float(np.mean([row[f"rank_{metric}"] for metric in metric_names]))
    winner = min(range(len(scored)), key=lambda index: (scored[index]["mean_rank"], int(scored[index]["seed"])))
    return winner, scored


__all__ = [
    "candidate_metrics",
    "hierarchical_expression_states",
    "multiscale_hierarchical_candidate",
    "select_stable_candidate",
]
