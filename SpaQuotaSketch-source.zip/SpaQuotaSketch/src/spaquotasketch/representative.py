"""Two-view representative initialization for constrained spatial sampling."""

from __future__ import annotations

from collections import defaultdict
from typing import Hashable, Sequence

from .soft_balance import proportional_quotas


def _standardize(values):
    import numpy as np

    mean = values.mean(axis=0)
    scale = values.std(axis=0)
    scale[scale <= np.finfo(float).eps] = 1.0
    return (values - mean) / scale


def _two_view_coordinates(raw_values, normalized_values):
    import numpy as np

    raw_standardized = _standardize(raw_values) / np.sqrt(raw_values.shape[1])
    normalized_standardized = _standardize(normalized_values) / np.sqrt(
        normalized_values.shape[1]
    )
    return np.concatenate([raw_standardized, normalized_standardized], axis=1)


def dual_view_spatial_representatives(
    spatial_bin_ids: Sequence[Hashable],
    raw_features,
    normalized_features,
    target_n: int,
    seed: int = 0,
) -> tuple[list[int], dict[str, object]]:
    """Select exact spatial quotas by two-view local representative clustering."""
    import numpy as np

    raw_values = np.asarray(raw_features, dtype=float)
    normalized_values = np.asarray(normalized_features, dtype=float)
    n_obs = len(spatial_bin_ids)
    if raw_values.ndim != 2 or normalized_values.ndim != 2:
        raise ValueError("Both feature views must be two-dimensional.")
    if raw_values.shape[0] != n_obs or normalized_values.shape[0] != n_obs:
        raise ValueError("Both feature views must have one row per observation.")
    if not np.isfinite(raw_values).all() or not np.isfinite(normalized_values).all():
        raise ValueError("Both feature views must contain finite values.")
    target_n = min(max(int(target_n), 0), n_obs)
    if target_n == 0:
        return [], {"n_selected": 0, "n_representative_bins": 0}

    quotas = proportional_quotas(list(spatial_bin_ids), target_n)
    indices_by_spatial: dict[Hashable, list[int]] = defaultdict(list)
    for index, spatial_bin_id in enumerate(spatial_bin_ids):
        indices_by_spatial[spatial_bin_id].append(index)

    selected: list[int] = []
    raw_distortion_total = 0.0
    normalized_distortion_total = 0.0
    n_distortion_cells = 0
    n_full_bin_selections = 0
    n_occupied_dual_view_grid_bins = 0
    rng = np.random.default_rng(seed)
    for spatial_position, (spatial_bin_id, indices_list) in enumerate(indices_by_spatial.items()):
        indices = np.asarray(indices_list, dtype=int)
        quota = int(quotas[spatial_bin_id])
        if quota <= 0:
            continue
        if quota >= indices.size:
            selected.extend(indices.tolist())
            n_full_bin_selections += 1
            continue

        local_raw = raw_values[indices]
        local_normalized = normalized_values[indices]
        coordinates = _two_view_coordinates(local_raw, local_normalized)
        # Project the two-view local structure onto its two main directions, then
        # draw representatives across an adaptive rectangular grid in that plane.
        centered = coordinates - coordinates.mean(axis=0, keepdims=True)
        _, _, right_vectors = np.linalg.svd(centered, full_matrices=False)
        n_components = min(2, right_vectors.shape[0])
        projection = centered @ right_vectors[:n_components].T
        if n_components == 1:
            projection = np.column_stack([projection[:, 0], np.zeros(indices.size)])

        n_x = max(1, int(np.ceil(np.sqrt(quota))))
        n_y = max(1, int(np.ceil(quota / n_x)))
        lower = projection.min(axis=0)
        span = projection.max(axis=0) - lower
        span[span <= np.finfo(float).eps] = 1.0
        grid_x = np.minimum(
            n_x - 1,
            np.floor((projection[:, 0] - lower[0]) / span[0] * n_x).astype(int),
        )
        grid_y = np.minimum(
            n_y - 1,
            np.floor((projection[:, 1] - lower[1]) / span[1] * n_y).astype(int),
        )
        grid_ids = (grid_x * n_y + grid_y).tolist()
        grid_quotas = proportional_quotas(grid_ids, quota)
        positions_by_grid: dict[int, list[int]] = defaultdict(list)
        for local_position, grid_id in enumerate(grid_ids):
            positions_by_grid[grid_id].append(local_position)

        local_selected_positions: list[int] = []
        for grid_id, positions_list in positions_by_grid.items():
            grid_quota = int(grid_quotas[grid_id])
            if grid_quota <= 0:
                continue
            positions = np.asarray(positions_list, dtype=int)
            if grid_quota >= positions.size:
                local_selected_positions.extend(positions.tolist())
                continue
            grid_coordinates = coordinates[positions]
            centroid = grid_coordinates.mean(axis=0, keepdims=True)
            distances = np.sum((grid_coordinates - centroid) ** 2, axis=1)
            ordered = positions[np.argsort(distances, kind="stable")]
            ranks = np.floor(
                (np.arange(grid_quota, dtype=float) + 0.5) * len(ordered) / grid_quota
            ).astype(int)
            local_selected_positions.extend(
                ordered[np.minimum(ranks, len(ordered) - 1)].tolist()
            )
        if len(local_selected_positions) != quota or len(set(local_selected_positions)) != quota:
            raise RuntimeError("Dual-view representative grid did not satisfy the local quota.")
        local_selected = indices[np.asarray(local_selected_positions, dtype=int)]
        selected.extend(local_selected.tolist())
        n_occupied_dual_view_grid_bins += int(len(positions_by_grid))

        report_n = min(int(indices.size), quota)
        report_positions = (
            np.arange(indices.size, dtype=int)
            if report_n == indices.size
            else rng.choice(indices.size, size=report_n, replace=False)
        )
        raw_distances = np.min(
            np.sum(
                (
                    local_raw[report_positions, None, :]
                    - local_raw[local_selected_positions][None, :, :]
                )
                ** 2,
                axis=2,
            ),
            axis=1,
        )
        normalized_distances = np.min(
            np.sum(
                (
                    local_normalized[report_positions, None, :]
                    - local_normalized[local_selected_positions][None, :, :]
                )
                ** 2,
                axis=2,
            ),
            axis=1,
        )
        raw_distortion_total += float(raw_distances.sum())
        normalized_distortion_total += float(normalized_distances.sum())
        n_distortion_cells += int(report_n)

    selected = sorted(set(int(index) for index in selected))
    if len(selected) != target_n:
        raise RuntimeError(
            f"Representative initializer selected {len(selected)} observations, expected {target_n}."
        )
    return selected, {
        "n_selected": len(selected),
        "n_representative_bins": int(len(indices_by_spatial) - n_full_bin_selections),
        "n_full_bin_selections": int(n_full_bin_selections),
        "mean_raw_local_distortion": float(raw_distortion_total / max(1, n_distortion_cells)),
        "mean_normalized_local_distortion": float(
            normalized_distortion_total / max(1, n_distortion_cells)
        ),
        "view_combination": "equal_per_component_after_within_bin_standardization",
        "representative_solver": "adaptive_dual_view_principal_grid",
        "n_occupied_dual_view_grid_bins": int(n_occupied_dual_view_grid_bins),
        "distortion_report": "one_report_point_per_requested_representative",
    }


def spatial_state_stratified_representatives(
    spatial_bin_ids: Sequence[Hashable],
    normalized_features,
    target_n: int,
    n_state_clusters: int = 32,
    seed: int = 0,
) -> tuple[list[int], dict[str, object]]:
    """Sample within each spatial quota while preserving unsupervised expression states."""
    import numpy as np
    from sklearn.cluster import MiniBatchKMeans

    values = np.asarray(normalized_features, dtype=float)
    n_obs = len(spatial_bin_ids)
    if values.ndim != 2 or values.shape[0] != n_obs:
        raise ValueError("Normalized features must have one two-dimensional row per observation.")
    if not np.isfinite(values).all():
        raise ValueError("Normalized features must contain finite values.")
    target_n = min(max(int(target_n), 0), n_obs)
    if target_n == 0:
        return [], {"n_selected": 0, "n_expression_states": 0}

    n_state_clusters = min(max(1, int(n_state_clusters)), n_obs)
    state_model = MiniBatchKMeans(
        n_clusters=n_state_clusters,
        batch_size=min(4096, n_obs),
        n_init=3,
        max_iter=100,
        random_state=seed,
    )
    state_ids = state_model.fit_predict(values).astype(int)
    spatial_quotas = proportional_quotas(list(spatial_bin_ids), target_n)
    indices_by_spatial: dict[Hashable, list[int]] = defaultdict(list)
    for index, spatial_bin_id in enumerate(spatial_bin_ids):
        indices_by_spatial[spatial_bin_id].append(index)

    selected: list[int] = []
    rng = np.random.default_rng(seed)
    n_selected_state_strata = 0
    for spatial_bin_id, indices_list in indices_by_spatial.items():
        indices = np.asarray(indices_list, dtype=int)
        quota = int(spatial_quotas[spatial_bin_id])
        if quota <= 0:
            continue
        if quota >= indices.size:
            selected.extend(indices.tolist())
            n_selected_state_strata += int(len(set(state_ids[indices].tolist())))
            continue
        local_state_ids = state_ids[indices].tolist()
        state_quotas = proportional_quotas(local_state_ids, quota)
        positions_by_state: dict[int, list[int]] = defaultdict(list)
        for local_position, state_id in enumerate(local_state_ids):
            positions_by_state[state_id].append(local_position)
        for state_id, positions_list in positions_by_state.items():
            state_quota = int(state_quotas[state_id])
            if state_quota <= 0:
                continue
            positions = np.asarray(positions_list, dtype=int)
            chosen = (
                positions
                if state_quota >= positions.size
                else rng.choice(positions, size=state_quota, replace=False)
            )
            selected.extend(indices[chosen].tolist())
            n_selected_state_strata += 1

    selected = sorted(set(int(index) for index in selected))
    if len(selected) != target_n:
        raise RuntimeError(
            f"State-stratified initializer selected {len(selected)} observations, expected {target_n}."
        )
    selected_state_ids = state_ids[np.asarray(selected, dtype=int)]
    return selected, {
        "n_selected": len(selected),
        "n_expression_states": int(n_state_clusters),
        "n_selected_expression_states": int(len(set(selected_state_ids.tolist()))),
        "n_selected_spatial_state_strata": int(n_selected_state_strata),
        "state_model": "MiniBatchKMeans_on_normalized_expression_embedding",
        "state_stratum_selection": "proportional_quota_then_seeded_random_within_stratum",
    }


def spatial_state_graph_coverage_representatives(
    spatial_bin_ids: Sequence[Hashable],
    normalized_features,
    knn_indices,
    target_n: int,
    n_state_clusters: int = 32,
    seed: int = 0,
) -> tuple[list[int], dict[str, object]]:
    """Keep V11 quotas while choosing graph-covering local representatives.

    The spatial quota and unsupervised expression-state quota are fixed exactly
    as in ``spatial_state_stratified_representatives``. Within each resulting
    stratum, representatives are selected greedily by the number of full-data
    expression-neighbor relationships they cover. Ties use graph in-degree and
    then distance to the stratum expression center. No labels are used.
    """
    import numpy as np
    from sklearn.cluster import MiniBatchKMeans

    values = np.asarray(normalized_features, dtype=float)
    n_obs = len(spatial_bin_ids)
    if values.ndim != 2 or values.shape[0] != n_obs:
        raise ValueError("Normalized features must have one two-dimensional row per observation.")
    if not np.isfinite(values).all():
        raise ValueError("Normalized features must contain finite values.")
    neighbors = np.asarray(knn_indices, dtype=int)
    if neighbors.ndim != 2 or neighbors.shape[0] != n_obs or neighbors.shape[1] < 1:
        raise ValueError("knn_indices must be a non-empty two-dimensional array with one row per observation.")
    if neighbors.min(initial=0) < 0 or neighbors.max(initial=-1) >= n_obs:
        raise ValueError("knn_indices contains an invalid observation index.")
    target_n = min(max(int(target_n), 0), n_obs)
    if target_n == 0:
        return [], {"n_selected": 0, "n_expression_states": 0}

    n_state_clusters = min(max(1, int(n_state_clusters)), n_obs)
    state_ids = MiniBatchKMeans(
        n_clusters=n_state_clusters,
        batch_size=min(4096, n_obs),
        n_init=3,
        max_iter=100,
        random_state=seed,
    ).fit_predict(values).astype(int)
    spatial_quotas = proportional_quotas(list(spatial_bin_ids), target_n)
    indices_by_spatial: dict[Hashable, list[int]] = defaultdict(list)
    for index, spatial_bin_id in enumerate(spatial_bin_ids):
        indices_by_spatial[spatial_bin_id].append(index)

    reverse_neighbors: list[list[int]] = [[] for _ in range(n_obs)]
    for source, targets in enumerate(neighbors):
        for target in targets.tolist():
            reverse_neighbors[int(target)].append(source)
    indegree = np.bincount(neighbors.reshape(-1), minlength=n_obs).astype(int)
    standardized = _standardize(values)

    selected: list[int] = []
    n_selected_state_strata = 0
    n_graph_selected_strata = 0
    total_local_graph_coverage = 0
    for spatial_bin_id, indices_list in indices_by_spatial.items():
        indices = np.asarray(indices_list, dtype=int)
        quota = int(spatial_quotas[spatial_bin_id])
        if quota <= 0:
            continue
        if quota >= indices.size:
            selected.extend(indices.tolist())
            n_selected_state_strata += int(len(set(state_ids[indices].tolist())))
            continue
        local_state_ids = state_ids[indices].tolist()
        state_quotas = proportional_quotas(local_state_ids, quota)
        positions_by_state: dict[int, list[int]] = defaultdict(list)
        for local_position, state_id in enumerate(local_state_ids):
            positions_by_state[state_id].append(local_position)
        for state_id, positions_list in positions_by_state.items():
            state_quota = int(state_quotas[state_id])
            if state_quota <= 0:
                continue
            positions = np.asarray(positions_list, dtype=int)
            candidates = indices[positions]
            if state_quota >= candidates.size:
                selected.extend(candidates.tolist())
                n_selected_state_strata += 1
                continue
            selected.extend(
                _graph_coverage_positions(
                    candidates,
                    standardized,
                    reverse_neighbors,
                    indegree,
                    state_quota,
                )
            )
            n_selected_state_strata += 1
            n_graph_selected_strata += 1

    selected = sorted(set(int(index) for index in selected))
    if len(selected) != target_n:
        raise RuntimeError(
            f"Graph-coverage initializer selected {len(selected)} observations, expected {target_n}."
        )
    selected_mask = np.zeros(n_obs, dtype=bool)
    selected_mask[np.asarray(selected, dtype=int)] = True
    represented = selected_mask | selected_mask[neighbors].any(axis=1)
    for index in selected:
        total_local_graph_coverage += len(reverse_neighbors[index]) + 1
    selected_state_ids = state_ids[np.asarray(selected, dtype=int)]
    return selected, {
        "n_selected": len(selected),
        "n_expression_states": int(n_state_clusters),
        "n_selected_expression_states": int(len(set(selected_state_ids.tolist()))),
        "n_selected_spatial_state_strata": int(n_selected_state_strata),
        "n_graph_selected_strata": int(n_graph_selected_strata),
        "mean_selected_graph_indegree": float(indegree[np.asarray(selected, dtype=int)].mean()),
        "graph_neighbor_coverage": float(represented.mean()),
        "mean_closed_reverse_neighbor_count": float(total_local_graph_coverage / len(selected)),
        "state_model": "MiniBatchKMeans_on_normalized_expression_embedding",
        "state_stratum_selection": "lexicographic_marginal_graph_coverage_then_indegree_then_expression_center",
    }


def _graph_coverage_positions(
    candidates,
    standardized_values,
    reverse_neighbors,
    indegree,
    target_n: int,
) -> list[int]:
    """Greedily cover distinct reverse-neighbor sets inside one fixed stratum."""
    import numpy as np

    values = standardized_values[candidates]
    centroid_distances = np.sum((values - values.mean(axis=0, keepdims=True)) ** 2, axis=1)
    remaining = list(range(candidates.size))
    covered: set[int] = set()
    selected: list[int] = []
    for _ in range(int(target_n)):
        best_position = None
        best_key = None
        for position in remaining:
            index = int(candidates[position])
            covered_cells = reverse_neighbors[index]
            marginal_gain = int(index not in covered) + sum(
                neighbor not in covered for neighbor in covered_cells
            )
            key = (
                int(marginal_gain),
                int(indegree[index]),
                -float(centroid_distances[position]),
                -index,
            )
            if best_key is None or key > best_key:
                best_key = key
                best_position = position
        if best_position is None:
            raise RuntimeError("Unable to choose a graph-covering representative.")
        best_index = int(candidates[best_position])
        selected.append(best_index)
        covered.add(best_index)
        covered.update(reverse_neighbors[best_index])
        remaining.remove(best_position)
    return selected


def spatial_state_representative_selection(
    spatial_bin_ids: Sequence[Hashable],
    normalized_features,
    target_n: int,
    n_state_clusters: int = 32,
    seed: int = 0,
    multi_representative_solver: str = "kmeans",
) -> tuple[list[int], dict[str, object]]:
    """Preserve spatial-state quotas while selecting local expression representatives.

    This is the deterministic V12 initializer. V11 chose a seeded random cell inside
    each spatial-expression stratum; here each stratum contributes cells nearest to
    its own expression centers. Spatial quotas and expression-state quotas remain
    unchanged.
    """
    import numpy as np
    from sklearn.cluster import KMeans, MiniBatchKMeans

    values = np.asarray(normalized_features, dtype=float)
    n_obs = len(spatial_bin_ids)
    if values.ndim != 2 or values.shape[0] != n_obs:
        raise ValueError("Normalized features must have one two-dimensional row per observation.")
    if not np.isfinite(values).all():
        raise ValueError("Normalized features must contain finite values.")
    target_n = min(max(int(target_n), 0), n_obs)
    if target_n == 0:
        return [], {"n_selected": 0, "n_expression_states": 0}

    # Equalize principal-component scales before measuring representative distances.
    if multi_representative_solver not in {"kmeans", "radial_quantiles"}:
        raise ValueError("multi_representative_solver must be 'kmeans' or 'radial_quantiles'.")
    standardized = _standardize(values)
    n_state_clusters = min(max(1, int(n_state_clusters)), n_obs)
    state_model = MiniBatchKMeans(
        n_clusters=n_state_clusters,
        batch_size=min(4096, n_obs),
        n_init=3,
        max_iter=100,
        random_state=seed,
    )
    state_ids = state_model.fit_predict(values).astype(int)
    spatial_quotas = proportional_quotas(list(spatial_bin_ids), target_n)
    indices_by_spatial: dict[Hashable, list[int]] = defaultdict(list)
    for index, spatial_bin_id in enumerate(spatial_bin_ids):
        indices_by_spatial[spatial_bin_id].append(index)

    selected: list[int] = []
    n_single_representatives = 0
    n_multi_representative_strata = 0
    stratum_counter = 0
    for spatial_bin_id, indices_list in indices_by_spatial.items():
        indices = np.asarray(indices_list, dtype=int)
        quota = int(spatial_quotas[spatial_bin_id])
        if quota <= 0:
            continue
        if quota >= indices.size:
            selected.extend(indices.tolist())
            continue
        local_state_ids = state_ids[indices].tolist()
        state_quotas = proportional_quotas(local_state_ids, quota)
        positions_by_state: dict[int, list[int]] = defaultdict(list)
        for local_position, state_id in enumerate(local_state_ids):
            positions_by_state[state_id].append(local_position)
        for state_id, positions_list in positions_by_state.items():
            state_quota = int(state_quotas[state_id])
            if state_quota <= 0:
                continue
            positions = np.asarray(positions_list, dtype=int)
            if state_quota >= positions.size:
                chosen_positions = positions
            else:
                stratum_values = standardized[indices[positions]]
                if state_quota == 1:
                    centroid = stratum_values.mean(axis=0, keepdims=True)
                    chosen_positions = positions[
                        np.asarray([np.argmin(np.sum((stratum_values - centroid) ** 2, axis=1))])
                    ]
                    n_single_representatives += 1
                elif multi_representative_solver == "kmeans":
                    model = KMeans(
                        n_clusters=state_quota,
                        n_init=1,
                        max_iter=50,
                        random_state=seed + stratum_counter,
                    )
                    labels = model.fit_predict(stratum_values)
                    chosen_local: list[int] = []
                    for cluster_id, center in enumerate(model.cluster_centers_):
                        members = np.flatnonzero(labels == cluster_id)
                        nearest = members[
                            np.argmin(np.sum((stratum_values[members] - center) ** 2, axis=1))
                        ]
                        chosen_local.append(int(nearest))
                    chosen_positions = positions[np.asarray(chosen_local, dtype=int)]
                    n_multi_representative_strata += 1
                else:
                    centroid = stratum_values.mean(axis=0, keepdims=True)
                    distances = np.sum((stratum_values - centroid) ** 2, axis=1)
                    ordered = np.argsort(distances, kind="stable")
                    ranks = np.floor(
                        (np.arange(state_quota, dtype=float) + 0.5) * len(ordered) / state_quota
                    ).astype(int)
                    chosen_positions = positions[np.minimum(ranks, len(ordered) - 1)]
                    n_multi_representative_strata += 1
            selected.extend(indices[chosen_positions].tolist())
            stratum_counter += 1

    selected = sorted(set(int(index) for index in selected))
    if len(selected) != target_n:
        raise RuntimeError(
            f"State-representative initializer selected {len(selected)} observations, expected {target_n}."
        )
    selected_state_ids = state_ids[np.asarray(selected, dtype=int)]
    return selected, {
        "n_selected": len(selected),
        "n_expression_states": int(n_state_clusters),
        "n_selected_expression_states": int(len(set(selected_state_ids.tolist()))),
        "state_model": "MiniBatchKMeans_on_normalized_expression_embedding",
        "state_stratum_selection": f"local_expression_medoid_or_{multi_representative_solver}",
        "n_single_representatives": int(n_single_representatives),
        "n_multi_representative_strata": int(n_multi_representative_strata),
    }


__all__ = [
    "dual_view_spatial_representatives",
    "spatial_state_representative_selection",
    "spatial_state_graph_coverage_representatives",
    "spatial_state_stratified_representatives",
]
