"""Label-free composition-locked sampling for SpaQuotaSketch V32."""

from __future__ import annotations

from collections import Counter, defaultdict
from typing import Hashable, Sequence

import numpy as np

from .soft_balance import proportional_quotas


def _validate_inputs(
    spatial_bin_ids: Sequence[Hashable],
    state_ids: Sequence[Hashable],
    expression_bin_ids: Sequence[Hashable],
    features: np.ndarray,
) -> tuple[int, np.ndarray]:
    n_obs = len(spatial_bin_ids)
    if len(state_ids) != n_obs or len(expression_bin_ids) != n_obs:
        raise ValueError("spatial, state, and expression identifiers must have equal length.")
    values = np.asarray(features, dtype=float)
    if values.ndim != 2 or values.shape[0] != n_obs:
        raise ValueError("features must be two-dimensional with one row per observation.")
    if not np.isfinite(values).all():
        raise ValueError("features must contain finite values.")
    return n_obs, values


def joint_spatial_state_quotas(
    spatial_bin_ids: Sequence[Hashable],
    state_ids: Sequence[Hashable],
    target_n: int,
) -> dict[tuple[Hashable, Hashable], int]:
    """Allocate exact spatial quotas and nested unsupervised-state quotas."""
    if len(spatial_bin_ids) != len(state_ids):
        raise ValueError("spatial_bin_ids and state_ids must have equal length.")
    if target_n < 0:
        raise ValueError("target_n must be non-negative.")
    target_n = min(int(target_n), len(spatial_bin_ids))
    spatial_quotas = proportional_quotas(list(spatial_bin_ids), target_n)
    states_by_spatial: dict[Hashable, list[Hashable]] = defaultdict(list)
    for spatial_bin_id, state_id in zip(spatial_bin_ids, state_ids):
        states_by_spatial[spatial_bin_id].append(state_id)

    quotas: dict[tuple[Hashable, Hashable], int] = {}
    for spatial_bin_id, local_states in states_by_spatial.items():
        local_quotas = proportional_quotas(local_states, spatial_quotas[spatial_bin_id])
        for state_id, quota in local_quotas.items():
            if quota > 0:
                quotas[(spatial_bin_id, state_id)] = int(quota)
    if sum(quotas.values()) != target_n:
        raise RuntimeError("Joint spatial-state quotas do not sum to target_n.")
    return quotas


def _moment_reference(values: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    mean = values.mean(axis=0)
    second = np.square(values).mean(axis=0)
    mean_scale = values.std(axis=0)
    second_scale = np.square(values).std(axis=0)
    mean_scale[mean_scale <= np.finfo(float).eps] = 1.0
    second_scale[second_scale <= np.finfo(float).eps] = 1.0
    return mean, second, mean_scale, second_scale


def _moment_loss(
    sums: np.ndarray,
    squared_sums: np.ndarray,
    n_selected: int,
    reference: tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray],
) -> float:
    mean, second, mean_scale, second_scale = reference
    selected_mean = sums / max(1, n_selected)
    selected_second = squared_sums / max(1, n_selected)
    standardized = np.concatenate(
        [
            (selected_mean - mean) / mean_scale,
            (selected_second - second) / second_scale,
        ]
    )
    return float(np.sqrt(np.mean(np.square(standardized))))


def _sample_candidates(candidates: np.ndarray, limit: int, rng: np.random.Generator) -> np.ndarray:
    if candidates.size <= limit:
        return candidates
    return np.sort(rng.choice(candidates, size=limit, replace=False))


def composition_locked_coverage_sample(
    spatial_bin_ids: Sequence[Hashable],
    state_ids: Sequence[Hashable],
    expression_bin_ids: Sequence[Hashable],
    features: np.ndarray,
    target_n: int,
    seed: int = 0,
    max_coverage_candidates: int = 128,
    max_balance_swaps: int = 80,
    balance_strata_per_pass: int = 320,
    balance_candidates_per_stratum: int = 10,
) -> tuple[list[int], dict[str, object]]:
    """Sample with exact spatial-state quotas and label-free expression repair.

    The selected count in every spatial-bin by unsupervised-expression-state
    stratum is fixed exactly. This provides a label-free proxy for local cell
    composition. Among choices satisfying those quotas, the function first
    maximizes global expression-bin coverage and then lowers a standardized
    first-and-second-moment discrepancy in the supplied feature space.
    """
    n_obs, values = _validate_inputs(
        spatial_bin_ids, state_ids, expression_bin_ids, features
    )
    target_n = min(max(int(target_n), 0), n_obs)
    if max_coverage_candidates < 1 or balance_strata_per_pass < 1 or balance_candidates_per_stratum < 1:
        raise ValueError("candidate limits must be positive.")
    if max_balance_swaps < 0:
        raise ValueError("max_balance_swaps must be non-negative.")
    if target_n == 0:
        return [], {
            "n_selected": 0,
            "n_joint_spatial_state_strata": 0,
            "preserved_joint_spatial_state_quotas": True,
        }

    strata = list(zip(spatial_bin_ids, state_ids))
    quota_plan = joint_spatial_state_quotas(spatial_bin_ids, state_ids, target_n)
    indices_by_stratum: dict[tuple[Hashable, Hashable], list[int]] = defaultdict(list)
    indices_by_expression: dict[Hashable, list[int]] = defaultdict(list)
    for index, (stratum, expression_bin_id) in enumerate(zip(strata, expression_bin_ids)):
        indices_by_stratum[stratum].append(index)
        indices_by_expression[expression_bin_id].append(index)

    rng = np.random.default_rng(seed)
    selected_mask = np.zeros(n_obs, dtype=bool)
    for stratum, quota in quota_plan.items():
        candidates = np.asarray(indices_by_stratum[stratum], dtype=int)
        if quota > candidates.size:
            raise RuntimeError("A joint spatial-state quota exceeds its population.")
        chosen = candidates if quota == candidates.size else rng.choice(candidates, size=quota, replace=False)
        selected_mask[chosen] = True
    if int(selected_mask.sum()) != target_n:
        raise RuntimeError("Initial selection does not match target_n.")

    reference = _moment_reference(values)
    selected_indices = np.flatnonzero(selected_mask)
    sums = values[selected_indices].sum(axis=0)
    squared_sums = np.square(values[selected_indices]).sum(axis=0)
    initial_loss = _moment_loss(sums, squared_sums, target_n, reference)
    expression_counts = Counter(expression_bin_ids[index] for index in selected_indices.tolist())
    expression_population = Counter(expression_bin_ids)
    initial_coverage = len(expression_counts) / max(1, len(expression_population))

    def apply_swap(leave_index: int, enter_index: int) -> None:
        nonlocal sums, squared_sums
        leave_label = expression_bin_ids[leave_index]
        enter_label = expression_bin_ids[enter_index]
        selected_mask[leave_index] = False
        selected_mask[enter_index] = True
        expression_counts[leave_label] -= 1
        if expression_counts[leave_label] == 0:
            del expression_counts[leave_label]
        expression_counts[enter_label] += 1
        sums = sums - values[leave_index] + values[enter_index]
        squared_sums = squared_sums - np.square(values[leave_index]) + np.square(values[enter_index])

    coverage_swaps = 0
    missing_labels = sorted(
        (label for label in expression_population if expression_counts[label] == 0),
        key=lambda label: (expression_population[label], str(label)),
    )
    for missing_label in missing_labels:
        best: tuple[float, int, int] | None = None
        candidates = np.asarray(indices_by_expression[missing_label], dtype=int)
        candidates = candidates[~selected_mask[candidates]]
        candidates = _sample_candidates(candidates, max_coverage_candidates, rng)
        for enter_index in candidates.tolist():
            stratum = strata[enter_index]
            selected_in_stratum = np.asarray(indices_by_stratum[stratum], dtype=int)
            selected_in_stratum = selected_in_stratum[selected_mask[selected_in_stratum]]
            removable = np.asarray(
                [
                    index
                    for index in selected_in_stratum.tolist()
                    if expression_counts[expression_bin_ids[index]] > 1
                ],
                dtype=int,
            )
            if removable.size == 0:
                continue
            candidate_sums = sums[None, :] - values[removable] + values[enter_index]
            candidate_squared_sums = (
                squared_sums[None, :]
                - np.square(values[removable])
                + np.square(values[enter_index])
            )
            mean, second, mean_scale, second_scale = reference
            standardized = np.concatenate(
                [
                    (candidate_sums / target_n - mean) / mean_scale,
                    (candidate_squared_sums / target_n - second) / second_scale,
                ],
                axis=1,
            )
            losses = np.sqrt(np.mean(np.square(standardized), axis=1))
            position = int(np.argmin(losses))
            proposal = (float(losses[position]), int(removable[position]), int(enter_index))
            if best is None or proposal < best:
                best = proposal
        if best is not None:
            _, leave_index, enter_index = best
            apply_swap(leave_index, enter_index)
            coverage_swaps += 1

    coverage_loss = _moment_loss(sums, squared_sums, target_n, reference)
    active_strata = [
        stratum
        for stratum, indices in indices_by_stratum.items()
        if selected_mask[np.asarray(indices, dtype=int)].any()
        and (~selected_mask[np.asarray(indices, dtype=int)]).any()
    ]
    balance_swaps = 0
    current_loss = coverage_loss
    while balance_swaps < max_balance_swaps and active_strata:
        sample_count = min(balance_strata_per_pass, len(active_strata))
        checked_positions = rng.choice(len(active_strata), size=sample_count, replace=False)
        best: tuple[float, int, int] | None = None
        for position in np.asarray(checked_positions, dtype=int).tolist():
            stratum = active_strata[position]
            all_indices = np.asarray(indices_by_stratum[stratum], dtype=int)
            selected_local = _sample_candidates(
                all_indices[selected_mask[all_indices]], balance_candidates_per_stratum, rng
            )
            unselected_local = _sample_candidates(
                all_indices[~selected_mask[all_indices]], balance_candidates_per_stratum, rng
            )
            for enter_index in unselected_local.tolist():
                for leave_index in selected_local.tolist():
                    leave_label = expression_bin_ids[leave_index]
                    enter_label = expression_bin_ids[enter_index]
                    if leave_label != enter_label and expression_counts[leave_label] <= 1:
                        continue
                    proposed_loss = _moment_loss(
                        sums - values[leave_index] + values[enter_index],
                        squared_sums - np.square(values[leave_index]) + np.square(values[enter_index]),
                        target_n,
                        reference,
                    )
                    proposal = (proposed_loss, leave_index, enter_index)
                    if proposed_loss + 1e-12 < current_loss and (best is None or proposal < best):
                        best = proposal
        if best is None:
            break
        current_loss, leave_index, enter_index = best
        apply_swap(leave_index, enter_index)
        balance_swaps += 1

    selected = np.flatnonzero(selected_mask).astype(int).tolist()
    selected_plan = Counter(strata[index] for index in selected)
    if selected_plan != Counter(quota_plan):
        raise RuntimeError("Selection changed an exact joint spatial-state quota.")
    final_coverage = len(expression_counts) / max(1, len(expression_population))
    return selected, {
        "n_selected": int(len(selected)),
        "n_joint_spatial_state_strata": int(len(quota_plan)),
        "preserved_joint_spatial_state_quotas": True,
        "joint_quota_definition": "spatial_quota_then_unsupervised_expression_state_quota",
        "n_expression_bins": int(len(expression_population)),
        "initial_expression_coverage": float(initial_coverage),
        "final_expression_coverage": float(final_coverage),
        "n_coverage_swaps": int(coverage_swaps),
        "n_balance_swaps": int(balance_swaps),
        "initial_standardized_moment_loss": float(initial_loss),
        "post_coverage_standardized_moment_loss": float(coverage_loss),
        "final_standardized_moment_loss": float(
            _moment_loss(sums, squared_sums, target_n, reference)
        ),
        "objective_order": [
            "exact sample size and spatial-state proxy quotas",
            "maximize global expression-bin coverage",
            "minimize standardized first-and-second-moment discrepancy",
        ],
        "annotations_used_for_selection": False,
    }


__all__ = ["composition_locked_coverage_sample", "joint_spatial_state_quotas"]
