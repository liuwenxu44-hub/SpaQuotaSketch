"""Dual-channel structural sampling primitives for SpaQuotaSketch V30."""

from __future__ import annotations

from collections import Counter, defaultdict
from typing import Hashable, Sequence

import numpy as np


def expression_neighbor_indices(expression_features, n_neighbors: int = 15) -> np.ndarray:
    """Build an expression-only neighbor graph, excluding each cell itself."""
    from sklearn.neighbors import NearestNeighbors

    values = np.asarray(expression_features, dtype=float)
    if values.ndim != 2 or values.shape[0] < 2 or not np.isfinite(values).all():
        raise ValueError("expression_features must be a finite two-dimensional array with two rows.")
    n_obs = values.shape[0]
    n_neighbors = min(max(1, int(n_neighbors)), n_obs - 1)
    raw = NearestNeighbors(n_neighbors=n_neighbors + 1, algorithm="auto").fit(values).kneighbors(
        values, return_distance=False
    )
    output = np.empty((n_obs, n_neighbors), dtype=int)
    for index, row in enumerate(raw):
        without_self = row[row != index]
        if without_self.size < n_neighbors:
            raise RuntimeError("Neighbor search did not return enough non-self neighbors.")
        output[index] = without_self[:n_neighbors]
    return output


def _validate_state_ids(state_ids, n_obs: int) -> tuple[np.ndarray, int]:
    states = np.asarray(state_ids, dtype=int)
    if states.shape != (n_obs,) or states.min(initial=0) < 0:
        raise ValueError("state_ids must be non-negative integers with one value per observation.")
    return states, int(states.max(initial=0) + 1)


def state_neighbor_histograms(state_ids, neighbor_indices: np.ndarray) -> np.ndarray:
    """Return each cell's distribution of neighboring expression states."""
    neighbors = np.asarray(neighbor_indices, dtype=int)
    if neighbors.ndim != 2 or neighbors.shape[1] < 1:
        raise ValueError("neighbor_indices must be a non-empty two-dimensional array.")
    states, n_states = _validate_state_ids(state_ids, neighbors.shape[0])
    if neighbors.min(initial=0) < 0 or neighbors.max(initial=-1) >= states.size:
        raise ValueError("neighbor_indices contains an invalid observation index.")
    histograms = np.zeros((states.size, n_states), dtype=float)
    owner = np.repeat(np.arange(states.size), neighbors.shape[1])
    np.add.at(histograms, (owner, states[neighbors.reshape(-1)]), 1.0 / neighbors.shape[1])
    return histograms


def state_neighbor_flow(
    state_ids,
    neighbor_histograms: np.ndarray,
    n_states: int | None = None,
) -> np.ndarray:
    """Aggregate cell-level neighbor state histograms into a state-flow matrix."""
    histograms = np.asarray(neighbor_histograms, dtype=float)
    states, inferred_n_states = _validate_state_ids(state_ids, histograms.shape[0])
    n_states = inferred_n_states if n_states is None else int(n_states)
    if n_states < inferred_n_states or histograms.shape[1] != n_states or not np.isfinite(histograms).all():
        raise ValueError("neighbor_histograms must have one finite column per expression state.")
    flow = np.zeros((n_states, n_states), dtype=float)
    np.add.at(flow, states, histograms)
    return flow / states.size


def state_flow_scale(reference_flows, target_flow: np.ndarray, confidence_level: float = 0.95) -> np.ndarray:
    """Estimate per-entry normal variation from repeated feasible reference samples."""
    values = np.asarray(reference_flows, dtype=float)
    target = np.asarray(target_flow, dtype=float)
    if values.ndim != 3 or values.shape[1:] != target.shape or not 0.5 < confidence_level < 1.0:
        raise ValueError("reference_flows and target_flow must have compatible shapes.")
    deviations = np.abs(values - target[None, :, :])
    scale = np.quantile(deviations, confidence_level, axis=0)
    return np.maximum(scale, 1.0 / max(1, values.shape[1] * values.shape[2] * 1000))


def standardized_state_flow_error(sample_flow: np.ndarray, target_flow: np.ndarray, scale: np.ndarray) -> float:
    """Return the largest scale-normalized state-flow deviation."""
    sample = np.asarray(sample_flow, dtype=float)
    target = np.asarray(target_flow, dtype=float)
    denominator = np.asarray(scale, dtype=float)
    if sample.shape != target.shape or denominator.shape != target.shape or np.any(denominator <= 0):
        raise ValueError("State-flow arrays and scale must have matching positive shapes.")
    return float(np.max(np.abs(sample - target) / denominator))


def sampled_state_flow(
    selected_indices: Sequence[int],
    expression_features,
    state_ids,
    n_neighbors: int = 15,
) -> np.ndarray:
    """Rebuild the sample graph and return its state-neighbor flow matrix."""
    selected = np.asarray(selected_indices, dtype=int)
    values = np.asarray(expression_features, dtype=float)
    states, n_states = _validate_state_ids(state_ids, values.shape[0])
    if (
        selected.ndim != 1
        or selected.size < 2
        or selected.size != np.unique(selected).size
        or selected.min(initial=0) < 0
        or selected.max(initial=-1) >= values.shape[0]
    ):
        raise ValueError("selected_indices must contain at least two unique valid observations.")
    local_states = states[selected]
    local_neighbors = expression_neighbor_indices(values[selected], n_neighbors=n_neighbors)
    local_histograms = state_neighbor_histograms(local_states, local_neighbors)
    flow = state_neighbor_flow(local_states, local_histograms, n_states=n_states)
    if flow.shape != (n_states, n_states):
        raise RuntimeError("Sampled state flow unexpectedly changed the state dimension.")
    return flow


def pca_moment_loss(selected_indices: Sequence[int], features) -> float:
    """Measure unweighted first- and second-moment error in a dense expression view."""
    selected = np.asarray(selected_indices, dtype=int)
    values = np.asarray(features, dtype=float)
    if values.ndim != 2 or selected.ndim != 1 or selected.size == 0:
        raise ValueError("features must be two-dimensional and selected_indices non-empty.")
    reference_mean = values.mean(axis=0)
    reference_variance = values.var(axis=0)
    observed = values[selected]
    observed_mean = observed.mean(axis=0)
    observed_variance = observed.var(axis=0)
    mean_scale = np.sqrt(np.maximum(reference_variance, 1e-12))
    variance_scale = np.maximum(reference_variance, 1e-12)
    return float(
        np.mean(np.square((observed_mean - reference_mean) / mean_scale))
        + np.mean(np.square((observed_variance - reference_variance) / variance_scale))
    )


def state_composition_l1(selected_indices: Sequence[int], state_ids) -> float:
    """Return unweighted state-proportion error for a selected cell set."""
    selected = np.asarray(selected_indices, dtype=int)
    states, n_states = _validate_state_ids(state_ids, len(state_ids))
    full = np.bincount(states, minlength=n_states) / states.size
    observed = np.bincount(states[selected], minlength=n_states) / selected.size
    return float(np.abs(observed - full).sum())


def flow_guarded_exchange_path(
    source_selected_indices: Sequence[int],
    spatial_bin_ids: Sequence[Hashable],
    state_ids,
    full_neighbor_histograms: np.ndarray,
    target_flow: np.ndarray,
    flow_scale: np.ndarray,
    moment_features,
    moment_loss_limit: float,
    state_l1_limit: float,
    max_rounds: int = 4,
    max_exchanges_per_round: int = 10,
    candidate_pool_size: int = 3,
) -> list[tuple[str, list[int], dict[str, object]]]:
    """Improve full-graph state flow with spatial and moment constraints.

    The search uses full-graph cell contributions as an efficient proposal score.
    The caller must still evaluate every snapshot on a rebuilt sample graph and
    on a disjoint gene view before accepting a final sample.
    """
    n_obs = len(spatial_bin_ids)
    states, n_states = _validate_state_ids(state_ids, n_obs)
    histograms = np.asarray(full_neighbor_histograms, dtype=float)
    target = np.asarray(target_flow, dtype=float)
    scale = np.asarray(flow_scale, dtype=float)
    features = np.asarray(moment_features, dtype=float)
    if (
        histograms.shape != (n_obs, n_states)
        or target.shape != (n_states, n_states)
        or scale.shape != target.shape
        or features.ndim != 2
        or features.shape[0] != n_obs
    ):
        raise ValueError("V30 exchange inputs have incompatible dimensions.")
    if max_rounds < 0 or max_exchanges_per_round < 1 or candidate_pool_size < 1:
        raise ValueError("Search controls must be non-negative or positive as appropriate.")
    source = np.asarray(source_selected_indices, dtype=int)
    if (
        source.ndim != 1
        or source.size == 0
        or source.size != np.unique(source).size
        or source.min(initial=0) < 0
        or source.max(initial=-1) >= n_obs
    ):
        raise ValueError("source_selected_indices must contain unique valid indices.")

    selected_mask = np.zeros(n_obs, dtype=bool)
    selected_mask[source] = True
    source_quotas = Counter(spatial_bin_ids[index] for index in source)
    indices_by_spatial: dict[Hashable, np.ndarray] = {}
    grouped: dict[Hashable, list[int]] = defaultdict(list)
    for index, spatial_bin in enumerate(spatial_bin_ids):
        grouped[spatial_bin].append(index)
    for spatial_bin, indices in grouped.items():
        indices_by_spatial[spatial_bin] = np.asarray(indices, dtype=int)

    n_selected = source.size
    full_mean = features.mean(axis=0)
    full_variance = features.var(axis=0)
    selected_sum = features[source].sum(axis=0)
    selected_squares = np.square(features[source]).sum(axis=0)
    state_counts = np.bincount(states[source], minlength=n_states).astype(int)
    flow_sum = np.zeros((n_states, n_states), dtype=float)
    for state in range(n_states):
        flow_sum[state] = histograms[source[states[source] == state]].sum(axis=0)

    def current_moment_loss(sum_values, square_values) -> float:
        observed_mean = sum_values / n_selected
        observed_variance = np.maximum(square_values / n_selected - observed_mean**2, 0.0)
        mean_scale = np.sqrt(np.maximum(full_variance, 1e-12))
        variance_scale = np.maximum(full_variance, 1e-12)
        return float(
            np.mean(np.square((observed_mean - full_mean) / mean_scale))
            + np.mean(np.square((observed_variance - full_variance) / variance_scale))
        )

    def current_state_l1(counts) -> float:
        return float(
            np.abs(counts / n_selected - np.bincount(states, minlength=n_states) / n_obs).sum()
        )

    def current_flow_error(sum_values) -> float:
        return standardized_state_flow_error(sum_values / n_selected, target, scale)

    path: list[tuple[str, list[int], dict[str, object]]] = []

    def append_snapshot(round_index: int, exchanges: int, cumulative_gain: float) -> None:
        selected = np.flatnonzero(selected_mask).astype(int)
        if Counter(spatial_bin_ids[index] for index in selected) != source_quotas:
            raise RuntimeError("V30 exchange changed a source spatial quota.")
        if np.any(state_counts[np.bincount(states[source], minlength=n_states) > 0] < 1):
            raise RuntimeError("V30 exchange removed a source expression state.")
        path.append(
            (
                f"round_{round_index:03d}",
                selected.tolist(),
                {
                    "candidate_name": f"round_{round_index:03d}",
                    "round_index": int(round_index),
                    "n_selected": int(n_selected),
                    "n_round_exchanges": int(exchanges),
                    "cumulative_flow_gain": float(cumulative_gain),
                    "selection_proxy_flow_error": float(current_flow_error(flow_sum)),
                    "selection_pca_moment_loss": float(current_moment_loss(selected_sum, selected_squares)),
                    "selection_state_composition_l1": float(current_state_l1(state_counts)),
                    "fixed_spatial_quotas_preserved": True,
                    "selection_state_coverage_preserved": True,
                },
            )
        )

    append_snapshot(0, 0, 0.0)
    cumulative_gain = 0.0
    for round_index in range(1, max_rounds + 1):
        residual = flow_sum / n_selected - target
        normalized_residual = residual / np.square(scale)
        proposals: list[tuple[float, int, int]] = []
        current_error = current_flow_error(flow_sum)
        for spatial_bin in sorted(source_quotas, key=str):
            local = indices_by_spatial[spatial_bin]
            incoming_all = local[~selected_mask[local]]
            outgoing_all = local[selected_mask[local]]
            if incoming_all.size == 0 or outgoing_all.size == 0:
                continue
            removable = outgoing_all[state_counts[states[outgoing_all]] > 1]
            if removable.size == 0:
                continue
            incoming_scores = np.einsum(
                "ij,ij->i", histograms[incoming_all], normalized_residual[states[incoming_all]]
            )
            outgoing_scores = np.einsum(
                "ij,ij->i", histograms[removable], normalized_residual[states[removable]]
            )
            incoming_pool = incoming_all[
                np.argsort(incoming_scores, kind="stable")[:candidate_pool_size]
            ]
            outgoing_pool = removable[
                np.argsort(-outgoing_scores, kind="stable")[:candidate_pool_size]
            ]
            best: tuple[float, int, int] | None = None
            for incoming in incoming_pool.tolist():
                for outgoing in outgoing_pool.tolist():
                    trial_sum = selected_sum - features[outgoing] + features[incoming]
                    trial_squares = (
                        selected_squares - np.square(features[outgoing]) + np.square(features[incoming])
                    )
                    if current_moment_loss(trial_sum, trial_squares) > moment_loss_limit + 1e-12:
                        continue
                    trial_counts = state_counts.copy()
                    trial_counts[states[outgoing]] -= 1
                    trial_counts[states[incoming]] += 1
                    if current_state_l1(trial_counts) > state_l1_limit + 1e-12:
                        continue
                    trial_flow = flow_sum.copy()
                    trial_flow[states[outgoing]] -= histograms[outgoing]
                    trial_flow[states[incoming]] += histograms[incoming]
                    trial_error = current_flow_error(trial_flow)
                    gain = current_error - trial_error
                    if gain <= 1e-12:
                        continue
                    candidate = (gain, incoming, outgoing)
                    if best is None or candidate[0] > best[0] + 1e-12 or (
                        abs(candidate[0] - best[0]) <= 1e-12 and candidate[1:] < best[1:]
                    ):
                        best = candidate
            if best is not None:
                proposals.append(best)

        exchanges = 0
        for _, incoming, outgoing in sorted(proposals, key=lambda item: (-item[0], item[1], item[2]))[
            :max_exchanges_per_round
        ]:
            if not selected_mask[outgoing] or selected_mask[incoming] or state_counts[states[outgoing]] <= 1:
                continue
            trial_sum = selected_sum - features[outgoing] + features[incoming]
            trial_squares = selected_squares - np.square(features[outgoing]) + np.square(features[incoming])
            if current_moment_loss(trial_sum, trial_squares) > moment_loss_limit + 1e-12:
                continue
            trial_counts = state_counts.copy()
            trial_counts[states[outgoing]] -= 1
            trial_counts[states[incoming]] += 1
            if current_state_l1(trial_counts) > state_l1_limit + 1e-12:
                continue
            trial_flow = flow_sum.copy()
            trial_flow[states[outgoing]] -= histograms[outgoing]
            trial_flow[states[incoming]] += histograms[incoming]
            gain = current_flow_error(flow_sum) - current_flow_error(trial_flow)
            if gain <= 1e-12:
                continue
            selected_mask[outgoing] = False
            selected_mask[incoming] = True
            selected_sum = trial_sum
            selected_squares = trial_squares
            state_counts = trial_counts
            flow_sum = trial_flow
            cumulative_gain += gain
            exchanges += 1
        append_snapshot(round_index, exchanges, cumulative_gain)
        if exchanges == 0:
            break
    return path


__all__ = [
    "expression_neighbor_indices",
    "flow_guarded_exchange_path",
    "pca_moment_loss",
    "sampled_state_flow",
    "standardized_state_flow_error",
    "state_composition_l1",
    "state_flow_scale",
    "state_neighbor_flow",
    "state_neighbor_histograms",
]
