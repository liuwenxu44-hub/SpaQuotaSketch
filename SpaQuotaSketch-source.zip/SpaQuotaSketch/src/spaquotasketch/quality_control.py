"""Reusable, conservative quality control for spatial expression matrices."""

from __future__ import annotations

from copy import deepcopy
from typing import Any

import numpy as np


DEFAULT_QC_CONFIG: dict[str, Any] = {
    "feature_filter": {
        "feature_type_column": "feature_type",
        "include_feature_types": ["gene"],
    },
    "cell_filter": {
        "require_finite_spatial_coordinates": True,
        "min_total_gene_counts_absolute": 20,
        "min_detected_genes_absolute": 10,
        "lower_tail_quantile": 0.005,
        "max_negative_control_fraction": 0.05,
        "minimum_retained_fraction": 0.98,
    },
    "warning_only": {
        "high_value_quantile": 0.995,
        "area_lower_quantile": 0.001,
        "area_upper_quantile": 0.999,
    },
}

CONTROL_FEATURE_TYPES = {
    "negative_control_codeword",
    "negative_control_probe",
    "unassigned_codeword",
}


def merge_qc_config(overrides: dict[str, Any] | None = None) -> dict[str, Any]:
    """Return defaults updated by a nested configuration dictionary."""
    result = deepcopy(DEFAULT_QC_CONFIG)
    for section, values in (overrides or {}).items():
        if isinstance(values, dict) and isinstance(result.get(section), dict):
            result[section].update(values)
        else:
            result[section] = values
    return result


def _row_sums(matrix) -> np.ndarray:
    return np.asarray(matrix.sum(axis=1)).reshape(-1).astype(float)


def _detected_feature_counts(matrix) -> np.ndarray:
    return np.asarray((matrix > 0).sum(axis=1)).reshape(-1).astype(int)


def _quantile_threshold(values: np.ndarray, absolute_minimum: float, quantile: float) -> float:
    if not 0 <= quantile < 1:
        raise ValueError("lower_tail_quantile must be in [0, 1).")
    return float(max(absolute_minimum, np.floor(np.quantile(values, quantile))))


def _feature_masks(adata: Any, config: dict[str, Any]) -> tuple[np.ndarray, np.ndarray]:
    n_vars = int(adata.n_vars)
    feature_config = config["feature_filter"]
    column = feature_config["feature_type_column"]
    include_types = {str(value) for value in feature_config["include_feature_types"]}
    if column not in adata.var.columns:
        return np.ones(n_vars, dtype=bool), np.zeros(n_vars, dtype=bool)

    feature_types = adata.var[column].astype(str).to_numpy()
    included = np.isin(feature_types, list(include_types))
    controls = np.isin(feature_types, list(CONTROL_FEATURE_TYPES))
    if not included.any():
        raise ValueError(
            f"No features matched {column} values {sorted(include_types)}. "
            "Check the quality-control configuration."
        )
    return included, controls


def _area_warning_mask(values: np.ndarray, lower_quantile: float, upper_quantile: float) -> np.ndarray:
    finite = np.isfinite(values)
    if not finite.any():
        return np.ones(values.shape[0], dtype=bool)
    lower = np.quantile(values[finite], lower_quantile)
    upper = np.quantile(values[finite], upper_quantile)
    return ~finite | (values < lower) | (values > upper)


def apply_spatial_qc(adata: Any, config: dict[str, Any] | None = None) -> tuple[Any, dict[str, Any]]:
    """Filter invalid or low-information observations and technical features.

    High-count and unusual-area observations are recorded as warnings only. They can
    be real tumor, large-cell, or rare biological states and should not be removed by
    a universal automated rule.
    """
    from .preprocess import validate_spatial_anndata

    validate_spatial_anndata(adata)
    resolved = merge_qc_config(config)
    cell_config = resolved["cell_filter"]
    warning_config = resolved["warning_only"]
    gene_mask, control_mask = _feature_masks(adata, resolved)

    gene_matrix = adata.X[:, gene_mask]
    total_gene_counts = _row_sums(gene_matrix)
    detected_genes = _detected_feature_counts(gene_matrix)
    if control_mask.any():
        control_counts = _row_sums(adata.X[:, control_mask])
    else:
        control_counts = np.zeros(adata.n_obs, dtype=float)
    total_all_counts = total_gene_counts + control_counts
    control_fraction = np.divide(
        control_counts,
        total_all_counts,
        out=np.zeros(adata.n_obs, dtype=float),
        where=total_all_counts > 0,
    )

    coords = np.asarray(adata.obsm["spatial"], dtype=float)[:, :2]
    finite_spatial = np.isfinite(coords).all(axis=1)
    count_threshold = _quantile_threshold(
        total_gene_counts,
        float(cell_config["min_total_gene_counts_absolute"]),
        float(cell_config["lower_tail_quantile"]),
    )
    gene_threshold = _quantile_threshold(
        detected_genes,
        float(cell_config["min_detected_genes_absolute"]),
        float(cell_config["lower_tail_quantile"]),
    )
    passes_count = total_gene_counts >= count_threshold
    passes_genes = detected_genes >= gene_threshold
    passes_controls = control_fraction <= float(cell_config["max_negative_control_fraction"])
    passes_spatial = finite_spatial | (not bool(cell_config["require_finite_spatial_coordinates"]))
    passes = passes_count & passes_genes & passes_controls & passes_spatial

    warning_high_count = total_gene_counts > np.quantile(
        total_gene_counts, float(warning_config["high_value_quantile"])
    )
    warning_high_genes = detected_genes > np.quantile(
        detected_genes, float(warning_config["high_value_quantile"])
    )
    warning_area = np.zeros(adata.n_obs, dtype=bool)
    if "cell_area" in adata.obs.columns:
        warning_area = _area_warning_mask(
            adata.obs["cell_area"].to_numpy(dtype=float),
            float(warning_config["area_lower_quantile"]),
            float(warning_config["area_upper_quantile"]),
        )

    retained_fraction = float(passes.mean()) if adata.n_obs else 0.0
    required_fraction = float(cell_config["minimum_retained_fraction"])
    if retained_fraction < required_fraction:
        raise ValueError(
            f"Quality control would retain only {retained_fraction:.3%}, below the "
            f"configured minimum {required_fraction:.3%}. Review the input or thresholds."
        )

    annotated = adata.copy()
    annotated.obs["spaquotasketch_total_gene_counts"] = total_gene_counts
    annotated.obs["spaquotasketch_detected_genes"] = detected_genes
    annotated.obs["spaquotasketch_control_counts"] = control_counts
    annotated.obs["spaquotasketch_control_fraction"] = control_fraction
    annotated.obs["spaquotasketch_qc_pass"] = passes
    annotated.obs["spaquotasketch_qc_warning_high_count"] = warning_high_count
    annotated.obs["spaquotasketch_qc_warning_high_genes"] = warning_high_genes
    annotated.obs["spaquotasketch_qc_warning_area"] = warning_area
    filtered = annotated[passes, gene_mask].copy()

    report = {
        "n_input_cells_or_spots": int(adata.n_obs),
        "n_retained_cells_or_spots": int(filtered.n_obs),
        "retained_fraction": retained_fraction,
        "n_input_features": int(adata.n_vars),
        "n_retained_gene_features": int(filtered.n_vars),
        "n_excluded_technical_features": int((~gene_mask).sum()),
        "thresholds": {
            "min_total_gene_counts": count_threshold,
            "min_detected_genes": gene_threshold,
            "max_negative_control_fraction": float(cell_config["max_negative_control_fraction"]),
        },
        "excluded_cells_by_reason": {
            "invalid_spatial_coordinates": int((~passes_spatial).sum()),
            "low_total_gene_counts": int((~passes_count).sum()),
            "low_detected_genes": int((~passes_genes).sum()),
            "high_negative_control_fraction": int((~passes_controls).sum()),
            "excluded_by_any_rule": int((~passes).sum()),
        },
        "warning_only_cells": {
            "high_total_gene_counts": int(warning_high_count.sum()),
            "high_detected_genes": int(warning_high_genes.sum()),
            "unusual_cell_area": int(warning_area.sum()),
        },
        "resolved_config": resolved,
    }
    filtered.uns["spaquotasketch_quality_control"] = report
    return filtered, report


__all__ = ["DEFAULT_QC_CONFIG", "apply_spatial_qc", "merge_qc_config"]
