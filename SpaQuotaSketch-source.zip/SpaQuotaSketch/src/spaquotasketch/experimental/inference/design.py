"""Single-sketch design metadata for experimental design-based inference.

This module is deliberately isolated from the frozen sampling implementation.
It validates exported metadata but never draws or changes a sample.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np


EXPERIMENTAL_DESIGN_ID = "spaquotasketch_equal_v22_inference_gate0"
EXPERIMENTAL_DESIGN_VERSION = "0.1.0-gate0"


@dataclass(frozen=True)
class StratumSpec:
    stratum_id: str
    population_n: int
    sample_n: int

    def as_dict(self) -> dict[str, Any]:
        return {
            "stratum_id": self.stratum_id,
            "population_n": int(self.population_n),
            "sample_n": int(self.sample_n),
        }


@dataclass(frozen=True)
class SketchDesignMetadata:
    stable_ids: np.ndarray
    sample_strata: np.ndarray
    inclusion_probability: np.ndarray
    sampling_weight: np.ndarray
    auxiliary_coordinates: np.ndarray
    strata: tuple[StratumSpec, ...]
    population_n: int
    design_id: str = EXPERIMENTAL_DESIGN_ID
    design_version: str = EXPERIMENTAL_DESIGN_VERSION
    auxiliary_transform: str = "frozen_standardized_expression_embedding"
    seed_rule: str = "frozen_sampler_seed_rule; inference_has_no_rng"
    neighbor_rule: str = "canonical_stable_id_order; euclidean; distance_then_stable_id_ties"
    source_hashes: Mapping[str, str] | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema": "spaquotasketch.experimental.inference.design.v1",
            "design_id": self.design_id,
            "design_version": self.design_version,
            "population_n": int(self.population_n),
            "stable_ids": [str(x) for x in self.stable_ids.tolist()],
            "sample_strata": [str(x) for x in self.sample_strata.tolist()],
            "inclusion_probability": [float(x) for x in self.inclusion_probability.tolist()],
            "sampling_weight": [float(x) for x in self.sampling_weight.tolist()],
            "auxiliary_coordinates": np.asarray(self.auxiliary_coordinates, dtype=float).tolist(),
            "strata": [x.as_dict() for x in self.strata],
            "auxiliary_transform": self.auxiliary_transform,
            "seed_rule": self.seed_rule,
            "neighbor_rule": self.neighbor_rule,
            "source_hashes": dict(self.source_hashes or {}),
            "supported_estimands": [
                "fixed_finite_population_linear_total",
                "known_population_size_mean",
                "prespecified_binary_indicator_proportion",
            ],
        }

    def metadata_sha256(self) -> str:
        payload = json.dumps(
            self.as_dict(), sort_keys=True, separators=(",", ":"), ensure_ascii=False
        ).encode("utf-8")
        return hashlib.sha256(payload).hexdigest()

    def to_json(self, path: str | Path) -> None:
        payload = self.as_dict()
        payload["metadata_sha256"] = self.metadata_sha256()
        Path(path).write_text(
            json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
        )

    @classmethod
    def from_json(cls, path: str | Path) -> "SketchDesignMetadata":
        payload = json.loads(Path(path).read_text(encoding="utf-8"))
        expected = payload.pop("metadata_sha256", None)
        obj = cls(
            stable_ids=np.asarray(payload["stable_ids"], dtype=object),
            sample_strata=np.asarray(payload["sample_strata"], dtype=object),
            inclusion_probability=np.asarray(payload["inclusion_probability"], dtype=float),
            sampling_weight=np.asarray(payload["sampling_weight"], dtype=float),
            auxiliary_coordinates=np.asarray(payload["auxiliary_coordinates"], dtype=float),
            strata=tuple(StratumSpec(**x) for x in payload["strata"]),
            population_n=int(payload["population_n"]),
            design_id=str(payload["design_id"]),
            design_version=str(payload["design_version"]),
            auxiliary_transform=str(payload["auxiliary_transform"]),
            seed_rule=str(payload["seed_rule"]),
            neighbor_rule=str(payload["neighbor_rule"]),
            source_hashes=payload.get("source_hashes", {}),
        )
        if expected is not None and expected != obj.metadata_sha256():
            raise ValueError("design metadata hash mismatch")
        return obj


def build_equal_design_metadata(
    *,
    stable_ids: Sequence[str],
    sample_strata: Sequence[str],
    auxiliary_coordinates: Any,
    stratum_population_n: Mapping[str, int],
    stratum_sample_n: Mapping[str, int],
    population_n: int,
    source_hashes: Mapping[str, str] | None = None,
) -> SketchDesignMetadata:
    ids = np.asarray(stable_ids, dtype=object)
    sample_h = np.asarray(sample_strata, dtype=object)
    coords = np.asarray(auxiliary_coordinates, dtype=float)
    specs = tuple(
        StratumSpec(str(h), int(stratum_population_n[h]), int(stratum_sample_n[h]))
        for h in sorted(stratum_population_n)
    )
    pi = np.asarray(
        [stratum_sample_n[str(h)] / stratum_population_n[str(h)] for h in sample_h],
        dtype=float,
    )
    obj = SketchDesignMetadata(
        stable_ids=ids,
        sample_strata=sample_h,
        inclusion_probability=pi,
        sampling_weight=1.0 / pi,
        auxiliary_coordinates=coords,
        strata=specs,
        population_n=int(population_n),
        source_hashes=source_hashes,
    )
    validate_design_metadata(obj)
    return obj


def validate_design_metadata(design: SketchDesignMetadata) -> dict[str, Any]:
    n = design.stable_ids.size
    arrays = [
        design.sample_strata.size,
        design.inclusion_probability.size,
        design.sampling_weight.size,
        design.auxiliary_coordinates.shape[0],
    ]
    if any(x != n for x in arrays) or n == 0:
        raise ValueError("sample metadata arrays must be aligned and nonempty")
    if len(set(map(str, design.stable_ids.tolist()))) != n:
        raise ValueError("stable IDs must be unique")
    if design.auxiliary_coordinates.ndim != 2 or not np.isfinite(
        design.auxiliary_coordinates
    ).all():
        raise ValueError("auxiliary coordinates must be a finite 2D matrix")
    pi = design.inclusion_probability
    if not np.isfinite(pi).all() or np.any(pi <= 0) or np.any(pi > 1):
        raise ValueError("sample inclusion probabilities must be in (0, 1]")
    if not np.allclose(design.sampling_weight, 1.0 / pi, atol=1e-12, rtol=1e-12):
        raise ValueError("sampling weights must equal 1/pi")
    specs = {x.stratum_id: x for x in design.strata}
    if len(specs) != len(design.strata):
        raise ValueError("stratum IDs must be unique")
    if sum(x.population_n for x in design.strata) != design.population_n:
        raise ValueError("stratum population sizes must sum to population_n")
    zero_quota = []
    singleton_noncensus = []
    census = []
    for h, spec in specs.items():
        if spec.population_n <= 0 or not 0 <= spec.sample_n <= spec.population_n:
            raise ValueError("invalid stratum population/sample size")
        observed = int(np.sum(design.sample_strata.astype(str) == h))
        if observed != spec.sample_n:
            raise ValueError(f"sample count mismatch for stratum {h}")
        if spec.sample_n == 0:
            zero_quota.append(h)
            continue
        expected_pi = spec.sample_n / spec.population_n
        local = pi[design.sample_strata.astype(str) == h]
        if not np.allclose(local, expected_pi, atol=1e-12, rtol=1e-12):
            raise ValueError(f"Equal probability mismatch for stratum {h}")
        if spec.sample_n == 1 and spec.population_n > 1:
            singleton_noncensus.append(h)
        if spec.sample_n == spec.population_n:
            census.append(h)
    denominator = float(design.sampling_weight.sum())
    expected_denominator = float(
        sum(x.population_n for x in design.strata if x.sample_n > 0)
    )
    if not np.isclose(denominator, expected_denominator, atol=1e-9, rtol=0):
        raise ValueError("inverse-probability denominator does not match covered population")
    return {
        "sample_n": int(n),
        "population_n": int(design.population_n),
        "weight_sum": denominator,
        "zero_quota_strata": zero_quota,
        "singleton_noncensus_strata": singleton_noncensus,
        "census_strata": census,
        "all_population_strata_covered": not zero_quota,
    }

