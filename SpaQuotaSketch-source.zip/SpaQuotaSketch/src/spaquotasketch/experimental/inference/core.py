"""Experimental one-sketch point and uncertainty estimates.

Intervals produced here are approximate and remain Gate-0-only. The module
does not read population truth or repeated-draw results.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from typing import Any, Literal

import numpy as np
from scipy.spatial import cKDTree
from scipy.stats import norm

from .design import SketchDesignMetadata, validate_design_metadata


Estimand = Literal["total", "mean", "proportion"]
VarianceMethod = Literal["local_difference_k1", "local_mean_k3", "srs_form"]


@dataclass(frozen=True)
class InferenceResult:
    estimate: float
    variance: float
    standard_error: float
    ci_lower: float
    ci_upper: float
    nominal_level: float
    variance_method: str
    inference_status: str
    refusal_reason: str
    design_id: str
    design_version: str
    estimand: str
    variable_definition: str
    interval_method: str
    sample_n: int
    population_n: int
    positive_count: int | None
    negative_count: int | None
    maximum_absolute_contribution_fraction: float
    diagnostic_json: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


def _canonical_neighbors(
    coordinates: np.ndarray, stable_ids: np.ndarray, k: int
) -> list[np.ndarray]:
    """Return deterministic sample neighbors without a dense distance matrix.

    The tree is built in stable-ID order. Exact distance ties at the kth radius
    are resolved by squared distance and then stable ID. Query-ball expansion
    can be quadratic when many coordinates are identical; this is diagnosed,
    not described as linear scaling.
    """
    n = len(stable_ids)
    if not 1 <= k < n:
        raise ValueError("k must be between one and sample_n - 1")
    canonical = np.argsort(stable_ids.astype(str), kind="mergesort")
    x = np.asarray(coordinates, dtype=float)[canonical]
    ids = stable_ids.astype(str)[canonical]
    tree = cKDTree(x)
    distances, _ = tree.query(x, k=k + 1, workers=1)
    distances = np.asarray(distances)
    if distances.ndim == 1:
        distances = distances[:, None]
    output: list[np.ndarray] = []
    inverse = np.empty(n, dtype=int)
    inverse[canonical] = np.arange(n)
    for row in range(n):
        radius = float(distances[row, -1])
        tolerance = max(1e-12, abs(radius) * 1e-12)
        candidates = tree.query_ball_point(x[row], radius + tolerance)
        candidates = [j for j in candidates if j != row]
        candidates.sort(key=lambda j: (float(np.sum((x[row] - x[j]) ** 2)), ids[j]))
        chosen_canonical = np.asarray(candidates[:k], dtype=int)
        if chosen_canonical.size < k:
            raise ValueError("insufficient distinct neighbor indices")
        output.append(canonical[chosen_canonical])
    # Return in original sample-row order.
    return [output[inverse[i]] for i in range(n)]


def local_variance_total(
    values: np.ndarray,
    design: SketchDesignMetadata,
    *,
    neighbors: int,
) -> tuple[float, dict[str, Any]]:
    y = np.asarray(values, dtype=float).reshape(-1)
    total = 0.0
    max_tie_multiplicity = 1
    for spec in design.strata:
        if spec.sample_n == 0 or spec.sample_n == spec.population_n:
            continue
        if spec.sample_n < 2:
            raise ValueError(f"noncensus singleton stratum: {spec.stratum_id}")
        mask = design.sample_strata.astype(str) == spec.stratum_id
        idx = np.flatnonzero(mask)
        k = min(int(neighbors), spec.sample_n - 1)
        x = design.auxiliary_coordinates[idx]
        ids = design.stable_ids[idx]
        local_neighbors = _canonical_neighbors(x, ids, k)
        z = y[idx] / design.inclusion_probability[idx]
        for local_i, neighbor_local in enumerate(local_neighbors):
            residual = z[local_i] - np.mean(np.r_[z[local_i], z[neighbor_local]])
            total += (k + 1.0) / k * residual * residual
        _, counts = np.unique(x, axis=0, return_counts=True)
        max_tie_multiplicity = max(max_tie_multiplicity, int(counts.max(initial=1)))
    return float(total), {
        "neighbor_count_requested": int(neighbors),
        "maximum_coordinate_tie_multiplicity": max_tie_multiplicity,
        "neighbor_storage": "sparse_index_lists",
        "worst_case_complexity": "quadratic_when_large_exact_tie_groups_expand_query_radius",
    }


def srs_form_variance_total(
    values: np.ndarray, design: SketchDesignMetadata
) -> tuple[float, dict[str, Any]]:
    y = np.asarray(values, dtype=float).reshape(-1)
    total = 0.0
    for spec in design.strata:
        if spec.sample_n == 0 or spec.sample_n == spec.population_n:
            continue
        if spec.sample_n < 2:
            raise ValueError(f"noncensus singleton stratum: {spec.stratum_id}")
        local = y[design.sample_strata.astype(str) == spec.stratum_id]
        total += (
            spec.population_n**2
            * (1.0 - spec.sample_n / spec.population_n)
            * float(np.var(local, ddof=1))
            / spec.sample_n
        )
    return float(total), {
        "warning": "SRS-form approximation is exact only for stratified SRS, not Equal LPM",
        "finite_population_correction": True,
    }


def _refused(
    *,
    estimate: float,
    method: str,
    design: SketchDesignMetadata,
    estimand: str,
    variable_definition: str,
    nominal_level: float,
    reason: str,
    positive_count: int | None,
    negative_count: int | None,
    influence: float,
    diagnostics: dict[str, Any],
) -> InferenceResult:
    return InferenceResult(
        estimate=float(estimate), variance=float("nan"), standard_error=float("nan"),
        ci_lower=float("nan"), ci_upper=float("nan"), nominal_level=float(nominal_level),
        variance_method=method, inference_status="REFUSED", refusal_reason=reason,
        design_id=design.design_id, design_version=design.design_version,
        estimand=estimand, variable_definition=variable_definition,
        interval_method="UNAVAILABLE", sample_n=int(len(design.stable_ids)),
        population_n=int(design.population_n), positive_count=positive_count,
        negative_count=negative_count, maximum_absolute_contribution_fraction=float(influence),
        diagnostic_json=json.dumps(diagnostics, sort_keys=True),
    )


def infer(
    values: Any,
    design: SketchDesignMetadata,
    *,
    estimand: Estimand,
    variance_method: VarianceMethod,
    variable_definition: str,
    nominal_level: float = 0.95,
    minimum_indicator_class_count: int = 2,
) -> InferenceResult:
    validation = validate_design_metadata(design)
    y = np.asarray(values, dtype=float).reshape(-1)
    if y.size != design.stable_ids.size or not np.isfinite(y).all():
        raise ValueError("sample values must be finite and align with design metadata")
    if estimand not in {"total", "mean", "proportion"}:
        raise ValueError("unsupported estimand")
    if not 0 < nominal_level < 1:
        raise ValueError("nominal_level must be in (0, 1)")
    if estimand == "proportion" and not np.all(np.isin(y, [0.0, 1.0])):
        raise ValueError("proportion values must be prespecified binary indicators")

    ht_total = float(np.sum(y * design.sampling_weight))
    estimate_value = ht_total if estimand == "total" else ht_total / design.population_n
    contributions = np.abs(y * design.sampling_weight)
    influence = float(contributions.max(initial=0.0) / max(contributions.sum(), 1e-15))
    positive = int(np.sum(y == 1)) if estimand == "proportion" else None
    negative = int(np.sum(y == 0)) if estimand == "proportion" else None

    if validation["zero_quota_strata"]:
        return _refused(
            estimate=float("nan"), method=variance_method, design=design, estimand=estimand,
            variable_definition=variable_definition, nominal_level=nominal_level,
            reason="ZERO_QUOTA_STRATUM_PREVENTS_FULL_POPULATION_INFERENCE",
            positive_count=positive, negative_count=negative, influence=influence,
            diagnostics=validation,
        )
    if validation["singleton_noncensus_strata"]:
        return _refused(
            estimate=estimate_value, method=variance_method, design=design, estimand=estimand,
            variable_definition=variable_definition, nominal_level=nominal_level,
            reason="NONCENSUS_SINGLETON_STRATUM_HAS_NO_WITHIN_STRATUM_VARIANCE",
            positive_count=positive, negative_count=negative, influence=influence,
            diagnostics=validation,
        )
    if estimand == "proportion" and (
        positive < minimum_indicator_class_count or negative < minimum_indicator_class_count
    ):
        return _refused(
            estimate=estimate_value, method=variance_method, design=design, estimand=estimand,
            variable_definition=variable_definition, nominal_level=nominal_level,
            reason="INSUFFICIENT_OBSERVED_INDICATOR_CLASS_COUNT",
            positive_count=positive, negative_count=negative, influence=influence,
            diagnostics=validation,
        )

    try:
        if variance_method == "local_difference_k1":
            variance_total, method_diag = local_variance_total(y, design, neighbors=1)
        elif variance_method == "local_mean_k3":
            variance_total, method_diag = local_variance_total(y, design, neighbors=3)
        elif variance_method == "srs_form":
            variance_total, method_diag = srs_form_variance_total(y, design)
        else:
            raise ValueError("unsupported variance method")
    except (ValueError, FloatingPointError) as exc:
        return _refused(
            estimate=estimate_value, method=variance_method, design=design, estimand=estimand,
            variable_definition=variable_definition, nominal_level=nominal_level,
            reason=f"VARIANCE_COMPUTATION_FAILED:{type(exc).__name__}",
            positive_count=positive, negative_count=negative, influence=influence,
            diagnostics=validation | {"error": str(exc)},
        )
    variance_value = variance_total if estimand == "total" else variance_total / design.population_n**2
    if not np.isfinite(variance_value) or variance_value < 0:
        return _refused(
            estimate=estimate_value, method=variance_method, design=design, estimand=estimand,
            variable_definition=variable_definition, nominal_level=nominal_level,
            reason="NONFINITE_OR_NEGATIVE_VARIANCE", positive_count=positive,
            negative_count=negative, influence=influence,
            diagnostics=validation | method_diag,
        )
    se = float(np.sqrt(variance_value))
    critical = float(norm.ppf(0.5 + nominal_level / 2.0))
    if estimand == "proportion":
        # Logit-delta interval is bounded but remains approximate.
        p = float(estimate_value)
        if not 0 < p < 1:
            return _refused(
                estimate=p, method=variance_method, design=design, estimand=estimand,
                variable_definition=variable_definition, nominal_level=nominal_level,
                reason="BOUNDARY_PROPORTION_HAS_NO_LOGIT_INTERVAL", positive_count=positive,
                negative_count=negative, influence=influence,
                diagnostics=validation | method_diag,
            )
        logit = float(np.log(p / (1.0 - p)))
        se_logit = se / (p * (1.0 - p))
        lower = 1.0 / (1.0 + np.exp(-(logit - critical * se_logit)))
        upper = 1.0 / (1.0 + np.exp(-(logit + critical * se_logit)))
        interval_method = "experimental_logit_delta"
    else:
        lower, upper = estimate_value - critical * se, estimate_value + critical * se
        interval_method = "experimental_normal"
    diagnostics = validation | method_diag | {
        "exact_design_interval": False,
        "influence_warning": influence > 0.50,
    }
    return InferenceResult(
        estimate=float(estimate_value), variance=float(variance_value), standard_error=se,
        ci_lower=float(lower), ci_upper=float(upper), nominal_level=float(nominal_level),
        variance_method=variance_method, inference_status="EXPERIMENTAL_APPROXIMATE",
        refusal_reason="", design_id=design.design_id, design_version=design.design_version,
        estimand=estimand, variable_definition=variable_definition,
        interval_method=interval_method, sample_n=int(y.size), population_n=int(design.population_n),
        positive_count=positive, negative_count=negative,
        maximum_absolute_contribution_fraction=influence,
        diagnostic_json=json.dumps(diagnostics, sort_keys=True),
    )

