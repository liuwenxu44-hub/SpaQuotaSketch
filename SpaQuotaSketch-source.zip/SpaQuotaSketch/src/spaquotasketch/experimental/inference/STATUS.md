# Experimental inference status

The experimental confidence-interval module is closed at Gate 0 with classification `C. GATE0_FAIL_UNDERCOVERAGE`. The preserved decision and complete evaluation records are under `results/inference_gate0_development_20260906`.

Confidence-interval validity was not established. The interval functions are not recommended for formal inference, scientific reporting, or production use. The Horvitz-Thompson total and known-population-size point estimators have different and narrower applicability conditions; their implementation does not validate the experimental interval approximation.

The source, frozen configuration, replicate-level results, refusals, failures, and deployment audit are retained unchanged. This result concerns the tested approximation and settings. It does not establish that every local-pivotal variance method is invalid. Any future work must begin as a new development stage with a new protocol and independent evaluation set.
