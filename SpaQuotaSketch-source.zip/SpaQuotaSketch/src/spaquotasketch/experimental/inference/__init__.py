"""Gate-0-only design-based inference from one SpaQuotaSketch sample."""

from .core import InferenceResult, infer, local_variance_total, srs_form_variance_total
from .design import (
    EXPERIMENTAL_DESIGN_ID,
    EXPERIMENTAL_DESIGN_VERSION,
    SketchDesignMetadata,
    StratumSpec,
    build_equal_design_metadata,
    validate_design_metadata,
)

__all__ = [
    "EXPERIMENTAL_DESIGN_ID",
    "EXPERIMENTAL_DESIGN_VERSION",
    "InferenceResult",
    "SketchDesignMetadata",
    "StratumSpec",
    "build_equal_design_metadata",
    "infer",
    "local_variance_total",
    "srs_form_variance_total",
    "validate_design_metadata",
]
