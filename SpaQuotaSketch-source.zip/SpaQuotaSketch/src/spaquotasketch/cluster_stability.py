"""Compare clustering stability within full and sampled analyses."""

from __future__ import annotations

from itertools import combinations
from typing import Mapping

import pandas as pd
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score


def _validated_assignments(frame: pd.DataFrame, label: str) -> pd.DataFrame:
    required = {"cell_id", "leiden"}
    if not required.issubset(frame.columns):
        raise ValueError(f"{label} must include cell_id and leiden columns.")
    result = frame[["cell_id", "leiden"]].copy()
    result["cell_id"] = result["cell_id"].astype(str)
    result["leiden"] = result["leiden"].astype(str)
    if result["cell_id"].duplicated().any():
        raise ValueError(f"{label} contains duplicate cell identifiers.")
    return result


def clustering_agreement(left: pd.DataFrame, right: pd.DataFrame) -> dict[str, float | int]:
    """Return label-invariant agreement metrics on shared cells."""
    left_frame = _validated_assignments(left, "left assignments").rename(
        columns={"leiden": "left_leiden"}
    )
    right_frame = _validated_assignments(right, "right assignments").rename(
        columns={"leiden": "right_leiden"}
    )
    merged = left_frame.merge(right_frame, on="cell_id", how="inner", validate="one_to_one")
    if merged.empty:
        raise ValueError("Assignments do not share any cells.")
    return {
        "n_cells": int(merged.shape[0]),
        "cluster_ari": float(
            adjusted_rand_score(merged["left_leiden"], merged["right_leiden"])
        ),
        "cluster_nmi": float(
            normalized_mutual_info_score(merged["left_leiden"], merged["right_leiden"])
        ),
    }


def clustering_stability_diagnosis(
    full_by_repeat: Mapping[int, pd.DataFrame],
    sample_by_repeat: Mapping[int, pd.DataFrame],
) -> pd.DataFrame:
    """Compare full and sampled clustering stability across matched repeats."""
    repeats = sorted(full_by_repeat)
    if repeats != sorted(sample_by_repeat):
        raise ValueError("full and sample assignments must use the same repeat identifiers.")
    if len(repeats) < 2:
        raise ValueError("At least two repeats are required for a stability diagnosis.")

    rows: list[dict[str, object]] = []
    for left_repeat, right_repeat in combinations(repeats, 2):
        full_scores = clustering_agreement(
            full_by_repeat[left_repeat], full_by_repeat[right_repeat]
        )
        rows.append(
            {
                "comparison_type": "full_repeat_stability_all_cells",
                "left_repeat": left_repeat,
                "right_repeat": right_repeat,
                **full_scores,
            }
        )
        sample_scores = clustering_agreement(
            sample_by_repeat[left_repeat], sample_by_repeat[right_repeat]
        )
        rows.append(
            {
                "comparison_type": "sample_repeat_stability",
                "left_repeat": left_repeat,
                "right_repeat": right_repeat,
                **sample_scores,
            }
        )

        sample_ids = _validated_assignments(
            sample_by_repeat[left_repeat], "sample assignments"
        )[["cell_id"]]
        left_full = _validated_assignments(
            full_by_repeat[left_repeat], "full assignments"
        ).merge(sample_ids, on="cell_id", how="inner", validate="one_to_one")
        right_full = _validated_assignments(
            full_by_repeat[right_repeat], "full assignments"
        ).merge(sample_ids, on="cell_id", how="inner", validate="one_to_one")
        restricted_scores = clustering_agreement(left_full, right_full)
        rows.append(
            {
                "comparison_type": "full_repeat_stability_on_sample_cells",
                "left_repeat": left_repeat,
                "right_repeat": right_repeat,
                **restricted_scores,
            }
        )

    for repeat in repeats:
        matched_scores = clustering_agreement(
            full_by_repeat[repeat], sample_by_repeat[repeat]
        )
        rows.append(
            {
                "comparison_type": "sample_vs_full_matched_repeat",
                "left_repeat": repeat,
                "right_repeat": repeat,
                **matched_scores,
            }
        )
    return pd.DataFrame(rows)


def summarize_cluster_stability(detail: pd.DataFrame) -> pd.DataFrame:
    """Summarize stability scores by comparison type."""
    required = {"comparison_type", "n_cells", "cluster_ari", "cluster_nmi"}
    if not required.issubset(detail.columns):
        raise ValueError("Detail table is missing stability metrics.")
    return (
        detail.groupby("comparison_type", as_index=False)
        .agg(
            n_comparisons=("cluster_ari", "size"),
            mean_n_cells=("n_cells", "mean"),
            mean_cluster_ari=("cluster_ari", "mean"),
            sd_cluster_ari=("cluster_ari", "std"),
            mean_cluster_nmi=("cluster_nmi", "mean"),
            sd_cluster_nmi=("cluster_nmi", "std"),
        )
        .sort_values("comparison_type")
        .reset_index(drop=True)
    )


__all__ = [
    "clustering_agreement",
    "clustering_stability_diagnosis",
    "summarize_cluster_stability",
]
