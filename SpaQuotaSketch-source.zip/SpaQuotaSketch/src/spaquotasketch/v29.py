"""Joint weighted reconstruction utilities for SpaQuotaSketch V29."""

from __future__ import annotations

from collections import Counter, defaultdict
from statistics import NormalDist
from typing import Hashable, Sequence

import numpy as np

from .metrics import (
    composition_error,
    relative_mean_absolute_error,
    weighted_column_detection_rate,
    weighted_column_mean,
    weighted_column_variance,
)


LOWER_IS_BETTER_METRICS = (
    "weighted_holdout_mean_relative_mae",
    "weighted_holdout_detection_relative_mae",
    "weighted_holdout_variance_relative_mae",
    "weighted_holdout_state_composition_l1",
    "weighted_holdout_graph_degree_l1",
)
HIGHER_IS_BETTER_METRICS = (
    "holdout_graph_coverage",
    "effective_sample_size_fraction",
)


def _standardize(values: np.ndarray) -> np.ndarray:
    scale = values.std(axis=0)
    scale[scale <= np.finfo(float).eps] = 1.0
    return (values - values.mean(axis=0, keepdims=True)) / scale


def build_joint_neighbor_graph(
    spatial_coordinates,
    expression_features,
    n_neighbors: int = 15,
):
    """Build a joint spatial-expression graph with data-scaled distances.

    Spatial coordinates and expression components are standardized separately and
    divided by the square root of their dimension. Neither source receives a
    manually chosen preference weight.
    """
    from scipy.sparse import csr_matrix
    from sklearn.neighbors import NearestNeighbors

    coordinates = np.asarray(spatial_coordinates, dtype=float)
    expression = np.asarray(expression_features, dtype=float)
    if coordinates.ndim != 2 or coordinates.shape[1] < 2:
        raise ValueError("spatial_coordinates must be a two-dimensional array with two columns.")
    if expression.ndim != 2 or expression.shape[0] != coordinates.shape[0]:
        raise ValueError("expression_features must have one row per spatial coordinate.")
    if not np.isfinite(coordinates).all() or not np.isfinite(expression).all():
        raise ValueError("Joint graph inputs must be finite.")
    n_obs = coordinates.shape[0]
    if n_obs < 2:
        raise ValueError("At least two observations are required for a neighbor graph.")
    n_neighbors = min(max(1, int(n_neighbors)), n_obs)
    joint_features = np.concatenate(
        [
            _standardize(coordinates[:, :2]) / np.sqrt(2.0),
            _standardize(expression) / np.sqrt(expression.shape[1]),
        ],
        axis=1,
    )
    distances, neighbors = NearestNeighbors(
        n_neighbors=n_neighbors,
        algorithm="auto",
    ).fit(joint_features).kneighbors(joint_features, return_distance=True)
    nonzero = distances[distances > np.finfo(float).eps]
    scale = float(np.median(nonzero)) if nonzero.size else 1.0
    affinity = np.exp(-0.5 * (distances / max(scale, np.finfo(float).eps)) ** 2)
    owner_rows = np.repeat(np.arange(n_obs, dtype=int), n_neighbors)
    reverse = csr_matrix(
        (
            np.ones(owner_rows.size, dtype=np.int8),
            (neighbors.reshape(-1), owner_rows),
        ),
        shape=(n_obs, n_obs),
    )
    return neighbors.astype(int), affinity.astype(float), reverse


def graph_coverage_values(selected_mask: np.ndarray, neighbors: np.ndarray, affinity: np.ndarray) -> np.ndarray:
    """Return the strongest selected-neighbor affinity for every observation."""
    selected = np.asarray(selected_mask, dtype=bool)
    if selected.ndim != 1 or neighbors.shape[0] != selected.size or affinity.shape != neighbors.shape:
        raise ValueError("selected_mask, neighbors, and affinity have incompatible shapes.")
    return np.max(affinity * selected[neighbors], axis=1)


def _affected_owners(reverse, first_index: int, second_index: int) -> np.ndarray:
    first = reverse.getrow(int(first_index)).indices
    second = reverse.getrow(int(second_index)).indices
    return np.unique(np.concatenate([first, second])).astype(int)


def _trial_coverage(
    selected_mask: np.ndarray,
    neighbors: np.ndarray,
    affinity: np.ndarray,
    owners: np.ndarray,
    removed_index: int | None = None,
    added_index: int | None = None,
) -> np.ndarray:
    local_selected = selected_mask[neighbors[owners]].copy()
    local_neighbors = neighbors[owners]
    if removed_index is not None:
        local_selected[local_neighbors == int(removed_index)] = False
    if added_index is not None:
        local_selected[local_neighbors == int(added_index)] = True
    return np.max(affinity[owners] * local_selected, axis=1)


def spatial_quota_graph_reconstruction_path(
    source_selected_indices: Sequence[int],
    spatial_bin_ids: Sequence[Hashable],
    state_ids: Sequence[Hashable],
    neighbors: np.ndarray,
    affinity: np.ndarray,
    reverse_graph,
    max_rounds: int = 4,
    candidate_pool_size: int = 3,
    max_exchanges_per_round: int | None = None,
) -> list[tuple[str, list[int], dict[str, object]]]:
    """Improve joint reconstruction while exactly preserving source spatial quotas.

    A round considers one best positive local replacement in each spatial bin.
    A cell cannot be removed when it is the final selected representative of its
    selection-view expression state. The caller recalibrates weights and applies
    independent checks between round snapshots.
    """
    n_obs = len(spatial_bin_ids)
    if len(state_ids) != n_obs:
        raise ValueError("state_ids must have the same length as spatial_bin_ids.")
    if max_rounds < 0 or candidate_pool_size < 1:
        raise ValueError("max_rounds must be non-negative and candidate_pool_size positive.")
    if max_exchanges_per_round is not None and max_exchanges_per_round < 1:
        raise ValueError("max_exchanges_per_round must be positive when provided.")
    neighbors = np.asarray(neighbors, dtype=int)
    affinity = np.asarray(affinity, dtype=float)
    if neighbors.ndim != 2 or affinity.shape != neighbors.shape or neighbors.shape[0] != n_obs:
        raise ValueError("neighbors and affinity must describe every observation.")
    if neighbors.min(initial=0) < 0 or neighbors.max(initial=-1) >= n_obs:
        raise ValueError("neighbors contains an invalid observation index.")

    source = np.asarray(source_selected_indices, dtype=int)
    if (
        source.ndim != 1
        or source.size == 0
        or source.size != np.unique(source).size
        or source.min(initial=0) < 0
        or source.max(initial=-1) >= n_obs
    ):
        raise ValueError("source_selected_indices must contain unique valid observation indices.")
    selected_mask = np.zeros(n_obs, dtype=bool)
    selected_mask[source] = True
    source_quotas = Counter(spatial_bin_ids[index] for index in source)
    state_counts = Counter(state_ids[index] for index in source)
    spatial_indices: dict[Hashable, np.ndarray] = {}
    temporary: dict[Hashable, list[int]] = defaultdict(list)
    for index, spatial_bin in enumerate(spatial_bin_ids):
        temporary[spatial_bin].append(index)
    for spatial_bin, indices in temporary.items():
        spatial_indices[spatial_bin] = np.asarray(indices, dtype=int)

    coverage = graph_coverage_values(selected_mask, neighbors, affinity)
    path: list[tuple[str, list[int], dict[str, object]]] = []
    round_budget = (
        int(max_exchanges_per_round)
        if max_exchanges_per_round is not None
        else max(1, int(np.ceil(np.sqrt(source.size))))
    )

    def append_snapshot(round_index: int, applied: int, gain: float) -> None:
        selected = np.flatnonzero(selected_mask).astype(int)
        observed_quotas = Counter(spatial_bin_ids[index] for index in selected)
        if observed_quotas != source_quotas:
            raise RuntimeError("Graph reconstruction changed a source spatial quota.")
        if any(count < 1 for count in state_counts.values()):
            raise RuntimeError("Graph reconstruction removed a selection-view state.")
        name = f"round_{round_index:03d}"
        path.append(
            (
                name,
                selected.tolist(),
                {
                    "candidate_name": name,
                    "round_index": int(round_index),
                    "n_selected": int(selected.size),
                    "n_round_exchanges": int(applied),
                    "max_exchanges_per_round": int(round_budget),
                    "cumulative_graph_gain": float(gain),
                    "selection_joint_graph_coverage": float(coverage.mean()),
                    "fixed_spatial_quotas_preserved": True,
                    "selection_state_coverage_preserved": True,
                    "selection_objective": "maximize_joint_spatial_expression_neighbor_reconstruction",
                },
            )
        )

    append_snapshot(round_index=0, applied=0, gain=0.0)
    cumulative_gain = 0.0
    for round_index in range(1, max_rounds + 1):
        proposals: list[tuple[float, int, int]] = []
        for spatial_bin in sorted(source_quotas, key=str):
            local = spatial_indices[spatial_bin]
            selected_local = local[selected_mask[local]]
            unselected_local = local[~selected_mask[local]]
            if selected_local.size == 0 or unselected_local.size == 0:
                continue
            removable = np.asarray(
                [index for index in selected_local if state_counts[state_ids[index]] > 1],
                dtype=int,
            )
            if removable.size == 0:
                continue

            addition_scores: list[tuple[float, int]] = []
            for incoming in unselected_local.tolist():
                owners = reverse_graph.getrow(int(incoming)).indices
                trial = _trial_coverage(
                    selected_mask, neighbors, affinity, owners, added_index=int(incoming)
                )
                addition_scores.append((float(trial.sum() - coverage[owners].sum()), int(incoming)))
            incoming_pool = [
                index
                for _, index in sorted(addition_scores, key=lambda item: (-item[0], item[1]))[
                    :candidate_pool_size
                ]
            ]

            removal_scores: list[tuple[float, int]] = []
            for outgoing in removable.tolist():
                owners = reverse_graph.getrow(int(outgoing)).indices
                trial = _trial_coverage(
                    selected_mask, neighbors, affinity, owners, removed_index=int(outgoing)
                )
                removal_scores.append((float(coverage[owners].sum() - trial.sum()), int(outgoing)))
            outgoing_pool = [
                index
                for _, index in sorted(removal_scores, key=lambda item: (item[0], item[1]))[
                    :candidate_pool_size
                ]
            ]

            best: tuple[float, int, int, np.ndarray, np.ndarray] | None = None
            for incoming in incoming_pool:
                for outgoing in outgoing_pool:
                    owners = _affected_owners(reverse_graph, incoming, outgoing)
                    trial = _trial_coverage(
                        selected_mask,
                        neighbors,
                        affinity,
                        owners,
                        removed_index=outgoing,
                        added_index=incoming,
                    )
                    gain = float(trial.sum() - coverage[owners].sum())
                    candidate = (gain, incoming, outgoing, owners, trial)
                    if gain > 1e-12 and (
                        best is None
                        or gain > best[0] + 1e-12
                        or (abs(gain - best[0]) <= 1e-12 and (incoming, outgoing) < (best[1], best[2]))
                    ):
                        best = candidate
            if best is None:
                continue
            gain, incoming, outgoing, _, _ = best
            proposals.append((gain, incoming, outgoing))

        round_exchanges = 0
        for _, incoming, outgoing in sorted(
            proposals,
            key=lambda item: (-item[0], item[1], item[2]),
        )[:round_budget]:
            if not selected_mask[outgoing] or selected_mask[incoming]:
                continue
            if state_counts[state_ids[outgoing]] <= 1:
                continue
            owners = _affected_owners(reverse_graph, incoming, outgoing)
            trial = _trial_coverage(
                selected_mask,
                neighbors,
                affinity,
                owners,
                removed_index=outgoing,
                added_index=incoming,
            )
            gain = float(trial.sum() - coverage[owners].sum())
            if gain <= 1e-12:
                continue
            selected_mask[outgoing] = False
            selected_mask[incoming] = True
            state_counts[state_ids[outgoing]] -= 1
            state_counts[state_ids[incoming]] += 1
            coverage[owners] = trial
            cumulative_gain += gain
            round_exchanges += 1
        append_snapshot(round_index, round_exchanges, cumulative_gain)
        if round_exchanges == 0:
            break
    return path


def effective_sample_size(weights) -> float:
    """Return the number of equally weighted cells represented by the weights."""
    values = np.asarray(weights, dtype=float).reshape(-1)
    if values.size == 0 or not np.isfinite(values).all() or np.any(values < 0):
        raise ValueError("weights must be finite, non-negative, and non-empty.")
    denominator = float(np.square(values).sum())
    if denominator <= 0:
        raise ValueError("weights must contain a positive value.")
    return float(np.square(values.sum()) / denominator)


def weighted_holdout_metrics(
    selected_indices: Sequence[int],
    weights,
    holdout_matrix,
    holdout_reference: dict[str, np.ndarray],
    holdout_structure: dict[str, np.ndarray],
) -> dict[str, float]:
    """Evaluate weighted gene and local-structure fidelity on held-out genes."""
    selected = np.asarray(selected_indices, dtype=int)
    values = np.asarray(weights, dtype=float).reshape(-1)
    state_ids = np.asarray(holdout_structure["state_ids"])
    degree_bins = np.asarray(holdout_structure["degree_bins"])
    neighbors = np.asarray(holdout_structure["neighbor_indices"], dtype=int)
    n_obs = state_ids.size
    if (
        selected.ndim != 1
        or selected.size == 0
        or selected.size != values.size
        or selected.size != np.unique(selected).size
        or selected.min(initial=0) < 0
        or selected.max(initial=-1) >= n_obs
        or degree_bins.shape != (n_obs,)
        or neighbors.ndim != 2
        or neighbors.shape[0] != n_obs
    ):
        raise ValueError("Selected indices, weights, and holdout structure are incompatible.")
    observed = holdout_matrix[selected]
    selected_mask = np.zeros(n_obs, dtype=bool)
    selected_mask[selected] = True
    represented = selected_mask | selected_mask[neighbors].any(axis=1)
    return {
        "weighted_holdout_mean_relative_mae": relative_mean_absolute_error(
            holdout_reference["mean"], weighted_column_mean(observed, values)
        ),
        "weighted_holdout_detection_relative_mae": relative_mean_absolute_error(
            holdout_reference["detection"], weighted_column_detection_rate(observed, values)
        ),
        "weighted_holdout_variance_relative_mae": relative_mean_absolute_error(
            holdout_reference["variance"], weighted_column_variance(observed, values)
        ),
        "weighted_holdout_state_composition_l1": composition_error(
            state_ids.tolist(), state_ids[selected].tolist(), values.tolist()
        ),
        "weighted_holdout_graph_degree_l1": composition_error(
            degree_bins.tolist(), degree_bins[selected].tolist(), values.tolist()
        ),
        "holdout_graph_coverage": float(represented.mean()),
        "effective_sample_size_fraction": float(effective_sample_size(values) / selected.size),
    }


def empirical_acceptance_thresholds(
    reference_rows: Sequence[dict[str, float]],
    confidence_level: float = 0.95,
) -> dict[str, float]:
    """Set acceptance limits from repeated feasible reference samples.

    Error metrics receive an upper limit at the requested quantile. Coverage and
    effective sample size receive a lower limit at the complementary quantile.
    """
    if not reference_rows:
        raise ValueError("reference_rows must not be empty.")
    if not 0.5 < confidence_level < 1.0:
        raise ValueError("confidence_level must be in (0.5, 1).")
    required = set(LOWER_IS_BETTER_METRICS) | set(HIGHER_IS_BETTER_METRICS)
    if any(required.difference(row) for row in reference_rows):
        raise ValueError("Each reference row must contain every V29 acceptance metric.")
    thresholds = {"confidence_level": float(confidence_level), "n_reference_samples": int(len(reference_rows))}
    for metric in LOWER_IS_BETTER_METRICS:
        thresholds[f"upper_{metric}"] = float(
            np.quantile([float(row[metric]) for row in reference_rows], confidence_level)
        )
    for metric in HIGHER_IS_BETTER_METRICS:
        thresholds[f"lower_{metric}"] = float(
            np.quantile([float(row[metric]) for row in reference_rows], 1.0 - confidence_level)
        )
    return thresholds


def anchor_acceptance_thresholds(
    reference_rows: Sequence[dict[str, float]],
    anchor_metrics: dict[str, float],
    confidence_level: float = 0.95,
) -> dict[str, float]:
    """Calibrate limits from reference samples while always admitting the anchor.

    The feasible source sample is an explicit non-inferiority anchor. Its allowed
    deviation is one one-sided confidence bound of the empirical variation among
    same-budget reference samples. This avoids an arbitrary zero-tolerance rule
    while retaining a data-derived limit for every metric.
    """
    thresholds = empirical_acceptance_thresholds(reference_rows, confidence_level)
    required = set(LOWER_IS_BETTER_METRICS) | set(HIGHER_IS_BETTER_METRICS)
    if required.difference(anchor_metrics):
        raise ValueError("anchor_metrics must contain every V29 acceptance metric.")
    normal_quantile = float(NormalDist().inv_cdf(confidence_level))
    thresholds["anchor_allowance_normal_quantile"] = normal_quantile
    for metric in LOWER_IS_BETTER_METRICS:
        values = np.asarray([float(row[metric]) for row in reference_rows], dtype=float)
        allowance = normal_quantile * float(values.std(ddof=1)) if values.size > 1 else 0.0
        thresholds[f"upper_{metric}"] = max(
            float(thresholds[f"upper_{metric}"]), float(anchor_metrics[metric]) + allowance
        )
        thresholds[f"anchor_allowance_{metric}"] = float(allowance)
    for metric in HIGHER_IS_BETTER_METRICS:
        values = np.asarray([float(row[metric]) for row in reference_rows], dtype=float)
        allowance = normal_quantile * float(values.std(ddof=1)) if values.size > 1 else 0.0
        thresholds[f"lower_{metric}"] = min(
            float(thresholds[f"lower_{metric}"]), float(anchor_metrics[metric]) - allowance
        )
        thresholds[f"anchor_allowance_{metric}"] = float(allowance)
    thresholds["anchor_metric_source"] = "source_selection_after_v29_weight_calibration"
    return thresholds


def passes_empirical_acceptance(metrics: dict[str, float], thresholds: dict[str, float]) -> bool:
    """Return whether one candidate lies inside all empirical acceptance limits."""
    for metric in LOWER_IS_BETTER_METRICS:
        if float(metrics[metric]) > float(thresholds[f"upper_{metric}"]) + 1e-12:
            return False
    for metric in HIGHER_IS_BETTER_METRICS:
        if float(metrics[metric]) < float(thresholds[f"lower_{metric}"]) - 1e-12:
            return False
    return True


__all__ = [
    "HIGHER_IS_BETTER_METRICS",
    "LOWER_IS_BETTER_METRICS",
    "build_joint_neighbor_graph",
    "effective_sample_size",
    "anchor_acceptance_thresholds",
    "empirical_acceptance_thresholds",
    "graph_coverage_values",
    "passes_empirical_acceptance",
    "spatial_quota_graph_reconstruction_path",
    "weighted_holdout_metrics",
]
