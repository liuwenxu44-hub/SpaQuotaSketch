"""Immutable execution support for the clean pancreas representation benchmark.

This module orchestrates existing samplers.  It deliberately does not change the
formal representation algorithm or any historical result.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import hashlib
import inspect
import json
import math
import os
from pathlib import Path
import subprocess
import threading
import time
from typing import Any, Callable, Iterable, Mapping, Sequence

import numpy as np
import pandas as pd
import yaml

from .core_workflow import bin_ids_for_indices, build_candidates_until_quota_feasible
from .metrics import (
    composition_error,
    matrix_column_mean,
    rare_cell_recall,
    relative_mean_absolute_error,
    spatial_coverage,
    weighted_column_mean,
)
from .preprocess import compute_pca_embedding, get_spatial_coordinates, validate_spatial_anndata
from .quota_sampling import sample_by_quota
from .samplers import (
    get_method_metadata,
    sample_spatial_pivotal,
    sample_spatial_stratified_srs,
    sample_uniform_srs,
)
from .spatial_bins import rectangular_grid_bins
from .spatial_group_fidelity import spatial_group_fidelity
from .v2_1.quota import allocate_largest_remainder_quotas


R1_METHODS = (
    "uniform_srs",
    "spatial_stratified_srs",
    "spatial_pivotal",
    "formal_representation_mode",
)
R1_FRACTIONS = (0.005, 0.01, 0.02, 0.05, 0.10)
R1_SEEDS = tuple(range(10))
METHOD_DISPLAY_NAMES = {
    "uniform_srs": "Uniform SRS",
    "spatial_stratified_srs": "Spatial-stratified SRS",
    "spatial_pivotal": "Spatial pivotal",
    "formal_representation_mode": "Formal representation mode",
}


class R1ValidationError(ValueError):
    """Raised when the frozen R1 benchmark contract is violated."""


@dataclass(frozen=True)
class Measurement:
    """Measured wall-clock duration and process memory around one operation."""

    seconds: float
    start_rss_mb: float
    peak_rss_mb: float


def sha256_file(path: str | Path, chunk_size: int = 1024 * 1024) -> str:
    """Return a streaming SHA256 digest without loading a file into memory."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def git_commit_hash(project_root: str | Path) -> str:
    """Return the checked-out revision used to generate an immutable run config."""
    completed = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=Path(project_root),
        check=True,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()


def target_n_from_fraction(n_cells: int, fraction: float) -> int:
    """Apply the preregistered floor rule with an explicit lower bound of one."""
    if n_cells < 1:
        raise R1ValidationError("R1 requires at least one input cell.")
    if not 0 < float(fraction) <= 1:
        raise R1ValidationError("Every target fraction must lie in (0, 1].")
    return max(1, min(int(n_cells), int(math.floor(int(n_cells) * float(fraction)))))


def choose_new_output_directory(results_root: str | Path, name: str) -> Path:
    """Choose an empty external result directory without overwriting an old run."""
    root = Path(results_root)
    primary = root / name
    if not primary.exists():
        return primary
    if not any(primary.iterdir()):
        return primary
    counter = 2
    while True:
        candidate = root / f"{name}_{counter:02d}"
        if not candidate.exists():
            return candidate
        counter += 1


def _read_yaml(path: str | Path) -> dict[str, Any]:
    with Path(path).open("r", encoding="utf-8") as handle:
        value = yaml.safe_load(handle)
    if not isinstance(value, dict):
        raise R1ValidationError(f"Expected a YAML mapping: {path}")
    return value


def _write_new_text(path: str | Path, content: str) -> Path:
    destination = Path(path)
    if destination.exists():
        raise FileExistsError(f"Refusing to overwrite R1 output: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(content, encoding="utf-8")
    return destination


def _write_new_csv(frame: pd.DataFrame, path: str | Path) -> Path:
    destination = Path(path)
    if destination.exists():
        raise FileExistsError(f"Refusing to overwrite R1 output: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(destination, index=False)
    return destination


def _write_new_json(value: Mapping[str, Any], path: str | Path) -> Path:
    return _write_new_text(
        path, json.dumps(_json_ready(value), ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    )


def _json_ready(value: Any) -> Any:
    """Convert NumPy and pathlib values before writing stable JSON provenance."""
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return [_json_ready(item) for item in value.tolist()]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {str(key): _json_ready(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_ready(item) for item in value]
    return value


def load_r1_plan(plan_path: str | Path) -> pd.DataFrame:
    """Load and validate exactly the R1 rows from the frozen external plan."""
    plan = pd.read_csv(Path(plan_path))
    required = {
        "plan_id",
        "dataset",
        "analysis_phase",
        "fraction",
        "method",
        "repeats",
        "shared_quotas",
        "q1_minimum_requirement",
    }
    missing = sorted(required - set(plan.columns))
    if missing:
        raise R1ValidationError(f"Frozen rerun plan is missing columns: {missing!r}")
    r1 = plan.loc[plan["analysis_phase"].eq("representation_clean_matrix")].copy()
    if r1.empty:
        raise R1ValidationError("Frozen rerun plan contains no R1 representation rows.")
    if set(r1["method"]) != set(R1_METHODS):
        raise R1ValidationError("R1 method set differs from the frozen four-method matrix.")
    if set(np.round(r1["fraction"].astype(float), 6)) != set(R1_FRACTIONS):
        raise R1ValidationError("R1 fraction set differs from the frozen five-fraction matrix.")
    if set(r1["repeats"].astype(int)) != {len(R1_SEEDS)}:
        raise R1ValidationError("R1 repeats differ from the frozen ten-seed requirement.")
    if not r1["shared_quotas"].astype(bool).all():
        raise R1ValidationError("Every R1 method must share the same quota vector.")
    if not r1["q1_minimum_requirement"].astype(bool).all():
        raise R1ValidationError("R1 requires a minimum quota of one per nonempty stratum.")
    expected = len(R1_METHODS) * len(R1_FRACTIONS)
    if len(r1) != expected:
        raise R1ValidationError(f"Expected {expected} R1 plan rows, found {len(r1)}.")
    return r1.sort_values(["fraction", "method"], kind="stable").reset_index(drop=True)


def check_r1_method_identities() -> list[dict[str, Any]]:
    """Verify metadata and public signatures for the four frozen R1 methods."""
    checks: list[dict[str, Any]] = []
    sampler_checks = {
        "uniform_srs": sample_uniform_srs,
        "spatial_stratified_srs": sample_spatial_stratified_srs,
        "spatial_pivotal": sample_spatial_pivotal,
    }
    expected_flags = {
        "uniform_srs": (False, False),
        "spatial_stratified_srs": (False, True),
        "spatial_pivotal": (False, True),
        "formal_representation_mode": (True, True),
    }
    for method_id in R1_METHODS:
        metadata = get_method_metadata(method_id)
        expected_expression, expected_spatial = expected_flags[method_id]
        if bool(metadata["uses_expression"]) != expected_expression:
            raise R1ValidationError(f"{method_id} has an unexpected expression-use declaration.")
        if bool(metadata["uses_spatial_coordinates"]) != expected_spatial:
            raise R1ValidationError(f"{method_id} has an unexpected spatial-use declaration.")
        if bool(metadata["uses_cell_labels"]) or bool(metadata["uses_domain_labels"]):
            raise R1ValidationError(f"{method_id} must not select using evaluation labels.")
        signature = None
        if method_id in sampler_checks:
            signature = sorted(inspect.signature(sampler_checks[method_id]).parameters)
            if not expected_expression and any(
                "expression" in value or "embedding" in value for value in signature
            ):
                raise R1ValidationError(f"Pure spatial method {method_id} accepts expression input.")
        checks.append(
            {
                "method_id": method_id,
                "method_display_name": METHOD_DISPLAY_NAMES[method_id],
                "uses_expression": expected_expression,
                "uses_spatial_coordinates": expected_spatial,
                "uses_cell_labels": False,
                "uses_domain_labels": False,
                "public_signature": ",".join(signature) if signature is not None else "formal_frozen_workflow",
                "registry_implementation_status": str(metadata.values.get("implementation_status", "")),
                "identity_check": "passed",
            }
        )
    return checks


def build_r1_config(
    *,
    project_root: str | Path,
    input_h5ad: str | Path,
    results_root: str | Path,
    rerun_plan_path: str | Path,
    registry_path: str | Path,
    audit_report_path: str | Path,
    output_name: str = "clean_baseline_pancreas_r1",
) -> tuple[dict[str, Any], Path]:
    """Build an immutable R1 config after checking the actual input and plan."""
    project = Path(project_root)
    input_path = Path(input_h5ad)
    if not input_path.exists():
        raise FileNotFoundError(f"Input h5ad is unavailable: {input_path}")
    plan = load_r1_plan(rerun_plan_path)
    identity_checks = check_r1_method_identities()
    for source in (rerun_plan_path, registry_path, audit_report_path):
        if not Path(source).exists():
            raise FileNotFoundError(f"Required frozen source is unavailable: {source}")

    import anndata as ad

    backed = ad.read_h5ad(input_path, backed="r")
    try:
        n_cells, n_genes = (int(backed.n_obs), int(backed.n_vars))
        obs_columns = [str(value) for value in backed.obs.columns]
        obsm_keys = [str(value) for value in backed.obsm.keys()]
    finally:
        backed.file.close()
    if "cell_group" not in obs_columns or "spatial" not in obsm_keys:
        raise R1ValidationError("R1 input must contain cell_group evaluation labels and spatial coordinates.")

    output_directory = choose_new_output_directory(results_root, output_name)
    target_sizes = {f"{fraction:.3f}": target_n_from_fraction(n_cells, fraction) for fraction in R1_FRACTIONS}
    candidate_per_seed = int(math.ceil(n_cells * 0.05))
    config: dict[str, Any] = {
        "r1_config_version": "clean-baseline-pancreas-r1-1",
        "dataset_id": "tenx_xenium_pancreas_cancer_qc",
        "input": {
            "h5ad_path": str(input_path),
            "sha256": sha256_file(input_path),
            "size_bytes": int(input_path.stat().st_size),
            "n_cells": n_cells,
            "n_genes": n_genes,
            "evaluation_cell_group_column": "cell_group",
            "spatial_coordinate_key": "spatial",
            "available_obs_columns": obs_columns,
        },
        "methods": list(R1_METHODS),
        "method_identity_checks": identity_checks,
        "target_fractions": list(R1_FRACTIONS),
        "target_n": target_sizes,
        "target_n_rule": "max(1, floor(n_cells * target_fraction))",
        "benchmark_repeat_seeds": list(R1_SEEDS),
        "selection_grid": {"kind": "fixed_rectangular", "n_x": 20, "n_y": 20},
        "evaluation_grid": {"kind": "fixed_rectangular", "n_x": 20, "n_y": 20},
        "quota_rule": {
            "name": "one_per_nonempty_grid_then_bounded_largest_remainder",
            "minimum_quota": 1,
            "shared_by": ["spatial_stratified_srs", "spatial_pivotal", "formal_representation_mode"],
            "reason": "Required by the frozen R1 q1_minimum_requirement; keeps all cells in a nonempty grid at positive first-order probability for probability methods.",
            "historical_difference": "This shared R1 quota vector is not the old unconstrained proportional fixed-grid vector. The formal algorithm itself is unchanged.",
        },
        "expression_preprocessing": {
            "function": "compute_pca_embedding",
            "input": "adata.X without normalization or log transform",
            "n_components": 30,
            "random_state": 0,
            "uses": ["formal candidate pool", "evaluation expression-state grid"],
        },
        "formal_candidate_pool": {
            "candidate_method": "stratified",
            "candidate_fraction_per_seed": 0.05,
            "n_select_per_seed": candidate_per_seed,
            "candidate_expression_grid": {"n_x": 10, "n_y": 10},
            "max_candidate_seeds": 20,
            "candidate_pool_seed_rule": "range(benchmark_repeat_seed * 20, benchmark_repeat_seed * 20 + 20)",
            "final_selection_seed_rule": "benchmark_repeat_seed",
            "weight_output": "composition_calibration_factor only; never sampling_weight",
        },
        "evaluation": {
            "expression_state_grid": {"n_x": 20, "n_y": 20},
            "rare_label_max_fraction": 0.01,
            "cell_group_metrics": True,
            "spatial_domain_metrics": "not_available_for_this_input",
            "nearest_neighbor_diagnostic": "median and mean nearest selected spatial neighbor distance",
            "gene_mean_error": "relative mean absolute error against full population",
        },
        "resource_measurement": {
            "memory_poll_interval_seconds": 0.02,
            "reported_components": [
                "data_read_seconds_shared",
                "spatial_quota_setup_seconds_shared",
                "expression_preprocessing_seconds_shared",
                "candidate_pool_seconds",
                "final_selection_seconds",
                "core_sampling_seconds",
                "metric_calculation_seconds",
                "output_seconds",
                "end_to_end_seconds_with_shared_cost",
                "end_to_end_seconds_amortized_shared_cost",
                "peak_rss_mb",
            ],
        },
        "source_provenance": {
            "rerun_plan_path": str(Path(rerun_plan_path)),
            "rerun_plan_sha256": sha256_file(rerun_plan_path),
            "method_registry_path": str(Path(registry_path)),
            "method_registry_sha256": sha256_file(registry_path),
            "historical_audit_report_path": str(Path(audit_report_path)),
            "historical_audit_report_sha256": sha256_file(audit_report_path),
            "code_commit": git_commit_hash(project),
            "legacy_validation_plan_difference": "configs/clean_baseline_validation_plan.yaml is limited to small synthetic validation and predates this separately authorized R1 execution; the machine-readable targeted R1 plan is the execution authority.",
        },
        "output": {
            "directory": str(output_directory),
            "overwrite_policy": "refuse_overwrite; choose a suffixed new directory when the primary directory is nonempty",
            "expected_official_run_units": len(R1_METHODS) * len(R1_FRACTIONS) * len(R1_SEEDS),
        },
    }
    return config, output_directory


def write_immutable_r1_config(config: Mapping[str, Any], output_directory: str | Path) -> tuple[Path, Path]:
    """Write the R1 YAML config once and a digest that is checked before execution."""
    directory = Path(output_directory)
    if directory.exists() and any(directory.iterdir()):
        raise FileExistsError(f"R1 output directory is not empty: {directory}")
    directory.mkdir(parents=True, exist_ok=False)
    config_path = directory / "pancreas_r1_run_config.yaml"
    content = yaml.safe_dump(dict(config), allow_unicode=True, sort_keys=False)
    _write_new_text(config_path, content)
    digest = sha256_file(config_path)
    digest_path = directory / "pancreas_r1_run_config.sha256"
    _write_new_text(digest_path, f"{digest}  {config_path.name}\n")
    _write_new_json(
        {
            "r1_config_path": str(config_path),
            "r1_config_sha256": digest,
            "official_run_units": int(config["output"]["expected_official_run_units"]),
            "status": "immutable_config_created",
        },
        directory / "config_manifest.json",
    )
    return config_path, digest_path


def verify_immutable_r1_config(config_path: str | Path) -> dict[str, Any]:
    """Reject execution when its config checksum or required identity contract changed."""
    path = Path(config_path)
    digest_path = path.with_suffix(".sha256")
    if not digest_path.exists():
        raise R1ValidationError(f"Missing config digest: {digest_path}")
    expected = digest_path.read_text(encoding="utf-8").split()[0]
    observed = sha256_file(path)
    if observed != expected:
        raise R1ValidationError("R1 configuration SHA256 differs from the frozen digest.")
    config = _read_yaml(path)
    if tuple(config.get("methods", [])) != R1_METHODS:
        raise R1ValidationError("R1 config method ordering or identity changed.")
    if tuple(float(value) for value in config.get("target_fractions", [])) != R1_FRACTIONS:
        raise R1ValidationError("R1 config fractions changed.")
    if tuple(int(value) for value in config.get("benchmark_repeat_seeds", [])) != R1_SEEDS:
        raise R1ValidationError("R1 config repeat seeds changed.")
    if int(config.get("quota_rule", {}).get("minimum_quota", 0)) != 1:
        raise R1ValidationError("R1 config no longer enforces a minimum quota of one.")
    check_r1_method_identities()
    return config


def measure_call(callback: Callable[[], Any], interval_seconds: float = 0.02) -> tuple[Any, Measurement]:
    """Measure wall time and process peak resident memory with one uniform protocol."""
    import psutil

    process = psutil.Process(os.getpid())
    start_rss_mb = float(process.memory_info().rss) / (1024 * 1024)
    peak = {"rss_mb": start_rss_mb}
    stopped = threading.Event()

    def monitor() -> None:
        while not stopped.is_set():
            peak["rss_mb"] = max(
                peak["rss_mb"], float(process.memory_info().rss) / (1024 * 1024)
            )
            time.sleep(interval_seconds)
        peak["rss_mb"] = max(
            peak["rss_mb"], float(process.memory_info().rss) / (1024 * 1024)
        )

    thread = threading.Thread(target=monitor, daemon=True)
    started = time.perf_counter()
    thread.start()
    try:
        result = callback()
    finally:
        stopped.set()
        thread.join()
    return result, Measurement(
        seconds=float(time.perf_counter() - started),
        start_rss_mb=start_rss_mb,
        peak_rss_mb=float(peak["rss_mb"]),
    )


def _as_observation_total(adata: Any) -> np.ndarray:
    """Return the fixed full-population expression-total outcome used for HT checks."""
    if "spaquotasketch_total_gene_counts" in adata.obs.columns:
        values = pd.to_numeric(
            adata.obs["spaquotasketch_total_gene_counts"], errors="raise"
        ).to_numpy(dtype=float)
    else:
        totals = adata.X.sum(axis=1)
        values = np.asarray(totals).reshape(-1).astype(float)
    if not np.isfinite(values).all() or (values < 0).any():
        raise R1ValidationError("The expression-total outcome must be finite and non-negative.")
    return values


def _stratum_table(spatial_bins: Sequence[str], target_n: int) -> tuple[dict[str, int], pd.DataFrame]:
    """Allocate the shared positive quotas required by the frozen R1 plan."""
    counts = Counter(str(value) for value in spatial_bins)
    strata = pd.DataFrame(
        {
            "spatial_stratum": sorted(counts),
            "N_g": [int(counts[stratum]) for stratum in sorted(counts)],
        }
    )
    allocation = allocate_largest_remainder_quotas(strata, int(target_n), minimum_quota=1)
    audit = allocation.audit.copy()
    if int(audit["q_g"].sum()) != int(target_n):
        raise R1ValidationError("The shared quota vector does not sum to target_n.")
    if (audit["q_g"] < 1).any() or (audit["q_g"] > audit["N_g"]).any():
        raise R1ValidationError("The shared quota vector violates its positive bounded rule.")
    audit["pi_value"] = audit["q_g"] / audit["N_g"]
    return {stratum: int(value) for stratum, value in allocation.quotas.items()}, audit


def _candidate_seed_set(config: Mapping[str, Any], benchmark_seed: int) -> list[int]:
    details = config["formal_candidate_pool"]
    maximum = int(details["max_candidate_seeds"])
    start = int(benchmark_seed) * maximum
    return list(range(start, start + maximum))


def _safe_float(value: Any) -> float:
    return float(value) if value is not None and np.isfinite(value) else float("nan")


def _nearest_neighbor_metrics(coordinates: np.ndarray, selected_indices: np.ndarray) -> dict[str, float]:
    """Compute descriptive selected-to-selected nearest-neighbor distances."""
    if selected_indices.size < 2:
        return {"nearest_selected_distance_median": float("nan"), "nearest_selected_distance_mean": float("nan")}
    from sklearn.neighbors import NearestNeighbors

    distances, _ = NearestNeighbors(n_neighbors=2).fit(coordinates[selected_indices]).kneighbors()
    nearest = distances[:, 1]
    return {
        "nearest_selected_distance_median": float(np.median(nearest)),
        "nearest_selected_distance_mean": float(np.mean(nearest)),
    }


def _probability_diagnostics(
    *,
    spatial_bins: np.ndarray,
    quota_audit: pd.DataFrame,
    inclusion_probability: np.ndarray,
) -> pd.DataFrame:
    """Make the per-stratum probability identity inspectable without saving all cells."""
    rows: list[dict[str, Any]] = []
    for row in quota_audit.itertuples(index=False):
        stratum = str(row.spatial_stratum)
        mask = spatial_bins == stratum
        probability = inclusion_probability[mask]
        rows.append(
            {
                "spatial_stratum": stratum,
                "N_g": int(row.N_g),
                "q_g": int(row.q_g),
                "pi_expected": float(row.pi_value),
                "pi_observed_min": float(np.min(probability)),
                "pi_observed_max": float(np.max(probability)),
                "pi_sum": float(np.sum(probability)),
                "pi_sum_minus_q_g": float(np.sum(probability) - int(row.q_g)),
                "positive_support": bool(np.all(probability > 0)),
            }
        )
    return pd.DataFrame(rows)


def _weight_diagnostics(weights: np.ndarray, selected_indices: np.ndarray) -> dict[str, float]:
    selected_weights = np.asarray(weights[selected_indices], dtype=float)
    if selected_weights.size == 0 or not np.isfinite(selected_weights).all():
        return {
            "weight_coefficient_of_variation": float("nan"),
            "maximum_weight": float("nan"),
            "maximum_to_median_weight": float("nan"),
            "kish_effective_sample_size": float("nan"),
            "kish_effective_sample_size_over_n": float("nan"),
        }
    mean = float(np.mean(selected_weights))
    coefficient = float(np.std(selected_weights, ddof=0) / mean) if mean > 0 else float("nan")
    sum_weight = float(np.sum(selected_weights))
    kish = (sum_weight * sum_weight) / float(np.sum(np.square(selected_weights)))
    median = float(np.median(selected_weights))
    return {
        "weight_coefficient_of_variation": coefficient,
        "maximum_weight": float(np.max(selected_weights)),
        "maximum_to_median_weight": float(np.max(selected_weights) / median) if median > 0 else float("nan"),
        "kish_effective_sample_size": float(kish),
        "kish_effective_sample_size_over_n": float(kish / selected_weights.size),
    }


def _probability_estimates(
    *,
    cell_groups: np.ndarray,
    expression_total: np.ndarray,
    selected_indices: np.ndarray,
    inclusion_probability: np.ndarray,
) -> dict[str, Any]:
    """Compute declared HT and Hajek diagnostics only when all cells have positive pi."""
    if np.any(inclusion_probability <= 0):
        return {
            "probability_design_eligible": False,
            "ht_total_expression_estimate": float("nan"),
            "ht_total_expression_relative_error": float("nan"),
            "hajek_mean_expression_estimate": float("nan"),
            "hajek_mean_expression_relative_error": float("nan"),
            "weighted_cell_group_l1_error": float("nan"),
            "probability_estimate_reason": "zero inclusion probability prevents full-population HT/Hajek estimation",
        }
    weights = 1.0 / inclusion_probability[selected_indices]
    selected_total = expression_total[selected_indices]
    true_total = float(np.sum(expression_total))
    true_mean = float(np.mean(expression_total))
    ht_total = float(np.sum(selected_total * weights))
    hajek_mean = float(np.average(selected_total, weights=weights))
    selected_labels = cell_groups[selected_indices].tolist()
    return {
        "probability_design_eligible": True,
        "ht_total_expression_estimate": ht_total,
        "ht_total_expression_relative_error": float(abs(ht_total - true_total) / max(abs(true_total), 1e-12)),
        "hajek_mean_expression_estimate": hajek_mean,
        "hajek_mean_expression_relative_error": float(abs(hajek_mean - true_mean) / max(abs(true_mean), 1e-12)),
        "weighted_cell_group_l1_error": float(
            composition_error(cell_groups.tolist(), selected_labels, weights.tolist())
        ),
        "probability_estimate_reason": "valid positive-support probability design",
    }


def _selection_frame_from_probability(result: Any) -> pd.DataFrame:
    selected = np.flatnonzero(result.selected_mask)
    return pd.DataFrame(
        {
            "cell_id": result.population_cell_ids[selected].astype(str),
            "selected": True,
            "spatial_stratum": result.stratum_id[selected].astype(str),
            "spatial_stratum_size": result.stratum_size[selected].astype(int),
            "spatial_quota": result.stratum_quota[selected].astype(int),
            "inclusion_probability": result.inclusion_probability[selected].astype(float),
            "sampling_weight": result.sampling_weight[selected].astype(float),
        }
    )


def _selection_frame_from_formal(
    *,
    cell_ids: np.ndarray,
    spatial_bins: np.ndarray,
    quota_audit: pd.DataFrame,
    selected_indices: np.ndarray,
) -> pd.DataFrame:
    lookup = quota_audit.set_index("spatial_stratum")
    rows = lookup.loc[spatial_bins[selected_indices]]
    # This field is deliberately descriptive. It is not a probability sampling weight.
    factor = rows["N_g"].to_numpy(dtype=float) / rows["q_g"].to_numpy(dtype=float)
    return pd.DataFrame(
        {
            "cell_id": cell_ids[selected_indices].astype(str),
            "selected": True,
            "spatial_stratum": spatial_bins[selected_indices].astype(str),
            "spatial_stratum_size": rows["N_g"].to_numpy(dtype=int),
            "spatial_quota": rows["q_g"].to_numpy(dtype=int),
            "composition_calibration_factor": factor,
        }
    )


def _formal_representation_draw(
    *,
    config: Mapping[str, Any],
    embedding: np.ndarray,
    expression_candidate_bins: np.ndarray,
    spatial_bins: np.ndarray,
    quotas: Mapping[str, int],
    benchmark_seed: int,
    interval_seconds: float,
) -> tuple[np.ndarray, dict[str, Any], Measurement, Measurement, list[dict[str, Any]]]:
    """Call the unchanged formal candidate-pool workflow with frozen R1 inputs."""
    candidate_config = config["formal_candidate_pool"]
    seeds = _candidate_seed_set(config, benchmark_seed)

    def build_candidates() -> Any:
        return build_candidates_until_quota_feasible(
            embedding=embedding,
            all_bin_ids=spatial_bins.tolist(),
            final_quotas=dict(quotas),
            n_select_per_seed=int(candidate_config["n_select_per_seed"]),
            seeds=seeds,
            method=str(candidate_config["candidate_method"]),
            candidate_strata=expression_candidate_bins.tolist(),
        )

    (candidates, selected_by_seed, history, _, feasibility), candidate_measurement = measure_call(
        build_candidates, interval_seconds
    )
    if int(feasibility["n_insufficient_bins"]) != 0:
        raise R1ValidationError(
            "Formal candidate pool did not satisfy the frozen positive spatial quota vector."
        )

    def final_draw() -> Any:
        candidate_bins = bin_ids_for_indices(candidates, spatial_bins.tolist())
        return sample_by_quota(candidates, candidate_bins, dict(quotas), seed=int(benchmark_seed))

    (selected, quota_report), final_measurement = measure_call(final_draw, interval_seconds)
    selected_indices = np.asarray(selected, dtype=int)
    metadata = get_method_metadata("formal_representation_mode")
    details = {
        **metadata.values,
        "method_id": "formal_representation_mode",
        "method_display_name": METHOD_DISPLAY_NAMES["formal_representation_mode"],
        "benchmark_repeat_seed": int(benchmark_seed),
        "candidate_pool_seed_set": seeds,
        "final_selection_seed": int(benchmark_seed),
        "actual_n": int(selected_indices.size),
        "candidate_pool_n": int(len(candidates)),
        "candidate_seeds_used": sorted(int(value) for value in selected_by_seed),
        "candidate_quota_feasibility": feasibility,
        "final_quota_report": quota_report,
        "sampling_weight_field_present": False,
        "composition_calibration_factor_field_present": True,
    }
    return selected_indices, details, candidate_measurement, final_measurement, history


def _method_metadata_for_probability(result: Any, benchmark_seed: int) -> dict[str, Any]:
    metadata = result.metadata_dict()
    metadata.update(
        {
            "method_display_name": METHOD_DISPLAY_NAMES[result.method_id],
            "benchmark_repeat_seed": int(benchmark_seed),
            "candidate_pool_seed_set": [],
            "final_selection_seed": int(benchmark_seed),
            "sampling_weight_field_present": True,
            "composition_calibration_factor_field_present": False,
        }
    )
    return metadata


def _evaluate_run(
    *,
    method_id: str,
    selected_indices: np.ndarray,
    cell_groups: np.ndarray,
    spatial_bins: np.ndarray,
    expression_bins: np.ndarray,
    coordinates: np.ndarray,
    full_gene_means: np.ndarray,
    matrix: Any,
    expression_total: np.ndarray,
    inclusion_probability: np.ndarray | None,
    sampling_weight: np.ndarray | None,
    rare_label_max_fraction: float,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Evaluate selections after sampling; labels never enter a sampler call."""
    selected_indices = np.asarray(selected_indices, dtype=int)
    selected_groups = cell_groups[selected_indices]
    selected_spatial_bins = spatial_bins[selected_indices]
    selected_expression_bins = expression_bins[selected_indices]
    unweighted_spatial, group_rows = spatial_group_fidelity(
        cell_groups.tolist(), spatial_bins.tolist(), selected_indices.tolist()
    )
    selected_matrix = matrix[selected_indices]
    unweighted_gene_means = matrix_column_mean(selected_matrix)
    metrics: dict[str, Any] = {
        "n_selected": int(selected_indices.size),
        "selected_spatial_coverage": float(
            spatial_coverage(spatial_bins.tolist(), selected_spatial_bins.tolist())
        ),
        "expression_state_coverage": float(
            spatial_coverage(expression_bins.tolist(), selected_expression_bins.tolist())
        ),
        "cell_group_l1_error": float(
            composition_error(cell_groups.tolist(), selected_groups.tolist())
        ),
        "rare_cell_recall": float(
            rare_cell_recall(
                cell_groups.tolist(), selected_groups.tolist(), max_fraction=rare_label_max_fraction
            )
        ),
        "joint_spatial_group_l1_error": float(unweighted_spatial["joint_spatial_group_l1_error"]),
        "mean_within_group_spatial_l1_error": float(
            unweighted_spatial["mean_within_group_spatial_l1_error"]
        ),
        "mean_within_group_spatial_coverage": float(
            unweighted_spatial["mean_within_group_spatial_coverage"]
        ),
        "gene_mean_relative_mae_unweighted": float(
            relative_mean_absolute_error(full_gene_means, unweighted_gene_means)
        ),
        "spatial_domain_metrics_status": "not_available_for_this_input",
        **_nearest_neighbor_metrics(coordinates, selected_indices),
    }
    if inclusion_probability is None or sampling_weight is None:
        metrics.update(
            {
                "probability_design_eligible": False,
                "weighted_cell_group_l1_error": float("nan"),
                "gene_mean_relative_mae_probability_weighted": float("nan"),
                "ht_total_expression_estimate": float("nan"),
                "ht_total_expression_relative_error": float("nan"),
                "hajek_mean_expression_estimate": float("nan"),
                "hajek_mean_expression_relative_error": float("nan"),
                "probability_estimate_reason": "formal representation mode is not a probability design",
                **_weight_diagnostics(np.asarray([], dtype=float), np.asarray([], dtype=int)),
            }
        )
        return metrics, group_rows

    probability_metrics = _probability_estimates(
        cell_groups=cell_groups,
        expression_total=expression_total,
        selected_indices=selected_indices,
        inclusion_probability=inclusion_probability,
    )
    metrics.update(probability_metrics)
    if probability_metrics["probability_design_eligible"]:
        weights = sampling_weight[selected_indices]
        metrics["gene_mean_relative_mae_probability_weighted"] = float(
            relative_mean_absolute_error(
                full_gene_means, weighted_column_mean(selected_matrix, weights)
            )
        )
    else:
        metrics["gene_mean_relative_mae_probability_weighted"] = float("nan")
    metrics.update(_weight_diagnostics(sampling_weight, selected_indices))
    return metrics, group_rows


def _run_one(
    *,
    config: Mapping[str, Any],
    run_id: str,
    method_id: str,
    fraction: float,
    benchmark_seed: int,
    cell_ids: np.ndarray,
    coordinates: np.ndarray,
    spatial_bins: np.ndarray,
    expression_candidate_bins: np.ndarray,
    expression_evaluation_bins: np.ndarray,
    quotas: Mapping[str, int],
    quota_audit: pd.DataFrame,
    cell_groups: np.ndarray,
    full_gene_means: np.ndarray,
    matrix: Any,
    expression_total: np.ndarray,
    shared_measurements: Mapping[str, Measurement],
    run_directory: Path,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Run, validate, evaluate, and serialize one immutable R1 unit."""
    if run_directory.exists():
        raise FileExistsError(f"Refusing to overwrite an existing R1 run directory: {run_directory}")
    interval = float(config["resource_measurement"]["memory_poll_interval_seconds"])
    target_n = int(config["target_n"][f"{float(fraction):.3f}"])
    candidate_measurement = Measurement(0.0, 0.0, 0.0)
    history: list[dict[str, Any]] = []
    inclusion_probability: np.ndarray | None = None
    sampling_weight: np.ndarray | None = None
    probability_diagnostics: pd.DataFrame | None = None

    if method_id == "uniform_srs":
        result, final_measurement = measure_call(
            lambda: sample_uniform_srs(cell_ids, target_n, random_seed=benchmark_seed), interval
        )
        selected_indices = np.flatnonzero(result.selected_mask)
        inclusion_probability = result.inclusion_probability
        sampling_weight = result.sampling_weight
        selection_frame = _selection_frame_from_probability(result)
        metadata = _method_metadata_for_probability(result, benchmark_seed)
        probability_diagnostics = pd.DataFrame(
            {
                "spatial_stratum": ["global"],
                "N_g": [int(cell_ids.size)],
                "q_g": [target_n],
                "pi_expected": [float(target_n / cell_ids.size)],
                "pi_observed_min": [float(np.min(inclusion_probability))],
                "pi_observed_max": [float(np.max(inclusion_probability))],
                "pi_sum": [float(np.sum(inclusion_probability))],
                "pi_sum_minus_q_g": [float(np.sum(inclusion_probability) - target_n)],
                "positive_support": [bool(np.all(inclusion_probability > 0))],
            }
        )
    elif method_id == "spatial_stratified_srs":
        result, final_measurement = measure_call(
            lambda: sample_spatial_stratified_srs(
                cell_ids, spatial_bins, quotas, random_seed=benchmark_seed
            ),
            interval,
        )
        selected_indices = np.flatnonzero(result.selected_mask)
        inclusion_probability = result.inclusion_probability
        sampling_weight = result.sampling_weight
        selection_frame = _selection_frame_from_probability(result)
        metadata = _method_metadata_for_probability(result, benchmark_seed)
        probability_diagnostics = _probability_diagnostics(
            spatial_bins=spatial_bins,
            quota_audit=quota_audit,
            inclusion_probability=inclusion_probability,
        )
    elif method_id == "spatial_pivotal":
        result, final_measurement = measure_call(
            lambda: sample_spatial_pivotal(
                cell_ids, coordinates, spatial_bins, quotas, random_seed=benchmark_seed
            ),
            interval,
        )
        selected_indices = np.flatnonzero(result.selected_mask)
        inclusion_probability = result.inclusion_probability
        sampling_weight = result.sampling_weight
        selection_frame = _selection_frame_from_probability(result)
        metadata = _method_metadata_for_probability(result, benchmark_seed)
        probability_diagnostics = _probability_diagnostics(
            spatial_bins=spatial_bins,
            quota_audit=quota_audit,
            inclusion_probability=inclusion_probability,
        )
    elif method_id == "formal_representation_mode":
        selected_indices, metadata, candidate_measurement, final_measurement, history = _formal_representation_draw(
            config=config,
            embedding=_require_embedding(config),
            expression_candidate_bins=expression_candidate_bins,
            spatial_bins=spatial_bins,
            quotas=quotas,
            benchmark_seed=benchmark_seed,
            interval_seconds=interval,
        )
        selection_frame = _selection_frame_from_formal(
            cell_ids=cell_ids,
            spatial_bins=spatial_bins,
            quota_audit=quota_audit,
            selected_indices=selected_indices,
        )
    else:
        raise R1ValidationError(f"Unsupported R1 method: {method_id}")

    # The embedding is carried only by the formal branch; pure methods never receive it.
    if selected_indices.size != target_n:
        raise R1ValidationError(f"{run_id} selected {selected_indices.size}, expected {target_n}.")
    if np.unique(selected_indices).size != selected_indices.size:
        raise R1ValidationError(f"{run_id} selected duplicate cells.")
    if method_id != "uniform_srs":
        observed = Counter(spatial_bins[selected_indices].tolist())
        expected = {stratum: int(quota) for stratum, quota in quotas.items() if int(quota) > 0}
        if observed != expected:
            raise R1ValidationError(f"{run_id} violates its frozen spatial quota vector.")
    if bool(metadata["uses_expression"]) != (method_id == "formal_representation_mode"):
        raise R1ValidationError(f"{run_id} has a method identity conflict for expression use.")
    if bool(metadata["uses_spatial_coordinates"]) != (method_id != "uniform_srs"):
        raise R1ValidationError(f"{run_id} has a method identity conflict for spatial use.")

    # Evaluation happens after selection and is never passed into a sampler.
    (metrics, group_rows), metric_measurement = measure_call(
        lambda: _evaluate_run(
            method_id=method_id,
            selected_indices=selected_indices,
            cell_groups=cell_groups,
            spatial_bins=spatial_bins,
            expression_bins=expression_evaluation_bins,
            coordinates=coordinates,
            full_gene_means=full_gene_means,
            matrix=matrix,
            expression_total=expression_total,
            inclusion_probability=inclusion_probability,
            sampling_weight=sampling_weight,
            rare_label_max_fraction=float(config["evaluation"]["rare_label_max_fraction"]),
        ),
        interval,
    )

    run_directory.mkdir(parents=True, exist_ok=False)
    _, output_measurement = measure_call(
        lambda: _write_run_artifacts(
            run_directory=run_directory,
            selection_frame=selection_frame,
            method_metadata=metadata,
            probability_diagnostics=probability_diagnostics,
            candidate_history=history,
            group_rows=group_rows,
        ),
        interval,
    )
    core_seconds = float(candidate_measurement.seconds + final_measurement.seconds)
    shared_total = float(
        shared_measurements["data_read"].seconds
        + shared_measurements["spatial_setup"].seconds
        + shared_measurements["expression_setup"].seconds
    )
    run_count = int(config["output"]["expected_official_run_units"])
    local_seconds = float(core_seconds + metric_measurement.seconds + output_measurement.seconds)
    resource = {
        "data_read_seconds_shared": shared_measurements["data_read"].seconds,
        "spatial_quota_setup_seconds_shared": shared_measurements["spatial_setup"].seconds,
        "expression_preprocessing_seconds_shared": shared_measurements["expression_setup"].seconds,
        "candidate_pool_seconds": candidate_measurement.seconds,
        "final_selection_seconds": final_measurement.seconds,
        "core_sampling_seconds": core_seconds,
        "metric_calculation_seconds": metric_measurement.seconds,
        "output_seconds": output_measurement.seconds,
        "end_to_end_seconds_local": local_seconds,
        "end_to_end_seconds_with_shared_cost": float(local_seconds + shared_total),
        "end_to_end_seconds_amortized_shared_cost": float(local_seconds + shared_total / run_count),
        "peak_rss_mb": float(
            max(
                shared_measurements["data_read"].peak_rss_mb,
                shared_measurements["spatial_setup"].peak_rss_mb,
                shared_measurements["expression_setup"].peak_rss_mb,
                candidate_measurement.peak_rss_mb,
                final_measurement.peak_rss_mb,
                metric_measurement.peak_rss_mb,
                output_measurement.peak_rss_mb,
            )
        ),
    }
    _write_new_json(resource, run_directory / "resource.json")
    _write_new_json(
        {
            "run_id": run_id,
            "status": "success",
            "method_id": method_id,
            "target_fraction": float(fraction),
            "target_n": target_n,
            "actual_n": int(selected_indices.size),
        },
        run_directory / "status.json",
    )
    record = {
        "run_id": run_id,
        "status": "success",
        "method": method_id,
        "method_display_name": METHOD_DISPLAY_NAMES[method_id],
        "target_fraction": float(fraction),
        "benchmark_repeat_seed": int(benchmark_seed),
        "candidate_pool_seed_set": json.dumps(metadata.get("candidate_pool_seed_set", [])),
        "final_selection_seed": int(metadata.get("final_selection_seed", benchmark_seed)),
        "target_n": target_n,
        "actual_n": int(selected_indices.size),
        "uses_expression": bool(metadata["uses_expression"]),
        "uses_spatial_coordinates": bool(metadata["uses_spatial_coordinates"]),
        "uses_cell_labels": bool(metadata["uses_cell_labels"]),
        "uses_domain_labels": bool(metadata["uses_domain_labels"]),
        "selection_directory": str(run_directory),
        **metrics,
        **resource,
    }
    return record, group_rows


def _require_embedding(config: Mapping[str, Any]) -> np.ndarray:
    """Read the process-local embedding installed only during formal execution."""
    embedding = config.get("_runtime_expression_embedding")
    if not isinstance(embedding, np.ndarray):
        raise R1ValidationError("Formal execution is missing its process-local expression embedding.")
    return embedding


def _write_run_artifacts(
    *,
    run_directory: Path,
    selection_frame: pd.DataFrame,
    method_metadata: Mapping[str, Any],
    probability_diagnostics: pd.DataFrame | None,
    candidate_history: Sequence[Mapping[str, Any]],
    group_rows: Sequence[Mapping[str, Any]],
) -> None:
    """Serialize one run without changing any historical result directory."""
    _write_new_csv(selection_frame, run_directory / "selected_cells.csv")
    _write_new_json(dict(method_metadata), run_directory / "method_metadata.json")
    _write_new_csv(pd.DataFrame(group_rows), run_directory / "cell_group_spatial_metrics.csv")
    if probability_diagnostics is not None:
        _write_new_csv(probability_diagnostics, run_directory / "probability_diagnostics.csv")
    if candidate_history:
        _write_new_csv(pd.DataFrame(candidate_history), run_directory / "formal_candidate_saturation.csv")


def _verify_execution_sources(config: Mapping[str, Any]) -> None:
    """Ensure the three frozen source files did not change after config creation."""
    provenance = config["source_provenance"]
    checks = (
        ("rerun_plan", provenance["rerun_plan_path"], provenance["rerun_plan_sha256"]),
        ("method_registry", provenance["method_registry_path"], provenance["method_registry_sha256"]),
        (
            "historical_audit_report",
            provenance["historical_audit_report_path"],
            provenance["historical_audit_report_sha256"],
        ),
    )
    for name, path, expected in checks:
        if sha256_file(path) != expected:
            raise R1ValidationError(f"Frozen {name} changed after R1 config creation.")


def _failure_record(
    *,
    run_id: str,
    method_id: str,
    fraction: float,
    seed: int,
    target_n: int,
    error: BaseException,
) -> dict[str, Any]:
    return {
        "run_id": run_id,
        "status": "failure",
        "method": method_id,
        "method_display_name": METHOD_DISPLAY_NAMES[method_id],
        "target_fraction": float(fraction),
        "benchmark_repeat_seed": int(seed),
        "target_n": int(target_n),
        "actual_n": np.nan,
        "error_type": type(error).__name__,
        "error_message": str(error),
    }


def _write_failure_status(run_directory: Path, record: Mapping[str, Any]) -> None:
    """Persist failure information without deleting or replacing partial artifacts."""
    run_directory.mkdir(parents=True, exist_ok=True)
    destination = run_directory / "failure.json"
    if not destination.exists():
        _write_new_json(dict(record), destination)


def execute_r1(config_path: str | Path, *, preflight_only: bool = False) -> dict[str, Any]:
    """Execute the frozen R1 matrix, or its one non-reporting resource preflight."""
    config = verify_immutable_r1_config(config_path)
    _verify_execution_sources(config)
    output_directory = Path(config["output"]["directory"])
    input_path = Path(config["input"]["h5ad_path"])
    if sha256_file(input_path) != config["input"]["sha256"]:
        raise R1ValidationError("Input h5ad SHA256 differs from the immutable R1 config.")
    marker = output_directory / ("preflight_manifest.json" if preflight_only else "execution_manifest.csv")
    if marker.exists():
        raise FileExistsError(f"R1 execution marker already exists: {marker}")

    interval = float(config["resource_measurement"]["memory_poll_interval_seconds"])

    def load_input() -> Any:
        import anndata as ad

        adata = ad.read_h5ad(input_path)
        validate_spatial_anndata(adata)
        return adata

    adata, data_read_measurement = measure_call(load_input, interval)
    n_cells = int(adata.n_obs)
    if n_cells != int(config["input"]["n_cells"]) or int(adata.n_vars) != int(config["input"]["n_genes"]):
        raise R1ValidationError("Input dimensions differ from the immutable R1 config.")
    cell_ids = np.asarray(adata.obs_names.astype(str), dtype=object)
    if np.unique(cell_ids).size != cell_ids.size:
        raise R1ValidationError("Input cell identifiers are not unique.")
    cell_groups = adata.obs[str(config["input"]["evaluation_cell_group_column"])].astype(str).to_numpy()
    expression_total = _as_observation_total(adata)
    full_gene_means = matrix_column_mean(adata.X)

    def setup_spatial() -> tuple[np.ndarray, np.ndarray, dict[float, dict[str, int]], dict[float, pd.DataFrame]]:
        coordinates = np.asarray(get_spatial_coordinates(adata), dtype=float)
        grid = config["selection_grid"]
        spatial_bins = np.asarray(
            rectangular_grid_bins(coordinates, n_x=int(grid["n_x"]), n_y=int(grid["n_y"])),
            dtype=object,
        )
        quotas_by_fraction: dict[float, dict[str, int]] = {}
        audits_by_fraction: dict[float, pd.DataFrame] = {}
        for fraction in R1_FRACTIONS:
            target_n = int(config["target_n"][f"{fraction:.3f}"])
            quotas, audit = _stratum_table(spatial_bins.tolist(), target_n)
            quotas_by_fraction[fraction] = quotas
            audits_by_fraction[fraction] = audit
        return coordinates, spatial_bins, quotas_by_fraction, audits_by_fraction

    (coordinates, spatial_bins, quotas_by_fraction, audits_by_fraction), spatial_measurement = measure_call(
        setup_spatial, interval
    )

    def setup_expression() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        settings = config["expression_preprocessing"]
        embedding = compute_pca_embedding(
            adata,
            n_components=int(settings["n_components"]),
            random_state=int(settings["random_state"]),
        )
        candidate_grid = config["formal_candidate_pool"]["candidate_expression_grid"]
        evaluation_grid = config["evaluation"]["expression_state_grid"]
        return (
            embedding,
            np.asarray(
                rectangular_grid_bins(
                    embedding[:, :2], n_x=int(candidate_grid["n_x"]), n_y=int(candidate_grid["n_y"])
                ),
                dtype=object,
            ),
            np.asarray(
                rectangular_grid_bins(
                    embedding[:, :2], n_x=int(evaluation_grid["n_x"]), n_y=int(evaluation_grid["n_y"])
                ),
                dtype=object,
            ),
        )

    (embedding, expression_candidate_bins, expression_evaluation_bins), expression_measurement = measure_call(
        setup_expression, interval
    )
    # Kept only in memory; it is never serialized into the immutable config.
    config["_runtime_expression_embedding"] = embedding
    shared_measurements = {
        "data_read": data_read_measurement,
        "spatial_setup": spatial_measurement,
        "expression_setup": expression_measurement,
    }
    shared_output_directory = output_directory / "preflight_nonreporting" if preflight_only else output_directory
    _write_new_json(
        {
            "data_read": data_read_measurement.__dict__,
            "spatial_setup": spatial_measurement.__dict__,
            "expression_setup": expression_measurement.__dict__,
            "n_nonempty_selection_grid_strata": int(len(set(spatial_bins.tolist()))),
            "preflight_only": bool(preflight_only),
        },
        shared_output_directory / "shared_preprocessing_resource.json",
    )
    for fraction, audit in audits_by_fraction.items():
        audit = audit.copy()
        audit["target_fraction"] = fraction
        _write_new_csv(
            audit,
            shared_output_directory / "shared_design" / f"fraction_{fraction:.3f}_quota_audit.csv",
        )

    if preflight_only:
        fraction = 0.10
        method_id = "formal_representation_mode"
        run_id = "preflight_nonreporting_formal_representation_mode_0.100_seed_00"
        record, _ = _run_one(
            config=config,
            run_id=run_id,
            method_id=method_id,
            fraction=fraction,
            benchmark_seed=0,
            cell_ids=cell_ids,
            coordinates=coordinates,
            spatial_bins=spatial_bins,
            expression_candidate_bins=expression_candidate_bins,
            expression_evaluation_bins=expression_evaluation_bins,
            quotas=quotas_by_fraction[fraction],
            quota_audit=audits_by_fraction[fraction],
            cell_groups=cell_groups,
            full_gene_means=full_gene_means,
            matrix=adata.X,
            expression_total=expression_total,
            shared_measurements=shared_measurements,
            run_directory=output_directory / "preflight_nonreporting" / run_id,
        )
        _write_new_json(
            {"status": "success", "preflight_record": _json_ready(record)},
            output_directory / "preflight_manifest.json",
        )
        return {"status": "preflight_success", "output_directory": str(output_directory), "record": record}

    plan = load_r1_plan(config["source_provenance"]["rerun_plan_path"])
    records: list[dict[str, Any]] = []
    group_records: list[dict[str, Any]] = []
    expected_run_ids: list[str] = []
    for plan_row in plan.itertuples(index=False):
        fraction = float(plan_row.fraction)
        method_id = str(plan_row.method)
        target_n = int(config["target_n"][f"{fraction:.3f}"])
        for seed in R1_SEEDS:
            run_id = f"{plan_row.plan_id}_seed_{seed:02d}"
            expected_run_ids.append(run_id)
            run_directory = output_directory / "runs" / run_id
            try:
                record, per_group = _run_one(
                    config=config,
                    run_id=run_id,
                    method_id=method_id,
                    fraction=fraction,
                    benchmark_seed=seed,
                    cell_ids=cell_ids,
                    coordinates=coordinates,
                    spatial_bins=spatial_bins,
                    expression_candidate_bins=expression_candidate_bins,
                    expression_evaluation_bins=expression_evaluation_bins,
                    quotas=quotas_by_fraction[fraction],
                    quota_audit=audits_by_fraction[fraction],
                    cell_groups=cell_groups,
                    full_gene_means=full_gene_means,
                    matrix=adata.X,
                    expression_total=expression_total,
                    shared_measurements=shared_measurements,
                    run_directory=run_directory,
                )
                records.append(record)
                group_records.extend(
                    {
                        "run_id": run_id,
                        "method": method_id,
                        "target_fraction": fraction,
                        **dict(item),
                    }
                    for item in per_group
                )
            except Exception as error:  # Preserve every failure rather than silently skipping it.
                failure = _failure_record(
                    run_id=run_id,
                    method_id=method_id,
                    fraction=fraction,
                    seed=seed,
                    target_n=target_n,
                    error=error,
                )
                records.append(failure)
                _write_failure_status(run_directory, failure)

    manifest = pd.DataFrame(records).sort_values(["target_fraction", "method", "benchmark_repeat_seed"])
    _write_new_csv(manifest, output_directory / "execution_manifest.csv")
    if group_records:
        _write_new_csv(
            pd.DataFrame(group_records).sort_values(["target_fraction", "method", "run_id", "cell_group"]),
            output_directory / "raw_cell_group_spatial_metrics.csv",
        )
    success = int(manifest["status"].eq("success").sum())
    failure = int(manifest["status"].eq("failure").sum())
    _write_new_json(
        {
            "expected_run_units": int(config["output"]["expected_official_run_units"]),
            "manifest_run_units": int(len(manifest)),
            "successful_run_units": success,
            "failed_or_infeasible_run_units": failure,
            "all_expected_run_ids_present": bool(set(expected_run_ids) == set(manifest["run_id"])),
            "all_runs_successful": bool(success == len(expected_run_ids) and failure == 0),
        },
        output_directory / "execution_validation.json",
    )
    if success != len(expected_run_ids) or failure:
        raise R1ValidationError("R1 execution completed with failed or missing run units; do not summarize conclusions.")
    return {
        "status": "success",
        "output_directory": str(output_directory),
        "successful_run_units": success,
        "failed_or_infeasible_run_units": failure,
    }


SUMMARY_METRICS = (
    "actual_n",
    "selected_spatial_coverage",
    "expression_state_coverage",
    "cell_group_l1_error",
    "weighted_cell_group_l1_error",
    "rare_cell_recall",
    "mean_within_group_spatial_l1_error",
    "mean_within_group_spatial_coverage",
    "joint_spatial_group_l1_error",
    "gene_mean_relative_mae_unweighted",
    "gene_mean_relative_mae_probability_weighted",
    "nearest_selected_distance_median",
    "ht_total_expression_relative_error",
    "hajek_mean_expression_relative_error",
    "weight_coefficient_of_variation",
    "maximum_weight",
    "maximum_to_median_weight",
    "kish_effective_sample_size",
    "kish_effective_sample_size_over_n",
    "core_sampling_seconds",
    "end_to_end_seconds_local",
    "end_to_end_seconds_with_shared_cost",
    "end_to_end_seconds_amortized_shared_cost",
    "peak_rss_mb",
)
HIGHER_IS_BETTER = {
    "selected_spatial_coverage",
    "expression_state_coverage",
    "rare_cell_recall",
    "mean_within_group_spatial_coverage",
    "kish_effective_sample_size",
    "kish_effective_sample_size_over_n",
}


def summarize_metric_table(raw: pd.DataFrame) -> pd.DataFrame:
    """Return the required five-number and standard-deviation summaries in long form."""
    rows: list[dict[str, Any]] = []
    for (fraction, method), frame in raw.groupby(["target_fraction", "method"], sort=True):
        for metric in SUMMARY_METRICS:
            if metric not in frame.columns:
                continue
            values = pd.to_numeric(frame[metric], errors="coerce").dropna()
            rows.append(
                {
                    "target_fraction": float(fraction),
                    "method": str(method),
                    "method_display_name": METHOD_DISPLAY_NAMES[str(method)],
                    "metric": metric,
                    "n_repeats": int(values.size),
                    "mean": float(values.mean()) if not values.empty else float("nan"),
                    "standard_deviation": float(values.std(ddof=1)) if values.size > 1 else (0.0 if values.size == 1 else float("nan")),
                    "median": float(values.median()) if not values.empty else float("nan"),
                    "minimum": float(values.min()) if not values.empty else float("nan"),
                    "maximum": float(values.max()) if not values.empty else float("nan"),
                    "quantile_25": float(values.quantile(0.25)) if not values.empty else float("nan"),
                    "quantile_75": float(values.quantile(0.75)) if not values.empty else float("nan"),
                }
            )
    return pd.DataFrame(rows).sort_values(["metric", "target_fraction", "method"], kind="stable")


def paired_difference_tables(raw: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Pair all methods against spatial-stratified SRS by fraction and outer seed."""
    base = raw.loc[raw["method"].eq("spatial_stratified_srs")].copy()
    detail_rows: list[dict[str, Any]] = []
    for method_id in R1_METHODS:
        if method_id == "spatial_stratified_srs":
            continue
        method = raw.loc[raw["method"].eq(method_id)].copy()
        for metric in SUMMARY_METRICS:
            if metric not in raw.columns:
                continue
            merged = method.loc[:, ["target_fraction", "benchmark_repeat_seed", metric]].merge(
                base.loc[:, ["target_fraction", "benchmark_repeat_seed", metric]],
                on=["target_fraction", "benchmark_repeat_seed"],
                suffixes=("_method", "_baseline"),
                how="inner",
            )
            for row in merged.itertuples(index=False):
                method_value = getattr(row, f"{metric}_method")
                baseline_value = getattr(row, f"{metric}_baseline")
                if not np.isfinite(method_value) or not np.isfinite(baseline_value):
                    continue
                difference = float(method_value - baseline_value)
                direction = "higher" if metric in HIGHER_IS_BETTER else "lower"
                if abs(difference) <= 1e-12:
                    outcome = "tie"
                elif (difference > 0 and direction == "higher") or (difference < 0 and direction == "lower"):
                    outcome = "win"
                else:
                    outcome = "loss"
                detail_rows.append(
                    {
                        "target_fraction": float(row.target_fraction),
                        "method": method_id,
                        "baseline_method": "spatial_stratified_srs",
                        "benchmark_repeat_seed": int(row.benchmark_repeat_seed),
                        "metric": metric,
                        "method_value": float(method_value),
                        "baseline_value": float(baseline_value),
                        "paired_difference_method_minus_baseline": difference,
                        "preferred_direction": direction,
                        "outcome": outcome,
                    }
                )
    detail = pd.DataFrame(detail_rows)
    summary_rows: list[dict[str, Any]] = []
    if not detail.empty:
        for keys, frame in detail.groupby(["target_fraction", "method", "metric", "preferred_direction"], sort=True):
            values = frame["paired_difference_method_minus_baseline"]
            summary_rows.append(
                {
                    "target_fraction": float(keys[0]),
                    "method": str(keys[1]),
                    "baseline_method": "spatial_stratified_srs",
                    "metric": str(keys[2]),
                    "preferred_direction": str(keys[3]),
                    "n_pairs": int(values.size),
                    "mean_paired_difference": float(values.mean()),
                    "median_paired_difference": float(values.median()),
                    "minimum_paired_difference": float(values.min()),
                    "maximum_paired_difference": float(values.max()),
                    "quantile_25_paired_difference": float(values.quantile(0.25)),
                    "quantile_75_paired_difference": float(values.quantile(0.75)),
                    "winning_seed_count": int(frame["outcome"].eq("win").sum()),
                    "tie_seed_count": int(frame["outcome"].eq("tie").sum()),
                    "losing_seed_count": int(frame["outcome"].eq("loss").sum()),
                }
            )
    return detail, pd.DataFrame(summary_rows)


def _direction_status(
    paired: pd.DataFrame,
    *,
    method: str,
    metric: str,
    fractions: Iterable[float],
    expected_sign: str,
) -> tuple[str, str]:
    subset = paired.loc[
        paired["method"].eq(method)
        & paired["metric"].eq(metric)
        & paired["target_fraction"].isin(list(fractions))
    ]
    if subset.empty:
        return "STILL_UNCERTAIN", "R1 did not yield a finite paired comparison for this endpoint."
    differences = subset["paired_difference_method_minus_baseline"].to_numpy(dtype=float)
    if expected_sign == "positive":
        favorable = differences > 1e-12
        opposing = differences < -1e-12
    elif expected_sign == "negative":
        favorable = differences < -1e-12
        opposing = differences > 1e-12
    elif expected_sign == "nonpositive":
        favorable = differences <= 1e-12
        opposing = differences > 1e-12
    else:
        raise R1ValidationError(f"Unknown expected paired-difference sign: {expected_sign}")
    wins = int(np.sum(favorable))
    total = int(len(subset))
    if wins >= math.ceil(0.7 * total):
        return "DIRECTION_CONFIRMED_NUMBERS_UPDATED", f"{wins}/{total} paired seeds support the predeclared expected difference sign ({expected_sign})."
    losses = int(np.sum(opposing))
    if losses >= math.ceil(0.7 * total):
        return "REVERSED", f"{losses}/{total} paired seeds oppose the historical direction."
    return "STILL_UNCERTAIN", f"Paired seed results are mixed ({wins} favorable of {total})."


def _direct_pair_status(
    raw: pd.DataFrame,
    *,
    method: str,
    baseline: str,
    metric: str,
    fractions: Iterable[float],
    expected_sign: str,
) -> tuple[str, str]:
    method_frame = raw.loc[
        raw["method"].eq(method) & raw["target_fraction"].isin(list(fractions)),
        ["target_fraction", "benchmark_repeat_seed", metric],
    ]
    baseline_frame = raw.loc[
        raw["method"].eq(baseline) & raw["target_fraction"].isin(list(fractions)),
        ["target_fraction", "benchmark_repeat_seed", metric],
    ]
    merged = method_frame.merge(
        baseline_frame,
        on=["target_fraction", "benchmark_repeat_seed"],
        suffixes=("_method", "_baseline"),
        how="inner",
    ).dropna()
    if merged.empty:
        return "STILL_UNCERTAIN", "R1 did not yield a finite paired comparison for this endpoint."
    difference = merged[f"{metric}_method"] - merged[f"{metric}_baseline"]
    if expected_sign == "positive":
        favorable, opposing = difference > 1e-12, difference < -1e-12
    elif expected_sign == "negative":
        favorable, opposing = difference < -1e-12, difference > 1e-12
    else:
        raise R1ValidationError(f"Unknown expected direct-pair sign: {expected_sign}")
    n = int(len(difference))
    wins, losses = int(favorable.sum()), int(opposing.sum())
    if wins >= math.ceil(0.7 * n):
        return "DIRECTION_CONFIRMED_NUMBERS_UPDATED", f"{wins}/{n} formal-versus-uniform pairs support the expected {expected_sign} difference."
    if losses >= math.ceil(0.7 * n):
        return "REVERSED", f"{losses}/{n} formal-versus-uniform pairs oppose the historical direction."
    return "STILL_UNCERTAIN", f"Formal-versus-uniform pairs are mixed ({wins} favorable of {n})."


def historical_conclusion_status(raw: pd.DataFrame, paired: pd.DataFrame) -> pd.DataFrame:
    """Classify all 13 audited historical conclusions without silently extending R1 scope."""
    conclusions: list[dict[str, Any]] = []
    checks = [
        ("C01", "formal representation has spatial coverage close to historical coordinate-only", "formal_representation_mode", "selected_spatial_coverage", R1_FRACTIONS, "similar"),
        ("C02", "formal representation has higher expression-state coverage than spatial SRS", "formal_representation_mode", "expression_state_coverage", R1_FRACTIONS, "positive"),
        ("C05", "at low fractions formal has lower cell-group proportion error than spatial SRS", "formal_representation_mode", "cell_group_l1_error", (0.005, 0.01), "negative"),
        ("C06", "at medium and high fractions spatial SRS has lower cell-group proportion error than formal", "formal_representation_mode", "cell_group_l1_error", (0.02, 0.05, 0.10), "positive"),
        ("C07", "formal and spatial SRS have close within-group spatial error", "formal_representation_mode", "mean_within_group_spatial_l1_error", R1_FRACTIONS, "similar"),
        ("C10", "formal rare-label recall does not exceed the spatial control", "formal_representation_mode", "rare_cell_recall", R1_FRACTIONS, "nonpositive"),
    ]
    for conclusion_id, historical, method, metric, fractions, direction in checks:
        if direction == "similar":
            subset = paired.loc[
                paired["method"].eq(method)
                & paired["metric"].eq(metric)
                & paired["target_fraction"].isin(list(fractions))
            ]
            if subset.empty:
                status, result = "STILL_UNCERTAIN", "No finite paired comparison was available."
            else:
                maximum_absolute_difference = float(
                    subset["paired_difference_method_minus_baseline"].abs().max()
                )
                status = "DIRECTION_CONFIRMED_NUMBERS_UPDATED" if maximum_absolute_difference <= 0.02 else "REVERSED"
                result = f"Maximum absolute paired difference was {maximum_absolute_difference:.6g}; predeclared closeness boundary is 0.02."
        else:
            status, result = _direction_status(
                paired, method=method, metric=metric, fractions=fractions, expected_sign=direction
            )
        conclusions.append(
            {
                "conclusion_id": conclusion_id,
                "historical_conclusion": historical,
                "historical_comparator": "historical coordinate-only or uniform comparator as documented in the audit",
                "r1_comparator": "spatial_stratified_srs" if conclusion_id != "C03" else "uniform_srs is separately assessed in the R1 report",
                "r1_result": result,
                "status": status,
                "allowed_in_future_manuscript": status in {"CONFIRMED", "DIRECTION_CONFIRMED_NUMBERS_UPDATED"},
                "recommended_wording": "Use only the registered R1 method names and report the paired effect direction.",
            }
        )
    c03_status, c03_result = _direct_pair_status(
        raw,
        method="formal_representation_mode",
        baseline="uniform_srs",
        metric="expression_state_coverage",
        fractions=R1_FRACTIONS,
        expected_sign="positive",
    )
    conclusions.append(
        {
            "conclusion_id": "C03",
            "historical_conclusion": "formal representation retains an advantage over uniform SRS",
            "historical_comparator": "historical uniform random sampling",
            "r1_comparator": "uniform_srs",
            "r1_result": c03_result,
            "status": c03_status,
            "allowed_in_future_manuscript": c03_status in {"CONFIRMED", "DIRECTION_CONFIRMED_NUMBERS_UPDATED"},
            "recommended_wording": "Describe the paired formal-versus-uniform expression-state result without a universal superiority claim.",
        }
    )
    assessed = {row["conclusion_id"] for row in conclusions}
    for conclusion_id in [f"C{index:02d}" for index in range(1, 14) if f"C{index:02d}" not in assessed]:
        conclusions.append(
            {
                "conclusion_id": conclusion_id,
                "historical_conclusion": "See historical_benchmark_impact_audit.csv for the original wording.",
                "historical_comparator": "outside the R1 representation matrix",
                "r1_comparator": "not assessed",
                "r1_result": "R1 does not test this inference, feasibility, or frozen discovery-route statement.",
                "status": "STILL_UNCERTAIN",
                "allowed_in_future_manuscript": False,
                "recommended_wording": "Do not promote this conclusion from R1 alone.",
            }
        )
    return pd.DataFrame(conclusions).sort_values("conclusion_id", kind="stable")


def _save_figure(figure: Any, output_directory: Path, stem: str) -> None:
    """Save every R1 figure as both a bitmap and a vector PDF."""
    output_directory.mkdir(parents=True, exist_ok=True)
    for suffix in ("png", "pdf"):
        destination = output_directory / f"{stem}.{suffix}"
        if destination.exists():
            raise FileExistsError(f"Refusing to overwrite R1 figure: {destination}")
        figure.savefig(destination, dpi=220 if suffix == "png" else None, bbox_inches="tight")


def _plot_metric_trend(raw: pd.DataFrame, metric: str, ylabel: str, figures: Path, stem: str) -> None:
    import matplotlib.pyplot as plt

    figure, axis = plt.subplots(figsize=(7.4, 4.5))
    for method_id in R1_METHODS:
        frame = raw.loc[raw["method"].eq(method_id)]
        grouped = frame.groupby("target_fraction", sort=True)[metric]
        x = np.asarray(sorted(grouped.groups), dtype=float)
        mean = np.asarray([grouped.get_group(value).mean() for value in x], dtype=float)
        std = np.asarray([grouped.get_group(value).std(ddof=1) for value in x], dtype=float)
        axis.plot(x * 100, mean, marker="o", linewidth=1.8, label=METHOD_DISPLAY_NAMES[method_id])
        axis.fill_between(x * 100, mean - std, mean + std, alpha=0.16)
    axis.set_xlabel("Sampling fraction (%)")
    axis.set_ylabel(ylabel)
    axis.set_xticks(np.asarray(R1_FRACTIONS) * 100)
    axis.grid(axis="y", alpha=0.25)
    axis.legend(frameon=False, fontsize=8)
    _save_figure(figure, figures, stem)
    plt.close(figure)


def _plot_resource_trends(raw: pd.DataFrame, figures: Path) -> None:
    import matplotlib.pyplot as plt

    figure, axes = plt.subplots(1, 2, figsize=(10.5, 4.2))
    for axis, metric, ylabel in (
        (axes[0], "end_to_end_seconds_amortized_shared_cost", "Amortized end-to-end time (s)"),
        (axes[1], "peak_rss_mb", "Peak resident memory (MB)"),
    ):
        for method_id in R1_METHODS:
            frame = raw.loc[raw["method"].eq(method_id)]
            grouped = frame.groupby("target_fraction", sort=True)[metric].mean()
            axis.plot(grouped.index.to_numpy(dtype=float) * 100, grouped.to_numpy(dtype=float), marker="o", label=METHOD_DISPLAY_NAMES[method_id])
        axis.set_xlabel("Sampling fraction (%)")
        axis.set_ylabel(ylabel)
        axis.set_xticks(np.asarray(R1_FRACTIONS) * 100)
        axis.grid(axis="y", alpha=0.25)
    axes[1].legend(frameon=False, fontsize=8)
    _save_figure(figure, figures, "resource_trends")
    plt.close(figure)


def _plot_paired_differences(paired: pd.DataFrame, figures: Path) -> None:
    import matplotlib.pyplot as plt

    metrics = (
        ("expression_state_coverage", "Expression-state coverage difference"),
        ("cell_group_l1_error", "Cell-group L1 error difference"),
        ("mean_within_group_spatial_l1_error", "Within-group spatial L1 difference"),
    )
    figure, axes = plt.subplots(1, 3, figsize=(14, 4.1), sharex=True)
    for axis, (metric, label) in zip(axes, metrics):
        subset = paired.loc[paired["metric"].eq(metric)]
        for method_id in ("uniform_srs", "spatial_pivotal", "formal_representation_mode"):
            frame = subset.loc[subset["method"].eq(method_id)]
            if frame.empty:
                continue
            grouped = frame.groupby("target_fraction", sort=True)["paired_difference_method_minus_baseline"].mean()
            axis.plot(grouped.index.to_numpy(dtype=float) * 100, grouped.to_numpy(dtype=float), marker="o", label=METHOD_DISPLAY_NAMES[method_id])
        axis.axhline(0, color="black", linewidth=0.8)
        axis.set_title(label, fontsize=10)
        axis.set_xlabel("Sampling fraction (%)")
        axis.set_xticks(np.asarray(R1_FRACTIONS) * 100)
        axis.grid(axis="y", alpha=0.25)
    axes[0].set_ylabel("Method minus Spatial-stratified SRS")
    axes[-1].legend(frameon=False, fontsize=8)
    _save_figure(figure, figures, "paired_differences_vs_spatial_stratified_srs")
    plt.close(figure)


def _plot_representative_map(raw: pd.DataFrame, coordinates: np.ndarray, figures: Path) -> None:
    import matplotlib.pyplot as plt

    fraction = 0.02
    seed = 0
    figure, axes = plt.subplots(2, 2, figsize=(9, 8), sharex=True, sharey=True)
    for axis, method_id in zip(axes.ravel(), R1_METHODS):
        row = raw.loc[
            raw["method"].eq(method_id)
            & np.isclose(raw["target_fraction"].astype(float), fraction)
            & raw["benchmark_repeat_seed"].eq(seed)
        ].iloc[0]
        selection = pd.read_csv(Path(row["selection_directory"]) / "selected_cells.csv")
        selected_ids = set(selection["cell_id"].astype(str))
        # Cell identifiers are stored in source order, so the boolean lookup stays deterministic.
        full_ids = np.asarray(row["_population_cell_ids"], dtype=object) if "_population_cell_ids" in row else None
        if full_ids is None:
            raise R1ValidationError("Representative map requires the temporary population identifier index.")
        mask = np.asarray([str(value) in selected_ids for value in full_ids], dtype=bool)
        axis.scatter(coordinates[:, 0], coordinates[:, 1], s=0.4, color="#b8b8b8", alpha=0.25, rasterized=True)
        axis.scatter(coordinates[mask, 0], coordinates[mask, 1], s=1.5, color="#1f77b4", alpha=0.8, rasterized=True)
        axis.set_title(METHOD_DISPLAY_NAMES[method_id], fontsize=10)
        axis.set_xticks([])
        axis.set_yticks([])
    _save_figure(figure, figures, "representative_spatial_sampling_map_fraction_2pct_seed_0")
    plt.close(figure)


def summarize_r1(config_path: str | Path) -> dict[str, Any]:
    """Create R1 summaries, paired tables, validation, and new figures after a complete run."""
    config = verify_immutable_r1_config(config_path)
    output_directory = Path(config["output"]["directory"])
    manifest_path = output_directory / "execution_manifest.csv"
    if not manifest_path.exists():
        raise FileNotFoundError("R1 execution manifest is missing.")
    manifest = pd.read_csv(manifest_path)
    expected = int(config["output"]["expected_official_run_units"])
    if len(manifest) != expected or not manifest["status"].eq("success").all():
        raise R1ValidationError("R1 is incomplete or has failures; final summaries are prohibited.")
    if manifest["run_id"].duplicated().any():
        raise R1ValidationError("R1 execution manifest contains duplicated run identifiers.")
    raw = manifest.copy()
    _write_new_csv(raw, output_directory / "raw_metrics.csv")
    summary = summarize_metric_table(raw)
    _write_new_csv(summary, output_directory / "summary_metrics.csv")
    paired_detail, paired_summary = paired_difference_tables(raw)
    _write_new_csv(paired_detail, output_directory / "paired_differences.csv")
    _write_new_csv(paired_summary, output_directory / "paired_difference_summary.csv")
    conclusions = historical_conclusion_status(raw, paired_detail)
    _write_new_csv(conclusions, output_directory / "historical_conclusion_status.csv")

    probability_methods = {"uniform_srs", "spatial_stratified_srs", "spatial_pivotal"}
    probability_identity_ok = bool(
        raw.loc[raw["method"].isin(probability_methods), "probability_design_eligible"].astype(bool).all()
    )
    formal_rows = raw.loc[raw["method"].eq("formal_representation_mode")]
    formal_probability_absent = bool(~formal_rows["probability_design_eligible"].astype(bool).any())
    validation = {
        "expected_run_units": expected,
        "completed_run_units": int(len(raw)),
        "failed_or_infeasible_run_units": 0,
        "unique_run_ids": int(raw["run_id"].nunique()),
        "all_target_sizes_exact": bool((raw["actual_n"].astype(int) == raw["target_n"].astype(int)).all()),
        "method_identity_checks_passed": bool(
            (~raw["uses_cell_labels"].astype(bool)).all()
            and (~raw["uses_domain_labels"].astype(bool)).all()
            and (~raw.loc[raw["method"].isin(["uniform_srs", "spatial_stratified_srs", "spatial_pivotal"]), "uses_expression"].astype(bool)).all()
        ),
        "probability_weight_only_for_probability_methods": probability_identity_ok and formal_probability_absent,
        "formal_composition_factor_separate_from_sampling_weight": formal_probability_absent,
        "selection_grid_quota_rule": config["quota_rule"],
        "legacy_validation_plan_difference": config["source_provenance"]["legacy_validation_plan_difference"],
    }
    _write_new_json(validation, output_directory / "result_validation_report.json")

    figures = output_directory / "figures"
    _plot_metric_trend(raw, "selected_spatial_coverage", "Spatial coverage", figures, "spatial_coverage_trend")
    _plot_metric_trend(raw, "expression_state_coverage", "Expression-state coverage", figures, "expression_state_coverage_trend")
    _plot_metric_trend(raw, "cell_group_l1_error", "Cell-group proportion L1 error", figures, "cell_group_proportion_error_trend")
    _plot_metric_trend(raw, "mean_within_group_spatial_l1_error", "Within-group spatial L1 error", figures, "within_group_spatial_error_trend")
    _plot_resource_trends(raw, figures)
    _plot_paired_differences(paired_detail, figures)
    # The map uses the source-order cell IDs only in memory and never writes them into summary tables.
    raw["_population_cell_ids"] = [None] * len(raw)
    import anndata as ad

    source = ad.read_h5ad(Path(config["input"]["h5ad_path"]), backed="r")
    try:
        population_ids = np.asarray(source.obs_names.astype(str), dtype=object)
        coordinates = np.asarray(source.obsm[config["input"]["spatial_coordinate_key"]])[:, :2]
    finally:
        source.file.close()
    raw["_population_cell_ids"] = [population_ids] * len(raw)
    _plot_representative_map(raw, coordinates, figures)

    return {
        "status": "success",
        "output_directory": str(output_directory),
        "summary_rows": int(len(summary)),
        "paired_difference_rows": int(len(paired_detail)),
        "conclusion_rows": int(len(conclusions)),
        "validation": validation,
    }
