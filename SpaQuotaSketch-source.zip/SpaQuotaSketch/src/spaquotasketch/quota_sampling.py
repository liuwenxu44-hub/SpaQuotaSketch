"""Quota-based sampling helpers."""

from __future__ import annotations

from collections import Counter, defaultdict
from typing import Hashable


def compute_bin_quotas(bin_ids: list[Hashable], target_n: int) -> dict[Hashable, int]:
    """Allocate final sample counts to bins in proportion to original bin sizes."""
    counts = Counter(bin_ids)
    if target_n < 0:
        raise ValueError("target_n must be non-negative.")
    if not counts or target_n == 0:
        return {bin_id: 0 for bin_id in counts}

    total = sum(counts.values())
    raw = {bin_id: target_n * count / total for bin_id, count in counts.items()}
    quotas = {bin_id: int(value) for bin_id, value in raw.items()}
    remaining = target_n - sum(quotas.values())
    order = sorted(raw, key=lambda key: raw[key] - quotas[key], reverse=True)
    for bin_id in order[:remaining]:
        quotas[bin_id] += 1
    return quotas


def sample_by_quota(
    candidate_ids: list[Hashable],
    candidate_bin_ids: list[Hashable],
    quotas: dict[Hashable, int],
    seed: int = 0,
) -> tuple[list[Hashable], dict[str, object]]:
    """Sample candidate ids within each bin according to precomputed quotas."""
    import random

    if len(candidate_ids) != len(candidate_bin_ids):
        raise ValueError("candidate_ids and candidate_bin_ids must have the same length.")

    rng = random.Random(seed)
    ids_by_bin: dict[Hashable, list[Hashable]] = defaultdict(list)
    for item, bin_id in zip(candidate_ids, candidate_bin_ids):
        ids_by_bin[bin_id].append(item)

    selected: list[Hashable] = []
    insufficient_bins: list[dict[str, object]] = []
    for bin_id, quota in quotas.items():
        available = ids_by_bin.get(bin_id, [])
        n_take = min(int(quota), len(available))
        if n_take < int(quota):
            insufficient_bins.append(
                {"bin_id": bin_id, "quota": int(quota), "available_candidates": len(available)}
            )
        selected.extend(rng.sample(available, n_take) if n_take else [])

    report = {
        "n_selected": len(selected),
        "n_bins": len(quotas),
        "n_insufficient_bins": len(insufficient_bins),
        "insufficient_bins": insufficient_bins,
    }
    return selected, report
