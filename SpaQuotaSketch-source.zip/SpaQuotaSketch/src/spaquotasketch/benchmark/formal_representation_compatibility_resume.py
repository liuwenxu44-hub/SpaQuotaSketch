"""Narrow preflight for an audited cross-commit Representation continuation.

This module never changes a sampler.  It validates a one-off compatibility
certificate before delegating pending units to the frozen formal Representation
runner.  It is deliberately not a global relaxation of Git-commit checks.
"""

from __future__ import annotations

import csv
from hashlib import sha256
import json
from pathlib import Path
import subprocess
from typing import Any, Mapping

from ..result_storage import SSHFSAppendOnlyBackend, StorageConfig
from .formal_multiplatform_canary_runner import current_git_commit
from .formal_multiplatform_freeze import canonical_sha256, load_freeze_bundle, verify_frozen_input_files
from .formal_multiplatform_representation_runner import (
    FormalRepresentationManifestDriftError,
    _run_id,
    frozen_representation_units,
    run_authorized_formal_representation,
)


class CompatibilityResumeError(RuntimeError):
    """The audited compatibility continuation cannot safely proceed."""


_NONCOMPUTATIONAL_PREPROCESSING_KEYS = frozenset(
    {"code_commit", "preprocessing_cache_key", "manifest_sha256"}
)
_RECOVERY_ONLY_CHANGED_PATHS = frozenset(
    {
        "src/spaquotasketch/benchmark/formal_representation_compatibility_resume.py",
        "src/spaquotasketch/benchmark/formal_multiplatform_representation_runner.py",
        "tests/test_formal_representation_compatibility_resume.py",
    }
)
_REQUIRED_LINEAGE_COLUMNS = frozenset(
    {
        "original_run_id",
        "original_commit",
        "original_manifest",
        "unit_id",
        "original_output_hash",
        "canonical_payload_hash",
        "compatibility_certificate_id",
        "approved_for_aggregation",
        "aggregation_group_id",
    }
)


def _canonical_json(value: Any) -> bytes:
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":"), allow_nan=False) + "\n").encode("utf-8")


def _normalise(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _normalise(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_normalise(item) for item in value]
    if hasattr(value, "tolist"):
        return _normalise(value.tolist())
    if hasattr(value, "item"):
        return _normalise(value.item())
    if isinstance(value, Path):
        return str(value)
    return value


def canonical_payload_from_stored_success(
    *,
    runtime_manifest: Mapping[str, Any],
    input_manifest: Mapping[str, Any],
    method_metadata: Mapping[str, Any],
    selected_cells_csv: str,
) -> dict[str, Any]:
    """Create the same computation-only payload used by the compatibility audit."""

    preprocessing = {
        str(key): _normalise(value)
        for key, value in dict(runtime_manifest["preprocessing_manifest"]).items()
        if str(key) not in _NONCOMPUTATIONAL_PREPROCESSING_KEYS
    }
    return {
        "execution_unit": _normalise(runtime_manifest["execution_unit"]),
        "input_identity_sha256": str(input_manifest["input_identity_sha256"]),
        "adapter_id": str(input_manifest["adapter_id"]),
        "selected_cells_csv": str(selected_cells_csv).replace("\r\n", "\n").replace("\r", "\n"),
        "method_metadata": _normalise(method_metadata),
        "frozen_target_n": int(runtime_manifest["frozen_target_n"]),
        "spatial_quotas": _normalise(runtime_manifest["spatial_quotas"]),
        "spatial_strata_count": int(runtime_manifest["spatial_strata_count"]),
        "preprocessing_manifest": preprocessing,
    }


def canonical_payload_sha256_from_stored_success(
    *,
    runtime_manifest: Mapping[str, Any],
    input_manifest: Mapping[str, Any],
    method_metadata: Mapping[str, Any],
    selected_cells_csv: str,
) -> str:
    payload = canonical_payload_from_stored_success(
        runtime_manifest=runtime_manifest,
        input_manifest=input_manifest,
        method_metadata=method_metadata,
        selected_cells_csv=selected_cells_csv,
    )
    return sha256(_canonical_json(payload)).hexdigest()


def _load_json(path: str | Path, label: str) -> dict[str, Any]:
    source = Path(path)
    if not source.is_file():
        raise CompatibilityResumeError(f"{label} is missing: {source}")
    try:
        value = json.loads(source.read_text(encoding="utf-8"))
    except json.JSONDecodeError as error:
        raise CompatibilityResumeError(f"{label} is not valid JSON: {source}") from error
    if not isinstance(value, dict):
        raise CompatibilityResumeError(f"{label} must be a JSON object: {source}")
    return value


def _file_sha256(path: str | Path) -> str:
    return sha256(Path(path).read_bytes()).hexdigest()


def _is_recovery_only_change(changed_paths: set[str]) -> bool:
    """Allow a clean descendant only when it changes the resume guard itself."""

    return bool(changed_paths) and changed_paths.issubset(_RECOVERY_ONLY_CHANGED_PATHS)


def _approved_continuation_commits(
    *,
    repo_root: Path,
    certificate_commit: str,
    current_commit: str,
) -> set[str]:
    """Approve the certificate commit and one recovery-only clean descendant."""

    if current_commit == certificate_commit:
        return {certificate_commit}
    ancestor = subprocess.run(
        ["git", "merge-base", "--is-ancestor", certificate_commit, current_commit],
        cwd=repo_root,
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    if ancestor.returncode != 0:
        raise CompatibilityResumeError("Current commit is not descended from the approved continuation commit.")
    changed = {
        line.strip()
        for line in subprocess.check_output(
            ["git", "diff", "--name-only", f"{certificate_commit}..{current_commit}"],
            cwd=repo_root,
            text=True,
            encoding="utf-8",
        ).splitlines()
        if line.strip()
    }
    if not _is_recovery_only_change(changed):
        raise CompatibilityResumeError("Current descendant changes code outside the narrowly approved recovery guard.")
    return {certificate_commit, current_commit}


def _load_lineage(path: str | Path) -> dict[str, dict[str, str]]:
    source = Path(path)
    if not source.is_file():
        raise CompatibilityResumeError(f"Result-lineage registry is missing: {source}")
    with source.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        if reader.fieldnames is None or not _REQUIRED_LINEAGE_COLUMNS.issubset(reader.fieldnames):
            raise CompatibilityResumeError("Result-lineage registry is missing required columns.")
        rows = [dict(row) for row in reader]
    by_unit = {str(row["unit_id"]): row for row in rows}
    if len(by_unit) != len(rows):
        raise CompatibilityResumeError("Result-lineage registry contains duplicate unit IDs.")
    return by_unit


def _attempt_artifacts(record: Mapping[str, Any]) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any], str]:
    attempt = Path(str(record["run_directory"]))
    required = {
        "runtime": attempt / "runtime_manifest.json",
        "input": attempt / "input_manifest.json",
        "metadata": attempt / "method_output" / "metadata.json",
        "selected": attempt / "method_output" / "selected_cells.csv",
        "success": attempt / "_SUCCESS.json",
    }
    missing = [name for name, path in required.items() if not path.is_file()]
    if missing:
        raise CompatibilityResumeError(f"A completed result is missing required artifacts: {missing}")
    runtime = json.loads(required["runtime"].read_text(encoding="utf-8"))
    input_manifest = json.loads(required["input"].read_text(encoding="utf-8"))
    metadata = json.loads(required["metadata"].read_text(encoding="utf-8"))
    return runtime, input_manifest, metadata, required["selected"].read_text(encoding="utf-8")


def _remaining_continuation_unit_ids(
    *,
    full_ids: set[str],
    original_ids: set[str],
    manifest_pending_ids: set[str],
    successful_ids: set[str],
) -> list[str]:
    """Return the dynamic remainder without weakening the frozen manifest.

    The continuation manifest records the original 160 compatible successes and
    the 960 units that were pending when the continuation began.  A resumed
    process may legitimately add successes from that frozen pending set, but it
    must never introduce a unit outside the original complete plan.
    """

    if original_ids.intersection(manifest_pending_ids) or original_ids.union(manifest_pending_ids) != full_ids:
        raise CompatibilityResumeError("Continuation manifest completed and pending unit lists are inconsistent.")
    if not original_ids.issubset(successful_ids):
        raise CompatibilityResumeError("An original compatible success is missing from result storage.")
    continuation_success_ids = successful_ids.difference(original_ids)
    if not continuation_success_ids.issubset(manifest_pending_ids):
        raise CompatibilityResumeError("Result storage contains a success outside the frozen continuation pending set.")
    return sorted(full_ids.difference(successful_ids))


def validate_compatibility_resume_preflight(
    *,
    repo_root: str | Path,
    data_root: str | Path,
    formal_results_root: str | Path,
    certificate_path: str | Path,
    continuation_manifest_path: str | Path,
    lineage_path: str | Path,
) -> dict[str, Any]:
    """Verify the isolated cross-commit continuation contract before sampling."""

    root = Path(repo_root)
    certificate = _load_json(certificate_path, "Compatibility certificate")
    continuation = _load_json(continuation_manifest_path, "Continuation manifest")
    if certificate.get("certificate_version") != 1:
        raise CompatibilityResumeError("Compatibility certificate schema version is unsupported.")
    if certificate.get("approved_for_cross_commit_resume") is not True:
        raise CompatibilityResumeError("Compatibility certificate does not approve cross-commit resume.")
    if certificate.get("equivalence_scope") != "formal representation benchmark only":
        raise CompatibilityResumeError("Compatibility certificate scope is not limited to formal Representation.")
    if certificate.get("excluded_scope") != "inference and all non-representation workflows":
        raise CompatibilityResumeError("Compatibility certificate does not explicitly exclude Inference.")
    current_commit = current_git_commit(root)
    certificate_continuation_commit = str(certificate.get("continuation_commit"))
    continuation_execution_commits = _approved_continuation_commits(
        repo_root=root,
        certificate_commit=certificate_continuation_commit,
        current_commit=current_commit,
    )
    approved_commits = {str(value) for value in certificate.get("approved_commits", [])}
    expected_original_commits = {str(certificate.get("commit_A")), str(certificate.get("commit_B"))}
    if not expected_original_commits.issubset(approved_commits) or certificate_continuation_commit not in approved_commits:
        raise CompatibilityResumeError("Compatibility certificate has an incomplete approved-commit set.")
    if continuation.get("continuation_run_id") != "formal_representation_compatibility_resume":
        raise CompatibilityResumeError("Continuation manifest has an unexpected run identity.")
    if continuation.get("phase") != "representation" or int(continuation.get("inference_execution_unit_count", -1)) != 0:
        raise CompatibilityResumeError("Continuation manifest permits an unsupported task or Inference unit.")
    if continuation.get("certificate_sha256") != _file_sha256(certificate_path):
        raise CompatibilityResumeError("Continuation manifest certificate hash does not match the certificate file.")
    if continuation.get("continuation_commit") != certificate_continuation_commit:
        raise CompatibilityResumeError("Continuation manifest does not name the certificate continuation commit.")
    if Path(str(continuation.get("formal_results_root"))).resolve() != Path(formal_results_root).resolve():
        raise CompatibilityResumeError("Continuation manifest result root does not match the requested result root.")

    units, frozen_manifest = frozen_representation_units(root)
    expected_by_id = {str(unit["execution_unit_id"]): unit for unit in units}
    full_ids = set(expected_by_id)
    if continuation.get("full_unit_ids_sha256") != canonical_sha256(sorted(full_ids)):
        raise CompatibilityResumeError("Continuation manifest full-unit identity hash differs from the frozen manifest.")
    if continuation.get("execution_unit_manifest_sha256") != frozen_manifest.execution_unit_manifest_sha256:
        raise CompatibilityResumeError("Continuation manifest execution-unit hash differs from the frozen manifest.")
    certificate_hashes = dict(certificate.get("formal_run_manifest", {}))
    for field, expected in frozen_manifest.as_dict().items():
        if field == "authorization_sha256":
            continue
        if certificate_hashes.get(field) != expected:
            raise CompatibilityResumeError(f"Certificate formal-run manifest differs at {field}.")

    try:
        bundle = load_freeze_bundle(root)
        verify_frozen_input_files(bundle["input_manifest"], Path(data_root))
    except Exception as error:
        raise CompatibilityResumeError(f"Frozen input identity verification failed: {error}") from error

    representation_root = Path(formal_results_root) / "representation"
    storage = SSHFSAppendOnlyBackend(
        StorageConfig(local_staging_root=Path("."), remote_results_root=representation_root, backend="sshfs_append_only")
    )
    state = storage.replay_events()
    if (Path(formal_results_root) / "inference").exists():
        raise CompatibilityResumeError("An Inference result directory exists; compatibility resume is forbidden.")
    success_records = {
        run_id: record for run_id, record in state.items() if record.get("status") == "SUCCESS"
    }
    unexpected_runs = sorted(set(success_records).difference({_run_id(unit) for unit in units}))
    if unexpected_runs:
        raise CompatibilityResumeError("Result storage contains a successful run outside the frozen Representation units.")
    lineage = _load_lineage(lineage_path)
    old_ids = {str(value) for value in continuation.get("completed_unit_ids", [])}
    if len(old_ids) != 160 or not old_ids.issubset(full_ids):
        raise CompatibilityResumeError("Continuation manifest completed-unit list is invalid.")
    if set(lineage) != old_ids:
        raise CompatibilityResumeError("Result-lineage registry does not exactly cover the 160 original successes.")
    group_id = str(continuation.get("aggregation_group_id"))
    for unit_id in sorted(old_ids):
        run_id = _run_id(expected_by_id[unit_id])
        record = success_records.get(run_id)
        if record is None or record.get("success_marker_valid") is not True:
            raise CompatibilityResumeError(f"Original compatible success is absent or invalid: {unit_id}")
        if str(record.get("code_commit")) not in expected_original_commits:
            raise CompatibilityResumeError(f"Original compatible success has an unapproved commit: {unit_id}")
        runtime, input_manifest, metadata, selected_csv = _attempt_artifacts(record)
        if runtime.get("execution_unit") != expected_by_id[unit_id]:
            raise CompatibilityResumeError(f"Original unit parameters drifted: {unit_id}")
        row = lineage[unit_id]
        if row["original_run_id"] != run_id or row["original_commit"] != str(record.get("code_commit")):
            raise CompatibilityResumeError(f"Result lineage disagrees with stored provenance: {unit_id}")
        if row["original_manifest"] != str(record.get("config_hash")):
            raise CompatibilityResumeError(f"Result lineage manifest hash disagrees: {unit_id}")
        if row["original_output_hash"] != str(runtime.get("output_hash")):
            raise CompatibilityResumeError(f"Result lineage output hash disagrees: {unit_id}")
        observed_canonical = canonical_payload_sha256_from_stored_success(
            runtime_manifest=runtime,
            input_manifest=input_manifest,
            method_metadata=metadata["metadata"],
            selected_cells_csv=selected_csv,
        )
        if row["canonical_payload_hash"] != observed_canonical:
            raise CompatibilityResumeError(f"Result lineage canonical payload hash disagrees: {unit_id}")
        if row["compatibility_certificate_id"] != str(certificate.get("certificate_id")):
            raise CompatibilityResumeError(f"Result lineage certificate identity disagrees: {unit_id}")
        if row["approved_for_aggregation"].lower() != "true" or row["aggregation_group_id"] != group_id:
            raise CompatibilityResumeError(f"Result lineage aggregation approval is invalid: {unit_id}")

    successful_ids = {run_id.removeprefix("representation_") for run_id in success_records}
    manifest_pending_ids = {str(value) for value in continuation.get("pending_unit_ids", [])}
    pending_ids = _remaining_continuation_unit_ids(
        full_ids=full_ids,
        original_ids=old_ids,
        manifest_pending_ids=manifest_pending_ids,
        successful_ids=successful_ids,
    )
    for unit_id in sorted(successful_ids.difference(old_ids)):
        record = success_records[_run_id(expected_by_id[unit_id])]
        if record.get("success_marker_valid") is not True:
            raise CompatibilityResumeError(f"Continuation success marker is invalid: {unit_id}")
        if str(record.get("code_commit")) not in continuation_execution_commits:
            raise CompatibilityResumeError(f"Continuation success has an unapproved commit: {unit_id}")
        if str(record.get("config_hash")) != frozen_manifest.execution_unit_manifest_sha256:
            raise CompatibilityResumeError(f"Continuation success has a different frozen manifest: {unit_id}")
        runtime, _, _, _ = _attempt_artifacts(record)
        if runtime.get("execution_unit") != expected_by_id[unit_id]:
            raise CompatibilityResumeError(f"Continuation unit parameters drifted: {unit_id}")
    return {
        "status": "READY_TO_RESUME_UNDER_COMPATIBILITY_CERTIFICATE",
        "current_commit": current_commit,
        "approved_continuation_execution_commits": sorted(continuation_execution_commits),
        "certificate_id": certificate["certificate_id"],
        "aggregation_group_id": group_id,
        "compatible_success_count": len(old_ids),
        "already_successful_unit_count": len(success_records),
        "pending_unit_count": len(pending_ids),
        "skipped_compatible_success_status": "SKIPPED_COMPATIBLE_SUCCESS",
        "inference_execution_count": 0,
    }


def run_compatibility_continuation(**kwargs: Any) -> dict[str, Any]:
    """Delegate only after the compatibility preflight has passed."""

    preflight_keys = {
        "repo_root",
        "data_root",
        "formal_results_root",
        "certificate_path",
        "continuation_manifest_path",
        "lineage_path",
    }
    preflight = validate_compatibility_resume_preflight(**{key: kwargs[key] for key in preflight_keys})
    result = run_authorized_formal_representation(
        repo_root=kwargs["repo_root"],
        authorization=kwargs["authorization"],
        data_root=kwargs["data_root"],
        formal_results_root=kwargs["formal_results_root"],
        local_staging_root=kwargs["local_staging_root"],
        max_workers=kwargs["max_workers"],
        threads_per_worker=kwargs["threads_per_worker"],
        resume=kwargs["resume"],
        retry_failed=kwargs.get("retry_failed", False),
        _input_identity_preverified=True,
    )
    return {"compatibility_preflight": preflight, "formal_representation_result": result}


__all__ = [
    "CompatibilityResumeError",
    "canonical_payload_from_stored_success",
    "canonical_payload_sha256_from_stored_success",
    "run_compatibility_continuation",
    "validate_compatibility_resume_preflight",
]
