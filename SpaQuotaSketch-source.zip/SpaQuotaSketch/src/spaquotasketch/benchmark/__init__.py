"""Independent benchmark execution utilities."""
