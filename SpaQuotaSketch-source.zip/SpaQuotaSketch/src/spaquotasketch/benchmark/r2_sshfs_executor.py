"""New SSHFS-safe execution path for a future pancreas R2 benchmark.

This module never imports the historical R2 executor.  It plans work, calls
registered sampler entry points through ``r2_method_adapter``, stages artifacts
locally, and delegates all remote persistence to ``SSHFSAppendOnlyBackend``.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import io
import json
import math
from pathlib import Path
from typing import Any, Mapping

import numpy as np
import pandas as pd
import yaml

from ..preprocess import compute_pca_embedding, get_spatial_coordinates, validate_spatial_anndata
from ..r1_benchmark import Measurement, _as_observation_total, _evaluate_run, _stratum_table, measure_call
from ..result_persistence import AppendOnlyRunPublisher
from ..result_storage import (
    EventWriteError,
    PublishError,
    SSHFSAppendOnlyBackend,
    StagedAttempt,
    StorageConfig,
    sha256_file,
)
from ..representation import QuotaCompletedRepresentationFailure
from ..samplers.registry import require_runnable_method
from ..spatial_bins import rectangular_grid_bins
from .r2_method_adapter import FORMAL_R2_METHODS, PROBABILITY_METHODS, run_registered_r2_method


FORMAL_R2_FRACTIONS = (0.005, 0.01, 0.02, 0.05, 0.10)
FORMAL_R2_SEEDS = tuple(range(10))


class R2SshfsExecutionError(RuntimeError):
    """Raised when the new R2 execution contract cannot be satisfied."""


class SyntheticComputeInterrupted(RuntimeError):
    """Test-only interruption used to verify immutable resume behavior."""


def _json_ready(value: Any) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return [_json_ready(item) for item in value.tolist()]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {str(key): _json_ready(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_ready(item) for item in value]
    return value


def _canonical_json(value: Mapping[str, Any]) -> bytes:
    return (json.dumps(_json_ready(value), ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")


def _frame_bytes(frame: pd.DataFrame) -> bytes:
    stream = io.StringIO(newline="")
    frame.to_csv(stream, index=False)
    return stream.getvalue().encode("utf-8")


def _read_yaml(path: str | Path) -> dict[str, Any]:
    value = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise R2SshfsExecutionError(f"Expected a YAML mapping: {path}")
    return value


def execution_config_hash(config: Mapping[str, Any]) -> str:
    """Stable hash for the frozen execution contract, including planned methods."""

    return hashlib.sha256(_canonical_json(dict(config))).hexdigest()


def target_n_from_fraction(n_cells: int, fraction: float) -> int:
    if not 0 < float(fraction) <= 1:
        raise ValueError("target fraction must lie in (0, 1]")
    return max(1, int(math.floor(int(n_cells) * float(fraction))))


def candidate_pool_seed_set(benchmark_repeat_seed: int, maximum_internal_seeds: int = 20) -> list[int]:
    start = int(benchmark_repeat_seed) * int(maximum_internal_seeds)
    return list(range(start, start + int(maximum_internal_seeds)))


def stable_run_id(method_id: str, fraction: float, benchmark_repeat_seed: int) -> str:
    return f"r2sshfs_{method_id}_{float(fraction):.3f}_seed_{int(benchmark_repeat_seed):02d}"


def validate_execution_config(config: Mapping[str, Any], *, require_formal_matrix: bool = False) -> None:
    """Validate an execution contract without creating a remote result directory."""

    methods = tuple(str(value) for value in config.get("methods", []))
    if methods != FORMAL_R2_METHODS:
        raise R2SshfsExecutionError("The new R2 config must use exactly the four registered methods.")
    fractions = tuple(float(value) for value in config.get("fractions", []))
    if not fractions or any(not 0 < value <= 1 for value in fractions) or len(set(fractions)) != len(fractions):
        raise R2SshfsExecutionError("Fractions must be unique values in (0, 1].")
    seeds = tuple(int(value) for value in config.get("benchmark_seeds", []))
    if not seeds or len(set(seeds)) != len(seeds) or any(value < 0 for value in seeds):
        raise R2SshfsExecutionError("Benchmark seeds must be unique non-negative integers.")
    if require_formal_matrix and fractions != FORMAL_R2_FRACTIONS:
        raise R2SshfsExecutionError("The formal R2 config must retain its five frozen fractions.")
    if require_formal_matrix and seeds != FORMAL_R2_SEEDS:
        raise R2SshfsExecutionError("The formal R2 config must retain seeds 0 through 9.")
    if not isinstance(config.get("dataset_id"), str) or not str(config["dataset_id"]).strip():
        raise R2SshfsExecutionError("The new R2 config requires a non-empty dataset_id.")
    storage = config.get("storage")
    if not isinstance(storage, Mapping):
        raise R2SshfsExecutionError("The new R2 config requires an explicit storage mapping.")
    storage_config = StorageConfig.from_mapping(storage)
    if storage_config.backend != "sshfs_append_only":
        raise R2SshfsExecutionError("The new R2 executor requires sshfs_append_only storage.")
    for method_id in methods:
        metadata = require_runnable_method(method_id)
        if method_id == "quota_completed_representation_mode" and metadata["implementation_status"] != "implemented_validated":
            raise R2SshfsExecutionError("quota_completed_representation_mode is not implemented_validated.")


def build_execution_plan(
    config: Mapping[str, Any],
    *,
    n_cells: int,
    code_commit: str,
) -> pd.DataFrame:
    """Build the exact matrix without loading expression values or creating a remote directory."""

    validate_execution_config(config)
    config_hash = execution_config_hash(config)
    rows: list[dict[str, Any]] = []
    for fraction in (float(value) for value in config["fractions"]):
        target_n = target_n_from_fraction(int(n_cells), fraction)
        for method_id in config["methods"]:
            metadata = require_runnable_method(str(method_id))
            for seed in (int(value) for value in config["benchmark_seeds"]):
                rows.append(
                    {
                        "run_id": stable_run_id(str(method_id), fraction, seed),
                        "dataset_id": str(config["dataset_id"]),
                        "target_fraction": float(fraction),
                        "target_n": int(target_n),
                        "method_id": str(method_id),
                        "method_display_name": str(metadata["method_display_name"]),
                        "benchmark_repeat_seed": int(seed),
                        "candidate_pool_seed_set": json.dumps(
                            candidate_pool_seed_set(seed)
                            if str(method_id) == "quota_completed_representation_mode"
                            else []
                        ),
                        "completion_seed": int(seed)
                        if str(method_id) == "quota_completed_representation_mode"
                        else "",
                        "final_selection_seed": int(seed),
                        "config_hash": config_hash,
                        "code_commit": str(code_commit),
                        "storage_backend": "sshfs_append_only",
                        "planned_attempt_id": 1,
                    }
                )
    plan = pd.DataFrame(rows).sort_values(
        ["target_fraction", "method_id", "benchmark_repeat_seed"], kind="stable"
    ).reset_index(drop=True)
    validate_execution_plan(plan, config)
    return plan


def validate_execution_plan(plan: pd.DataFrame, config: Mapping[str, Any]) -> None:
    expected = len(config["methods"]) * len(config["fractions"]) * len(config["benchmark_seeds"])
    if len(plan) != expected or plan["run_id"].duplicated().any():
        raise R2SshfsExecutionError("Execution plan must contain one unique row per planned unit.")
    if set(plan["method_id"]) != set(FORMAL_R2_METHODS):
        raise R2SshfsExecutionError("Execution plan method identities are incomplete.")
    per_method = len(config["fractions"]) * len(config["benchmark_seeds"])
    per_fraction = len(config["methods"]) * len(config["benchmark_seeds"])
    if not (plan.groupby("method_id").size() == per_method).all():
        raise R2SshfsExecutionError("Each method must occur equally often in the execution plan.")
    if not (plan.groupby("target_fraction").size() == per_fraction).all():
        raise R2SshfsExecutionError("Each fraction must occur equally often in the execution plan.")


def load_frozen_execution_plan(
    plan_path: str | Path,
    *,
    config: Mapping[str, Any],
    expected_code_commit: str,
    checksum_path: str | Path | None = None,
) -> tuple[pd.DataFrame, str]:
    """Load an already frozen local plan and reject any identity mismatch."""

    source = Path(plan_path)
    sidecar = source.with_suffix(source.suffix + ".sha256") if checksum_path is None else Path(checksum_path)
    if not source.is_file() or not sidecar.is_file():
        raise FileNotFoundError("Frozen execution plan and its SHA256 sidecar must both exist.")
    expected_text = sidecar.read_text(encoding="utf-8").strip().split()
    if not expected_text or expected_text[0] != sha256_file(source):
        raise R2SshfsExecutionError("Frozen execution plan SHA256 does not match its sidecar.")
    plan = pd.read_csv(source)
    validate_execution_plan(plan, config)
    expected_hash = execution_config_hash(config)
    if set(plan["config_hash"].astype(str)) != {expected_hash}:
        raise R2SshfsExecutionError("Frozen execution plan has a different configuration hash.")
    if set(plan["code_commit"].astype(str)) != {str(expected_code_commit)}:
        raise R2SshfsExecutionError("Frozen execution plan has a different code commit.")
    if set(plan["storage_backend"].astype(str)) != {"sshfs_append_only"}:
        raise R2SshfsExecutionError("Frozen execution plan does not require the SSHFS append-only backend.")
    return plan, expected_text[0]


def write_local_plan(plan: pd.DataFrame, directory: str | Path, stem: str = "pancreas_r2_sshfs_execution_plan") -> tuple[Path, Path]:
    """Create a local immutable plan and a checksum sidecar; never create a remote R2 directory."""

    target = Path(directory)
    target.mkdir(parents=True, exist_ok=True)
    plan_path = target / f"{stem}.csv"
    checksum_path = target / f"{stem}.csv.sha256"
    if plan_path.exists() or checksum_path.exists():
        raise FileExistsError(f"Refusing to overwrite local execution plan: {plan_path}")
    content = _frame_bytes(plan)
    with plan_path.open("xb") as handle:
        handle.write(content)
    digest = sha256_file(plan_path)
    with checksum_path.open("xb") as handle:
        handle.write(f"{digest}  {plan_path.name}\n".encode("utf-8"))
    return plan_path, checksum_path


def _probability_diagnostics(
    spatial_bins: np.ndarray,
    inclusion_probability: np.ndarray,
    *,
    method_id: str,
    target_n: int,
) -> pd.DataFrame:
    if method_id == "uniform_srs":
        return pd.DataFrame(
            [
                {
                    "sampling_scope": "global",
                    "spatial_stratum": "global",
                    "pi_min": float(np.min(inclusion_probability)),
                    "pi_max": float(np.max(inclusion_probability)),
                    "pi_sum": float(np.sum(inclusion_probability)),
                    "q_g": int(target_n),
                    "pi_sum_minus_q_g": float(np.sum(inclusion_probability) - int(target_n)),
                    "positive_support": bool(np.all(inclusion_probability > 0)),
                }
            ]
        )
    rows: list[dict[str, Any]] = []
    for stratum in sorted(set(spatial_bins.tolist())):
        mask = spatial_bins == stratum
        values = inclusion_probability[mask]
        rows.append(
            {
                "spatial_stratum": str(stratum),
                "pi_min": float(np.min(values)),
                "pi_max": float(np.max(values)),
                "pi_sum": float(np.sum(values)),
                "q_g": None,
                "positive_support": bool(np.all(values > 0)),
            }
        )
    return pd.DataFrame(rows)


@dataclass(frozen=True)
class ExecutionContext:
    cell_ids: np.ndarray
    cell_groups: np.ndarray
    coordinates: np.ndarray
    spatial_bins: np.ndarray
    expression_bins: np.ndarray
    expression_embedding: np.ndarray
    quotas_by_fraction: Mapping[float, Mapping[str, int]]
    quota_audit_by_fraction: Mapping[float, pd.DataFrame]
    full_gene_means: np.ndarray
    expression_total: np.ndarray
    matrix: Any


def build_execution_context(adata: Any, config: Mapping[str, Any]) -> ExecutionContext:
    """Build shared data structures using existing preprocessing and quota utilities."""

    validate_spatial_anndata(adata)
    cell_group_column = str(config["input"]["cell_group_column"])
    if cell_group_column not in adata.obs.columns:
        raise R2SshfsExecutionError(f"Missing evaluation column: {cell_group_column}")
    cell_ids = np.asarray(adata.obs_names.astype(str), dtype=object)
    coordinates = get_spatial_coordinates(adata)
    spatial_bins = np.asarray(
        rectangular_grid_bins(
            coordinates,
            n_x=int(config["selection_strata"]["n_x"]),
            n_y=int(config["selection_strata"]["n_y"]),
        ),
        dtype=object,
    )
    embedding = compute_pca_embedding(
        adata,
        n_components=int(config["expression_preprocessing"]["n_components"]),
        random_state=int(config["expression_preprocessing"]["random_state"]),
    )
    expression_bins = np.asarray(
        rectangular_grid_bins(
            embedding[:, :2],
            n_x=int(config["evaluation_grid"]["n_x"]),
            n_y=int(config["evaluation_grid"]["n_y"]),
        ),
        dtype=object,
    )
    quotas_by_fraction: dict[float, Mapping[str, int]] = {}
    audits_by_fraction: dict[float, pd.DataFrame] = {}
    for fraction in (float(value) for value in config["fractions"]):
        quotas, audit = _stratum_table(spatial_bins, target_n_from_fraction(adata.n_obs, fraction))
        quotas_by_fraction[fraction] = quotas
        audits_by_fraction[fraction] = audit
    return ExecutionContext(
        cell_ids=cell_ids,
        cell_groups=np.asarray(adata.obs[cell_group_column].astype(str), dtype=object),
        coordinates=coordinates,
        spatial_bins=spatial_bins,
        expression_bins=expression_bins,
        expression_embedding=embedding,
        quotas_by_fraction=quotas_by_fraction,
        quota_audit_by_fraction=audits_by_fraction,
        full_gene_means=np.asarray(adata.X.mean(axis=0)).reshape(-1),
        expression_total=_as_observation_total(adata),
        matrix=adata.X,
    )


def _draw_artifacts(
    *,
    draw: Any,
    context: ExecutionContext,
    target_n: int,
    method_id: str,
    quota_audit: pd.DataFrame,
    rare_label_max_fraction: float,
    measurement: Measurement,
) -> tuple[dict[str, bytes], dict[str, Any]]:
    selected = np.asarray(draw.selected_indices, dtype=int)
    if selected.size != int(target_n) or selected.size != np.unique(selected).size:
        raise R2SshfsExecutionError("Registered method did not return the exact unique target sample size.")
    if np.any(selected < 0) or np.any(selected >= context.cell_ids.size):
        raise R2SshfsExecutionError("Registered method returned a selected index outside the population.")
    if "cell_id" not in draw.selected_cells.columns or set(draw.selected_cells["cell_id"].astype(str)) != set(
        context.cell_ids[selected].astype(str)
    ):
        raise R2SshfsExecutionError("Selected cell identifiers do not match the registered selected indices.")
    artifacts: dict[str, bytes] = {"selected_cells.csv": _frame_bytes(draw.selected_cells)}
    quota_lookup = quota_audit.set_index("spatial_stratum")
    selected_spatial_counts = {
        stratum: int(np.sum(context.spatial_bins[selected] == stratum))
        for stratum in sorted(set(context.spatial_bins.tolist()))
    }
    spatial_quota_expected = {
        str(key): int(value) for key, value in quota_lookup["q_g"].items()
    }
    spatial_quota_checked = method_id != "uniform_srs"
    if spatial_quota_checked and selected_spatial_counts != spatial_quota_expected:
        raise R2SshfsExecutionError("A spatial-quota method did not satisfy every frozen quota.")
    if method_id in PROBABILITY_METHODS:
        if draw.inclusion_probability is None or draw.sampling_weight is None:
            raise R2SshfsExecutionError("Probability method omitted probability fields.")
        if not np.isfinite(draw.inclusion_probability).all() or np.any(draw.inclusion_probability <= 0) or np.any(draw.inclusion_probability > 1):
            raise R2SshfsExecutionError("Probability method returned an invalid inclusion probability.")
        selected_pi = draw.inclusion_probability[selected]
        selected_weight = draw.sampling_weight[selected]
        if not np.allclose(selected_weight, 1.0 / selected_pi, rtol=0, atol=1e-12):
            raise R2SshfsExecutionError("Probability method violated sampling_weight = 1 / inclusion_probability.")
        if method_id == "uniform_srs":
            probability_quota_error = float(abs(np.sum(draw.inclusion_probability) - int(target_n)))
        else:
            per_stratum_error = [
                abs(float(np.sum(draw.inclusion_probability[context.spatial_bins == stratum])) - int(quota))
                for stratum, quota in spatial_quota_expected.items()
            ]
            probability_quota_error = float(max(per_stratum_error, default=0.0))
        if probability_quota_error > 1e-10:
            raise R2SshfsExecutionError("Probability inclusion-probability sums do not match the design quota.")
        artifacts["probability_diagnostics.csv"] = _frame_bytes(
            _probability_diagnostics(
                context.spatial_bins,
                draw.inclusion_probability,
                method_id=method_id,
                target_n=int(target_n),
            )
        )
    else:
        if "sampling_weight" in draw.selected_cells.columns:
            raise R2SshfsExecutionError("Representation mode must not output sampling_weight.")
        representation = draw.representation_result
        diagnostics = representation.stratum_diagnostics
        if not np.array_equal(
            diagnostics["completion_added"].to_numpy(dtype=int),
            diagnostics["deficit_g"].to_numpy(dtype=int),
        ) or (diagnostics["C_g_after"].to_numpy(dtype=int) < diagnostics["q_g"].to_numpy(dtype=int)).any():
            raise R2SshfsExecutionError("Representation completion diagnostics violate the frozen quota contract.")
        if representation.candidate_cells["candidate_source"].isna().any():
            raise R2SshfsExecutionError("Representation candidate provenance is incomplete.")
        artifacts["candidate_cells.csv"] = _frame_bytes(representation.candidate_cells)
        artifacts["candidate_completion_stratum_diagnostics.csv"] = _frame_bytes(
            representation.stratum_diagnostics
        )
        artifacts["candidate_completion_global_diagnostics.json"] = _canonical_json(
            dict(representation.global_diagnostics)
        )
    metrics, group_rows = _evaluate_run(
        method_id=method_id,
        selected_indices=selected,
        cell_groups=context.cell_groups,
        spatial_bins=context.spatial_bins,
        expression_bins=context.expression_bins,
        coordinates=context.coordinates,
        full_gene_means=context.full_gene_means,
        matrix=context.matrix,
        expression_total=context.expression_total,
        inclusion_probability=draw.inclusion_probability,
        sampling_weight=draw.sampling_weight,
        rare_label_max_fraction=float(rare_label_max_fraction),
    )
    metadata = dict(draw.metadata)
    metadata.update({"method_id": method_id, "actual_n": int(selected.size)})
    quality = {
        "exact_target_n": True,
        "unique_selected_cells": True,
        "selected_cell_ids_in_population": True,
        "spatial_quota_applicable": spatial_quota_checked,
        "spatial_quota_counts": selected_spatial_counts,
        "spatial_quota_expected": spatial_quota_expected,
        "spatial_quota_satisfied": (not spatial_quota_checked) or selected_spatial_counts == spatial_quota_expected,
        "uniform_global_quota_satisfied": method_id != "uniform_srs" or selected.size == int(target_n),
        "maximum_probability_quota_error": probability_quota_error if method_id in PROBABILITY_METHODS else None,
        "probability_weight_identity": method_id in PROBABILITY_METHODS,
        "representation_has_sampling_weight": bool("sampling_weight" in draw.selected_cells.columns),
        "uses_evaluation_labels_for_sampling": False,
    }
    artifacts["method_metadata.json"] = _canonical_json(metadata)
    artifacts["metrics.json"] = _canonical_json(metrics)
    artifacts["cell_group_spatial_metrics.csv"] = _frame_bytes(pd.DataFrame(group_rows))
    artifacts["quality_checks.json"] = _canonical_json(quality)
    artifacts["resource.json"] = _canonical_json(
        {
            "compute_seconds": float(measurement.seconds),
            "compute_start_rss_mb": float(measurement.start_rss_mb),
            "compute_peak_rss_mb": float(measurement.peak_rss_mb),
            "measurement_scope": "registered_method_compute_including_candidate_pool_and_final_selection",
        }
    )
    return artifacts, {"metrics": metrics, "quality_checks": quality}


def _attempt_from_state(record: Mapping[str, Any], plan_row: Mapping[str, Any]) -> StagedAttempt:
    local_directory = Path(str(record["source_local_staging_path"]))
    remote_directory = Path(str(record["run_directory"]))
    if not local_directory.is_dir():
        raise R2SshfsExecutionError("A resumable publish attempt no longer has local staging files.")
    return StagedAttempt(
        run_id=str(plan_row["run_id"]),
        attempt_id=int(record["attempt_id"]),
        method_id=str(plan_row["method_id"]),
        config_hash=str(plan_row["config_hash"]),
        code_commit=str(plan_row["code_commit"]),
        local_directory=local_directory,
        remote_directory=remote_directory,
    )


def _check_resume_identity(state: Mapping[str, Mapping[str, Any]], plan: pd.DataFrame) -> None:
    expected_hashes = set(plan["config_hash"].astype(str))
    expected_commits = set(plan["code_commit"].astype(str))
    for run_id, record in state.items():
        if run_id not in set(plan["run_id"].astype(str)):
            continue
        if record.get("config_hash") not in expected_hashes or record.get("code_commit") not in expected_commits:
            raise R2SshfsExecutionError("Resume refused because an event has a different config hash or code commit.")


def execute_plan(
    *,
    plan: pd.DataFrame,
    config: Mapping[str, Any],
    context: ExecutionContext,
    backend: SSHFSAppendOnlyBackend,
    compute_interrupt_run_ids: set[str] | None = None,
) -> dict[str, Any]:
    """Execute or resume a plan without mutable manifests or unsafe remote writes."""

    validate_execution_plan(plan, config)
    state = backend.replay_events()
    _check_resume_identity(state, plan)
    publisher = AppendOnlyRunPublisher(backend)
    interrupted = set(compute_interrupt_run_ids or set())
    records: list[dict[str, Any]] = []
    for row in plan.to_dict(orient="records"):
        run_id = str(row["run_id"])
        prior = state.get(run_id)
        if prior and prior.get("status") == "SUCCESS" and prior.get("success_marker_valid"):
            records.append({"run_id": run_id, "status": "SKIPPED_VERIFIED_SUCCESS"})
            continue
        attempt: StagedAttempt | None = None
        try:
            if prior and str(prior.get("status")) in {
                "PUBLISH_FAILED",
                "UNCONFIRMED_SUCCESS_MARKER",
                "COMPUTE_SUCCESS",
            }:
                attempt = backend.retry_from_staging(
                    _attempt_from_state(prior, row),
                    previous_status=str(prior["status"]),
                )
                backend.record_event(attempt, new_status="RESUME_DETECTED", previous_status="PLANNED")
                backend.record_event(attempt, new_status="PUBLISHING", previous_status="RESUME_DETECTED")
                result = backend.publish(attempt, previous_status="PUBLISHING")
                records.append({"run_id": run_id, "status": result.status, "attempt_id": attempt.attempt_id})
                continue

            previous_status = str(prior["status"]) if prior else None
            attempt = backend.begin_attempt(
                run_id=run_id,
                method_id=str(row["method_id"]),
                config_hash=str(row["config_hash"]),
                code_commit=str(row["code_commit"]),
                previous_status=previous_status,
            )
            running_previous = "PLANNED"
            if prior:
                backend.record_event(attempt, new_status="RESUME_DETECTED", previous_status="PLANNED")
                running_previous = "RESUME_DETECTED"
            backend.mark_running(attempt, previous_status=running_previous)
            if run_id in interrupted:
                interrupted.remove(run_id)
                backend.record_event(attempt, new_status="INTERRUPTED", previous_status="RUNNING")
                records.append(
                    {"run_id": run_id, "status": "INTERRUPTED", "attempt_id": attempt.attempt_id}
                )
                continue
            fraction = float(row["target_fraction"])
            draw, measurement = measure_call(
                lambda: run_registered_r2_method(
                    method_id=str(row["method_id"]),
                    cell_ids=context.cell_ids,
                    coordinates=context.coordinates,
                    spatial_strata=context.spatial_bins,
                    quotas=context.quotas_by_fraction[fraction],
                    expression_embedding=context.expression_embedding,
                    target_n=int(row["target_n"]),
                    dataset_id=str(row["dataset_id"]),
                    target_fraction=fraction,
                    benchmark_repeat_seed=int(row["benchmark_repeat_seed"]),
                ),
                interval_seconds=float(config["resource_measurement"]["memory_poll_interval_seconds"]),
            )
            artifacts, _ = _draw_artifacts(
                draw=draw,
                context=context,
                target_n=int(row["target_n"]),
                method_id=str(row["method_id"]),
                quota_audit=context.quota_audit_by_fraction[fraction],
                rare_label_max_fraction=float(config["quality_control"]["rare_label_max_fraction"]),
                measurement=measurement,
            )
            publisher.stage(attempt, artifacts)
            backend.record_event(attempt, new_status="COMPUTE_SUCCESS", previous_status="RUNNING")
            backend.record_event(attempt, new_status="PUBLISHING", previous_status="COMPUTE_SUCCESS")
            result = backend.publish(attempt, previous_status="PUBLISHING")
            records.append({"run_id": run_id, "status": result.status, "attempt_id": attempt.attempt_id})
        except EventWriteError as error:
            records.append({"run_id": run_id, "status": "PUBLISH_FAILED", "error": str(error)})
        except PublishError as error:
            records.append({"run_id": run_id, "status": "PUBLISH_FAILED", "error": str(error)})
        except QuotaCompletedRepresentationFailure as error:
            if isinstance(attempt, StagedAttempt):
                backend.record_event(
                    attempt,
                    new_status="INFEASIBLE",
                    previous_status="RUNNING",
                    error={
                        "error_type": type(error).__name__,
                        "message": str(error),
                        "diagnostics": error.diagnostics,
                    },
                )
            records.append({"run_id": run_id, "status": "INFEASIBLE", "error": str(error)})
        except Exception as error:
            if isinstance(attempt, StagedAttempt):
                try:
                    backend.record_event(
                        attempt,
                        new_status="FAIL",
                        previous_status="RUNNING",
                        error={"error_type": type(error).__name__, "message": str(error)},
                    )
                except (ValueError, EventWriteError):
                    pass
            records.append({"run_id": run_id, "status": "FAIL", "error": str(error)})
        finally:
            attempt = None
    snapshot, snapshot_checksum, replayed = backend.rebuild_snapshot()
    successful = [
        run_id
        for run_id in plan["run_id"].astype(str)
        if replayed.get(run_id, {}).get("status") == "SUCCESS"
        and replayed.get(run_id, {}).get("success_marker_valid")
    ]
    return {
        "planned_units": int(len(plan)),
        "successful_units": int(len(successful)),
        "all_successful": bool(len(successful) == len(plan)),
        "records": records,
        "snapshot": str(snapshot),
        "snapshot_checksum": str(snapshot_checksum),
        "replayed_state": replayed,
        "operation_audit": backend.audit.as_dict(),
    }


def formal_plan_from_h5ad(
    config: Mapping[str, Any],
    *,
    h5ad_path: str | Path,
    code_commit: str,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Read only h5ad metadata to generate the formal local 200-unit plan."""

    import anndata as ad

    validate_execution_config(config, require_formal_matrix=True)
    input_path = Path(h5ad_path)
    backed = ad.read_h5ad(input_path, backed="r")
    try:
        n_cells = int(backed.n_obs)
        n_genes = int(backed.n_vars)
        obs_columns = [str(value) for value in backed.obs.columns]
        obsm_keys = [str(value) for value in backed.obsm.keys()]
    finally:
        backed.file.close()
    if str(config["input"]["cell_group_column"]) not in obs_columns or "spatial" not in obsm_keys:
        raise R2SshfsExecutionError("Formal input metadata does not satisfy the frozen requirements.")
    plan = build_execution_plan(config, n_cells=n_cells, code_commit=code_commit)
    return plan, {
        "h5ad_path": str(input_path),
        "sha256": sha256_file(input_path),
        "n_cells": n_cells,
        "n_genes": n_genes,
        "obs_columns": obs_columns,
        "obsm_keys": obsm_keys,
    }


__all__ = [
    "ExecutionContext",
    "FORMAL_R2_FRACTIONS",
    "FORMAL_R2_SEEDS",
    "R2SshfsExecutionError",
    "SyntheticComputeInterrupted",
    "build_execution_context",
    "build_execution_plan",
    "execute_plan",
    "execution_config_hash",
    "formal_plan_from_h5ad",
    "load_frozen_execution_plan",
    "stable_run_id",
    "target_n_from_fraction",
    "validate_execution_config",
    "validate_execution_plan",
    "write_local_plan",
]
