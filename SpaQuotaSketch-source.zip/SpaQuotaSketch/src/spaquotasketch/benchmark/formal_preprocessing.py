"""Frozen preprocessing protocol for the formal multi-platform benchmark.

The module deliberately separates two products.  Representation inputs may
contain the frozen expression embedding needed by the candidate-pool method.
Inference inputs remain raw aligned populations and never calculate an
expression embedding.  No function here writes a cache or reads a real input
unless a caller explicitly supplies one.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

import numpy as np
from scipy import sparse

from ..preprocess import compute_pca_embedding
from ..v2_1.quota import QuotaAllocation, allocate_largest_remainder_quotas
from ..v2_1.spatial import AdaptiveSpatialPartition, choose_adaptive_regular_partition
from .formal_multiplatform_freeze import canonical_sha256, load_yaml
from .formal_multiplatform_input_adapters import FormalRawInput


PREPROCESSING_CONFIG_PATH = Path("configs/formal_multiplatform_preprocessing_v1.yaml")
PREPROCESSING_PROTOCOL_ID = "formal_multiplatform_preprocessing_v1"


class FormalPreprocessingError(ValueError):
    """A frozen preprocessing requirement cannot be met safely."""


@dataclass(frozen=True)
class InputValidationReport:
    """Read-only raw-population facts retained in preprocessing manifests."""

    n_obs: int
    n_vars: int
    zero_count_observations: int
    zero_count_features: int
    targeted_panel: bool
    panel_manifest_name: str | None


@dataclass(frozen=True)
class FrozenSpatialDesign:
    """One target-size-specific spatial partition and its exact quota table."""

    target_n: int
    partition: AdaptiveSpatialPartition
    quota_allocation: QuotaAllocation

    @property
    def stratum_ids(self) -> np.ndarray:
        return self.partition.stratum_ids

    @property
    def quotas(self) -> dict[str, int]:
        return self.quota_allocation.quotas


@dataclass(frozen=True)
class RepresentationPreprocessedInput:
    """Frozen Representation-mode input, including its expression embedding."""

    raw_population: FormalRawInput
    expression_embedding: np.ndarray
    spatial_design: FrozenSpatialDesign
    validation: InputValidationReport
    preprocessing_manifest: Mapping[str, Any]


@dataclass(frozen=True)
class InferencePopulationInput:
    """Raw inference population.  It intentionally has no expression embedding."""

    raw_population: FormalRawInput
    validation: InputValidationReport
    preprocessing_manifest: Mapping[str, Any]

    @property
    def cell_ids(self) -> np.ndarray:
        return self.raw_population.cell_ids

    @property
    def expression_matrix(self) -> sparse.csr_matrix:
        return self.raw_population.expression_matrix

    @property
    def coordinates(self) -> np.ndarray:
        return self.raw_population.coordinates


def load_formal_preprocessing_config(repo_root: str | Path) -> dict[str, Any]:
    """Load and validate the tracked protocol configuration without opening data."""

    config = load_yaml(Path(repo_root) / PREPROCESSING_CONFIG_PATH)
    validate_formal_preprocessing_config(config)
    return config


def validate_formal_preprocessing_config(config: Mapping[str, Any]) -> None:
    """Reject ambiguous or silently data-dependent protocol definitions."""

    if str(config.get("protocol_id")) != PREPROCESSING_PROTOCOL_ID:
        raise FormalPreprocessingError("Unexpected formal preprocessing protocol identifier.")
    if str(config.get("protocol_completion_status")) != "PRE_BENCHMARK_PROTOCOL_COMPLETION":
        raise FormalPreprocessingError("Formal preprocessing must be recorded as protocol completion.")
    representation = config.get("representation")
    inference = config.get("inference")
    spatial = config.get("spatial")
    if not all(isinstance(item, Mapping) for item in (representation, inference, spatial)):
        raise FormalPreprocessingError("Formal preprocessing configuration is incomplete.")
    expression = representation.get("expression")
    if not isinstance(expression, Mapping):
        raise FormalPreprocessingError("Representation expression settings are missing.")
    forbidden = {"normalization", "log1p", "highly_variable_gene_selection", "batch_correction", "clustering"}
    if any(bool(expression.get(key)) for key in forbidden):
        raise FormalPreprocessingError("Formal representation preprocessing enables an unregistered transformation.")
    if str(expression.get("embedding_function")) != "compute_pca_embedding":
        raise FormalPreprocessingError("Formal representation preprocessing must reuse compute_pca_embedding.")
    if int(expression.get("requested_components", 0)) != 30 or int(expression.get("random_state", -1)) != 0:
        raise FormalPreprocessingError("Formal expression embedding parameters drifted from the fixed protocol.")
    if bool(inference.get("expression_embedding_permitted", True)):
        raise FormalPreprocessingError("Inference preprocessing must prohibit expression embeddings.")
    if str(spatial.get("partition_function")) != "choose_adaptive_regular_partition":
        raise FormalPreprocessingError("Formal spatial partitioning must reuse Version 2.1 adaptive partitioning.")
    if str(spatial.get("quota_function")) != "allocate_largest_remainder_quotas":
        raise FormalPreprocessingError("Formal quota allocation must reuse the Version 2.1 allocator.")
    if int(spatial.get("minimum_quota", 0)) != 1:
        raise FormalPreprocessingError("Formal spatial strata require exactly one minimum allocated observation.")
    if int(spatial.get("minimum_nonempty_strata", 0)) != 4:
        raise FormalPreprocessingError("Formal spatial protocol must require at least four nonempty strata.")
    if int(spatial.get("max_n_x", 0)) != 20 or int(spatial.get("max_n_y", 0)) != 20:
        raise FormalPreprocessingError("Formal spatial search bounds changed from the registered protocol.")


def preprocessing_config_sha256(config: Mapping[str, Any]) -> str:
    """Return the canonical hash of the frozen preprocessing definition."""

    return canonical_sha256(dict(config))


def _as_string_ids(values: np.ndarray, *, kind: str, expected_size: int) -> np.ndarray:
    identifiers = np.asarray(values, dtype=str)
    if identifiers.ndim != 1 or identifiers.size != expected_size:
        raise FormalPreprocessingError(f"{kind} identifiers do not match the raw matrix dimension.")
    if not np.all(np.char.str_len(identifiers) > 0) or len(set(identifiers.tolist())) != identifiers.size:
        raise FormalPreprocessingError(f"{kind} identifiers must be nonempty and unique.")
    return identifiers


def validate_formal_raw_population(
    raw_population: FormalRawInput,
    *,
    targeted_panel: bool,
    panel_manifest_name: str | None,
) -> InputValidationReport:
    """Validate without filtering, deleting, reordering, or modifying raw data."""

    matrix = raw_population.expression_matrix
    if not sparse.isspmatrix_csr(matrix) or matrix.ndim != 2 or min(matrix.shape) < 1:
        raise FormalPreprocessingError("Raw expression data must be a nonempty CSR matrix.")
    _as_string_ids(raw_population.cell_ids, kind="Cell", expected_size=matrix.shape[0])
    if raw_population.gene_ids is None:
        raise FormalPreprocessingError("Raw feature identifiers are required by the formal preprocessing protocol.")
    _as_string_ids(raw_population.gene_ids, kind="Feature", expected_size=matrix.shape[1])
    coordinates = np.asarray(raw_population.coordinates, dtype=float)
    if coordinates.shape != (matrix.shape[0], 2) or not np.isfinite(coordinates).all():
        raise FormalPreprocessingError("Raw spatial coordinates must be finite two-dimensional values aligned to cells.")
    if not np.isfinite(matrix.data).all() or np.any(matrix.data < 0):
        raise FormalPreprocessingError("Raw expression counts must be finite and nonnegative.")
    if targeted_panel:
        if not panel_manifest_name:
            raise FormalPreprocessingError("Targeted-panel input requires its frozen panel manifest name.")
        if panel_manifest_name not in set(raw_population.source_files):
            raise FormalPreprocessingError("Targeted-panel manifest is absent from the immutable raw input identity.")
    elif panel_manifest_name is not None:
        raise FormalPreprocessingError("Whole-transcriptome input cannot declare a targeted-panel manifest.")
    zero_observations = int(np.count_nonzero(np.diff(matrix.indptr) == 0))
    zero_features = int(np.count_nonzero(np.asarray(matrix.getnnz(axis=0)).reshape(-1) == 0))
    return InputValidationReport(
        n_obs=int(matrix.shape[0]),
        n_vars=int(matrix.shape[1]),
        zero_count_observations=zero_observations,
        zero_count_features=zero_features,
        targeted_panel=bool(targeted_panel),
        panel_manifest_name=panel_manifest_name,
    )


def build_preprocessing_cache_key(
    *,
    raw_population: FormalRawInput,
    config: Mapping[str, Any],
    dataset_id: str,
    sample_id: str,
    target_n: int,
    task: str,
    code_commit: str,
) -> str:
    """Build a content-addressed cache key; storage remains append-only elsewhere."""

    if task not in {"representation", "inference"}:
        raise FormalPreprocessingError("Preprocessing cache key has an unsupported task.")
    return canonical_sha256(
        {
            "protocol_config_sha256": preprocessing_config_sha256(config),
            "raw_source_identity_sha256": raw_population.source_identity_sha256,
            "dataset_id": str(dataset_id),
            "sample_id": str(sample_id),
            "target_n": int(target_n),
            "task": task,
            "code_commit": str(code_commit),
        }
    )


def build_frozen_spatial_design(
    inference_population: InferencePopulationInput,
    *,
    target_n: int,
    config: Mapping[str, Any],
) -> FrozenSpatialDesign:
    """Reuse the Version 2.1 partition and quota engine without reimplementation."""

    validate_formal_preprocessing_config(config)
    target_n = int(target_n)
    if not 1 <= target_n <= inference_population.validation.n_obs:
        raise FormalPreprocessingError("Frozen target sample size is outside the aligned raw population range.")
    settings = config["spatial"]
    try:
        partition = choose_adaptive_regular_partition(
            inference_population.coordinates,
            target_n,
            minimum_quota=int(settings["minimum_quota"]),
            max_n_x=int(settings["max_n_x"]),
            max_n_y=int(settings["max_n_y"]),
        )
    except ValueError as error:
        raise FormalPreprocessingError(f"No feasible formal spatial partition: {error}") from error
    positive_strata = int(len(partition.stratum_audit))
    required_strata = int(settings["minimum_nonempty_strata"])
    if positive_strata < required_strata:
        raise FormalPreprocessingError(
            f"Formal spatial design has only {positive_strata} nonempty strata; at least {required_strata} are required."
        )
    try:
        allocation = allocate_largest_remainder_quotas(
            partition.stratum_audit,
            target_n,
            minimum_quota=int(settings["minimum_quota"]),
        )
    except ValueError as error:
        raise FormalPreprocessingError(f"Formal spatial quota allocation is infeasible: {error}") from error
    if sum(allocation.quotas.values()) != target_n:
        raise RuntimeError("The reused quota allocator violated the frozen total sample size.")
    return FrozenSpatialDesign(target_n=target_n, partition=partition, quota_allocation=allocation)


def _preprocessing_manifest(
    *,
    task: str,
    raw_population: FormalRawInput,
    validation: InputValidationReport,
    config: Mapping[str, Any],
    dataset_id: str,
    sample_id: str,
    target_n: int | None,
    code_commit: str,
    spatial_design: FrozenSpatialDesign | None,
    embedding_components: int | None,
) -> dict[str, Any]:
    manifest: dict[str, Any] = {
        "protocol_id": PREPROCESSING_PROTOCOL_ID,
        "protocol_completion_status": str(config["protocol_completion_status"]),
        "task": task,
        "dataset_id": str(dataset_id),
        "sample_id": str(sample_id),
        "target_n": None if target_n is None else int(target_n),
        "code_commit": str(code_commit),
        "preprocessing_config_sha256": preprocessing_config_sha256(config),
        "raw_source_identity_sha256": raw_population.source_identity_sha256,
        "raw_source_files": list(raw_population.source_files),
        "input_validation": {
            "n_obs": validation.n_obs,
            "n_vars": validation.n_vars,
            "zero_count_observations_retained": validation.zero_count_observations,
            "zero_count_features_retained": validation.zero_count_features,
            "targeted_panel": validation.targeted_panel,
            "panel_manifest_name": validation.panel_manifest_name,
        },
        "expression_embedding_components": embedding_components,
        "expression_embedding_used": embedding_components is not None,
    }
    if spatial_design is not None:
        manifest["spatial_design"] = {
            "n_x": spatial_design.partition.n_x,
            "n_y": spatial_design.partition.n_y,
            "nonempty_strata": int(len(spatial_design.partition.stratum_audit)),
            "quota_sum": int(sum(spatial_design.quotas.values())),
            "selection_reason": spatial_design.partition.selection_reason,
            "quota_tie_break": "largest remainder, then N_g descending, then spatial stratum ascending",
        }
    manifest["preprocessing_cache_key"] = build_preprocessing_cache_key(
        raw_population=raw_population,
        config=config,
        dataset_id=dataset_id,
        sample_id=sample_id,
        target_n=0 if target_n is None else target_n,
        task=task,
        code_commit=code_commit,
    )
    manifest["manifest_sha256"] = canonical_sha256(manifest)
    return manifest


def prepare_inference_population(
    raw_population: FormalRawInput,
    *,
    config: Mapping[str, Any],
    dataset_id: str,
    sample_id: str,
    targeted_panel: bool,
    panel_manifest_name: str | None,
    code_commit: str,
) -> InferencePopulationInput:
    """Create an inference-only raw population without calculating PCA or candidates."""

    validate_formal_preprocessing_config(config)
    validation = validate_formal_raw_population(
        raw_population,
        targeted_panel=targeted_panel,
        panel_manifest_name=panel_manifest_name,
    )
    manifest = _preprocessing_manifest(
        task="inference",
        raw_population=raw_population,
        validation=validation,
        config=config,
        dataset_id=dataset_id,
        sample_id=sample_id,
        target_n=None,
        code_commit=code_commit,
        spatial_design=None,
        embedding_components=None,
    )
    return InferencePopulationInput(raw_population=raw_population, validation=validation, preprocessing_manifest=manifest)


def prepare_representation_input(
    raw_population: FormalRawInput,
    *,
    config: Mapping[str, Any],
    dataset_id: str,
    sample_id: str,
    target_n: int,
    targeted_panel: bool,
    panel_manifest_name: str | None,
    code_commit: str,
) -> RepresentationPreprocessedInput:
    """Build the only permitted expression embedding, then a shared spatial design."""

    inference_population = prepare_inference_population(
        raw_population,
        config=config,
        dataset_id=dataset_id,
        sample_id=sample_id,
        targeted_panel=targeted_panel,
        panel_manifest_name=panel_manifest_name,
        code_commit=code_commit,
    )
    from anndata import AnnData

    expression = config["representation"]["expression"]
    adata = AnnData(X=raw_population.expression_matrix)
    adata.obsm["spatial"] = raw_population.coordinates
    try:
        embedding = compute_pca_embedding(
            adata,
            n_components=int(expression["requested_components"]),
            random_state=int(expression["random_state"]),
        )
    except ValueError as error:
        raise FormalPreprocessingError(f"Formal expression embedding is infeasible: {error}") from error
    embedding = np.asarray(embedding, dtype=float)
    if embedding.shape[0] != raw_population.n_obs or embedding.ndim != 2 or embedding.shape[1] < 1:
        raise FormalPreprocessingError("Formal expression embedding has an invalid shape.")
    spatial_design = build_frozen_spatial_design(
        inference_population,
        target_n=target_n,
        config=config,
    )
    manifest = _preprocessing_manifest(
        task="representation",
        raw_population=raw_population,
        validation=inference_population.validation,
        config=config,
        dataset_id=dataset_id,
        sample_id=sample_id,
        target_n=target_n,
        code_commit=code_commit,
        spatial_design=spatial_design,
        embedding_components=int(embedding.shape[1]),
    )
    return RepresentationPreprocessedInput(
        raw_population=raw_population,
        expression_embedding=embedding,
        spatial_design=spatial_design,
        validation=inference_population.validation,
        preprocessing_manifest=manifest,
    )


__all__ = [
    "FormalPreprocessingError",
    "FrozenSpatialDesign",
    "InferencePopulationInput",
    "InputValidationReport",
    "PREPROCESSING_CONFIG_PATH",
    "RepresentationPreprocessedInput",
    "build_frozen_spatial_design",
    "build_preprocessing_cache_key",
    "load_formal_preprocessing_config",
    "prepare_inference_population",
    "prepare_representation_input",
    "preprocessing_config_sha256",
    "validate_formal_preprocessing_config",
    "validate_formal_raw_population",
]
