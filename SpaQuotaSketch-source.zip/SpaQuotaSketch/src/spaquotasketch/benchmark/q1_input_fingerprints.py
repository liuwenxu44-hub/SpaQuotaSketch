"""Content fingerprints for frozen Q1 task-validation expression inputs.

The functions in this module deliberately preserve the supplied cell order.
They are used to stop an external expression-space baseline from silently
sorting cells before it receives a frozen PCA matrix.
"""

from __future__ import annotations

from hashlib import sha256
from typing import Iterable

import numpy as np


class FrozenInputFingerprintError(ValueError):
    """Raised when a frozen input no longer has its registered identity."""


def _canonical_cell_id_bytes(cell_ids: Iterable[object]) -> bytes:
    values = [str(value) for value in cell_ids]
    if not values:
        raise FrozenInputFingerprintError("At least one cell identifier is required.")
    if len(set(values)) != len(values):
        raise FrozenInputFingerprintError("Cell identifiers must be unique before hashing.")
    return b"".join(value.encode("utf-8") + b"\0" for value in values)


def ordered_cell_id_sha256(cell_ids: Iterable[object]) -> str:
    """Hash a unique cell-id sequence without sorting it."""
    return sha256(_canonical_cell_id_bytes(cell_ids)).hexdigest()


def unordered_cell_set_sha256(cell_ids: Iterable[object]) -> str:
    """Hash the same unique identifiers after a documented lexical sort."""
    values = [str(value) for value in cell_ids]
    return sha256(_canonical_cell_id_bytes(sorted(values))).hexdigest()


def pca_matrix_sha256(values: np.ndarray) -> str:
    """Hash PCA values with an explicit shape and canonical C-order float64 bytes."""
    matrix = np.asarray(values, dtype=np.float64)
    if matrix.ndim != 2 or matrix.shape[0] == 0 or matrix.shape[1] == 0:
        raise FrozenInputFingerprintError("PCA input must be a nonempty two-dimensional matrix.")
    if not np.isfinite(matrix).all():
        raise FrozenInputFingerprintError("PCA input contains non-finite values.")
    canonical = np.ascontiguousarray(matrix, dtype=np.float64)
    header = f"shape={canonical.shape[0]},{canonical.shape[1]};dtype=float64;order=C\n".encode("ascii")
    return sha256(header + canonical.tobytes(order="C")).hexdigest()


def validate_frozen_pca_input(
    cell_ids: Iterable[object],
    pca_values: np.ndarray,
    *,
    expected_ordered_cell_id_sha256: str,
    expected_pca_matrix_sha256: str,
) -> None:
    """Require the registered row order and PCA content without reordering either."""
    ids = [str(value) for value in cell_ids]
    matrix = np.asarray(pca_values)
    if matrix.ndim != 2 or len(ids) != matrix.shape[0]:
        raise FrozenInputFingerprintError("PCA row count must equal the supplied cell-id count.")
    actual_ordered_hash = ordered_cell_id_sha256(ids)
    if actual_ordered_hash != expected_ordered_cell_id_sha256:
        raise FrozenInputFingerprintError(
            "Frozen cell order does not match the registered ordered cell-id SHA256. "
            "Automatic sorting is forbidden."
        )
    actual_pca_hash = pca_matrix_sha256(matrix)
    if actual_pca_hash != expected_pca_matrix_sha256:
        raise FrozenInputFingerprintError("Frozen PCA matrix does not match the registered PCA SHA256.")
