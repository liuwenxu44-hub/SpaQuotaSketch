"""Frozen-manifest helpers for the isolated Q1 engineering pilot.

This module intentionally knows nothing about scientific endpoints.  It only
defines the 48 pre-authorized engineering units and validates their immutable
identity before an external runner invokes existing samplers.
"""

from __future__ import annotations

from hashlib import sha256
import json
from pathlib import Path
from typing import Any, Iterable, Mapping


ENGINEERING_METHODS = (
    "uniform_srs",
    "spatial_stratified_srs",
    "spatial_pivotal",
    "geosketch",
    "scsampler",
    "quota_completed_representation_mode",
)
ENGINEERING_SAMPLES = (
    ("cosmx_crc_stromal_niches_gse303070", "278T", "cosmx_crc_stromal_niches_gse303070:Donor278:278T"),
    ("merfish_human_liver_fibrosis_dryad_2024", "AM042", "merfish_human_liver_fibrosis_dryad_2024:AM042"),
)
ENGINEERING_FRACTIONS = (0.02, 0.05)
ENGINEERING_SEEDS = (101, 202)


class EngineeringPilotManifestError(ValueError):
    """The requested engineering run is not the frozen 48-unit design."""


def canonical_sha256(value: object) -> str:
    """Return the canonical JSON SHA256 used by the frozen Q1 manifests."""

    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
    return sha256(payload).hexdigest()


def file_sha256(path: str | Path) -> str:
    """Hash a file without changing its content or location."""

    digest = sha256()
    with Path(path).open("rb") as handle:
        while block := handle.read(1024 * 1024):
            digest.update(block)
    return digest.hexdigest()


def target_size(n_cells: int, fraction: float) -> int:
    """Use the repository's registered nearest-integer target-size rule."""

    if not 1 <= int(n_cells):
        raise EngineeringPilotManifestError("n_cells must be positive.")
    if not 0.0 < float(fraction) <= 1.0:
        raise EngineeringPilotManifestError("sampling fraction must lie in (0, 1].")
    return max(1, min(int(n_cells), int(round(int(n_cells) * float(fraction)))))


def _records_by_key(fingerprint_document: Mapping[str, Any]) -> dict[tuple[str, str], Mapping[str, Any]]:
    records = fingerprint_document.get("records")
    if not isinstance(records, list):
        raise EngineeringPilotManifestError("Frozen fingerprint document has no record list.")
    result: dict[tuple[str, str], Mapping[str, Any]] = {}
    for record in records:
        if not isinstance(record, Mapping):
            raise EngineeringPilotManifestError("Frozen fingerprint document contains an invalid record.")
        key = (str(record.get("dataset_id")), str(record.get("sample_id")))
        if key in result:
            raise EngineeringPilotManifestError(f"Duplicate frozen fingerprint record: {key}.")
        result[key] = record
    return result


def build_engineering_units(fingerprint_document: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Expand the fixed two-sample, six-method, 48-unit engineering design."""

    fingerprint_manifest_sha256 = str(fingerprint_document.get("manifest_sha256", ""))
    if len(fingerprint_manifest_sha256) != 64:
        raise EngineeringPilotManifestError("Frozen input fingerprint manifest SHA256 is missing.")
    records = _records_by_key(fingerprint_document)
    units: list[dict[str, Any]] = []
    for dataset_id, sample_id, independent_sample_id in ENGINEERING_SAMPLES:
        record = records.get((dataset_id, sample_id))
        if record is None:
            raise EngineeringPilotManifestError(f"Missing frozen input record for {dataset_id}:{sample_id}.")
        n_cells = int(record["n_cells"])
        for method_id in ENGINEERING_METHODS:
            for fraction in ENGINEERING_FRACTIONS:
                for seed in ENGINEERING_SEEDS:
                    payload: dict[str, Any] = {
                        "arm": "engineering_pilot",
                        "dataset_id": dataset_id,
                        "sample_id": sample_id,
                        "independent_sample_id": independent_sample_id,
                        "method_id": method_id,
                        "sampling_fraction": float(fraction),
                        "target_n": target_size(n_cells, fraction),
                        "seed": int(seed),
                        "ordered_cell_id_sha256": str(record["ordered_cell_id_sha256"]),
                        "unordered_cell_set_sha256": str(record["unordered_cell_set_sha256"]),
                        "pca_matrix_sha256": str(record["pca_matrix_sha256"]),
                        "source_input_sha256": str(record["source_input_sha256"]),
                        "input_fingerprint_manifest_sha256": fingerprint_manifest_sha256,
                        "engineering_pilot_only": True,
                        "not_for_formal_inference": True,
                        "not_for_manuscript_claims": True,
                    }
                    units.append({"unit_id": f"q1eng_{canonical_sha256(payload)[:20]}", **payload})
    if len(units) != 48 or len({unit["unit_id"] for unit in units}) != 48:
        raise EngineeringPilotManifestError("Engineering pilot must contain exactly 48 unique units.")
    return units


def build_engineering_manifest(
    fingerprint_document: Mapping[str, Any],
    *,
    code_commit: str,
    formal_manifest_sha256: str,
) -> dict[str, Any]:
    """Create an immutable 48-unit manifest without authorizing formal units."""

    if len(str(code_commit)) < 7 or len(str(formal_manifest_sha256)) != 64:
        raise EngineeringPilotManifestError("Code commit or formal-manifest SHA256 is invalid.")
    document: dict[str, Any] = {
        "schema_version": "q1-task-validation-engineering-pilot-manifest-v1",
        "status": "ENGINEERING_PILOT_AUTHORIZED",
        "formal_task_units_authorized": False,
        "engineering_pilot_only": True,
        "not_for_formal_inference": True,
        "not_for_manuscript_claims": True,
        "code_commit": str(code_commit),
        "formal_manifest_sha256": str(formal_manifest_sha256),
        "input_fingerprint_manifest_sha256": str(fingerprint_document["manifest_sha256"]),
        "sample_cell_counts": [
            {
                "dataset_id": dataset_id,
                "sample_id": sample_id,
                "n_cells": int(_records_by_key(fingerprint_document)[(dataset_id, sample_id)]["n_cells"]),
            }
            for dataset_id, sample_id, _ in ENGINEERING_SAMPLES
        ],
        "unit_count": 48,
        "inference_unit_count": 0,
        "units": build_engineering_units(fingerprint_document),
    }
    document["manifest_sha256"] = canonical_sha256(document)
    return document


def validate_engineering_manifest(
    document: Mapping[str, Any],
    *,
    expected_code_commit: str | None = None,
    expected_formal_manifest_sha256: str | None = None,
) -> None:
    """Reject any expansion, reordering, label use, or formal-unit drift."""

    actual = dict(document)
    supplied_hash = str(actual.pop("manifest_sha256", ""))
    if canonical_sha256(actual) != supplied_hash:
        raise EngineeringPilotManifestError("Engineering pilot manifest SHA256 is invalid.")
    if actual.get("status") != "ENGINEERING_PILOT_AUTHORIZED" or actual.get("formal_task_units_authorized") is not False:
        raise EngineeringPilotManifestError("Manifest does not isolate the engineering pilot from formal execution.")
    if actual.get("unit_count") != 48 or actual.get("inference_unit_count") != 0:
        raise EngineeringPilotManifestError("Engineering manifest unit count or mode count drifted.")
    if expected_code_commit is not None and actual.get("code_commit") != expected_code_commit:
        raise EngineeringPilotManifestError("Engineering manifest code commit drifted.")
    if expected_formal_manifest_sha256 is not None and actual.get("formal_manifest_sha256") != expected_formal_manifest_sha256:
        raise EngineeringPilotManifestError("Engineering manifest formal-reference SHA256 drifted.")
    units = actual.get("units")
    if not isinstance(units, list) or len(units) != 48 or len({str(unit.get("unit_id")) for unit in units}) != 48:
        raise EngineeringPilotManifestError("Engineering manifest does not contain 48 unique units.")
    expected_keys = {
        (dataset_id, sample_id, method_id, fraction, seed)
        for dataset_id, sample_id, _ in ENGINEERING_SAMPLES
        for method_id in ENGINEERING_METHODS
        for fraction in ENGINEERING_FRACTIONS
        for seed in ENGINEERING_SEEDS
    }
    actual_keys = {
        (
            str(unit.get("dataset_id")),
            str(unit.get("sample_id")),
            str(unit.get("method_id")),
            float(unit.get("sampling_fraction")),
            int(unit.get("seed")),
        )
        for unit in units
    }
    if actual_keys != expected_keys:
        raise EngineeringPilotManifestError("Engineering manifest parameter space differs from the frozen 48-unit plan.")
    sample_sizes = {
        (str(row.get("dataset_id")), str(row.get("sample_id"))): int(row.get("n_cells"))
        for row in actual.get("sample_cell_counts", [])
        if isinstance(row, Mapping)
    }
    if set(sample_sizes) != {(dataset_id, sample_id) for dataset_id, sample_id, _ in ENGINEERING_SAMPLES}:
        raise EngineeringPilotManifestError("Engineering manifest sample-cell counts are incomplete.")
    for unit in units:
        if unit.get("arm") != "engineering_pilot" or not all(
            unit.get(key) is True
            for key in ("engineering_pilot_only", "not_for_formal_inference", "not_for_manuscript_claims")
        ):
            raise EngineeringPilotManifestError("Engineering-unit scope flags are missing or invalid.")
        n_cells = sample_sizes[(str(unit["dataset_id"]), str(unit["sample_id"]))]
        if int(unit["target_n"]) != target_size(n_cells, float(unit["sampling_fraction"])):
            raise EngineeringPilotManifestError("Engineering-unit target size drifted.")


def write_json_once(path: str | Path, value: Mapping[str, Any]) -> None:
    """Write a generated control file once; never overwrite a prior run control."""

    destination = Path(path)
    if destination.exists():
        raise FileExistsError(f"Refusing to overwrite existing control file: {destination}")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


__all__ = [
    "ENGINEERING_FRACTIONS",
    "ENGINEERING_METHODS",
    "ENGINEERING_SAMPLES",
    "ENGINEERING_SEEDS",
    "EngineeringPilotManifestError",
    "build_engineering_manifest",
    "build_engineering_units",
    "canonical_sha256",
    "file_sha256",
    "target_size",
    "validate_engineering_manifest",
    "write_json_once",
]
