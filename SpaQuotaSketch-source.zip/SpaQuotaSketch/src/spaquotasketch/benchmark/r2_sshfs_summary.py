"""Pure helpers for summarizing immutable pancreas R2 result artifacts."""

from __future__ import annotations

import io
import re
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd


R2_METHODS = (
    "uniform_srs",
    "spatial_stratified_srs",
    "spatial_pivotal",
    "quota_completed_representation_mode",
)

R2_METHOD_DISPLAY_NAMES = {
    "uniform_srs": "Uniform SRS",
    "spatial_stratified_srs": "Spatial-stratified SRS",
    "spatial_pivotal": "Spatial pivotal",
    "quota_completed_representation_mode": "Quota-completed representation",
}

SUMMARY_METRICS = (
    "target_n",
    "n_selected",
    "selected_spatial_coverage",
    "expression_state_coverage",
    "cell_group_l1_error",
    "mean_within_group_spatial_l1_error",
    "mean_within_group_spatial_coverage",
    "joint_spatial_group_l1_error",
    "rare_cell_recall",
    "gene_mean_relative_mae_unweighted",
    "gene_mean_relative_mae_probability_weighted",
    "nearest_selected_distance_median",
    "compute_seconds",
    "compute_peak_rss_mb",
    "ht_total_expression_relative_error",
    "hajek_mean_expression_relative_error",
    "weight_coefficient_of_variation",
    "maximum_weight",
    "maximum_to_median_weight",
    "kish_effective_sample_size",
    "kish_effective_sample_size_over_n",
    "completion_fraction",
    "completion_cell_count",
)

HIGHER_IS_BETTER = {
    "selected_spatial_coverage",
    "expression_state_coverage",
    "mean_within_group_spatial_coverage",
    "rare_cell_recall",
    "kish_effective_sample_size",
    "kish_effective_sample_size_over_n",
}

_RUN_ID_PATTERN = re.compile(
    r"^r2sshfs_(?P<method>.+)_(?P<fraction>0\.\d+)_seed_(?P<seed>\d+)$"
)


class R2SummaryError(RuntimeError):
    """Raised when immutable R2 artifacts cannot support a valid summary."""


@dataclass(frozen=True)
class ParsedRunId:
    """The frozen experimental dimensions encoded in one R2 run identifier."""

    method: str
    target_fraction: float
    benchmark_repeat_seed: int


def parse_run_id(run_id: str) -> ParsedRunId:
    """Parse the formal R2 run identifier without guessing its method identity."""

    match = _RUN_ID_PATTERN.fullmatch(str(run_id))
    if match is None:
        raise R2SummaryError(f"Unparseable R2 run ID: {run_id}")
    method = match.group("method")
    if method not in R2_METHODS:
        raise R2SummaryError(f"R2 run ID has an unregistered method: {method}")
    return ParsedRunId(
        method=method,
        target_fraction=float(match.group("fraction")),
        benchmark_repeat_seed=int(match.group("seed")),
    )


def frame_bytes(frame: pd.DataFrame) -> bytes:
    """Encode a table in the stable CSV form used by immutable report bundles."""

    return frame.to_csv(index=False, lineterminator="\n").encode("utf-8")


def summarize_metrics(raw: pd.DataFrame, metrics: Iterable[str] = SUMMARY_METRICS) -> pd.DataFrame:
    """Summarize repeats by sampling fraction and method in long-table form."""

    required = {"target_fraction", "method"}
    missing = required.difference(raw.columns)
    if missing:
        raise R2SummaryError(f"Raw metric table misses required columns: {sorted(missing)}")
    rows: list[dict[str, Any]] = []
    for (fraction, method), frame in raw.groupby(["target_fraction", "method"], sort=True):
        for metric in metrics:
            if metric not in frame.columns:
                continue
            values = pd.to_numeric(frame[metric], errors="coerce").dropna()
            rows.append(
                {
                    "target_fraction": float(fraction),
                    "method": str(method),
                    "method_display_name": R2_METHOD_DISPLAY_NAMES[str(method)],
                    "metric": metric,
                    "n_repeats": int(values.size),
                    "mean": float(values.mean()) if not values.empty else float("nan"),
                    "standard_deviation": float(values.std(ddof=1)) if values.size > 1 else (0.0 if values.size == 1 else float("nan")),
                    "median": float(values.median()) if not values.empty else float("nan"),
                    "minimum": float(values.min()) if not values.empty else float("nan"),
                    "maximum": float(values.max()) if not values.empty else float("nan"),
                    "quantile_25": float(values.quantile(0.25)) if not values.empty else float("nan"),
                    "quantile_75": float(values.quantile(0.75)) if not values.empty else float("nan"),
                }
            )
    return pd.DataFrame(rows).sort_values(["metric", "target_fraction", "method"], kind="stable")


def paired_differences(
    raw: pd.DataFrame,
    *,
    baseline_method: str = "spatial_stratified_srs",
    metrics: Iterable[str] = SUMMARY_METRICS,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Pair each method with the spatial SRS control by fraction and outer seed."""

    required = {"target_fraction", "method", "benchmark_repeat_seed"}
    missing = required.difference(raw.columns)
    if missing:
        raise R2SummaryError(f"Raw metric table misses paired-comparison columns: {sorted(missing)}")
    base = raw.loc[raw["method"].eq(baseline_method)].copy()
    if base.empty:
        raise R2SummaryError(f"Paired baseline is absent: {baseline_method}")
    rows: list[dict[str, Any]] = []
    for method in R2_METHODS:
        if method == baseline_method:
            continue
        method_frame = raw.loc[raw["method"].eq(method)]
        for metric in metrics:
            if metric not in raw.columns:
                continue
            merged = method_frame.loc[:, ["target_fraction", "benchmark_repeat_seed", metric]].merge(
                base.loc[:, ["target_fraction", "benchmark_repeat_seed", metric]],
                on=["target_fraction", "benchmark_repeat_seed"],
                suffixes=("_method", "_baseline"),
                how="inner",
            )
            for row in merged.itertuples(index=False):
                method_value = float(getattr(row, f"{metric}_method"))
                baseline_value = float(getattr(row, f"{metric}_baseline"))
                if not np.isfinite(method_value) or not np.isfinite(baseline_value):
                    continue
                difference = method_value - baseline_value
                direction = "higher" if metric in HIGHER_IS_BETTER else "lower"
                if abs(difference) <= 1e-12:
                    outcome = "tie"
                elif (direction == "higher" and difference > 0) or (direction == "lower" and difference < 0):
                    outcome = "win"
                else:
                    outcome = "loss"
                rows.append(
                    {
                        "target_fraction": float(row.target_fraction),
                        "method": method,
                        "baseline_method": baseline_method,
                        "benchmark_repeat_seed": int(row.benchmark_repeat_seed),
                        "metric": metric,
                        "method_value": method_value,
                        "baseline_value": baseline_value,
                        "paired_difference_method_minus_baseline": difference,
                        "preferred_direction": direction,
                        "outcome": outcome,
                    }
                )
    detail = pd.DataFrame(rows)
    summary_rows: list[dict[str, Any]] = []
    if not detail.empty:
        for keys, frame in detail.groupby(
            ["target_fraction", "method", "metric", "preferred_direction"], sort=True
        ):
            values = frame["paired_difference_method_minus_baseline"]
            summary_rows.append(
                {
                    "target_fraction": float(keys[0]),
                    "method": str(keys[1]),
                    "baseline_method": baseline_method,
                    "metric": str(keys[2]),
                    "preferred_direction": str(keys[3]),
                    "n_pairs": int(values.size),
                    "mean_paired_difference": float(values.mean()),
                    "standard_deviation_paired_difference": float(values.std(ddof=1)) if values.size > 1 else 0.0,
                    "median_paired_difference": float(values.median()),
                    "minimum_paired_difference": float(values.min()),
                    "maximum_paired_difference": float(values.max()),
                    "winning_seed_count": int(frame["outcome"].eq("win").sum()),
                    "tie_seed_count": int(frame["outcome"].eq("tie").sum()),
                    "losing_seed_count": int(frame["outcome"].eq("loss").sum()),
                }
            )
    return detail, pd.DataFrame(summary_rows)


def trend_figure_bytes(
    raw: pd.DataFrame,
    *,
    metric: str,
    ylabel: str,
    title: str | None = None,
) -> tuple[bytes, bytes]:
    """Create PNG and PDF trend plots without writing intermediate files."""

    if metric not in raw.columns:
        raise R2SummaryError(f"Metric is absent from raw table: {metric}")
    import matplotlib.pyplot as plt

    figure, axis = plt.subplots(figsize=(7.4, 4.5))
    for method in R2_METHODS:
        frame = raw.loc[raw["method"].eq(method)]
        grouped = frame.groupby("target_fraction", sort=True)[metric]
        fractions = np.asarray(sorted(grouped.groups), dtype=float)
        means = np.asarray([grouped.get_group(value).mean() for value in fractions], dtype=float)
        stds = np.asarray([grouped.get_group(value).std(ddof=1) for value in fractions], dtype=float)
        axis.plot(fractions * 100, means, marker="o", linewidth=1.8, label=R2_METHOD_DISPLAY_NAMES[method])
        axis.fill_between(fractions * 100, means - stds, means + stds, alpha=0.15)
    axis.set_xlabel("Sampling fraction (%)")
    axis.set_ylabel(ylabel)
    if title:
        axis.set_title(title)
    axis.set_xticks(np.asarray(sorted(raw["target_fraction"].unique()), dtype=float) * 100)
    axis.grid(axis="y", alpha=0.25)
    axis.legend(frameon=False, fontsize=8)
    png = io.BytesIO()
    pdf = io.BytesIO()
    figure.savefig(png, format="png", dpi=220, bbox_inches="tight")
    figure.savefig(pdf, format="pdf", bbox_inches="tight")
    plt.close(figure)
    return png.getvalue(), pdf.getvalue()

def resource_figure_bytes(raw: pd.DataFrame) -> tuple[bytes, bytes]:
    """Create the shared compute-time and peak-memory trend plot."""

    import matplotlib.pyplot as plt

    figure, axes = plt.subplots(1, 2, figsize=(10.5, 4.2))
    for axis, metric, ylabel in (
        (axes[0], "compute_seconds", "Method compute time (s)"),
        (axes[1], "compute_peak_rss_mb", "Peak resident memory (MB)"),
    ):
        for method in R2_METHODS:
            grouped = raw.loc[raw["method"].eq(method)].groupby("target_fraction", sort=True)[metric].mean()
            axis.plot(
                grouped.index.to_numpy(dtype=float) * 100,
                grouped.to_numpy(dtype=float),
                marker="o",
                label=R2_METHOD_DISPLAY_NAMES[method],
            )
        axis.set_xlabel("Sampling fraction (%)")
        axis.set_ylabel(ylabel)
        axis.set_xticks(np.asarray(sorted(raw["target_fraction"].unique()), dtype=float) * 100)
        axis.grid(axis="y", alpha=0.25)
    axes[1].legend(frameon=False, fontsize=8)
    png = io.BytesIO()
    pdf = io.BytesIO()
    figure.savefig(png, format="png", dpi=220, bbox_inches="tight")
    figure.savefig(pdf, format="pdf", bbox_inches="tight")
    plt.close(figure)
    return png.getvalue(), pdf.getvalue()


def paired_difference_figure_bytes(paired: pd.DataFrame) -> tuple[bytes, bytes]:
    """Plot paired differences against spatial-stratified SRS for key endpoints."""

    import matplotlib.pyplot as plt

    endpoints = (
        ("expression_state_coverage", "Expression-state coverage difference"),
        ("cell_group_l1_error", "Cell-group L1 error difference"),
        ("mean_within_group_spatial_l1_error", "Within-group spatial L1 difference"),
    )
    figure, axes = plt.subplots(1, 3, figsize=(14, 4.1), sharex=True)
    for axis, (metric, title) in zip(axes, endpoints):
        for method in ("uniform_srs", "spatial_pivotal", "quota_completed_representation_mode"):
            frame = paired.loc[(paired["metric"].eq(metric)) & (paired["method"].eq(method))]
            if frame.empty:
                continue
            grouped = frame.groupby("target_fraction", sort=True)["paired_difference_method_minus_baseline"].mean()
            axis.plot(
                grouped.index.to_numpy(dtype=float) * 100,
                grouped.to_numpy(dtype=float),
                marker="o",
                label=R2_METHOD_DISPLAY_NAMES[method],
            )
        axis.axhline(0, color="black", linewidth=0.8)
        axis.set_title(title, fontsize=10)
        axis.set_xlabel("Sampling fraction (%)")
        axis.set_xticks(np.asarray(sorted(paired["target_fraction"].unique()), dtype=float) * 100)
        axis.grid(axis="y", alpha=0.25)
    axes[0].set_ylabel("Method minus spatial-stratified SRS")
    axes[-1].legend(frameon=False, fontsize=8)
    png = io.BytesIO()
    pdf = io.BytesIO()
    figure.savefig(png, format="png", dpi=220, bbox_inches="tight")
    figure.savefig(pdf, format="pdf", bbox_inches="tight")
    plt.close(figure)
    return png.getvalue(), pdf.getvalue()
