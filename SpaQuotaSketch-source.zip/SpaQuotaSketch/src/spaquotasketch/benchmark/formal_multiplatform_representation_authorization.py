"""Strict authorization for the frozen formal Representation benchmark.

This module validates one explicit authorization file before a caller may
construct a real-data Representation runner.  It cannot authorize canary,
Inference, summary, an alternate execution-unit set, or command-line
scientific overrides.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

from .formal_multiplatform_freeze import canonical_sha256, load_yaml
from .formal_preprocessing import preprocessing_config_sha256


AUTHORIZATION_CONFIG_PATH = Path("configs/formal_multiplatform_representation_authorization.yaml")
AUTHORIZATION_ID = "formal-multiplatform-representation-v1"
REPRESENTATION_DIRECTORY = "representation"
REPRESENTATION_UNIT_COUNT = 1120


class RepresentationAuthorizationError(ValueError):
    """A requested run exceeds the frozen Representation authorization scope."""


@dataclass(frozen=True)
class RepresentationAuthorization:
    """Validated immutable facts permitting only frozen Representation units."""

    payload: Mapping[str, Any]
    authorization_sha256: str
    unit_ids: tuple[str, ...]


def _require_equal(actual: Any, expected: Any, *, field: str) -> None:
    if actual != expected:
        raise RepresentationAuthorizationError(f"Authorization field {field} is not the frozen value.")


def _require_exact_set(values: Any, expected: set[str], *, field: str) -> None:
    if not isinstance(values, list) or set(map(str, values)) != expected or len(values) != len(expected):
        raise RepresentationAuthorizationError(f"Authorization field {field} has an unsafe scope.")


def load_representation_authorization(
    repo_root: str | Path,
    authorization_config: str | Path,
) -> RepresentationAuthorization:
    """Load only the tracked Representation authorization configuration path."""

    root = Path(repo_root).resolve()
    actual_path = Path(authorization_config).resolve()
    expected_path = (root / AUTHORIZATION_CONFIG_PATH).resolve()
    if actual_path != expected_path:
        raise RepresentationAuthorizationError(
            "Only the tracked frozen Representation authorization configuration is accepted."
        )
    payload = load_yaml(actual_path)
    return RepresentationAuthorization(
        payload=payload,
        authorization_sha256=canonical_sha256(payload),
        unit_ids=(),
    )


def _method_registry_matches(bundle: Mapping[str, Any], method_registry: Mapping[str, Any]) -> bool:
    frozen_methods = list(bundle["benchmark"]["methods"])
    expected_hash = canonical_sha256(frozen_methods)
    expected_ids = [str(row["registry_id"]) for row in frozen_methods]
    return str(method_registry.get("sha256", "")) == expected_hash and list(method_registry.get("method_ids", [])) == expected_ids


def validate_representation_authorization(
    authorization: RepresentationAuthorization,
    *,
    bundle: Mapping[str, Any],
    representation_units: Sequence[Mapping[str, Any]],
    preprocessing_config: Mapping[str, Any],
    resource_plan: Mapping[str, Any],
    global_runner_policy: Mapping[str, Any],
    phase: str,
    max_workers: int,
    threads_per_worker: int,
    resume: bool,
    retry_failed: bool,
    requested_overrides: Mapping[str, Any],
    result_subdirectory: str,
) -> RepresentationAuthorization:
    """Reject scope drift before input reads, storage, or sampler construction."""

    payload = authorization.payload
    _require_equal(payload.get("authorization_schema_version"), 1, field="authorization_schema_version")
    _require_equal(payload.get("authorization_id"), AUTHORIZATION_ID, field="authorization_id")
    real_data = payload.get("real_data_execution")
    if not isinstance(real_data, Mapping):
        raise RepresentationAuthorizationError("Authorization has no real_data_execution section.")
    _require_equal(real_data.get("allowed"), True, field="real_data_execution.allowed")
    _require_equal(real_data.get("scope"), "formal_representation_only", field="real_data_execution.scope")
    _require_exact_set(payload.get("allowed_phases"), {"representation"}, field="allowed_phases")
    _require_exact_set(payload.get("prohibited_phases"), {"canary", "inference", "summarize"}, field="prohibited_phases")
    _require_equal(phase, "representation", field="requested_phase")
    if bool(global_runner_policy.get("allow_real_data_execution", True)):
        raise RepresentationAuthorizationError("The global unrestricted real-execution policy must remain closed.")

    execution_units = payload.get("execution_units")
    if not isinstance(execution_units, Mapping):
        raise RepresentationAuthorizationError("Authorization has no execution_units section.")
    _require_equal(execution_units.get("task"), "representation", field="execution_units.task")
    _require_equal(execution_units.get("expected_unit_count"), REPRESENTATION_UNIT_COUNT, field="execution_units.expected_unit_count")
    _require_equal(
        execution_units.get("manifest_path"),
        "configs/formal_multiplatform_execution_units.yaml",
        field="execution_units.manifest_path",
    )
    _require_equal(
        execution_units.get("manifest_sha256"),
        canonical_sha256(bundle["execution_units"]),
        field="execution_units.manifest_sha256",
    )
    actual_ids = tuple(str(unit["execution_unit_id"]) for unit in representation_units)
    if len(actual_ids) != REPRESENTATION_UNIT_COUNT or len(set(actual_ids)) != REPRESENTATION_UNIT_COUNT:
        raise RepresentationAuthorizationError("The runner did not resolve exactly 1,120 unique Representation units.")
    if any(str(unit["task"]) != "representation" for unit in representation_units):
        raise RepresentationAuthorizationError("An Inference unit entered the Representation authorization scope.")
    _require_equal(
        execution_units.get("execution_unit_ids_sha256"),
        canonical_sha256(list(actual_ids)),
        field="execution_units.execution_unit_ids_sha256",
    )

    frozen_hashes = payload.get("frozen_hashes")
    if not isinstance(frozen_hashes, Mapping):
        raise RepresentationAuthorizationError("Authorization has no frozen_hashes section.")
    expected_hashes = {
        "benchmark_config_sha256": bundle["benchmark"]["benchmark_config_sha256"],
        "freeze_manifest_sha256": bundle["freeze_manifest"]["freeze_manifest_sha256"],
        "preprocessing_config_sha256": preprocessing_config_sha256(preprocessing_config),
        "input_manifest_sha256": bundle["input_manifest"]["formal_input_manifest_sha256"],
        "seed_manifest_sha256": bundle["seeds"]["seed_manifest_sha256"],
    }
    for field, expected in expected_hashes.items():
        _require_equal(frozen_hashes.get(field), expected, field=f"frozen_hashes.{field}")
    method_registry = payload.get("method_registry")
    if not isinstance(method_registry, Mapping) or not _method_registry_matches(bundle, method_registry):
        raise RepresentationAuthorizationError("The authorization method registry does not match the frozen benchmark registry.")

    resource = payload.get("resource_plan")
    if not isinstance(resource, Mapping):
        raise RepresentationAuthorizationError("Authorization has no resource_plan section.")
    _require_equal(resource.get("path"), "configs/formal_multiplatform_resource_plan.yaml", field="resource_plan.path")
    _require_equal(resource.get("sha256"), canonical_sha256(resource_plan), field="resource_plan.sha256")
    required_workers = int(resource_plan["representation_recommended_concurrency"])
    required_threads = int(resource_plan["threads_per_process"])
    _require_equal(resource.get("max_workers"), required_workers, field="resource_plan.max_workers")
    _require_equal(resource.get("threads_per_worker"), required_threads, field="resource_plan.threads_per_worker")
    _require_equal(int(max_workers), required_workers, field="requested_max_workers")
    _require_equal(int(threads_per_worker), required_threads, field="requested_threads_per_worker")

    runtime = payload.get("runtime")
    if not isinstance(runtime, Mapping):
        raise RepresentationAuthorizationError("Authorization has no runtime section.")
    _require_equal(runtime.get("resume_required"), True, field="runtime.resume_required")
    _require_equal(runtime.get("overwrite_allowed"), False, field="runtime.overwrite_allowed")
    _require_equal(bool(resume), True, field="requested_resume")
    _require_equal(bool(retry_failed), False, field="requested_retry_failed")

    cli_overrides = payload.get("cli_overrides")
    if not isinstance(cli_overrides, Mapping):
        raise RepresentationAuthorizationError("Authorization has no cli_overrides section.")
    for name in ("method", "fraction", "seed", "sample", "dataset", "endpoint", "execution_unit"):
        _require_equal(cli_overrides.get(f"allow_{name}_override"), False, field=f"cli_overrides.allow_{name}_override")
        if requested_overrides.get(name) is not None:
            raise RepresentationAuthorizationError(f"The Representation authorization refuses a {name} override.")

    result_policy = payload.get("result_policy")
    if not isinstance(result_policy, Mapping):
        raise RepresentationAuthorizationError("Authorization has no result_policy section.")
    _require_equal(result_policy.get("engineering_only"), False, field="result_policy.engineering_only")
    _require_equal(result_policy.get("formal_summary_eligible"), True, field="result_policy.formal_summary_eligible")
    _require_equal(result_policy.get("result_subdirectory"), REPRESENTATION_DIRECTORY, field="result_policy.result_subdirectory")
    _require_equal(result_policy.get("overwrite_allowed"), False, field="result_policy.overwrite_allowed")
    _require_equal(result_policy.get("resume_allowed"), True, field="result_policy.resume_allowed")
    _require_equal(result_subdirectory, REPRESENTATION_DIRECTORY, field="requested_result_subdirectory")
    formal = payload.get("formal_benchmark_execution")
    if not isinstance(formal, Mapping):
        raise RepresentationAuthorizationError("Authorization has no formal_benchmark_execution section.")
    _require_equal(formal.get("representation_allowed"), True, field="formal_benchmark_execution.representation_allowed")
    _require_equal(formal.get("inference_allowed"), False, field="formal_benchmark_execution.inference_allowed")
    _require_equal(formal.get("full_benchmark_allowed"), False, field="formal_benchmark_execution.full_benchmark_allowed")

    return RepresentationAuthorization(
        payload=payload,
        authorization_sha256=authorization.authorization_sha256,
        unit_ids=actual_ids,
    )


__all__ = [
    "AUTHORIZATION_CONFIG_PATH",
    "AUTHORIZATION_ID",
    "REPRESENTATION_DIRECTORY",
    "REPRESENTATION_UNIT_COUNT",
    "RepresentationAuthorization",
    "RepresentationAuthorizationError",
    "load_representation_authorization",
    "validate_representation_authorization",
]
