"""Read-only adapters for the three frozen formal benchmark input formats.

The adapters build one aligned raw population only.  They neither calculate an
expression embedding nor call a sampler.  Those operations need their own
frozen formal execution specification before real canary execution is allowed.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from hashlib import sha256
from pathlib import Path
import re
from typing import Any, Mapping, Sequence

import h5py
import numpy as np
import pandas as pd
from scipy import sparse

from ..datasets.final_external_input_qualification import _coordinates_from_parquet, _coordinates_from_visium_tar
from .formal_multiplatform_freeze import canonical_sha256


class FormalInputAdapterError(ValueError):
    """A frozen raw input cannot be read or aligned safely."""


@dataclass(frozen=True)
class FormalRawInput:
    """A raw, aligned population that is ready for separately frozen preprocessing."""

    cell_ids: np.ndarray
    expression_matrix: sparse.csr_matrix
    coordinates: np.ndarray
    adapter_id: str
    source_files: tuple[str, ...]
    source_identity_sha256: str
    gene_ids: np.ndarray | None = None

    @property
    def n_obs(self) -> int:
        return int(self.expression_matrix.shape[0])

    @property
    def n_vars(self) -> int:
        return int(self.expression_matrix.shape[1])


def _decode_strings(values: Any) -> np.ndarray:
    return np.asarray(
        [value.decode("utf-8") if isinstance(value, bytes) else str(value) for value in np.ravel(values)],
        dtype=str,
    )


def _validate_matrix(matrix: sparse.spmatrix, *, expected_n_obs: int | None = None) -> sparse.csr_matrix:
    values = matrix.tocsr(copy=False)
    if values.ndim != 2 or min(values.shape) < 1:
        raise FormalInputAdapterError("Expression matrix must have at least one observation and one feature.")
    if expected_n_obs is not None and values.shape[0] != int(expected_n_obs):
        raise FormalInputAdapterError("Expression matrix observation count does not match the identifier count.")
    if not np.isfinite(values.data).all() or np.any(values.data < 0):
        raise FormalInputAdapterError("Expression matrix contains non-finite or negative values.")
    return values


def read_10x_h5_matrix_with_features(path: str | Path) -> tuple[np.ndarray, np.ndarray, sparse.csr_matrix]:
    """Read a 10x HDF5 sparse matrix and its feature identifiers."""

    source = Path(path)
    with h5py.File(source, "r") as handle:
        if "matrix" not in handle:
            raise FormalInputAdapterError(f"10x matrix group is missing: {source.name}")
        matrix = handle["matrix"]
        required = {"shape", "barcodes", "data", "indices", "indptr", "features"}
        missing = sorted(required.difference(matrix.keys()))
        if missing or "id" not in matrix["features"]:
            raise FormalInputAdapterError(f"10x matrix schema is incomplete: {source.name}")
        shape = tuple(int(value) for value in np.asarray(matrix["shape"]))
        if len(shape) != 2 or min(shape) < 1:
            raise FormalInputAdapterError(f"10x matrix shape is invalid: {source.name}")
        n_features, n_observations = shape
        cell_ids = _decode_strings(matrix["barcodes"][()])
        if cell_ids.size != n_observations or len(set(cell_ids.tolist())) != n_observations:
            raise FormalInputAdapterError(f"10x observation identifiers are invalid: {source.name}")
        feature_ids = _decode_strings(matrix["features"]["id"][()])
        if feature_ids.size != n_features:
            raise FormalInputAdapterError(f"10x feature identifiers are invalid: {source.name}")
        data = np.asarray(matrix["data"][()])
        indices = np.asarray(matrix["indices"][()])
        indptr = np.asarray(matrix["indptr"][()])
    if indptr.size != n_observations + 1 or int(indptr[-1]) != data.size or indices.size != data.size:
        raise FormalInputAdapterError(f"10x sparse index pointers are invalid: {source.name}")
    if indices.size and (int(indices.min()) < 0 or int(indices.max()) >= n_features):
        raise FormalInputAdapterError(f"10x sparse feature indices are invalid: {source.name}")
    raw = sparse.csc_matrix((data, indices, indptr), shape=(n_features, n_observations))
    return cell_ids, feature_ids, _validate_matrix(raw.transpose().tocsr(), expected_n_obs=n_observations)


def read_10x_h5_matrix(path: str | Path) -> tuple[np.ndarray, sparse.csr_matrix]:
    """Read a 10x HDF5 sparse matrix as observations-by-features CSR data.

    This compatibility wrapper keeps the originally frozen raw-adapter public
    function stable while the formal preprocessing layer also receives feature
    identities for strict validation.
    """

    cell_ids, _, matrix = read_10x_h5_matrix_with_features(path)
    return cell_ids, matrix


def _align_coordinates(
    *,
    cell_ids: np.ndarray,
    expression_matrix: sparse.csr_matrix,
    coordinate_ids: Sequence[str],
    coordinate_values: np.ndarray,
) -> tuple[np.ndarray, sparse.csr_matrix, np.ndarray]:
    values = np.asarray(coordinate_values, dtype=float)
    identifiers = np.asarray([str(item) for item in coordinate_ids], dtype=str)
    if values.ndim != 2 or values.shape[1] < 2 or values.shape[0] != identifiers.size:
        raise FormalInputAdapterError("Spatial coordinate table has an invalid shape.")
    if identifiers.size != len(set(identifiers.tolist())) or not np.isfinite(values[:, :2]).all():
        raise FormalInputAdapterError("Spatial coordinate identifiers are duplicated or coordinates are non-finite.")
    lookup = {identifier: index for index, identifier in enumerate(identifiers.tolist())}
    try:
        order = np.asarray([lookup[str(identifier)] for identifier in cell_ids], dtype=int)
    except KeyError as error:
        raise FormalInputAdapterError(f"Expression observation has no spatial coordinate: {error.args[0]}") from error
    return cell_ids.astype(str, copy=False), expression_matrix, values[order, :2]


def _identity(adapter_id: str, source_files: Sequence[Path], *, n_obs: int, n_vars: int) -> str:
    records: list[dict[str, Any]] = []
    for path in source_files:
        digest = sha256()
        with path.open("rb") as handle:
            while chunk := handle.read(1024 * 1024):
                digest.update(chunk)
        records.append({"path": path.name, "bytes": int(path.stat().st_size), "sha256": digest.hexdigest()})
    return canonical_sha256(
        {"adapter_id": adapter_id, "source_files": records, "n_obs": int(n_obs), "n_vars": int(n_vars)}
    )


def load_xenium_h5_parquet(matrix_path: str | Path, cells_parquet_path: str | Path) -> FormalRawInput:
    """Load a Xenium sparse HDF5 matrix and cell-centroid parquet table."""

    matrix_file, coordinate_file = Path(matrix_path), Path(cells_parquet_path)
    cell_ids, gene_ids, matrix = read_10x_h5_matrix_with_features(matrix_file)
    coordinates = _coordinates_from_parquet(coordinate_file)
    ids, matrix, aligned = _align_coordinates(
        cell_ids=cell_ids,
        expression_matrix=matrix,
        coordinate_ids=coordinates.identifiers,
        coordinate_values=coordinates.coordinates,
    )
    return FormalRawInput(
        cell_ids=ids,
        expression_matrix=matrix,
        coordinates=aligned,
        adapter_id="xenium_h5_parquet",
        source_files=(matrix_file.name, coordinate_file.name),
        source_identity_sha256=_identity("xenium_h5_parquet", (matrix_file, coordinate_file), n_obs=matrix.shape[0], n_vars=matrix.shape[1]),
        gene_ids=gene_ids,
    )


def load_visium_h5_spatial_tar(matrix_path: str | Path, spatial_tar_path: str | Path) -> FormalRawInput:
    """Load a Visium sparse HDF5 matrix and its archived spatial positions."""

    matrix_file, coordinate_file = Path(matrix_path), Path(spatial_tar_path)
    cell_ids, gene_ids, matrix = read_10x_h5_matrix_with_features(matrix_file)
    coordinates = _coordinates_from_visium_tar(coordinate_file)
    ids, matrix, aligned = _align_coordinates(
        cell_ids=cell_ids,
        expression_matrix=matrix,
        coordinate_ids=coordinates.identifiers,
        coordinate_values=coordinates.coordinates,
    )
    return FormalRawInput(
        cell_ids=ids,
        expression_matrix=matrix,
        coordinates=aligned,
        adapter_id="visium_h5_spatial_tar",
        source_files=(matrix_file.name, coordinate_file.name),
        source_identity_sha256=_identity("visium_h5_spatial_tar", (matrix_file, coordinate_file), n_obs=matrix.shape[0], n_vars=matrix.shape[1]),
        gene_ids=gene_ids,
    )


def load_visium_hd_feature_slice(matrix_path: str | Path, *, mask_name: str = "square_016um") -> FormalRawInput:
    """Materialize the qualified Visium HD mask population from feature slices.

    Feature slices are sparse triplets on the native 2-micrometre grid.  A
    ``square_XXXum`` mask is indexed on its own binned grid, so native feature
    coordinates must first be integer-divided by ``XXX / 2`` and counts for
    the resulting bin must be summed.  Only binned coordinates present in the
    frozen mask become observations; slices outside it are ignored instead of
    being silently treated as new bins.
    """

    source = Path(matrix_path)
    match = re.fullmatch(r"square_(\d{3})um", mask_name)
    if match is None:
        raise FormalInputAdapterError(f"Visium HD mask name does not encode a square bin size: {mask_name}")
    bin_size_um = int(match.group(1))
    if bin_size_um < 2 or bin_size_um % 2:
        raise FormalInputAdapterError(f"Visium HD mask bin size must be an even number of micrometres: {mask_name}")
    binning_scale = bin_size_um // 2
    with h5py.File(source, "r") as handle:
        mask_path = f"masks/{mask_name}"
        if mask_path not in handle or "features" not in handle or "feature_slices" not in handle:
            raise FormalInputAdapterError(f"Visium HD feature-slice schema is incomplete: {source.name}")
        mask = handle[mask_path]
        if not {"row", "col"}.issubset(mask.keys()) or "id" not in handle["features"]:
            raise FormalInputAdapterError(f"Visium HD mask or feature identifiers are incomplete: {source.name}")
        rows = np.asarray(mask["row"][()], dtype=np.int64)
        columns = np.asarray(mask["col"][()], dtype=np.int64)
        gene_ids = _decode_strings(handle["features"]["id"][()])
        feature_count = int(gene_ids.size)
        if rows.size == 0 or rows.shape != columns.shape or feature_count < 1:
            raise FormalInputAdapterError(f"Visium HD mask or feature shape is invalid: {source.name}")
        coordinate_index = {(int(row), int(column)): index for index, (row, column) in enumerate(zip(rows, columns, strict=True))}
        if len(coordinate_index) != rows.size:
            raise FormalInputAdapterError(f"Visium HD mask coordinates are duplicated: {source.name}")
        observation_chunks: list[np.ndarray] = []
        feature_chunks: list[np.ndarray] = []
        value_chunks: list[np.ndarray] = []
        slice_group = handle["feature_slices"]
        for feature_key in sorted(
            slice_group.keys(), key=lambda item: (not item.isdigit(), int(item) if item.isdigit() else item)
        ):
            if not feature_key.isdigit() or int(feature_key) >= feature_count:
                raise FormalInputAdapterError(f"Visium HD feature slice identifier is invalid: {feature_key}")
            feature = slice_group[feature_key]
            if not {"row", "col", "data"}.issubset(feature.keys()):
                raise FormalInputAdapterError(f"Visium HD feature slice is incomplete: {feature_key}")
            slice_rows = np.asarray(feature["row"][()], dtype=np.int64)
            slice_columns = np.asarray(feature["col"][()], dtype=np.int64)
            slice_values = np.asarray(feature["data"][()])
            if slice_rows.shape != slice_columns.shape or slice_rows.shape != slice_values.shape:
                raise FormalInputAdapterError(f"Visium HD feature slice dimensions do not agree: {feature_key}")
            binned_rows = slice_rows // binning_scale
            binned_columns = slice_columns // binning_scale
            observation_indices = np.fromiter(
                (
                    coordinate_index.get((int(row), int(column)), -1)
                    for row, column in zip(binned_rows, binned_columns, strict=True)
                ),
                dtype=np.int64,
                count=slice_rows.size,
            )
            keep = observation_indices >= 0
            if np.any(keep):
                kept_observations = observation_indices[keep]
                kept_values = slice_values[keep]
                order = np.argsort(kept_observations, kind="stable")
                sorted_observations = kept_observations[order]
                sorted_values = kept_values[order]
                unique_observations, first = np.unique(sorted_observations, return_index=True)
                binned_values = np.add.reduceat(sorted_values, first)
                nonzero = binned_values != 0
                observation_chunks.append(unique_observations[nonzero])
                feature_chunks.append(np.full(int(nonzero.sum()), int(feature_key), dtype=np.int64))
                value_chunks.append(binned_values[nonzero])
    if observation_chunks:
        matrix = sparse.coo_matrix(
            (np.concatenate(value_chunks), (np.concatenate(observation_chunks), np.concatenate(feature_chunks))),
            shape=(rows.size, feature_count),
        ).tocsr()
    else:
        matrix = sparse.csr_matrix((rows.size, feature_count), dtype=float)
    matrix = _validate_matrix(matrix, expected_n_obs=rows.size)
    cell_ids = np.asarray([f"{int(row)}:{int(column)}" for row, column in zip(rows, columns, strict=True)], dtype=str)
    return FormalRawInput(
        cell_ids=cell_ids,
        expression_matrix=matrix,
        coordinates=np.column_stack((columns, rows)).astype(float, copy=False),
        adapter_id="visium_hd_feature_slice",
        source_files=(source.name,),
        source_identity_sha256=_identity("visium_hd_feature_slice", (source,), n_obs=matrix.shape[0], n_vars=matrix.shape[1]),
        gene_ids=gene_ids,
    )


def _with_declared_source_identity(value: FormalRawInput, source_files: Sequence[Path]) -> FormalRawInput:
    """Include every frozen source, including a targeted-panel manifest, in identity."""

    return replace(
        value,
        source_files=tuple(path.name for path in source_files),
        source_identity_sha256=_identity(
            value.adapter_id,
            source_files,
            n_obs=value.n_obs,
            n_vars=value.n_vars,
        ),
    )


def load_formal_raw_input(
    *,
    adapter_id: str,
    source_files: Sequence[str | Path],
    visium_hd_mask_name: str = "square_016um",
) -> FormalRawInput:
    """Dispatch only one of the three frozen raw input adapters."""

    files = tuple(Path(item) for item in source_files)
    if adapter_id == "xenium_h5_parquet":
        if len(files) < 2:
            raise FormalInputAdapterError("Xenium adapter requires a matrix HDF5 file and cells parquet file.")
        matrix = next((path for path in files if path.suffix == ".h5"), None)
        cells = next((path for path in files if path.name.endswith("cells.parquet")), None)
        if matrix is None or cells is None:
            raise FormalInputAdapterError("Xenium adapter could not identify its HDF5 matrix and cells parquet inputs.")
        return _with_declared_source_identity(load_xenium_h5_parquet(matrix, cells), files)
    if adapter_id == "visium_h5_spatial_tar":
        if len(files) != 2:
            raise FormalInputAdapterError("Visium adapter requires exactly one HDF5 matrix and one spatial tar archive.")
        matrix = next((path for path in files if path.suffix == ".h5"), None)
        spatial = next((path for path in files if path.name.endswith(".tar.gz")), None)
        if matrix is None or spatial is None:
            raise FormalInputAdapterError("Visium adapter could not identify its HDF5 matrix and spatial archive.")
        return _with_declared_source_identity(load_visium_h5_spatial_tar(matrix, spatial), files)
    if adapter_id == "visium_hd_feature_slice":
        if len(files) != 1 or files[0].suffix != ".h5":
            raise FormalInputAdapterError("Visium HD adapter requires exactly one feature-slice HDF5 input.")
        return _with_declared_source_identity(load_visium_hd_feature_slice(files[0], mask_name=visium_hd_mask_name), files)
    raise FormalInputAdapterError(f"Unsupported frozen input adapter: {adapter_id}")


def resolve_frozen_unit_sources(
    *,
    execution_unit: Mapping[str, Any],
    dataset_freeze: Mapping[str, Any],
    data_root: str | Path,
) -> tuple[str, tuple[Path, ...]]:
    """Resolve source paths only from the matching frozen dataset record."""

    dataset_id = str(execution_unit.get("dataset_id", ""))
    sample_id = str(execution_unit.get("sample_id", ""))
    adapter_id = str(execution_unit.get("adapter", ""))
    records = [item for item in dataset_freeze.get("datasets", []) if str(item.get("dataset_id", "")) == dataset_id]
    if len(records) != 1:
        raise FormalInputAdapterError(f"Frozen dataset identity is not unique: {dataset_id}")
    record = records[0]
    if sample_id not in {str(item) for item in record.get("frozen_sample_ids", [])}:
        raise FormalInputAdapterError(f"Execution unit sample is not frozen for dataset {dataset_id}: {sample_id}")
    if adapter_id != str(record.get("adapter_id", "")):
        raise FormalInputAdapterError(f"Execution unit adapter does not match frozen dataset {dataset_id}.")
    relative_paths = tuple(str(item) for item in record.get("input_file_relative_paths", []))
    if not relative_paths:
        raise FormalInputAdapterError(f"Frozen dataset has no declared input files: {dataset_id}")
    root = Path(data_root)
    paths = tuple(root / relative for relative in relative_paths)
    missing = [str(path.relative_to(root)) for path in paths if not path.is_file()]
    if missing:
        raise FormalInputAdapterError(f"Frozen input files are missing for {dataset_id}: {missing}")
    return adapter_id, paths


def load_frozen_unit_raw_input(
    *,
    execution_unit: Mapping[str, Any],
    dataset_freeze: Mapping[str, Any],
    data_root: str | Path,
    visium_hd_mask_name: str = "square_016um",
) -> FormalRawInput:
    """Read one unit only after its source identity matches the freeze record.

    This function intentionally stops at the raw aligned population.  It is
    not a sampler entry point and has no side effects outside read-only input
    access.
    """

    adapter_id, paths = resolve_frozen_unit_sources(
        execution_unit=execution_unit,
        dataset_freeze=dataset_freeze,
        data_root=data_root,
    )
    return load_formal_raw_input(
        adapter_id=adapter_id,
        source_files=paths,
        visium_hd_mask_name=visium_hd_mask_name,
    )


__all__ = [
    "FormalInputAdapterError",
    "FormalRawInput",
    "load_frozen_unit_raw_input",
    "load_formal_raw_input",
    "load_visium_hd_feature_slice",
    "load_visium_h5_spatial_tar",
    "load_xenium_h5_parquet",
    "read_10x_h5_matrix",
    "read_10x_h5_matrix_with_features",
    "resolve_frozen_unit_sources",
]
