"""Snapshot-indexed, batch-local continuation utilities.

This module schedules frozen Representation units only.  It never invokes a
sampler, changes a unit, or reads an old result tree after a snapshot exists.
"""

from __future__ import annotations

from hashlib import sha256
import json
from pathlib import Path
from typing import Any, Iterable, Mapping


class BatchContinuationError(RuntimeError):
    pass


def canonical_sha256(value: Any) -> str:
    return sha256((json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True) + "\n").encode()).hexdigest()


def _unit_id(unit: Mapping[str, Any]) -> str:
    return str(unit["execution_unit_id"])


def validate_snapshot(snapshot: Mapping[str, Any], master_manifest_hash: str) -> list[dict[str, Any]]:
    entries = list(snapshot.get("units", []))
    if int(snapshot.get("record_count", -1)) != 280 or len(entries) != 280:
        raise BatchContinuationError("Verified-success snapshot must contain exactly 280 records.")
    if str(snapshot.get("master_manifest_hash")) != master_manifest_hash:
        raise BatchContinuationError("Verified-success snapshot master manifest differs.")
    ids = [_unit_id(entry) for entry in entries]
    if len(set(ids)) != 280:
        raise BatchContinuationError("Verified-success snapshot has duplicate unit IDs.")
    payload = {key: value for key, value in snapshot.items() if key != "snapshot_sha256"}
    if snapshot.get("snapshot_sha256") != canonical_sha256(payload):
        raise BatchContinuationError("Verified-success snapshot hash is invalid.")
    return entries


def build_snapshot(*, master_manifest_hash: str, config_hash: str, input_hashes: Mapping[str, Any], fingerprint: Mapping[str, Any], records: Iterable[Mapping[str, Any]], created_at: str) -> dict[str, Any]:
    units = sorted((dict(record) for record in records), key=_unit_id)
    snapshot = {"snapshot_version": 1, "master_manifest_hash": master_manifest_hash, "config_hash": config_hash, "input_hashes": dict(input_hashes), "computational_fingerprint": dict(fingerprint), "units": units, "record_count": len(units), "created_at": created_at}
    snapshot["snapshot_sha256"] = canonical_sha256(snapshot)
    validate_snapshot(snapshot, master_manifest_hash)
    return snapshot


def deterministic_batches(units: Iterable[Mapping[str, Any]], verified_ids: set[str], master_manifest_hash: str) -> list[dict[str, Any]]:
    remaining = [dict(unit) for unit in units if _unit_id(unit) not in verified_ids]
    if len(remaining) != 840 or len({_unit_id(unit) for unit in remaining}) != 840:
        raise BatchContinuationError("Frozen plan minus verified successes must contain exactly 840 unique units.")
    if any(str(unit.get("task")) != "representation" for unit in remaining):
        raise BatchContinuationError("Inference units are forbidden from continuation batches.")
    # A deterministic rotation spreads every sorted stratum across batches.
    strata: dict[tuple[str, str, str, str], list[dict[str, Any]]] = {}
    for unit in remaining:
        key = tuple(str(unit.get(field, "")) for field in ("dataset_id", "method", "fraction", "seed"))
        strata.setdefault(key, []).append(unit)
    ordered: list[dict[str, Any]] = []
    while any(strata.values()):
        for key in sorted(strata):
            if strata[key]: ordered.append(strata[key].pop(0))
    sizes = [50] * 16 + [40]
    batches, offset = [], 0
    for number, size in enumerate(sizes, 1):
        selected = ordered[offset:offset + size]; offset += size
        manifest = {"batch_id": f"batch_{number:03d}", "master_manifest_hash": master_manifest_hash, "phase": "representation", "inference_execution_unit_count": 0, "units": selected, "unit_ids": [_unit_id(unit) for unit in selected]}
        manifest["batch_manifest_sha256"] = canonical_sha256(manifest)
        batches.append(manifest)
    if offset != 840 or len(set().union(*(set(batch["unit_ids"]) for batch in batches))) != 840:
        raise BatchContinuationError("Batch partition is incomplete or overlapping.")
    return batches


def load_completed_batch_ids(summaries: Iterable[Mapping[str, Any]], master_manifest_hash: str) -> set[str]:
    completed: set[str] = set()
    for summary in summaries:
        if summary.get("master_manifest_hash") != master_manifest_hash or summary.get("inference_unit_count") != 0:
            raise BatchContinuationError("Batch summary does not belong to this Representation continuation.")
        payload = {key: value for key, value in summary.items() if key != "summary_sha256"}
        if summary.get("summary_sha256") != canonical_sha256(payload):
            raise BatchContinuationError("Batch summary hash is invalid.")
        completed.update(map(str, summary.get("unit_ids", [])))
    return completed
