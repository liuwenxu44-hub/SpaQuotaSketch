"""Read-only scientific endpoint helpers for frozen Representation results.

The functions in this module consume an existing selected-cell set. They do
not contain a sampler, quota allocator, candidate-pool operation, or seed
derivation rule.
"""

from __future__ import annotations

from typing import Iterable, Sequence

import numpy as np

from ..metrics import spatial_coverage


FORMAL_ENDPOINT_SPEC_VERSION = "formal_endpoint_spec_v1"
EVALUATION_GRID_SHAPE = (20, 20)


class FormalEndpointEvaluationError(ValueError):
    """Raised when a completed result cannot be aligned to its raw population."""


def selected_indices_from_cell_ids(
    population_cell_ids: Sequence[str],
    selected_cell_ids: Iterable[str],
) -> np.ndarray:
    """Map immutable selected-cell identifiers back to aligned population rows."""

    population = np.asarray(population_cell_ids, dtype=str).reshape(-1)
    selected = np.asarray(list(selected_cell_ids), dtype=str).reshape(-1)
    if population.size == 0 or selected.size == 0:
        raise FormalEndpointEvaluationError("Population and selected-cell identifiers must be nonempty.")
    if len(set(population.tolist())) != population.size:
        raise FormalEndpointEvaluationError("Population cell identifiers are not unique.")
    if len(set(selected.tolist())) != selected.size:
        raise FormalEndpointEvaluationError("Selected-cell identifiers are duplicated.")
    positions = {cell_id: index for index, cell_id in enumerate(population.tolist())}
    missing = [cell_id for cell_id in selected.tolist() if cell_id not in positions]
    if missing:
        raise FormalEndpointEvaluationError(
            f"Selected-cell identifiers are absent from the frozen raw population; first={missing[0]!r}."
        )
    return np.asarray([positions[cell_id] for cell_id in selected.tolist()], dtype=int)


def evaluate_primary_coverage(
    *,
    spatial_bin_ids: Sequence[str],
    expression_state_bin_ids: Sequence[str],
    selected_indices: Sequence[int],
) -> dict[str, float | int]:
    """Calculate the two registered label-free Representation endpoints."""

    spatial = np.asarray(spatial_bin_ids, dtype=str).reshape(-1)
    expression = np.asarray(expression_state_bin_ids, dtype=str).reshape(-1)
    selected = np.asarray(selected_indices, dtype=int).reshape(-1)
    if spatial.shape != expression.shape or spatial.size == 0:
        raise FormalEndpointEvaluationError("Spatial and expression-state bins must align to a nonempty population.")
    if selected.size == 0 or np.unique(selected).size != selected.size:
        raise FormalEndpointEvaluationError("Selected indices must be nonempty and unique.")
    if selected.min() < 0 or selected.max() >= spatial.size:
        raise FormalEndpointEvaluationError("Selected indices are outside the frozen population.")
    return {
        "spatial_fidelity": float(spatial_coverage(spatial.tolist(), spatial[selected].tolist())),
        "expression_fidelity": float(spatial_coverage(expression.tolist(), expression[selected].tolist())),
        "n_selected": int(selected.size),
        "n_population_spatial_bins": int(np.unique(spatial).size),
        "n_population_expression_state_bins": int(np.unique(expression).size),
        "n_selected_spatial_bins": int(np.unique(spatial[selected]).size),
        "n_selected_expression_state_bins": int(np.unique(expression[selected]).size),
    }


def metric_direction(metric: str) -> str:
    """Return the frozen orientation used for paired differences and ranking."""

    directions = {
        "spatial_fidelity": "higher",
        "expression_fidelity": "higher",
        "composition_error": "lower",
        "cell_type_spatial_distribution_error": "lower",
        "rare_state_retention": "higher",
        "runtime_seconds": "lower",
        "peak_memory_bytes": "lower",
    }
    try:
        return directions[metric]
    except KeyError as error:
        raise FormalEndpointEvaluationError(f"Unknown formal endpoint metric: {metric}") from error


__all__ = [
    "EVALUATION_GRID_SHAPE",
    "FORMAL_ENDPOINT_SPEC_VERSION",
    "FormalEndpointEvaluationError",
    "evaluate_primary_coverage",
    "metric_direction",
    "selected_indices_from_cell_ids",
]
