"""Batch-local, resumable execution state around existing formal unit compute code."""
from __future__ import annotations

from hashlib import sha256
import json
import os
from pathlib import Path
from typing import Any, Callable, Mapping

from ..result_persistence import AppendOnlyRunPublisher
from ..result_storage import SSHFSAppendOnlyBackend
from .formal_batch_continuation import BatchContinuationError, canonical_sha256, validate_snapshot

NOT_STARTED = "NOT_STARTED"
RUNNING_LOCAL = "RUNNING_LOCAL"
LOCAL_SUCCESS_PENDING_SYNC = "LOCAL_SUCCESS_PENDING_SYNC"
REMOTE_SUCCESS = "REMOTE_SUCCESS"
FAILED_RETRYABLE = "FAILED_RETRYABLE"
FAILED_FINAL = "FAILED_FINAL"
_TERMINAL = {REMOTE_SUCCESS, FAILED_FINAL}


def _sha(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def _read(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _write(path: Path, value: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n", encoding="utf-8")


class BatchContinuationExecutor:
    """A local journal never scans historical formal result directories."""

    def __init__(self, *, control_dir: Path, local_batch_dir: Path, remote_batch_root: Path) -> None:
        self.control_dir = control_dir
        self.local = local_batch_dir
        self.remote = remote_batch_root

    def load_batch(self, batch_id: str, master_manifest_hash: str) -> tuple[dict[str, Any], dict[str, Any]]:
        snapshot = _read(self.control_dir / "verified_success_snapshot_280.json")
        validate_snapshot(snapshot, master_manifest_hash)
        batch = _read(self.control_dir / f"{batch_id}_manifest.json")
        payload = {key: value for key, value in batch.items() if key != "batch_manifest_sha256"}
        if batch.get("batch_manifest_sha256") != canonical_sha256(payload):
            raise BatchContinuationError("Current batch manifest hash is invalid.")
        if batch.get("inference_execution_unit_count") != 0 or any(unit.get("task") != "representation" for unit in batch["units"]):
            raise BatchContinuationError("Only Representation units are permitted.")
        if set(batch["unit_ids"]) & {row["execution_unit_id"] for row in snapshot["units"]}:
            raise BatchContinuationError("Current batch overlaps the verified snapshot.")
        return snapshot, batch

    @property
    def state_path(self) -> Path: return self.local / "current_state.json"
    @property
    def journal_path(self) -> Path: return self.local / "local_journal.jsonl"

    def initialise(self, batch: Mapping[str, Any]) -> dict[str, Any]:
        if self.state_path.exists(): return _read(self.state_path)
        state = {"batch_id": batch["batch_id"], "sealed": False, "unit_states": {unit_id: NOT_STARTED for unit_id in batch["unit_ids"]}}
        _write(self.state_path, state); return state

    def _save(self, state: dict[str, Any], unit_id: str, status: str, **extra: Any) -> None:
        state["unit_states"][unit_id] = status; _write(self.state_path, state)
        self.journal_path.parent.mkdir(parents=True, exist_ok=True)
        with self.journal_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps({"unit_id": unit_id, "status": status, **extra}, sort_keys=True) + "\n")

    def run(self, *, batch: Mapping[str, Any], state: dict[str, Any], compute: Callable[[Mapping[str, Any], Path], Mapping[str, Path]], storage: SSHFSAppendOnlyBackend, code_commit: str, config_hash: str, defer_remote_failures: bool = False) -> dict[str, Any]:
        """Compute locally once; retries after a network fault sync local artifacts only."""
        publisher = AppendOnlyRunPublisher(storage)
        for unit in batch["units"]:
            unit_id = str(unit["execution_unit_id"]); status = state["unit_states"][unit_id]
            if status in _TERMINAL: continue
            output = self.local / "outputs" / unit_id
            metadata_path = output / "local_success.json"
            if status != LOCAL_SUCCESS_PENDING_SYNC:
                self._save(state, unit_id, RUNNING_LOCAL)
                try:
                    output.mkdir(parents=True, exist_ok=True)
                    artifacts = compute(unit, output)
                    checksums = {name: _sha(path) for name, path in artifacts.items()}
                    _write(metadata_path, {"unit_id": unit_id, "checksums": checksums})
                    self._save(state, unit_id, LOCAL_SUCCESS_PENDING_SYNC)
                except Exception as error:
                    self._save(state, unit_id, FAILED_RETRYABLE, error=f"{type(error).__name__}: {error}"); continue
            local = _read(metadata_path)
            try:
                attempt = publisher.begin(run_id=f"{batch['batch_id']}_{unit_id}", method_id=str(unit["method"]), config_hash=config_hash, code_commit=code_commit)
                publisher.stage(attempt, {name: output / name for name in local["checksums"]})
                published = publisher.publish(attempt)
                if dict(published.artifact_checksums) != {name: {"sha256": digest, "bytes": (output / name).stat().st_size} for name, digest in local["checksums"].items()}:
                    raise BatchContinuationError("Remote artifact verification differs from local checksums.")
                self._save(state, unit_id, REMOTE_SUCCESS)
            except OSError:
                self._save(state, unit_id, LOCAL_SUCCESS_PENDING_SYNC)
                if not defer_remote_failures:
                    break
            except Exception as error:
                self._save(state, unit_id, LOCAL_SUCCESS_PENDING_SYNC, error=f"sync:{type(error).__name__}: {error}")
                break
        return state

    def _validate_summary(self, summary: Mapping[str, Any], batch: Mapping[str, Any]) -> None:
        payload = {key: value for key, value in summary.items() if key != "summary_sha256"}
        if summary.get("summary_sha256") != canonical_sha256(payload):
            raise BatchContinuationError("Batch summary hash is invalid.")
        ids = list(summary.get("unit_ids", []))
        if ids != list(batch["unit_ids"]) or len(set(ids)) != len(ids):
            raise BatchContinuationError("Batch summary unit IDs differ from the batch manifest.")
        if summary.get("successful_unit_count") != summary.get("expected_unit_count") or summary.get("failed_unit_count") != 0:
            raise BatchContinuationError("Batch summary counts are not sealed-success counts.")
        if summary.get("inference_unit_count") != 0 or summary.get("status") != "SEALED_SUCCESS":
            raise BatchContinuationError("Batch summary has an invalid task scope or status.")
        hashes = summary.get("output_hashes", {})
        if set(hashes) != set(ids) or any(not value for value in hashes.values()):
            raise BatchContinuationError("Batch summary output hashes are incomplete.")

    def seal(self, *, batch: Mapping[str, Any], state: dict[str, Any], continuation_run_id: str, code_commit: str, fingerprint: Mapping[str, Any]) -> dict[str, Any]:
        if any(value != REMOTE_SUCCESS for value in state["unit_states"].values()):
            raise BatchContinuationError("Batch cannot be sealed before every unit has REMOTE_SUCCESS.")
        output_hashes = {}
        for unit_id in batch["unit_ids"]:
            local_success = _read(self.local / "outputs" / unit_id / "local_success.json")
            output_hashes[unit_id] = canonical_sha256(local_success["checksums"])
        summary = {"continuation_run_id": continuation_run_id, "batch_id": batch["batch_id"], "batch_manifest_sha256": batch["batch_manifest_sha256"], "code_commit": code_commit, "computational_fingerprint": dict(fingerprint), "expected_unit_count": len(batch["unit_ids"]), "successful_unit_count": len(batch["unit_ids"]), "failed_unit_count": 0, "unit_ids": list(batch["unit_ids"]), "output_hashes": output_hashes, "inference_unit_count": 0, "status": "SEALED_SUCCESS"}
        summary["summary_sha256"] = canonical_sha256(summary); self._validate_summary(summary, batch)
        local_summary = self.local / f"{batch['batch_id']}_summary.json"; _write(local_summary, summary)
        self.remote.mkdir(parents=True, exist_ok=True)
        remote_summary = self.remote / f"{batch['batch_id']}_summary.json"
        if remote_summary.exists(): raise BatchContinuationError("Remote batch summary already exists.")
        temporary = self.remote / f".{batch['batch_id']}_summary.json.tmp"
        if temporary.exists(): raise BatchContinuationError("Remote batch summary staging file already exists.")
        _write(temporary, summary)
        if _sha(temporary) != _sha(local_summary): raise BatchContinuationError("Remote summary staging hash differs from local summary.")
        os.replace(temporary, remote_summary)
        remote_value = _read(remote_summary); self._validate_summary(remote_value, batch)
        if _sha(remote_summary) != _sha(local_summary): raise BatchContinuationError("Remote summary hash differs after publish.")
        state["sealed"] = True; _write(self.state_path, state); return summary
