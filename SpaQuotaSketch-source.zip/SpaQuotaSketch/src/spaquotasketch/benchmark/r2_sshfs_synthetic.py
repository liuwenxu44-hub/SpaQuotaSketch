"""Small synthetic end-to-end validation for the new SSHFS-safe R2 executor."""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any, Mapping

import anndata as ad
import numpy as np
import pandas as pd
import yaml

from ..result_storage import OperationAudit, SSHFSAppendOnlyBackend, StorageConfig, sha256_file
from .r2_sshfs_executor import (
    build_execution_context,
    build_execution_plan,
    execute_plan,
    execution_config_hash,
)


class R2SshfsSyntheticValidationError(AssertionError):
    """Raised when a required end-to-end persistence contract is violated."""


@dataclass
class _FaultSequence:
    """Inject exactly one copy failure and one final-success event failure."""

    copy_failed: bool = False
    success_event_failed: bool = False

    def __call__(self, operation: str) -> None:
        if operation == "copy" and not self.copy_failed:
            self.copy_failed = True
            raise OSError("synthetic publish interruption")
        if operation == "event:SUCCESS" and not self.success_event_failed:
            self.success_event_failed = True
            raise OSError("synthetic success-event interruption")


@dataclass
class _ConflictOnce:
    """Create one nonmatching remote target before a normal append-only copy."""

    target_run_id: str
    injected: bool = False

    def __call__(self, _source: Path, destination: Path) -> None:
        if self.injected or self.target_run_id not in destination.parts:
            return
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("xb") as handle:
            handle.write(b"synthetic nonmatching remote target\n")
        self.injected = True


def load_validation_config(path: str | Path) -> dict[str, Any]:
    value = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Validation configuration must be a mapping: {path}")
    return value


def build_synthetic_adata(config: Mapping[str, Any]) -> ad.AnnData:
    """Create a fixed small population with one rare spatial stratum.

    A one-dimensional expression gradient places the rare spatial cell inside
    an ordinary expression stratum. Across three fixed outer seeds, the
    validation therefore covers both ordinary candidate pools and the
    registered within-stratum completion path.
    """

    details = config["synthetic_population"]
    n_cells = int(details["n_cells"])
    n_genes = int(details["n_genes"])
    n_x, n_y = (int(value) for value in details["spatial_grid"])
    rare_size = int(details["rare_spatial_stratum_size"])
    if n_cells != 480 or rare_size != 1 or (n_x, n_y) != (4, 3):
        raise ValueError("The tracked validation plan fixes the 480-cell 4-by-3 synthetic population.")
    n_strata = n_x * n_y
    common_counts = [43 + int(index < (n_cells - rare_size) % (n_strata - 1)) for index in range(n_strata - 1)]
    if sum(common_counts) + rare_size != n_cells:
        raise AssertionError("Synthetic spatial stratum sizes do not sum to the planned population.")
    coordinates: list[tuple[float, float]] = []
    labels: list[str] = []
    groups: list[str] = []
    for index, count in enumerate(common_counts):
        x_index = index % n_x
        y_index = index // n_x
        for offset in range(count):
            jitter = (offset + 1) / (count + 2)
            coordinates.append((x_index + 0.15 + 0.60 * jitter, y_index + 0.15 + 0.60 * jitter))
            labels.append(f"synthetic_cell_{len(labels):04d}")
            groups.append("common_a" if index % 2 == 0 else "common_b")
    # Put the rare cell in the last grid cell, while retaining the same
    # expression vector as every other cell.
    coordinates.append((n_x - 0.2, n_y - 0.2))
    labels.append(f"synthetic_cell_{len(labels):04d}")
    groups.append("rare_spatial")
    expression_signal = np.linspace(0.0, 1.0, n_cells, dtype=float)
    expression_signal[-1] = 0.50
    gene_loading = np.linspace(0.05, 1.0, n_genes, dtype=float)
    matrix = 1.0 + np.outer(expression_signal, gene_loading)
    adata = ad.AnnData(
        X=matrix,
        obs=pd.DataFrame({"cell_group": groups}, index=labels),
    )
    adata.obsm["spatial"] = np.asarray(coordinates, dtype=float)
    return adata


def _verify_remote_matches_local(backend: SSHFSAppendOnlyBackend) -> None:
    state = backend.replay_events()
    for run_id, record in state.items():
        if record.get("status") != "SUCCESS":
            raise R2SshfsSyntheticValidationError(f"Final state is not SUCCESS for {run_id}")
        attempt_directory = Path(str(record["run_directory"]))
        valid, marker = backend.valid_success_marker(attempt_directory)
        if not valid or marker is None:
            raise R2SshfsSyntheticValidationError(f"Missing valid success marker for {run_id}")
        local_directory = Path(str(marker["source_local_staging_path"]))
        for relative, expected in marker["file_checksums"].items():
            local_file = local_directory / relative
            remote_file = attempt_directory / relative
            if not local_file.is_file() or not remote_file.is_file():
                raise R2SshfsSyntheticValidationError(f"Missing paired artifact for {run_id}: {relative}")
            if sha256_file(local_file) != expected["sha256"] or sha256_file(remote_file) != expected["sha256"]:
                raise R2SshfsSyntheticValidationError(f"Local/remote checksum mismatch for {run_id}: {relative}")


def _verify_method_semantics(backend: SSHFSAppendOnlyBackend) -> dict[str, int]:
    state = backend.replay_events()
    completion_counts: list[int] = []
    probability_methods = {"uniform_srs", "spatial_stratified_srs", "spatial_pivotal"}
    for record in state.values():
        attempt = Path(str(record["run_directory"]))
        metadata = json.loads((attempt / "method_metadata.json").read_text(encoding="utf-8"))
        selected = pd.read_csv(attempt / "selected_cells.csv")
        method_id = str(metadata["method_id"])
        if method_id in probability_methods:
            if not {"inclusion_probability", "sampling_weight"}.issubset(selected.columns):
                raise R2SshfsSyntheticValidationError(f"Probability output is incomplete for {method_id}")
            if not np.allclose(
                selected["sampling_weight"].to_numpy(dtype=float),
                1.0 / selected["inclusion_probability"].to_numpy(dtype=float),
                rtol=0,
                atol=1e-12,
            ):
                raise R2SshfsSyntheticValidationError(f"Probability weight identity failed for {method_id}")
        elif method_id == "quota_completed_representation_mode":
            if "sampling_weight" in selected.columns:
                raise R2SshfsSyntheticValidationError("Representation mode emitted sampling_weight")
            diagnostics = json.loads(
                (attempt / "candidate_completion_global_diagnostics.json").read_text(encoding="utf-8")
            )
            completion_counts.append(int(diagnostics["completion_cell_count"]))
        else:  # pragma: no cover - every method is frozen by the tracked plan
            raise R2SshfsSyntheticValidationError(f"Unexpected method identity: {method_id}")
    return {
        "representation_runs": len(completion_counts),
        "representation_no_completion_runs": sum(value == 0 for value in completion_counts),
        "representation_completion_runs": sum(value > 0 for value in completion_counts),
    }


def run_r2_sshfs_synthetic_validation(
    *,
    config: Mapping[str, Any],
    local_staging_root: str | Path,
    remote_results_root: str | Path,
    code_commit: str,
) -> dict[str, Any]:
    """Execute 24 synthetic units, inject four failures, and recover immutably."""

    required = int(config["synthetic_population"]["required_run_units"])
    storage_value = dict(config["storage"])
    storage_value["local_staging_root"] = str(local_staging_root)
    storage_value["remote_results_root"] = str(remote_results_root)
    storage = StorageConfig.from_mapping(storage_value)
    if storage.remote_results_root.exists():
        raise FileExistsError(f"Synthetic validation root already exists: {storage.remote_results_root}")
    adata = build_synthetic_adata(config)
    plan = build_execution_plan(config, n_cells=adata.n_obs, code_commit=code_commit)
    if len(plan) != required or plan["run_id"].duplicated().any():
        raise R2SshfsSyntheticValidationError("Synthetic execution plan is not the required unique 24-unit matrix.")
    context = build_execution_context(adata, config)
    audit = OperationAudit()
    compute_interrupt = str(plan.iloc[0]["run_id"])
    conflict_run = str(plan.iloc[3]["run_id"])
    faults = _FaultSequence()
    conflict = _ConflictOnce(target_run_id=conflict_run)
    first_backend = SSHFSAppendOnlyBackend(
        storage,
        audit=audit,
        fault_injector=faults,
        before_copy=conflict,
    )
    first = execute_plan(
        plan=plan,
        config=config,
        context=context,
        backend=first_backend,
        compute_interrupt_run_ids={compute_interrupt},
    )
    initial_state = first_backend.replay_events()
    if first["all_successful"]:
        raise R2SshfsSyntheticValidationError("Fault-injected first pass was incorrectly fully successful.")
    observed_statuses = {str(record.get("status")) for record in initial_state.values()}
    if "INTERRUPTED" not in observed_statuses or "PUBLISH_FAILED" not in observed_statuses:
        raise R2SshfsSyntheticValidationError("Required interruption and publish-failure states were not retained.")
    if not faults.copy_failed or not faults.success_event_failed or not conflict.injected:
        raise R2SshfsSyntheticValidationError("Not every required synthetic fault was injected.")

    second_backend = SSHFSAppendOnlyBackend(storage, audit=audit)
    second = execute_plan(plan=plan, config=config, context=context, backend=second_backend)
    if not second["all_successful"] or second["successful_units"] != required:
        raise R2SshfsSyntheticValidationError("Resume did not restore every planned unit to verified success.")
    _verify_remote_matches_local(second_backend)
    semantics = _verify_method_semantics(second_backend)
    if not semantics["representation_no_completion_runs"] or not semantics["representation_completion_runs"]:
        raise R2SshfsSyntheticValidationError(
            "Synthetic validation did not cover both ordinary and completion-required representation draws."
        )
    snapshot, snapshot_checksum, replayed = second_backend.rebuild_snapshot()
    if len(replayed) != required or any(record.get("status") != "SUCCESS" for record in replayed.values()):
        raise R2SshfsSyntheticValidationError("Event replay cannot reconstruct the final success manifest.")
    if audit.os_replace_calls or audit.directory_rename_calls or audit.cross_filesystem_move_calls:
        raise R2SshfsSyntheticValidationError("SSHFS validation observed a forbidden storage operation.")
    if audit.target_file_overwrite_calls:
        raise R2SshfsSyntheticValidationError("SSHFS validation observed a target overwrite.")
    return {
        "status": "PASS",
        "planned_units": int(len(plan)),
        "successful_units": int(second["successful_units"]),
        "config_hash": execution_config_hash(config),
        "code_commit": str(code_commit),
        "first_pass_records": first["records"],
        "second_pass_records": second["records"],
        "faults": {
            "compute_interruption": compute_interrupt,
            "publish_interruption": bool(faults.copy_failed),
            "event_write_failure": bool(faults.success_event_failed),
            "target_checksum_conflict": bool(conflict.injected),
        },
        "method_semantics": semantics,
        "snapshot": str(snapshot),
        "snapshot_checksum": str(snapshot_checksum),
        "operation_audit": audit.as_dict(),
        "remote_results_root": str(storage.remote_results_root),
        "local_staging_root": str(storage.local_staging_root),
    }


__all__ = [
    "R2SshfsSyntheticValidationError",
    "build_synthetic_adata",
    "load_validation_config",
    "run_r2_sshfs_synthetic_validation",
]
