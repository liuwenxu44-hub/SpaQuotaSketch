"""Public-method adapter for the four registered clean-baseline R2 methods."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

import numpy as np
import pandas as pd

from ..representation import METHOD_ID as REPRESENTATION_METHOD_ID
from ..representation import sample_quota_completed_representation
from ..samplers import (
    SamplingResult,
    sample_spatial_pivotal,
    sample_spatial_stratified_srs,
    sample_uniform_srs,
)
from ..samplers.registry import require_runnable_method


PROBABILITY_METHODS = frozenset(
    {"uniform_srs", "spatial_stratified_srs", "spatial_pivotal"}
)
FORMAL_R2_METHODS = (
    "uniform_srs",
    "spatial_stratified_srs",
    "spatial_pivotal",
    REPRESENTATION_METHOD_ID,
)


@dataclass(frozen=True)
class RegisteredMethodDraw:
    """Uniform, storage-independent output from one already-implemented method."""

    method_id: str
    selected_indices: np.ndarray
    selected_cells: pd.DataFrame
    metadata: Mapping[str, Any]
    inclusion_probability: np.ndarray | None
    sampling_weight: np.ndarray | None
    representation_result: Any | None


def _probability_selection(result: SamplingResult) -> pd.DataFrame:
    selected = np.flatnonzero(result.selected_mask)
    return pd.DataFrame(
        {
            "cell_id": result.population_cell_ids[selected].astype(str),
            "selected": True,
            "spatial_stratum": result.stratum_id[selected].astype(str),
            "spatial_stratum_size": result.stratum_size[selected].astype(int),
            "spatial_quota": result.stratum_quota[selected].astype(int),
            "inclusion_probability": result.inclusion_probability[selected].astype(float),
            "sampling_weight": result.sampling_weight[selected].astype(float),
        }
    )


def run_registered_r2_method(
    *,
    method_id: str,
    cell_ids: np.ndarray,
    coordinates: np.ndarray,
    spatial_strata: np.ndarray,
    quotas: Mapping[str, int],
    expression_embedding: np.ndarray,
    target_n: int,
    dataset_id: str,
    target_fraction: float,
    benchmark_repeat_seed: int,
) -> RegisteredMethodDraw:
    """Dispatch only to public registered method implementations."""

    require_runnable_method(method_id)
    if method_id == "uniform_srs":
        result = sample_uniform_srs(cell_ids, target_n, random_seed=benchmark_repeat_seed)
    elif method_id == "spatial_stratified_srs":
        result = sample_spatial_stratified_srs(
            cell_ids,
            spatial_strata,
            quotas,
            random_seed=benchmark_repeat_seed,
        )
    elif method_id == "spatial_pivotal":
        result = sample_spatial_pivotal(
            cell_ids,
            coordinates,
            spatial_strata,
            quotas,
            random_seed=benchmark_repeat_seed,
        )
    elif method_id == REPRESENTATION_METHOD_ID:
        representation = sample_quota_completed_representation(
            cell_ids=cell_ids.tolist(),
            expression_embedding=expression_embedding,
            spatial_strata=spatial_strata.tolist(),
            quotas=quotas,
            target_n=target_n,
            dataset_id=dataset_id,
            target_fraction=target_fraction,
            benchmark_repeat_seed=benchmark_repeat_seed,
        )
        return RegisteredMethodDraw(
            method_id=method_id,
            selected_indices=np.asarray(representation.selected_indices, dtype=int),
            selected_cells=representation.selected_cells.copy(),
            metadata=dict(representation.metadata),
            inclusion_probability=None,
            sampling_weight=None,
            representation_result=representation,
        )
    else:
        raise ValueError(f"Unsupported formal R2 method: {method_id}")

    return RegisteredMethodDraw(
        method_id=method_id,
        selected_indices=np.flatnonzero(result.selected_mask),
        selected_cells=_probability_selection(result),
        metadata=result.metadata_dict(),
        inclusion_probability=np.asarray(result.inclusion_probability, dtype=float),
        sampling_weight=np.asarray(result.sampling_weight, dtype=float),
        representation_result=None,
    )


__all__ = [
    "FORMAL_R2_METHODS",
    "PROBABILITY_METHODS",
    "RegisteredMethodDraw",
    "run_registered_r2_method",
]
