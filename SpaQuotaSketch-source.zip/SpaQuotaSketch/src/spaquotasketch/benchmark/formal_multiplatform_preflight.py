"""Read-only preflight checks for the frozen formal multi-platform plan."""

from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
from importlib import import_module
from importlib.metadata import PackageNotFoundError, version
import os
from pathlib import Path
import platform
import subprocess
import sys
import tarfile
from typing import Any, Mapping

import h5py
import yaml

from spaquotasketch.benchmark.formal_multiplatform_freeze import (
    FORMAL_METHODS,
    FreezeValidationError,
    build_execution_units,
    canonical_sha256,
    load_freeze_bundle,
    load_yaml,
    validate_freeze_bundle,
)
from spaquotasketch.samplers.registry import get_method_metadata


FREEZE_COMMIT = "f19fcd3"
FREEZE_CONFIG_PATHS = (
    "configs/formal_multiplatform_dataset_freeze.yaml",
    "configs/formal_multiplatform_input_manifest.yaml",
    "configs/formal_dataset_fraction_matrix.yaml",
    "configs/formal_dataset_endpoint_matrix.yaml",
    "configs/formal_multiplatform_seeds.yaml",
    "configs/formal_multiplatform_execution_units.yaml",
    "configs/formal_multiplatform_benchmark_v1.yaml",
    "configs/formal_multiplatform_freeze_manifest.yaml",
    "configs/final_external_dataset_status.yaml",
    "configs/final_external_input_checksums.yaml",
)

FREEZE_DOCUMENT_PATHS = (
    "manuscript/formal_multiplatform_benchmark_freeze_report.md",
    "manuscript/formal_multiplatform_benchmark_execution_plan.md",
)


def sha256_path(path: Path) -> str:
    """Hash a file incrementally so the large Visium HD input stays bounded in memory."""
    digest = sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_yaml_hash(path: Path) -> str:
    """Hash parsed YAML rather than operating-system line endings."""
    return canonical_sha256(load_yaml(path))


def frozen_git_yaml_hash(repo_root: Path, relative_path: str, commit: str = FREEZE_COMMIT) -> str:
    """Read the authoritative YAML blob from the freeze commit without changing checkout state."""
    content = subprocess.check_output(
        ["git", "show", f"{commit}:{relative_path}"], cwd=repo_root, text=True, encoding="utf-8"
    )
    payload = yaml.safe_load(content)
    if not isinstance(payload, Mapping):
        raise FreezeValidationError(f"Frozen Git blob is not a YAML mapping: {relative_path}")
    return canonical_sha256(dict(payload))


def normalize_text_newlines(data: bytes) -> bytes:
    """Make text identity checks independent of the Windows checkout newline style."""
    return data.replace(b"\r\n", b"\n").replace(b"\r", b"\n")


def frozen_git_text_hash(repo_root: Path, relative_path: str, commit: str = FREEZE_COMMIT) -> str:
    """Hash a frozen Markdown blob while ignoring only checkout newline conversion."""
    content = subprocess.check_output(["git", "show", f"{commit}:{relative_path}"], cwd=repo_root)
    return sha256(normalize_text_newlines(content)).hexdigest()


def verify_freeze_file_hashes(repo_root: Path) -> dict[str, Any]:
    """Compare every frozen authority artifact with its immutable f19fcd3 content."""
    rows = []
    for relative_path in FREEZE_CONFIG_PATHS:
        working = repo_root / relative_path
        actual = canonical_yaml_hash(working)
        expected = frozen_git_yaml_hash(repo_root, relative_path)
        rows.append(
            {
                "relative_path": relative_path,
                "artifact_kind": "yaml_configuration",
                "expected_sha256": expected,
                "actual_sha256": actual,
                "match": actual == expected,
            }
        )
    for relative_path in FREEZE_DOCUMENT_PATHS:
        working = repo_root / relative_path
        actual = sha256(normalize_text_newlines(working.read_bytes())).hexdigest()
        expected = frozen_git_text_hash(repo_root, relative_path)
        rows.append(
            {
                "relative_path": relative_path,
                "artifact_kind": "frozen_document",
                "expected_sha256": expected,
                "actual_sha256": actual,
                "match": actual == expected,
            }
        )
    if not all(row["match"] for row in rows):
        raise FreezeValidationError("HOLD_FREEZE_HASH_MISMATCH: a frozen configuration changed.")
    return {"freeze_commit": FREEZE_COMMIT, "files": rows, "all_match": True}


def collect_git_identity(repo_root: Path) -> dict[str, Any]:
    """Capture version-control identity without altering repository state."""
    def command(*parts: str) -> str:
        return subprocess.check_output(list(parts), cwd=repo_root, text=True, encoding="utf-8").strip()

    status = command("git", "status", "--porcelain")
    branch = command("git", "branch", "--show-current")
    head = command("git", "rev-parse", "HEAD")
    contains = subprocess.run(["git", "merge-base", "--is-ancestor", FREEZE_COMMIT, "HEAD"], cwd=repo_root, check=False).returncode == 0
    remotes = command("git", "remote", "-v")
    return {
        "branch": branch,
        "head": head,
        "contains_freeze_commit": contains,
        "worktree_clean": not bool(status),
        "git_status_porcelain": status.splitlines(),
        "remote_configured": bool(remotes),
        "remote_lines": remotes.splitlines(),
    }


def _input_file_rows(manifest: Mapping[str, Any], data_root: Path) -> list[dict[str, Any]]:
    rows = []
    basename_counts = Counter(Path(item["relative_path"]).name for item in manifest["files"])
    for item in manifest["files"]:
        path = data_root / item["relative_path"]
        exists = path.exists()
        regular = bool(exists and path.is_file())
        size = path.stat().st_size if regular else None
        observed_hash = sha256_path(path) if regular else None
        modified = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc).isoformat() if regular else None
        rows.append(
            {
                "relative_path": item["relative_path"],
                "sample_id": item["sample_id"],
                "dataset_id": item["dataset_id"],
                "file_role": item["file_role"],
                "exists": exists,
                "regular_file": regular,
                "actual_size_bytes": size,
                "frozen_size_bytes": item["size_bytes"],
                "size_match": bool(regular and size == item["size_bytes"]),
                "actual_sha256": observed_hash,
                "frozen_sha256": item["sha256"],
                "sha256_match": bool(regular and observed_hash == item["sha256"]),
                "mtime_utc": modified,
                "duplicate_basename": basename_counts[Path(item["relative_path"]).name] > 1,
                "path_mapping_match": regular,
                "readable": regular,
            }
        )
    return rows


def verify_input_identity(manifest: Mapping[str, Any], data_root: Path) -> dict[str, Any]:
    """Perform a read-only exact identity check of all formal input files."""
    rows = _input_file_rows(manifest, data_root)
    valid = all(row["exists"] and row["regular_file"] and row["size_match"] and row["sha256_match"] and row["path_mapping_match"] for row in rows)
    return {
        "input_root_placeholder": "${SPAQUOTASKETCH_EXTERNAL_INPUT_ROOT}",
        "formal_input_count": len(rows),
        "files_existing": sum(row["exists"] for row in rows),
        "size_matching": sum(row["size_match"] for row in rows),
        "sha256_matching": sum(row["sha256_match"] for row in rows),
        "missing_files": sum(not row["exists"] for row in rows),
        "sha256_mismatches": sum(row["exists"] and not row["sha256_match"] for row in rows),
        "identity_status": "PASS" if valid else "HOLD_INPUT_IDENTITY_MISMATCH",
        "files": rows,
    }


def _first_matching_path(paths: Mapping[str, Path], suffix: str) -> Path:
    try:
        return next(path for name, path in paths.items() if name.endswith(suffix))
    except StopIteration as error:
        raise FreezeValidationError(f"Required frozen input with suffix {suffix!r} is missing.") from error


def _inspect_10x_h5_metadata(path: Path) -> dict[str, Any]:
    """Read only 10x H5 schema and scalar dimensions, never barcodes or matrix data."""
    with h5py.File(path, "r") as handle:
        if "matrix" not in handle:
            raise FreezeValidationError(f"10x H5 lacks matrix group: {path.name}")
        matrix = handle["matrix"]
        for required in ("shape", "barcodes", "features"):
            if required not in matrix:
                raise FreezeValidationError(f"10x H5 matrix lacks {required}: {path.name}")
        shape = tuple(int(value) for value in matrix["shape"][()])
        if len(shape) != 2:
            raise FreezeValidationError(f"10x H5 shape is not two-dimensional: {path.name}")
        barcode_count = int(matrix["barcodes"].shape[0])
        feature_group = matrix["features"]
        feature_key = "id" if "id" in feature_group else "name" if "name" in feature_group else None
        if feature_key is None:
            raise FreezeValidationError(f"10x H5 lacks feature identifier field: {path.name}")
        feature_count = int(feature_group[feature_key].shape[0])
    if barcode_count != shape[1] or feature_count != shape[0]:
        raise FreezeValidationError(f"10x H5 identifier dimensions do not match matrix shape: {path.name}")
    return {
        "expression_orientation": "features_by_units",
        "unit_field": "matrix/barcodes",
        "unit_count": shape[1],
        "gene_count": shape[0],
        "schema_index_check": "matrix.shape; matrix.barcodes.shape; matrix.features.identifier.shape",
    }


def _inspect_xenium_coordinate_schema(path: Path) -> dict[str, Any]:
    """Read only the Parquet schema; coordinate values and cell identifiers stay unread."""
    try:
        parquet = import_module("pyarrow.parquet")
    except ImportError as error:
        raise FreezeValidationError("pyarrow is required for the Xenium coordinate schema check.") from error
    columns = {str(column).lower(): str(column) for column in parquet.ParquetFile(path).schema_arrow.names}
    id_column = next((columns[key] for key in ("cell_id", "cellid", "barcode", "cell", "id") if key in columns), None)
    x_column = next((columns[key] for key in ("x_centroid", "x_centroid_in_pixels", "x", "x_location") if key in columns), None)
    y_column = next((columns[key] for key in ("y_centroid", "y_centroid_in_pixels", "y", "y_location") if key in columns), None)
    if id_column is None or x_column is None or y_column is None:
        raise FreezeValidationError(f"Xenium Parquet coordinate schema is incomplete: {path.name}")
    return {"coordinate_fields": [x_column, y_column], "coordinate_unit_field": id_column, "coordinate_schema_read_only": True}


def _inspect_visium_coordinate_schema(path: Path) -> dict[str, Any]:
    """Read only the archive directory and first text line of the position table."""
    with tarfile.open(path, "r:gz") as archive:
        members = [member for member in archive.getmembers() if member.isfile() and "tissue_positions" in member.name.lower()]
        if len(members) != 1:
            raise FreezeValidationError(f"Expected exactly one tissue-position table: {path.name}")
        raw = archive.extractfile(members[0])
        if raw is None:
            raise FreezeValidationError(f"Could not read tissue-position header: {path.name}")
        first_line = raw.readline(8192).decode("utf-8").strip()
    header = [value.strip() for value in first_line.split(",")]
    lowered = {value.lower(): value for value in header}
    if "barcode" in lowered or "pxl_row_in_fullres" in lowered:
        x_column = lowered.get("pxl_col_in_fullres", lowered.get("array_col"))
        y_column = lowered.get("pxl_row_in_fullres", lowered.get("array_row"))
        if x_column is None or y_column is None:
            raise FreezeValidationError(f"Visium tissue-position header lacks coordinate fields: {path.name}")
        return {
            "coordinate_fields": [x_column, y_column],
            "coordinate_unit_field": lowered.get("barcode", "column_0"),
            "coordinate_schema_read_only": True,
        }
    # The published legacy headerless layout has barcode, in-tissue, array row,
    # array column, pixel row, pixel column in this exact order.
    if len(header) < 6:
        raise FreezeValidationError(f"Headerless Visium tissue-position row is too narrow: {path.name}")
    return {
        "coordinate_fields": ["column_5", "column_4"],
        "coordinate_unit_field": "column_0",
        "coordinate_schema_read_only": True,
    }


def _inspect_visium_hd_metadata(path: Path) -> dict[str, Any]:
    """Read only Visium HD group names and dataset shapes, never feature slices."""
    with h5py.File(path, "r") as handle:
        mask_path = "masks/square_016um"
        if mask_path not in handle or "features" not in handle or "feature_slices" not in handle:
            raise FreezeValidationError(f"Visium HD feature-slice schema is incomplete: {path.name}")
        mask = handle[mask_path]
        if "row" not in mask or "col" not in mask or "id" not in handle["features"]:
            raise FreezeValidationError(f"Visium HD coordinate or feature index is incomplete: {path.name}")
        row_count = int(mask["row"].shape[0])
        column_count = int(mask["col"].shape[0])
        gene_count = int(handle["features"]["id"].shape[0])
    if row_count != column_count:
        raise FreezeValidationError(f"Visium HD row/column index lengths differ: {path.name}")
    return {
        "expression_orientation": "feature_slices_by_embedded_bins",
        "unit_field": "published_row:column",
        "coordinate_fields": ["published_col", "published_row"],
        "unit_count": row_count,
        "gene_count": gene_count,
        "schema_index_check": "masks/square_016um.row.shape; masks/square_016um.col.shape; features/id.shape",
    }


def _smoke_one(dataset: Mapping[str, Any], manifest_files: list[Mapping[str, Any]], data_root: Path) -> dict[str, Any]:
    paths = {Path(item["relative_path"]).name: data_root / item["relative_path"] for item in manifest_files}
    adapter = dataset["adapter_id"]
    if adapter == "visium_hd_feature_slice":
        return _inspect_visium_hd_metadata(_first_matching_path(paths, ".h5"))
    if adapter == "xenium_h5_parquet":
        expression = _inspect_10x_h5_metadata(_first_matching_path(paths, ".h5"))
        return {**expression, **_inspect_xenium_coordinate_schema(_first_matching_path(paths, "cells.parquet"))}
    if adapter == "visium_h5_spatial_tar":
        expression = _inspect_10x_h5_metadata(_first_matching_path(paths, ".h5"))
        return {**expression, **_inspect_visium_coordinate_schema(_first_matching_path(paths, ".tar.gz"))}
    raise FreezeValidationError(f"Unsupported frozen adapter: {adapter}")


def adapter_smoke_tests(dataset_freeze: Mapping[str, Any], manifest: Mapping[str, Any], data_root: Path) -> list[dict[str, Any]]:
    """Read only schemas, shape metadata, identifier fields, and coordinate fields."""
    rows = []
    for dataset in dataset_freeze["datasets"]:
        files = [item for item in manifest["files"] if item["dataset_id"] == dataset["dataset_id"]]
        try:
            details = _smoke_one(dataset, files, data_root)
            status, reason = "PASS", "metadata_and_schema_read_only"
        except Exception as error:  # preserved as a preflight diagnostic, never repaired here
            details = {}
            status, reason = "HOLD", f"{type(error).__name__}: {error}"
        rows.append(
            {
                "dataset_id": dataset["dataset_id"],
                "sample_ids": dataset["frozen_sample_ids"],
                "adapter_id": dataset["adapter_id"],
                "import_success": True,
                "schema_match": status == "PASS",
                "panel_or_wts": dataset["endpoint_stratum"],
                "smoke_test_status": status,
                "reason": reason,
                **details,
            }
        )
    return rows


def method_registry_snapshot(bundle: Mapping[str, Any]) -> dict[str, Any]:
    """Confirm the formal method identities and their task boundaries."""
    methods = []
    for method_id in FORMAL_METHODS:
        metadata = get_method_metadata(method_id).values
        methods.append(
            {
                "registry_id": method_id,
                "implementation_module": metadata.get("implementation_entrypoint", f"spaquotasketch.framework:{method_id}"),
                "legacy_status": metadata["legacy_status"],
                "supported_modes": metadata["supported_modes"],
                "probability_design": metadata["probability_design"],
                "inclusion_probability_available": bool(metadata["has_positive_inclusion_probability"]),
                "sampling_weight_allowed": bool(metadata["returns_sampling_weight"]),
            }
        )
    expected = [item["registry_id"] for item in bundle["benchmark"]["methods"]]
    valid = expected == list(FORMAL_METHODS) and all(item["legacy_status"] == "current" for item in methods)
    return {"methods": methods, "registry_ids_match_freeze": valid, "status": "PASS" if valid else "HOLD_METHOD_REGISTRY_DRIFT"}


def execution_unit_drift(bundle: Mapping[str, Any]) -> dict[str, Any]:
    """Regenerate units twice and require byte-for-byte semantic equality."""
    regenerated_a = build_execution_units(
        bundle["dataset_freeze"]["datasets"], bundle["fraction_matrix"]["rows"], bundle["endpoint_matrix"]["rows"], bundle["seeds"]["seeds"], bundle["input_manifest"]["formal_input_manifest_sha256"]
    )
    regenerated_b = build_execution_units(
        bundle["dataset_freeze"]["datasets"], bundle["fraction_matrix"]["rows"], bundle["endpoint_matrix"]["rows"], bundle["seeds"]["seeds"], bundle["input_manifest"]["formal_input_manifest_sha256"]
    )
    frozen = bundle["execution_units"]["units"]
    return {"representation_execution_units": sum(row["task"] == "representation" for row in frozen), "inference_execution_units": sum(row["task"] == "inference" for row in frozen), "total_execution_units": len(frozen), "two_regenerations_identical": regenerated_a == regenerated_b, "matches_frozen_manifest": regenerated_a == frozen, "status": "PASS" if regenerated_a == regenerated_b == frozen else "HOLD_EXECUTION_UNIT_DRIFT"}


def formal_runner_dry_run(repo_root: Path, data_root: Path) -> dict[str, Any]:
    """Exercise the formal entrypoint in its sampler-free preflight mode only."""
    runner = repo_root / "scripts" / "run_formal_multiplatform_benchmark.py"
    result = subprocess.run(
        [
            sys.executable,
            str(runner),
            "--phase",
            "preflight",
            "--config",
            "configs/formal_multiplatform_benchmark_v1.yaml",
            "--repo-root",
            str(repo_root),
            "--data-root",
            str(data_root),
            "--results-root",
            "${SERVER_NATIVE_SPAQUOTASKETCH_RESULTS_ROOT}/formal_multiplatform_benchmark_v1",
            "--dry-run",
            "--list-limit",
            "0",
        ],
        cwd=repo_root,
        text=True,
        encoding="utf-8",
        capture_output=True,
        check=False,
    )
    if result.returncode != 0:
        return {
            "status": "HOLD_PREFLIGHT_FAILURE",
            "returncode": result.returncode,
            "reason": result.stderr.strip() or result.stdout.strip(),
            "sampler_call_count": "NOT_CONFIRMED",
            "formal_result_directory_created": False,
        }
    try:
        payload = yaml.safe_load(result.stdout)
    except yaml.YAMLError as error:
        return {
            "status": "HOLD_PREFLIGHT_FAILURE",
            "returncode": result.returncode,
            "reason": f"Could not parse formal dry-run response: {error}",
            "sampler_call_count": "NOT_CONFIRMED",
            "formal_result_directory_created": False,
        }
    valid = isinstance(payload, Mapping) and payload.get("dry_run") is True and payload.get("real_sampler_run") is False and payload.get("unit_count") == 1960
    return {
        "status": "PASS" if valid else "HOLD_PREFLIGHT_FAILURE",
        "returncode": result.returncode,
        "phase": payload.get("phase") if isinstance(payload, Mapping) else None,
        "unit_count": payload.get("unit_count") if isinstance(payload, Mapping) else None,
        "listed_unit_count": payload.get("listed_unit_count") if isinstance(payload, Mapping) else None,
        "sampler_call_count": 0 if valid else "NOT_CONFIRMED",
        "real_sampler_run": payload.get("real_sampler_run") if isinstance(payload, Mapping) else None,
        "formal_result_directory_created": False,
    }


def determine_preflight_decision(
    freeze: Mapping[str, Any],
    inputs: Mapping[str, Any] | None,
    methods: Mapping[str, Any] | None,
    execution: Mapping[str, Any] | None,
    smoke: list[Mapping[str, Any]] | None,
    dry_run: Mapping[str, Any] | None,
    environment: Mapping[str, Any] | None,
) -> str:
    """Return only a registered preflight decision; never infer missing environment facts."""
    if not freeze.get("all_match", False):
        return "HOLD_FREEZE_HASH_MISMATCH"
    if inputs is None or inputs.get("identity_status") != "PASS":
        return "HOLD_INPUT_IDENTITY_MISMATCH"
    if methods is None or methods.get("status") != "PASS":
        return "HOLD_METHOD_REGISTRY_DRIFT"
    if execution is None or execution.get("status") != "PASS":
        return "HOLD_EXECUTION_UNIT_DRIFT"
    if smoke is None or any(row["smoke_test_status"] != "PASS" for row in smoke):
        return "HOLD_PREFLIGHT_FAILURE"
    if dry_run is None or dry_run.get("status") != "PASS":
        return "HOLD_PREFLIGHT_FAILURE"
    if environment is None or not environment.get("server_native_results_root_confirmed", False):
        return "HOLD_ENVIRONMENT_CONFIGURATION"
    return "READY_FOR_FORMAL_BENCHMARK_CANARY"


def select_canary_units(units: list[Mapping[str, Any]]) -> dict[str, Any]:
    """Select a deterministic engineering-only set covering tasks and platform paradigms."""
    requirements = (
        ("large_representation", "large_memory", "representation"),
        ("large_inference", "large_memory", "inference"),
        ("small_targeted_representation", "standard", "representation"),
        ("small_targeted_inference", "standard", "inference"),
        ("spot_representation", None, "representation"),
        ("spot_inference", None, "inference"),
    )
    selected = []
    for label, resource, task in requirements:
        options = [row for row in units if row["task"] == task and (resource is None or row["resource_class"] == resource)]
        if label.startswith("small_targeted"):
            options = [row for row in options if row["platform"] in {"Xenium", "Xenium_Prime"}]
        if label.startswith("spot_"):
            options = [row for row in options if row["platform"] == "Visium"]
        if not options:
            raise FreezeValidationError(f"No deterministic canary option for {label}.")
        selected.append({"selection_role": label, "execution_unit_id": sorted(options, key=lambda row: row["execution_unit_id"])[0]["execution_unit_id"]})
    return {"schema_version": 1, "purpose": "engineering_only_not_for_scientific_summary", "selection_rule": "lexicographically_smallest_eligible_frozen_execution_unit_for_each_predeclared_coverage_role", "units": selected, "canary_count": len(selected), "deterministic": True, "excluded_from_formal_summary": True}


def environment_manifest(data_root: Path) -> dict[str, Any]:
    """Record only portable local facts; native server result storage stays unconfirmed."""
    dependencies = {}
    distributions = {"yaml": "PyYAML"}
    for name in ("numpy", "pandas", "scipy", "anndata", "scanpy", "h5py", "pyarrow", "yaml"):
        try:
            import_module(name)
            dependencies[name] = version(distributions.get(name, name))
        except (ImportError, PackageNotFoundError):
            dependencies[name] = "not_available"
    return {
        "schema_version": 1,
        "operating_system": platform.platform(),
        "python_version": sys.version,
        "spaquotasketch_import_path": "runtime_path_verified_locally_not_committed",
        "virtual_environment_active": sys.prefix != sys.base_prefix,
        "cpu_logical_cores": os.cpu_count(),
        "available_memory_bytes": "NOT_RECORDED_WITHOUT_A_PORTABLE_MEMORY_PROVIDER",
        "data_root_readable": data_root.is_dir() and os.access(data_root, os.R_OK),
        "results_root_placeholder": "${SERVER_NATIVE_SPAQUOTASKETCH_RESULTS_ROOT}/formal_multiplatform_benchmark_v1",
        "windows_results_root_placeholder": "${SPAQUOTASKETCH_WINDOWS_RESULTS_ROOT}/formal_multiplatform_benchmark_v1",
        "formal_result_directory_name": "formal_multiplatform_benchmark_v1",
        "results_storage_policy": "server_native_filesystem_required_for_formal_high_frequency_writes",
        "append_only_capability": "NOT_CONFIRMED_NO_NATIVE_SERVER_PATH",
        "attempt_directory_policy": "immutable_attempt_directories_required_before_formal_execution",
        "resume_policy": "successful_units_must_not_be_overwritten; failed_units_require_a_new_attempt_directory",
        "server_native_results_root_confirmed": False,
        "server_results_directory_writable": "NOT_CHECKED_NO_NATIVE_SERVER_PATH",
        "available_disk_space_bytes": "NOT_CHECKED_NO_NATIVE_SERVER_PATH",
        "temporary_directory_strategy": "local_runtime_tmp_configured_outside_repository; formal results remain server-native.",
        "multiprocessing_start_method": "spawn_on_windows",
        "thread_environment_recommendation": {"OMP_NUM_THREADS": 1, "MKL_NUM_THREADS": 1, "OPENBLAS_NUM_THREADS": 1},
        "dependencies": dependencies,
    }


def resource_plan(bundle: Mapping[str, Any]) -> dict[str, Any]:
    """Estimate conservative execution concurrency from frozen input sizes only."""
    files = bundle["input_manifest"]["files"]
    total_by_dataset: dict[str, int] = {}
    for item in files:
        total_by_dataset[item["dataset_id"]] = total_by_dataset.get(item["dataset_id"], 0) + int(item["size_bytes"])
    classified = {dataset: ("large" if size >= 1_000_000_000 else "medium" if size >= 64_000_000 else "small") for dataset, size in total_by_dataset.items()}
    total_input_bytes = sum(total_by_dataset.values())
    class_counts = {name: sum(value == name for value in classified.values()) for name in ("small", "medium", "large")}
    return {
        "schema_version": 1,
        "classification_rule": "large_at_least_1GB; medium_at_least_64MB; otherwise_small_by_frozen_input_bytes",
        "dataset_resource_class": classified,
        "resource_class_counts": class_counts,
        "total_frozen_input_bytes": total_input_bytes,
        "input_staging_lower_bound_bytes": 3 * total_input_bytes,
        "estimated_result_bytes": "NOT_ESTIMABLE_WITHOUT_ENGINEERING_CANARY",
        "estimated_cache_bytes": "NOT_ESTIMABLE_WITHOUT_ENGINEERING_CANARY",
        "representation_recommended_concurrency": 1,
        "inference_recommended_concurrency": 2,
        "threads_per_process": 1,
        "single_dataset_concurrency_limit": 1,
        "single_sample_concurrency_limit": 1,
        "concurrency_rationale": "Avoid duplicate loading of one expression matrix; start small, then medium, then large.",
        "recommended_minimum_free_space": "input_staging_lower_bound_bytes_plus_expected_output_and_cache; verify on server before authorization",
        "server_space_confirmed": False,
    }
