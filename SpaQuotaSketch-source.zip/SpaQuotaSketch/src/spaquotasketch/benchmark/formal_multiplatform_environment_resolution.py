"""Audit sanitized server evidence without storing a private server path."""

from __future__ import annotations

from pathlib import Path
import re
from typing import Any, Mapping

from .formal_multiplatform_freeze import FreezeValidationError, load_yaml


RUNTIME_PATHS = {
    "project_root_runtime_expression": "$HOME/SpaQuotaSketch",
    "data_root_runtime_expression": "$HOME/SpaQuotaSketch/data/external_inputs",
    "results_root_runtime_expression": "$HOME/SpaQuotaSketch/results",
    "formal_benchmark_root_runtime_expression": "$HOME/SpaQuotaSketch/results/formal_multiplatform_benchmark_v1",
    "temporary_root_runtime_expression": "$HOME/SpaQuotaSketch/results/tmp",
}
MINIMUM_INODE_RESERVE = 196_000
RECOMMENDED_CAPACITY_BYTES = 128 * 1024**3


class ServerEnvironmentEvidenceError(FreezeValidationError):
    """Raised when manually supplied server facts are incomplete or unsafe."""


def _require(mapping: Mapping[str, Any], key: str) -> Any:
    if key not in mapping:
        raise ServerEnvironmentEvidenceError(f"Server evidence is missing required field: {key}")
    return mapping[key]


def validate_runtime_path_expressions(evidence: Mapping[str, Any]) -> None:
    """Require public shell expressions and reject Windows or private Linux paths."""
    for key, expected in RUNTIME_PATHS.items():
        value = str(_require(evidence, key))
        if value != expected:
            raise ServerEnvironmentEvidenceError(f"Unexpected runtime path expression for {key}")
        if "\\" in value or ":" in value or value.startswith("~") or "'~'" in value or '"~"' in value:
            raise ServerEnvironmentEvidenceError(f"Runtime path expression is not a portable server shell path: {key}")


def _capacity_assessment(evidence: Mapping[str, Any], base_resource_plan: Mapping[str, Any]) -> dict[str, Any]:
    available = int(_require(evidence, "available_bytes"))
    available_inodes = int(_require(evidence, "available_inodes"))
    minimum = int(_require(base_resource_plan, "input_staging_lower_bound_bytes"))
    minimum_pass = available >= minimum
    recommended_pass = available >= RECOMMENDED_CAPACITY_BYTES
    inode_pass = available_inodes >= MINIMUM_INODE_RESERVE and int(_require(evidence, "inode_used_percent")) < 90
    if not minimum_pass or not inode_pass:
        status = "HOLD_INSUFFICIENT_STORAGE"
    elif recommended_pass:
        status = "CAPACITY_PASS"
    else:
        status = "CAPACITY_PASS_WITH_WARNING"
    return {
        "capacity_status": status,
        "minimum_required_bytes": minimum,
        "minimum_requirement_scope": "pre_canary_input_staging_floor",
        "recommended_required_bytes": RECOMMENDED_CAPACITY_BYTES,
        "recommended_requirement_scope": "conservative_pre_canary_server_reserve_not_an_observed_output_estimate",
        "benchmark_output_estimate": "NOT_ESTIMATED_BEFORE_ENGINEERING_CANARY",
        "cache_estimate": "NOT_ESTIMATED_BEFORE_ENGINEERING_CANARY",
        "temporary_space_estimate": "NOT_ESTIMATED_BEFORE_ENGINEERING_CANARY",
        "safety_margin": "included_in_recommended_pre_canary_server_reserve",
        "available_bytes": available,
        "available_human_readable": str(_require(evidence, "available_human_readable")),
        "used_percent": int(_require(evidence, "used_percent")),
        "available_to_minimum_ratio": available / minimum,
        "available_to_recommended_ratio": available / RECOMMENDED_CAPACITY_BYTES,
        "total_inodes": int(_require(evidence, "total_inodes")),
        "available_inodes": available_inodes,
        "inode_used_percent": int(_require(evidence, "inode_used_percent")),
        "minimum_inode_reserve": MINIMUM_INODE_RESERVE,
        "inode_capacity_status": "PASS" if inode_pass else "HOLD_INSUFFICIENT_STORAGE",
        "server_space_confirmed": True,
    }


def audit_server_environment(evidence: Mapping[str, Any], base_resource_plan: Mapping[str, Any]) -> dict[str, Any]:
    """Return a sanitized, reproducible verdict from user-run server probes."""
    validate_runtime_path_expressions(evidence)
    required_true = (
        "project_root_exists",
        "data_root_exists",
        "results_root_exists",
        "results_root_readable",
        "results_root_writable",
        "results_root_traversable",
        "probe_file_created",
        "probe_file_readable",
        "probe_cleanup_success",
    )
    missing_or_false = [key for key in required_true if _require(evidence, key) is not True]
    if str(_require(evidence, "realpath_kind")) != "server_native_linux_absolute":
        missing_or_false.append("realpath_kind")
    if str(_require(evidence, "filesystem_kind")) != "server_native_filesystem":
        missing_or_false.append("filesystem_kind")
    if str(_require(evidence, "write_delete_probe")) != "PASS":
        missing_or_false.append("write_delete_probe")
    if bool(_require(evidence, "real_server_absolute_path_committed")):
        missing_or_false.append("real_server_absolute_path_committed")
    capacity = _capacity_assessment(evidence, base_resource_plan)
    if missing_or_false:
        environment_status = "HOLD_ENVIRONMENT_CONFIGURATION"
    elif capacity["capacity_status"] == "HOLD_INSUFFICIENT_STORAGE":
        environment_status = "HOLD_INSUFFICIENT_STORAGE"
    else:
        environment_status = "PASS"
    return {
        "schema_version": 1,
        "resolution_source": "user_manual_server_probe",
        **RUNTIME_PATHS,
        "server_native_results_root_status": "USER_VERIFIED" if environment_status == "PASS" else "HOLD",
        "server_native_results_root_committed": False,
        "runtime_path_source": "environment_variable_or_ignored_local_config",
        "results_root_exists": bool(evidence["results_root_exists"]),
        "results_root_readable": bool(evidence["results_root_readable"]),
        "results_root_writable": bool(evidence["results_root_writable"]),
        "results_root_traversable": bool(evidence["results_root_traversable"]),
        "realpath_is_server_native_linux_path": str(evidence["realpath_kind"]) == "server_native_linux_absolute",
        "filesystem_is_server_native": str(evidence["filesystem_kind"]) == "server_native_filesystem",
        "write_permission_verified": bool(evidence["results_root_writable"]),
        "write_delete_probe": str(evidence["write_delete_probe"]),
        "probe_cleanup_success": bool(evidence["probe_cleanup_success"]),
        "results_directory_mode_octal": str(evidence["results_directory_mode_octal"]),
        "umask_octal": str(evidence["umask_octal"]),
        "server_user_identity_verified": bool(evidence["server_user_identity_verified"]),
        "results_directory_owner_matches_server_user": bool(evidence["results_directory_owner_matches_server_user"]),
        "environment_status": environment_status,
        "unresolved_environment_fields": missing_or_false,
        "capacity": capacity,
    }


def update_resource_plan(base_resource_plan: Mapping[str, Any], environment: Mapping[str, Any]) -> dict[str, Any]:
    """Keep frozen resource classes while appending a transparent capacity verdict."""
    updated = dict(base_resource_plan)
    capacity = dict(environment["capacity"])
    capacity["user_manual_probe"] = True
    updated["server_capacity_assessment"] = capacity
    updated["server_space_confirmed"] = bool(capacity["server_space_confirmed"])
    updated["minimum_required_bytes"] = int(capacity["minimum_required_bytes"])
    updated["recommended_required_bytes"] = int(capacity["recommended_required_bytes"])
    updated["recommended_minimum_free_space"] = (
        "recommended_required_bytes_from_server_capacity_assessment; "
        "full_benchmark_output_and_cache_sizes_remain_unmeasured_before_engineering_canary"
    )
    return updated


def canary_coverage(bundle: Mapping[str, Any], canary: Mapping[str, Any]) -> dict[str, Any]:
    """Verify the frozen engineering units without selecting replacements."""
    by_id = {str(unit["execution_unit_id"]): unit for unit in bundle["execution_units"]["units"]}
    selected = [by_id.get(str(row["execution_unit_id"])) for row in canary["units"]]
    if any(unit is None for unit in selected):
        raise ServerEnvironmentEvidenceError("A frozen canary unit is not in the formal execution manifest.")
    units = [unit for unit in selected if unit is not None]
    dataset_by_id = {str(item["dataset_id"]): item for item in bundle["dataset_freeze"]["datasets"]}
    endpoint_strata = {str(dataset_by_id[str(unit["dataset_id"])]["endpoint_stratum"]) for unit in units}
    platform_families = {str(dataset_by_id[str(unit["dataset_id"])]["platform_family"]) for unit in units}
    exact_platforms = {str(unit["platform"]) for unit in units}
    all_exact_platforms = {str(dataset["platform"]) for dataset in bundle["dataset_freeze"]["datasets"]}
    return {
        "canary_count": len(units),
        "unit_ids_unchanged": True,
        "all_units_in_frozen_execution_manifest": True,
        "deterministic": bool(canary["deterministic"]),
        "excluded_from_formal_summary": bool(canary["excluded_from_formal_summary"]),
        "tasks_covered": sorted({str(unit["task"]) for unit in units}),
        "endpoint_strata_covered": sorted(endpoint_strata),
        "platform_families_covered": sorted(platform_families),
        "exact_platforms_covered": sorted(exact_platforms),
        "exact_platforms_not_directly_covered": sorted(all_exact_platforms - exact_platforms),
        "resource_classes_covered": sorted({str(unit["resource_class"]) for unit in units}),
        "coverage_status": "PASS_ADAPTER_FAMILY_COVERAGE",
    }


def formal_runner_can_execute_canary(repo_root: str | Path) -> bool:
    """Detect the intentionally frozen runner guard without invoking it."""
    source = (Path(repo_root) / "scripts" / "run_formal_multiplatform_benchmark.py").read_text(encoding="utf-8")
    return '"canary"' in source and "Real benchmark execution is disabled during the freeze phase" not in source


def private_path_free(payload: Mapping[str, Any]) -> bool:
    """Protect committed records from Windows mounts and private Linux paths."""
    serialized = str(payload)
    if "Z:\\" in serialized or "C:\\" in serialized:
        return False
    return re.search(r"(?<![A-Za-z0-9_$])/(?:data|home)/", serialized) is None


def load_server_evidence(repo_root: str | Path) -> dict[str, Any]:
    return load_yaml(Path(repo_root) / "configs/formal_multiplatform_server_environment_evidence.yaml")
