"""Controlled runner for the frozen formal Representation benchmark.

The runner resolves its 1,120 units solely from the frozen execution-unit
manifest.  It has no Inference path and shares neither attempts nor success
records with the engineering canary.  Results are published with the existing
SSHFS-safe append-only backend under the dedicated ``representation`` child.
"""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import time
import tracemalloc
import traceback
from typing import Any, Callable, Mapping, Sequence

import numpy as np
from scipy import sparse

from ..result_persistence import AppendOnlyRunPublisher
from ..result_storage import (
    ChecksumMismatchError,
    ImmutableWriteError,
    PublishError,
    SSHFSAppendOnlyBackend,
    StorageConfig,
)
from .formal_multiplatform_canary_runner import (
    _draw_prepared_real_unit,
    _synthetic_raw_population,
    _validate_canary_input,
    current_git_commit,
    prepare_frozen_canary_unit_input,
    synthetic_canary_input,
    validate_unit_method_capability,
)
from .formal_multiplatform_canary_runner import load_canary_runner_config
from .formal_multiplatform_freeze import (
    FreezeValidationError,
    canonical_sha256,
    load_freeze_bundle,
    load_yaml,
    validate_freeze_bundle,
    verify_frozen_input_files,
)
from .formal_multiplatform_representation_authorization import (
    REPRESENTATION_DIRECTORY,
    REPRESENTATION_UNIT_COUNT,
    RepresentationAuthorization,
    RepresentationAuthorizationError,
    validate_representation_authorization,
)
from .formal_preprocessing import load_formal_preprocessing_config, prepare_representation_input


FORMAL_REPRESENTATION_BASE_COMMIT = "36ef422"
REPRESENTATION_STATUSES = frozenset(
    {
        "PENDING",
        "RUNNING",
        "SUCCESS",
        "FAILURE",
        "INCOMPLETE",
        "SKIPPED_ALREADY_SUCCESS",
        "BLOCKED_PREFLIGHT",
        "BLOCKED_HASH_MISMATCH",
        "BLOCKED_RESULT_ISOLATION",
    }
)


class FormalRepresentationRunnerError(RuntimeError):
    """Base error for a formal Representation execution failure."""


class FormalRepresentationManifestDriftError(FormalRepresentationRunnerError):
    """A frozen formal artifact no longer matches the authorized run scope."""


class FormalRepresentationPreflightError(FormalRepresentationRunnerError):
    """A required gate failed before a formal attempt or sampler call."""


class FormalRepresentationResultIsolationError(FormalRepresentationRunnerError):
    """A formal Representation run would cross into another result namespace."""


@dataclass(frozen=True)
class FormalRepresentationRunManifest:
    """Immutable identity fields recorded with every formal Representation attempt."""

    execution_unit_manifest_sha256: str
    execution_unit_ids_sha256: str
    benchmark_config_sha256: str
    freeze_manifest_sha256: str
    preprocessing_config_sha256: str
    input_manifest_sha256: str
    seed_manifest_sha256: str
    authorization_sha256: str
    formal_execution_unit_count: int
    representation_execution_unit_count: int

    def as_dict(self) -> dict[str, Any]:
        return dict(self.__dict__)


def _canonical_json(value: Any) -> bytes:
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":")) + "\n").encode("utf-8")


def _git_text(repo_root: Path, arguments: Sequence[str]) -> str:
    return subprocess.check_output(["git", *arguments], cwd=repo_root, text=True, encoding="utf-8").strip()


def _assert_base_commit(repo_root: Path) -> None:
    completed = subprocess.run(
        ["git", "merge-base", "--is-ancestor", FORMAL_REPRESENTATION_BASE_COMMIT, "HEAD"],
        cwd=repo_root,
        check=False,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    if completed.returncode != 0:
        raise FormalRepresentationManifestDriftError(
            "The current execution commit is not traceable to the approved canary checkpoint."
        )


def _assert_clean_worktree(repo_root: Path) -> None:
    if _git_text(repo_root, ["status", "--porcelain"]):
        raise FormalRepresentationPreflightError("Formal real execution requires a clean Git worktree.")


def frozen_representation_units(
    repo_root: str | Path,
    bundle: Mapping[str, Any] | None = None,
) -> tuple[list[dict[str, Any]], FormalRepresentationRunManifest]:
    """Resolve exactly the frozen 1,120 Representation units without reselection."""

    root = Path(repo_root)
    bundle = dict(bundle or load_freeze_bundle(root))
    validate_freeze_bundle(bundle)
    declared_counts = dict(bundle["execution_units"].get("counts") or {})
    all_units = list(bundle["execution_units"]["units"])
    if len(all_units) != 1960 or int(declared_counts.get("total_execution_units", -1)) != 1960:
        raise FormalRepresentationManifestDriftError("Frozen formal execution-unit count is not 1,960.")
    units = [dict(unit) for unit in all_units if str(unit.get("task")) == "representation"]
    if len(units) != REPRESENTATION_UNIT_COUNT or int(declared_counts.get("representation_execution_units", -1)) != REPRESENTATION_UNIT_COUNT:
        raise FormalRepresentationManifestDriftError("Frozen Representation execution-unit count is not 1,120.")
    if int(declared_counts.get("inference_execution_units", -1)) != 840:
        raise FormalRepresentationManifestDriftError("Frozen Inference execution-unit count is not 840.")
    if len({str(unit["execution_unit_id"]) for unit in units}) != REPRESENTATION_UNIT_COUNT:
        raise FormalRepresentationManifestDriftError("Frozen Representation execution-unit identifiers are not unique.")
    if any(str(unit["task"]) != "representation" for unit in units):
        raise FormalRepresentationManifestDriftError("An Inference unit entered the Representation runner.")
    for unit in units:
        validate_unit_method_capability(unit, bundle["benchmark"])
    units.sort(key=lambda unit: str(unit["execution_unit_id"]))
    preprocessing = load_formal_preprocessing_config(root)
    manifest = FormalRepresentationRunManifest(
        execution_unit_manifest_sha256=canonical_sha256(bundle["execution_units"]),
        execution_unit_ids_sha256=canonical_sha256([str(unit["execution_unit_id"]) for unit in units]),
        benchmark_config_sha256=str(bundle["benchmark"]["benchmark_config_sha256"]),
        freeze_manifest_sha256=str(bundle["freeze_manifest"]["freeze_manifest_sha256"]),
        preprocessing_config_sha256=canonical_sha256(preprocessing),
        input_manifest_sha256=str(bundle["input_manifest"]["formal_input_manifest_sha256"]),
        seed_manifest_sha256=str(bundle["seeds"]["seed_manifest_sha256"]),
        authorization_sha256="",
        formal_execution_unit_count=1960,
        representation_execution_unit_count=REPRESENTATION_UNIT_COUNT,
    )
    return units, manifest


def _read_canary_status(repo_root: Path) -> Mapping[str, Any]:
    status = load_yaml(repo_root / "configs/formal_multiplatform_canary_execution_status.yaml")
    required = {
        "status": "READY_FOR_FORMAL_REPRESENTATION_BENCHMARK",
        "first_real_run_success_count": 6,
        "resume_sampler_calls": 0,
        "result_isolation_verified_by_execution": True,
    }
    for field, expected in required.items():
        if status.get(field) != expected:
            raise FormalRepresentationPreflightError(f"Canary completion gate failed: {field} is not {expected!r}.")
    return status


def verify_formal_representation_preflight(
    *,
    repo_root: str | Path,
    authorization: RepresentationAuthorization,
    data_root: str | Path | None,
    results_root: str | Path | None,
    max_workers: int,
    threads_per_worker: int,
    resume: bool,
    retry_failed: bool,
    require_data_identity: bool,
    require_clean_worktree: bool,
) -> tuple[list[dict[str, Any]], FormalRepresentationRunManifest, dict[str, Any]]:
    """Validate all formal Representation gates before storage or samplers exist."""

    root = Path(repo_root)
    _assert_base_commit(root)
    bundle = load_freeze_bundle(root)
    validate_freeze_bundle(bundle)
    units, manifest = frozen_representation_units(root, bundle)
    preprocessing = load_formal_preprocessing_config(root)
    resource_plan = load_yaml(root / "configs/formal_multiplatform_resource_plan.yaml")
    policy = load_canary_runner_config(root)
    validated_authorization = validate_representation_authorization(
        authorization,
        bundle=bundle,
        representation_units=units,
        preprocessing_config=preprocessing,
        resource_plan=resource_plan,
        global_runner_policy=policy,
        phase="representation",
        max_workers=max_workers,
        threads_per_worker=threads_per_worker,
        resume=resume,
        retry_failed=retry_failed,
        requested_overrides={
            "method": None,
            "fraction": None,
            "seed": None,
            "sample": None,
            "dataset": None,
            "endpoint": None,
            "execution_unit": None,
        },
        result_subdirectory=REPRESENTATION_DIRECTORY,
    )
    _read_canary_status(root)
    if require_clean_worktree:
        _assert_clean_worktree(root)
    if require_data_identity:
        if data_root is None:
            raise FormalRepresentationPreflightError("--data-root is required for a real formal Representation run.")
        try:
            verify_frozen_input_files(bundle["input_manifest"], Path(data_root))
        except FreezeValidationError as error:
            raise FormalRepresentationPreflightError(f"Frozen input identity verification failed: {error}") from error
    if results_root is not None and Path(results_root).name == REPRESENTATION_DIRECTORY:
        raise FormalRepresentationResultIsolationError("--results-root must be the formal root, not the Representation child.")
    manifest = FormalRepresentationRunManifest(
        **{**manifest.as_dict(), "authorization_sha256": validated_authorization.authorization_sha256}
    )
    preflight = {
        "status": "PASS",
        "current_git_commit": current_git_commit(root),
        "canary_status": "READY_FOR_FORMAL_REPRESENTATION_BENCHMARK",
        "input_identity_verified": bool(require_data_identity),
        "worktree_clean": bool(require_clean_worktree),
        "resource_plan_sha256": canonical_sha256(resource_plan),
        "max_workers": int(max_workers),
        "threads_per_worker": int(threads_per_worker),
        "representation_results_root": None if results_root is None else str(Path(results_root) / REPRESENTATION_DIRECTORY),
        "sampler_calls": 0,
    }
    return units, manifest, preflight


def _serialise_selected(draw: Any) -> str:
    return draw.selected_cells.to_csv(index=False, lineterminator="\n")


def _run_id(unit: Mapping[str, Any]) -> str:
    return f"representation_{unit['execution_unit_id']}"


def _stage_formal_success(
    publisher: AppendOnlyRunPublisher,
    attempt: Any,
    *,
    unit: Mapping[str, Any],
    manifest: FormalRepresentationRunManifest,
    input_identity_sha256: str,
    adapter_id: str,
    source_files: Sequence[str],
    preprocessing_manifest: Mapping[str, Any],
    draw: Any,
    runtime: Mapping[str, Any],
) -> Any:
    artifacts = _build_formal_success_artifacts(
        unit=unit, manifest=manifest, input_identity_sha256=input_identity_sha256,
        adapter_id=adapter_id, source_files=source_files, preprocessing_manifest=preprocessing_manifest,
        draw=draw, runtime=runtime,
    )
    for relative_path, payload in artifacts.items():
        publisher.backend.stage_bytes(attempt, relative_path, payload)
    return publisher.backend.publish(attempt, previous_status="RUNNING")


def _build_formal_success_artifacts(
    *, unit: Mapping[str, Any], manifest: FormalRepresentationRunManifest,
    input_identity_sha256: str, adapter_id: str, source_files: Sequence[str],
    preprocessing_manifest: Mapping[str, Any], draw: Any, runtime: Mapping[str, Any],
) -> dict[str, bytes]:
    """Build byte-identical formal artifacts without storage, events, or markers."""
    return {
        "input_manifest.json": _canonical_json(
        {
            "engineering_only": False,
            "formal_summary_eligible": True,
            "phase": "representation",
            "execution_unit_id": unit["execution_unit_id"],
            "input_identity_sha256": input_identity_sha256,
            "adapter_id": adapter_id,
            "source_files": list(source_files),
            "preprocessing_manifest": dict(preprocessing_manifest),
        }),
        "runtime_manifest.json": _canonical_json(
        {
            "engineering_only": False,
            "formal_summary_eligible": True,
            "phase": "representation",
            "execution_unit": dict(unit),
            "formal_run_manifest": manifest.as_dict(),
            "sampler_called": True,
            "sampler_registry_id": draw.method_id,
            **dict(runtime),
        }),
        "method_output/selected_cells.csv": _serialise_selected(draw).encode("utf-8"),
        "method_output/metadata.json": _canonical_json(
        {
            "engineering_only": False,
            "formal_summary_eligible": True,
            "phase": "representation",
            "method_id": draw.method_id,
            "metadata": dict(draw.metadata),
        }),
        "endpoint_output/representation_endpoint_status.json": _canonical_json(
        {
            "engineering_only": False,
            "formal_summary_eligible": True,
            "phase": "representation",
            "endpoint_set": list(unit["endpoint_set"]),
            "scientific_summary": "deferred_to_formal_representation_summary_phase",
        }),
        "logs/runtime.json": _canonical_json({"engineering_only": False, **dict(runtime)}),
    }


def _stage_formal_failure(
    publisher: AppendOnlyRunPublisher,
    attempt: Any,
    *,
    unit: Mapping[str, Any],
    error: BaseException,
    incomplete: bool,
) -> Any:
    publisher.backend.stage_json(
        attempt,
        "logs/failure.json",
        {
            "engineering_only": False,
            "formal_summary_eligible": False,
            "phase": "representation",
            "execution_unit_id": unit["execution_unit_id"],
            "incomplete": bool(incomplete),
            "error_type": type(error).__name__,
            "error": str(error),
            "traceback": traceback.format_exc(),
        },
    )
    return publisher.backend.publish_failure(
        attempt,
        previous_status="RUNNING",
        incomplete=incomplete,
        error={"error_type": type(error).__name__, "message": str(error)},
    )


def _pending_by_preprocessing_key(units: Sequence[Mapping[str, Any]]) -> list[list[Mapping[str, Any]]]:
    """Create a deterministic scheduling order without changing unit identity."""

    grouped: dict[tuple[str, str, float], list[Mapping[str, Any]]] = defaultdict(list)
    for unit in units:
        grouped[(str(unit["dataset_id"]), str(unit["sample_id"]), float(unit["fraction"]))].append(unit)
    return [
        sorted(grouped[key], key=lambda item: str(item["execution_unit_id"]))
        for key in sorted(grouped)
    ]


def _existing_status(storage: SSHFSAppendOnlyBackend, run_id: str, state: Mapping[str, Mapping[str, Any]]) -> str | None:
    if storage.has_verified_success(run_id):
        return "SUCCESS"
    record = state.get(run_id)
    return None if record is None else str(record.get("status"))


def _resume_incomplete_status(status: str | None, resume: bool) -> bool:
    """Return whether an immutable interrupted attempt needs one new attempt."""

    return bool(resume and status in {"INCOMPLETE", "INTERRUPTED", "PUBLISH_FAILED"})


def run_authorized_formal_representation(
    *,
    repo_root: str | Path,
    authorization: RepresentationAuthorization,
    data_root: str | Path,
    formal_results_root: str | Path,
    local_staging_root: str | Path,
    max_workers: int,
    threads_per_worker: int,
    resume: bool,
    retry_failed: bool = False,
    _input_identity_preverified: bool = False,
) -> dict[str, Any]:
    """Execute only the frozen formal Representation units with append-only results."""

    root = Path(repo_root)
    units, manifest, preflight = verify_formal_representation_preflight(
        repo_root=root,
        authorization=authorization,
        data_root=data_root,
        results_root=formal_results_root,
        max_workers=max_workers,
        threads_per_worker=threads_per_worker,
        resume=resume,
        retry_failed=retry_failed,
        require_data_identity=not _input_identity_preverified,
        require_clean_worktree=True,
    )
    results_root = Path(formal_results_root)
    representation_root = results_root / REPRESENTATION_DIRECTORY
    if representation_root.parent != results_root:
        raise FormalRepresentationResultIsolationError("Representation output is not a direct formal-results child.")
    storage = SSHFSAppendOnlyBackend(
        StorageConfig(
            local_staging_root=Path(local_staging_root),
            remote_results_root=representation_root,
            backend="sshfs_append_only",
        )
    )
    bundle = load_freeze_bundle(root)
    preprocessing_config = load_formal_preprocessing_config(root)
    code_commit = current_git_commit(root)
    state = storage.replay_events()
    rows: list[dict[str, Any]] = []
    sampler_calls = 0
    system_error: str | None = None

    for group in _pending_by_preprocessing_key(units):
        pending: list[Mapping[str, Any]] = []
        for unit in group:
            status = _existing_status(storage, _run_id(unit), state)
            if status == "SUCCESS":
                rows.append({"execution_unit_id": unit["execution_unit_id"], "status": "SKIPPED_ALREADY_SUCCESS", "sampler_called": False})
            elif _resume_incomplete_status(status, resume):
                # A prior interrupted attempt is immutable; resume creates a new attempt only for this unit.
                pending.append(unit)
            elif status in {"FAIL", "FAILURE", "INCOMPLETE", "INTERRUPTED", "PUBLISH_FAILED"}:
                rows.append({"execution_unit_id": unit["execution_unit_id"], "status": "FAILURE" if status == "FAIL" else status, "sampler_called": False})
            else:
                pending.append(unit)
        if not pending:
            continue
        try:
            prepared = prepare_frozen_canary_unit_input(
                unit=pending[0],
                bundle=bundle,
                data_root=data_root,
                preprocessing_config=preprocessing_config,
                code_commit=code_commit,
            )
        except Exception as error:
            system_error = f"{type(error).__name__}: {error}"
            break

        for unit in pending:
            publisher = AppendOnlyRunPublisher(storage)
            attempt = publisher.begin(
                run_id=_run_id(unit),
                method_id=str(unit["method"]),
                config_hash=manifest.execution_unit_manifest_sha256,
                code_commit=code_commit,
            )
            publisher.backend.mark_running(attempt)
            start = time.perf_counter()
            tracemalloc.start()
            try:
                draw, sampling_audit = _draw_prepared_real_unit(unit, prepared)
                sampler_calls += 1
                _, peak_bytes = tracemalloc.get_traced_memory()
                runtime = {
                    "runtime_seconds": time.perf_counter() - start,
                    "peak_memory_bytes": int(peak_bytes),
                    "sampler_code_commit": code_commit,
                    "seed": int(unit["seed"]),
                    "output_hash": sha256(_serialise_selected(draw).encode("utf-8")).hexdigest(),
                    "exit_status": "SUCCESS",
                    "authorization_sha256": authorization.authorization_sha256,
                    "real_data_execution": True,
                    **sampling_audit,
                }
                _stage_formal_success(
                    publisher,
                    attempt,
                    unit=unit,
                    manifest=manifest,
                    input_identity_sha256=prepared.raw_population.source_identity_sha256,
                    adapter_id=prepared.raw_population.adapter_id,
                    source_files=prepared.raw_population.source_files,
                    preprocessing_manifest=sampling_audit["preprocessing_manifest"],
                    draw=draw,
                    runtime=runtime,
                )
                rows.append({"execution_unit_id": unit["execution_unit_id"], "status": "SUCCESS", "sampler_called": True, **runtime})
            except KeyboardInterrupt as error:
                _stage_formal_failure(publisher, attempt, unit=unit, error=error, incomplete=True)
                rows.append({"execution_unit_id": unit["execution_unit_id"], "status": "INCOMPLETE", "sampler_called": sampler_calls > 0})
                raise
            except (ChecksumMismatchError, ImmutableWriteError, PublishError, OSError) as error:
                try:
                    _stage_formal_failure(publisher, attempt, unit=unit, error=error, incomplete=True)
                except Exception:
                    pass
                system_error = f"{type(error).__name__}: {error}"
                rows.append({"execution_unit_id": unit["execution_unit_id"], "status": "INCOMPLETE", "sampler_called": False})
                break
            except Exception as error:
                _stage_formal_failure(publisher, attempt, unit=unit, error=error, incomplete=False)
                rows.append({"execution_unit_id": unit["execution_unit_id"], "status": "FAILURE", "sampler_called": False})
            finally:
                tracemalloc.stop()
        if system_error is not None:
            break

    completed_ids = {str(row["execution_unit_id"]) for row in rows}
    missing_ids = [str(unit["execution_unit_id"]) for unit in units if str(unit["execution_unit_id"]) not in completed_ids]
    counts = {status: sum(row["status"] == status for row in rows) for status in sorted({row["status"] for row in rows})}
    if system_error is not None or missing_ids or counts.get("INCOMPLETE", 0):
        status = "FORMAL_REPRESENTATION_INCOMPLETE"
    elif counts.get("FAILURE", 0):
        status = "FORMAL_REPRESENTATION_UNIT_FAILURE"
    elif counts.get("SUCCESS", 0) + counts.get("SKIPPED_ALREADY_SUCCESS", 0) == REPRESENTATION_UNIT_COUNT:
        status = "FORMAL_REPRESENTATION_SUCCESS"
    else:
        status = "FORMAL_REPRESENTATION_INCOMPLETE"
    summary = {
        "engineering_only": False,
        "formal_summary_eligible": True,
        "phase": "representation",
        "status": status,
        "authorization_sha256": authorization.authorization_sha256,
        "formal_run_manifest": manifest.as_dict(),
        "frozen_unit_count": REPRESENTATION_UNIT_COUNT,
        "unit_status_counts": counts,
        "missing_unit_count": len(missing_ids),
        "sampler_calls": sampler_calls,
        "resume": bool(resume),
        "retry_failed": bool(retry_failed),
        "system_error": system_error,
        "scientific_summary": "deferred_to_formal_representation_summary_phase",
        "preflight": preflight,
    }
    storage.publish_immutable_provenance(
        provenance_id=f"formal_representation_execution_summary_{int(time.time_ns())}",
        artifacts={"formal_representation_execution_summary.json": _canonical_json(summary)},
        metadata={
            "engineering_only": False,
            "formal_summary_eligible": True,
            "phase": "representation",
            "status": status,
        },
    )
    return summary


def run_synthetic_formal_representation(
    *,
    repo_root: str | Path,
    local_staging_root: str | Path,
    representation_results_root: str | Path,
    unit_limit: int = 1,
    input_provider: Callable[[Mapping[str, Any]], Any] = synthetic_canary_input,
) -> dict[str, Any]:
    """Exercise the formal Representation storage path using synthetic inputs only."""

    if unit_limit < 1:
        raise ValueError("unit_limit must be positive for the synthetic Representation runner.")
    root = Path(repo_root)
    bundle = load_freeze_bundle(root)
    units, manifest = frozen_representation_units(root, bundle)
    selected_units = units[:unit_limit]
    preprocessing_config = load_formal_preprocessing_config(root)
    storage = SSHFSAppendOnlyBackend(
        StorageConfig(
            local_staging_root=Path(local_staging_root),
            remote_results_root=Path(representation_results_root),
            backend="sshfs_append_only",
        )
    )
    code_commit = current_git_commit(root)
    rows: list[dict[str, Any]] = []
    for unit in selected_units:
        value = input_provider(unit)
        _validate_canary_input(value)
        target_n = max(4, min(len(value.cell_ids), int(np.floor(len(value.cell_ids) * float(unit["fraction"])))) )
        dataset = next(item for item in bundle["dataset_freeze"]["datasets"] if item["dataset_id"] == unit["dataset_id"])
        raw = _synthetic_raw_population(unit, value, targeted_panel=bool(dataset["targeted_panel"]))
        representation_input = prepare_representation_input(
            raw,
            config=preprocessing_config,
            dataset_id=f"synthetic_{unit['dataset_id']}",
            sample_id=str(unit["sample_id"]),
            target_n=target_n,
            targeted_panel=bool(dataset["targeted_panel"]),
            panel_manifest_name=str(dataset["panel_gene_manifest"]) if bool(dataset["targeted_panel"]) else None,
            code_commit=code_commit,
        )
        prepared = type("SyntheticPrepared", (), {"raw_population": raw, "representation_input": representation_input, "target_n": target_n})()
        draw, audit = _draw_prepared_real_unit(unit, prepared)
        publisher = AppendOnlyRunPublisher(storage)
        attempt = publisher.begin(
            run_id=_run_id(unit),
            method_id=str(unit["method"]),
            config_hash=manifest.execution_unit_manifest_sha256,
            code_commit=code_commit,
        )
        publisher.backend.mark_running(attempt)
        runtime = {
            "runtime_seconds": 0.0,
            "peak_memory_bytes": 0,
            "sampler_code_commit": code_commit,
            "seed": int(unit["seed"]),
            "output_hash": sha256(_serialise_selected(draw).encode("utf-8")).hexdigest(),
            "exit_status": "SUCCESS",
            "authorization_sha256": "synthetic_test_only",
            "real_data_execution": False,
            **audit,
        }
        _stage_formal_success(
            publisher,
            attempt,
            unit=unit,
            manifest=manifest,
            input_identity_sha256=value.input_hash,
            adapter_id=value.adapter_id,
            source_files=(),
            preprocessing_manifest=audit["preprocessing_manifest"],
            draw=draw,
            runtime=runtime,
        )
        rows.append({"execution_unit_id": unit["execution_unit_id"], "status": "SUCCESS", "sampler_called": True})
    return {"status": "SYNTHETIC_SUCCESS", "unit_count": len(selected_units), "sampler_calls": len(selected_units), "units": rows}


def validate_formal_representation_results(
    *,
    repo_root: str | Path,
    formal_results_root: str | Path,
) -> dict[str, Any]:
    """Read-only structural validation for a completed formal Representation run."""

    root = Path(repo_root)
    units, manifest = frozen_representation_units(root)
    expected_runs = {_run_id(unit) for unit in units}
    formal_root = Path(formal_results_root)
    representation_root = formal_root / REPRESENTATION_DIRECTORY
    storage = SSHFSAppendOnlyBackend(
        StorageConfig(
            local_staging_root=Path("."),
            remote_results_root=representation_root,
            backend="sshfs_append_only",
        )
    )
    state = storage.replay_events()
    unexpected_runs = sorted(set(state).difference(expected_runs))
    missing_runs = sorted(expected_runs.difference(state))
    statuses = {run_id: str(record.get("status")) for run_id, record in state.items()}
    success_runs = sorted(run_id for run_id, status in statuses.items() if status == "SUCCESS")
    failure_runs = sorted(run_id for run_id, status in statuses.items() if status in {"FAIL", "FAILURE"})
    incomplete_runs = sorted(run_id for run_id, status in statuses.items() if status not in {"SUCCESS", "FAIL", "FAILURE"})
    invalid_markers = sorted(
        run_id for run_id in success_runs if state[run_id].get("success_marker_valid") is not True
    )
    siblings = sorted(path.name for path in formal_root.iterdir()) if formal_root.is_dir() else []
    if "inference" in siblings:
        raise FormalRepresentationResultIsolationError("An Inference result directory exists during the Representation-only phase.")
    if not representation_root.is_dir():
        raise FormalRepresentationResultIsolationError("The formal Representation result directory is missing.")
    complete = (
        len(success_runs) == REPRESENTATION_UNIT_COUNT
        and not failure_runs
        and not incomplete_runs
        and not missing_runs
        and not unexpected_runs
        and not invalid_markers
    )
    return {
        "status": "PASS" if complete else "INCOMPLETE_OR_INVALID",
        "frozen_unit_count": REPRESENTATION_UNIT_COUNT,
        "observed_run_count": len(state),
        "success_count": len(success_runs),
        "failure_count": len(failure_runs),
        "incomplete_count": len(incomplete_runs),
        "missing_count": len(missing_runs),
        "duplicate_count": len(unexpected_runs),
        "invalid_success_marker_count": len(invalid_markers),
        "representation_result_directory": REPRESENTATION_DIRECTORY,
        "formal_result_siblings": siblings,
        "inference_execution_count": 0,
        "engineering_canary_preserved": (formal_root / "engineering_canary").is_dir(),
        "execution_unit_manifest_sha256": manifest.execution_unit_manifest_sha256,
    }


__all__ = [
    "FORMAL_REPRESENTATION_BASE_COMMIT",
    "REPRESENTATION_STATUSES",
    "FormalRepresentationManifestDriftError",
    "FormalRepresentationPreflightError",
    "FormalRepresentationResultIsolationError",
    "FormalRepresentationRunnerError",
    "FormalRepresentationRunManifest",
    "frozen_representation_units",
    "_resume_incomplete_status",
    "run_authorized_formal_representation",
    "run_synthetic_formal_representation",
    "validate_formal_representation_results",
    "verify_formal_representation_preflight",
]
