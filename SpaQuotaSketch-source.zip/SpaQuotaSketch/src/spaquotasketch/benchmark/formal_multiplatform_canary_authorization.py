"""Strict authorization for the six frozen real-data engineering canary units.

This module cannot authorize a formal Representation, Inference, or summary
run.  It validates one explicit tracked authorization file against the frozen
benchmark artifacts before a caller is allowed to construct an execution
runner.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

from .formal_multiplatform_freeze import canonical_sha256, load_yaml
from .formal_preprocessing import preprocessing_config_sha256


AUTHORIZATION_CONFIG_PATH = Path("configs/formal_multiplatform_canary_authorization.yaml")
AUTHORIZATION_ID = "formal-multiplatform-canary-v1"
ENGINEERING_DIRECTORY = "engineering_canary"


class CanaryAuthorizationError(ValueError):
    """A requested real-data canary exceeds its frozen authorization scope."""


@dataclass(frozen=True)
class CanaryAuthorization:
    """Validated immutable facts permitting only the frozen engineering canary."""

    payload: Mapping[str, Any]
    authorization_sha256: str
    unit_ids: tuple[str, ...]


def _require_equal(actual: Any, expected: Any, *, field: str) -> None:
    if actual != expected:
        raise CanaryAuthorizationError(f"Authorization field {field} is not the frozen value.")


def _require_exact_set(values: Any, expected: set[str], *, field: str) -> None:
    if not isinstance(values, list) or set(map(str, values)) != expected or len(values) != len(expected):
        raise CanaryAuthorizationError(f"Authorization field {field} has an unsafe scope.")


def load_canary_authorization(
    repo_root: str | Path,
    authorization_config: str | Path,
) -> CanaryAuthorization:
    """Load only the single tracked authorization configuration path."""

    root = Path(repo_root).resolve()
    actual_path = Path(authorization_config).resolve()
    expected_path = (root / AUTHORIZATION_CONFIG_PATH).resolve()
    if actual_path != expected_path:
        raise CanaryAuthorizationError("Only the tracked frozen canary authorization configuration is accepted.")
    payload = load_yaml(actual_path)
    return CanaryAuthorization(
        payload=payload,
        authorization_sha256=canonical_sha256(payload),
        unit_ids=(),
    )


def _method_registry_matches(bundle: Mapping[str, Any], method_registry: Mapping[str, Any]) -> bool:
    frozen_methods = list(bundle["benchmark"]["methods"])
    expected_hash = canonical_sha256(frozen_methods)
    if str(method_registry.get("sha256", "")) != expected_hash:
        return False
    expected_ids = [str(row["registry_id"]) for row in frozen_methods]
    return list(method_registry.get("method_ids", [])) == expected_ids


def validate_canary_authorization(
    authorization: CanaryAuthorization,
    *,
    bundle: Mapping[str, Any],
    canary_units: Sequence[Mapping[str, Any]],
    canary_manifest: Mapping[str, Any],
    preprocessing_config: Mapping[str, Any],
    global_runner_policy: Mapping[str, Any],
    phase: str,
    max_workers: int,
    threads_per_worker: int,
    requested_overrides: Mapping[str, Any],
    result_subdirectory: str,
) -> CanaryAuthorization:
    """Reject any scope drift before raw input, storage, or samplers are touched."""

    payload = authorization.payload
    _require_equal(payload.get("authorization_schema_version"), 1, field="authorization_schema_version")
    _require_equal(payload.get("authorization_id"), AUTHORIZATION_ID, field="authorization_id")
    real_data = payload.get("real_data_execution")
    if not isinstance(real_data, Mapping):
        raise CanaryAuthorizationError("Authorization has no real_data_execution section.")
    _require_equal(real_data.get("allowed"), True, field="real_data_execution.allowed")
    _require_equal(real_data.get("scope"), "canary_only", field="real_data_execution.scope")
    _require_exact_set(payload.get("allowed_phases"), {"canary"}, field="allowed_phases")
    _require_exact_set(
        payload.get("prohibited_phases"), {"representation", "inference", "summarize"}, field="prohibited_phases"
    )
    _require_equal(phase, "canary", field="requested_phase")
    if bool(global_runner_policy.get("allow_real_data_execution", True)):
        raise CanaryAuthorizationError("The global runner policy must remain closed for real benchmark execution.")

    allowed_manifest = payload.get("allowed_execution_unit_manifest")
    formal_manifest = payload.get("formal_execution_unit_manifest")
    if not isinstance(allowed_manifest, Mapping) or not isinstance(formal_manifest, Mapping):
        raise CanaryAuthorizationError("Authorization is missing an execution-unit manifest declaration.")
    _require_equal(
        allowed_manifest.get("path"), "configs/formal_multiplatform_canary_units.yaml", field="allowed_execution_unit_manifest.path"
    )
    _require_equal(
        allowed_manifest.get("sha256"), canary_manifest["canary_manifest_sha256"], field="allowed_execution_unit_manifest.sha256"
    )
    _require_equal(
        formal_manifest.get("path"), "configs/formal_multiplatform_execution_units.yaml", field="formal_execution_unit_manifest.path"
    )
    _require_equal(
        formal_manifest.get("sha256"), canonical_sha256(bundle["execution_units"]), field="formal_execution_unit_manifest.sha256"
    )
    _require_equal(payload.get("allowed_unit_count"), 6, field="allowed_unit_count")
    _require_equal(payload.get("maximum_unit_count"), 6, field="maximum_unit_count")
    actual_ids = tuple(str(unit["execution_unit_id"]) for unit in canary_units)
    if len(actual_ids) != 6 or len(set(actual_ids)) != 6:
        raise CanaryAuthorizationError("The canary runner did not resolve exactly six unique units.")
    _require_equal(
        payload.get("allowed_execution_unit_ids_sha256"), canonical_sha256(list(actual_ids)), field="allowed_execution_unit_ids_sha256"
    )
    all_ids = {str(unit["execution_unit_id"]) for unit in bundle["execution_units"]["units"]}
    if set(actual_ids).difference(all_ids):
        raise CanaryAuthorizationError("At least one canary unit is not in the frozen formal execution manifest.")

    frozen_hashes = payload.get("frozen_hashes")
    if not isinstance(frozen_hashes, Mapping):
        raise CanaryAuthorizationError("Authorization has no frozen_hashes section.")
    expected_hashes = {
        "benchmark_config_sha256": bundle["benchmark"]["benchmark_config_sha256"],
        "freeze_manifest_sha256": bundle["freeze_manifest"]["freeze_manifest_sha256"],
        "preprocessing_config_sha256": preprocessing_config_sha256(preprocessing_config),
        "input_manifest_sha256": bundle["input_manifest"]["formal_input_manifest_sha256"],
        "seed_manifest_sha256": bundle["seeds"]["seed_manifest_sha256"],
    }
    for field, expected in expected_hashes.items():
        _require_equal(frozen_hashes.get(field), expected, field=f"frozen_hashes.{field}")
    method_registry = payload.get("method_registry")
    if not isinstance(method_registry, Mapping) or not _method_registry_matches(bundle, method_registry):
        raise CanaryAuthorizationError("The authorization method registry does not match the frozen benchmark registry.")

    limits = payload.get("runtime_limits")
    if not isinstance(limits, Mapping):
        raise CanaryAuthorizationError("Authorization has no runtime_limits section.")
    _require_equal(limits.get("max_workers"), 1, field="runtime_limits.max_workers")
    _require_equal(limits.get("threads_per_worker"), 1, field="runtime_limits.threads_per_worker")
    _require_equal(int(max_workers), 1, field="requested_max_workers")
    _require_equal(int(threads_per_worker), 1, field="requested_threads_per_worker")

    cli_overrides = payload.get("cli_overrides")
    if not isinstance(cli_overrides, Mapping):
        raise CanaryAuthorizationError("Authorization has no cli_overrides section.")
    for name in ("method", "fraction", "seed", "sample", "dataset", "endpoint", "execution_unit"):
        _require_equal(cli_overrides.get(f"allow_{name}_override"), False, field=f"cli_overrides.allow_{name}_override")
        if requested_overrides.get(name) is not None:
            raise CanaryAuthorizationError(f"The canary authorization refuses a {name} override.")

    result_policy = payload.get("result_policy")
    if not isinstance(result_policy, Mapping):
        raise CanaryAuthorizationError("Authorization has no result_policy section.")
    _require_equal(result_policy.get("engineering_only"), True, field="result_policy.engineering_only")
    _require_equal(result_policy.get("formal_summary_eligible"), False, field="result_policy.formal_summary_eligible")
    _require_equal(result_policy.get("result_subdirectory"), ENGINEERING_DIRECTORY, field="result_policy.result_subdirectory")
    _require_equal(result_policy.get("overwrite_allowed"), False, field="result_policy.overwrite_allowed")
    _require_equal(result_policy.get("resume_allowed"), True, field="result_policy.resume_allowed")
    _require_equal(result_subdirectory, ENGINEERING_DIRECTORY, field="requested_result_subdirectory")
    formal = payload.get("formal_benchmark_execution")
    if not isinstance(formal, Mapping):
        raise CanaryAuthorizationError("Authorization has no formal_benchmark_execution section.")
    for name in ("representation_allowed", "inference_allowed", "full_benchmark_allowed"):
        _require_equal(formal.get(name), False, field=f"formal_benchmark_execution.{name}")

    return CanaryAuthorization(payload=payload, authorization_sha256=authorization.authorization_sha256, unit_ids=actual_ids)


__all__ = [
    "AUTHORIZATION_CONFIG_PATH",
    "AUTHORIZATION_ID",
    "CanaryAuthorization",
    "CanaryAuthorizationError",
    "ENGINEERING_DIRECTORY",
    "load_canary_authorization",
    "validate_canary_authorization",
]
