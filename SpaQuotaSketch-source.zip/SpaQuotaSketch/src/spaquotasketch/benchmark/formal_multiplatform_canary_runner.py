"""Safe engineering-only runner for the frozen formal benchmark canary.

This module is intentionally narrow.  It never chooses units, changes the
formal plan, or writes a scientific benchmark summary.  The six canary units
remain a read-only subset of the frozen 1,960-unit manifest.  Its execution
path is exercised only with synthetic inputs in this development stage.
"""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
import json
from pathlib import Path
import shutil
import subprocess
import time
import tracemalloc
import traceback
from typing import Any, Callable, Mapping, Sequence

import numpy as np
import yaml
from scipy import sparse

from ..result_persistence import AppendOnlyRunPublisher
from ..result_storage import SSHFSAppendOnlyBackend, StorageConfig
from .formal_multiplatform_freeze import (
    FreezeValidationError,
    canonical_sha256,
    load_freeze_bundle,
    load_yaml,
    validate_freeze_bundle,
    verify_frozen_input_files,
)
from .formal_multiplatform_input_adapters import FormalRawInput, load_frozen_unit_raw_input
from .formal_multiplatform_canary_authorization import (
    CanaryAuthorization,
    validate_canary_authorization,
)
from .formal_preprocessing import (
    build_frozen_spatial_design,
    load_formal_preprocessing_config,
    prepare_inference_population,
    prepare_representation_input,
)
from .r2_method_adapter import run_registered_r2_method


CANARY_CONFIG_PATH = Path("configs/formal_multiplatform_canary_units.yaml")
CANARY_RUNNER_CONFIG_PATH = Path("configs/formal_multiplatform_canary_runner.yaml")
CANARY_BASE_COMMIT = "9c05c6b"
ENGINEERING_DIRECTORY = "engineering_canary"
CANARY_UNIT_COUNT = 6
CANARY_STATUSES = frozenset(
    {
        "PENDING",
        "RUNNING",
        "SUCCESS",
        "FAILURE",
        "INCOMPLETE",
        "SKIPPED_ALREADY_SUCCESS",
        "BLOCKED_PREFLIGHT",
        "BLOCKED_HASH_MISMATCH",
        "BLOCKED_METHOD_CAPABILITY",
        "BLOCKED_INPUT_IDENTITY",
    }
)


class CanaryRunnerError(RuntimeError):
    """Base error for an engineering canary failure."""


class CanaryManifestDriftError(CanaryRunnerError):
    """The immutable six-unit canary manifest was changed."""


class CanaryPreflightError(CanaryRunnerError):
    """A required gate failed before a sampler could be called."""


class CanaryMethodCapabilityError(CanaryRunnerError):
    """A frozen unit requests a method outside its allowed task boundary."""


class CanaryInterrupted(CanaryRunnerError):
    """Test-only interruption used to verify safe resume behavior."""


@dataclass(frozen=True)
class CanaryInput:
    """The minimal, adapter-independent sampler input for one frozen unit."""

    cell_ids: np.ndarray
    expression_embedding: np.ndarray
    coordinates: np.ndarray
    input_hash: str
    adapter_id: str


@dataclass(frozen=True)
class FrozenCanaryPreparedInput:
    """Task-appropriate input prepared from one frozen raw canary population.

    This is a read-only integration point.  It is not invoked by the current
    engineering-only synthetic runner and cannot create a scientific result.
    """

    execution_unit_id: str
    target_n: int
    raw_population: FormalRawInput
    inference_population: Any
    representation_input: Any | None
    spatial_design: Any


def _canonical_json(value: Any) -> bytes:
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":")) + "\n").encode("utf-8")


def _git_text(repo_root: Path, arguments: Sequence[str]) -> str:
    return subprocess.check_output(["git", *arguments], cwd=repo_root, text=True, encoding="utf-8").strip()


def current_git_commit(repo_root: str | Path) -> str:
    """Return the commit recorded in an engineering runtime manifest."""

    return _git_text(Path(repo_root), ["rev-parse", "HEAD"])


def _base_canary_yaml(repo_root: Path) -> dict[str, Any]:
    try:
        content = _git_text(repo_root, ["show", f"{CANARY_BASE_COMMIT}:{CANARY_CONFIG_PATH.as_posix()}"])
    except subprocess.CalledProcessError as error:  # pragma: no cover - only a damaged Git repository can cause this.
        raise CanaryManifestDriftError(f"Cannot read the protected canary manifest from {CANARY_BASE_COMMIT}.") from error
    payload = yaml.safe_load(content)
    if not isinstance(payload, Mapping):
        raise CanaryManifestDriftError("The protected canary manifest is not a mapping.")
    return dict(payload)


def load_canary_runner_config(repo_root: str | Path) -> dict[str, Any]:
    """Load and validate the small tracked execution-policy configuration."""

    config = load_yaml(Path(repo_root) / CANARY_RUNNER_CONFIG_PATH)
    if int(config.get("max_workers", -1)) != 1 or int(config.get("threads_per_worker", -1)) != 1:
        raise CanaryPreflightError("The first formal canary is frozen to one worker and one thread.")
    if config.get("storage_backend") != "sshfs_append_only":
        raise CanaryPreflightError("The canary must use the SSHFS append-only storage backend.")
    if config.get("engineering_directory") != ENGINEERING_DIRECTORY:
        raise CanaryPreflightError("Canary outputs must remain in the engineering-only directory.")
    if config.get("excluded_from_formal_summary") is not True:
        raise CanaryPreflightError("Canary outputs must be excluded from formal scientific summaries.")
    return config


def frozen_canary_units(repo_root: str | Path, bundle: Mapping[str, Any] | None = None) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Resolve exactly the six protected units and prove their identity.

    The tracked canary YAML is compared to the version recorded at the parent
    preflight commit.  This makes a changed list a blocking condition instead
    of an opportunity to silently choose a more convenient canary.
    """

    root = Path(repo_root)
    actual = load_yaml(root / CANARY_CONFIG_PATH)
    protected = _base_canary_yaml(root)
    actual_hash = canonical_sha256(actual)
    protected_hash = canonical_sha256(protected)
    if actual_hash != protected_hash:
        raise CanaryManifestDriftError(
            "The tracked canary manifest differs from the protected preflight version; refusing to select units."
        )
    policy = load_canary_runner_config(root)
    if policy.get("canary_manifest_sha256") != actual_hash:
        raise CanaryManifestDriftError("The canary runner policy does not match the frozen canary manifest hash.")
    entries = list(actual.get("units") or [])
    if int(actual.get("canary_count", -1)) != CANARY_UNIT_COUNT or len(entries) != CANARY_UNIT_COUNT:
        raise CanaryManifestDriftError("The canary must contain exactly six units.")
    ids = [str(item.get("execution_unit_id", "")) for item in entries]
    if len(set(ids)) != CANARY_UNIT_COUNT or any(not item for item in ids):
        raise CanaryManifestDriftError("Canary execution-unit identifiers must be unique and nonempty.")

    bundle = dict(bundle or load_freeze_bundle(root))
    validate_freeze_bundle(bundle)
    all_units = {str(item["execution_unit_id"]): dict(item) for item in bundle["execution_units"]["units"]}
    missing = sorted(set(ids).difference(all_units))
    if missing:
        raise CanaryManifestDriftError(f"Canary units are not all present in the frozen execution manifest: {missing}")
    units: list[dict[str, Any]] = []
    for entry in entries:
        unit = dict(all_units[str(entry["execution_unit_id"])])
        unit["selection_role"] = str(entry["selection_role"])
        units.append(unit)
    units.sort(key=lambda item: str(item["execution_unit_id"]))
    tasks = {str(unit["task"]) for unit in units}
    if tasks != {"representation", "inference"}:
        raise CanaryManifestDriftError("The canary must cover both representation and inference.")
    strata = {
        str(dataset["endpoint_stratum"])
        for dataset in bundle["dataset_freeze"]["datasets"]
        if str(dataset["dataset_id"]) in {str(unit["dataset_id"]) for unit in units}
    }
    if strata != {"WTS_STRATUM", "TARGETED_PANEL_STRATUM"}:
        raise CanaryManifestDriftError("The canary must cover both whole-transcriptome and targeted-panel strata.")
    manifest = {
        "engineering_only": True,
        "canary_manifest_sha256": actual_hash,
        "execution_unit_ids_sorted": [str(unit["execution_unit_id"]) for unit in units],
        "units": [
            {
                key: unit[key]
                for key in ("execution_unit_id", "dataset_id", "sample_id", "task", "method", "fraction", "seed", "adapter", "selection_role")
            }
            for unit in units
        ],
        "input_manifest_sha256": str(bundle["input_manifest"]["formal_input_manifest_sha256"]),
        "benchmark_config_sha256": str(bundle["benchmark"]["benchmark_config_sha256"]),
        "freeze_manifest_sha256": str(bundle["freeze_manifest"]["freeze_manifest_sha256"]),
        "formal_execution_unit_count": int(bundle["execution_units"]["counts"]["total_execution_units"]),
        "excluded_from_formal_summary": True,
    }
    return units, manifest


def validate_unit_method_capability(unit: Mapping[str, Any], benchmark: Mapping[str, Any]) -> None:
    """Enforce the benchmark task boundary, including its secondary controls.

    The formal benchmark permits clean probability controls to be evaluated on
    representation endpoints.  That is a benchmark role, not a claim that the
    controls implement the public Representation mode.  The registered R2
    adapter is therefore used below, rather than mislabelling a public API.
    """

    task, method = str(unit["task"]), str(unit["method"])
    if method.startswith("legacy_"):
        raise CanaryMethodCapabilityError("Legacy methods are forbidden from the formal canary.")
    if task == "inference" and method == "quota_completed_representation_mode":
        raise CanaryMethodCapabilityError("quota_completed_representation_mode cannot enter inference.")
    if task == "representation" and method not in set(benchmark["representation_methods"]):
        raise CanaryMethodCapabilityError(f"{method} is not a frozen representation comparison method.")
    if task == "inference" and method not in set(benchmark["inference_methods"]):
        raise CanaryMethodCapabilityError(f"{method} is not a frozen inference method.")
    if task not in {"representation", "inference"}:
        raise CanaryMethodCapabilityError(f"Unsupported frozen task: {task}")


def _assert_clean_worktree(repo_root: Path) -> None:
    if _git_text(repo_root, ["status", "--porcelain"]):
        raise CanaryPreflightError("The real canary requires a clean Git worktree.")


def verify_canary_preflight(
    *,
    repo_root: str | Path,
    data_root: str | Path | None,
    results_root: str | Path | None,
    require_data_identity: bool,
    require_clean_worktree: bool,
    check_result_storage_capability: bool = True,
) -> dict[str, Any]:
    """Run all gates before any sampler or attempt directory is created."""

    root = Path(repo_root)
    bundle = load_freeze_bundle(root)
    validate_freeze_bundle(bundle)
    units, canary_manifest = frozen_canary_units(root, bundle)
    if require_clean_worktree:
        _assert_clean_worktree(root)
    for unit in units:
        validate_unit_method_capability(unit, bundle["benchmark"])
    if require_data_identity:
        if data_root is None:
            raise CanaryPreflightError("--data-root is required for a real canary execution.")
        try:
            verify_frozen_input_files(bundle["input_manifest"], Path(data_root))
        except FreezeValidationError as error:
            raise CanaryPreflightError(f"Frozen input identity verification failed: {error}") from error
    if results_root is not None:
        formal_root = Path(results_root)
        canary_root = formal_root / ENGINEERING_DIRECTORY
        if canary_root.parent != formal_root:
            raise CanaryPreflightError("Canary outputs must be a direct engineering-only child of the formal root.")
        if check_result_storage_capability:
            if not formal_root.is_dir():
                raise CanaryPreflightError("The formal benchmark results root must already exist and be a directory.")
            if not formal_root.parent.exists() or not os_access_writable(formal_root.parent):
                raise CanaryPreflightError("The parent of the formal results root is not writable for a new engineering directory.")
            free_bytes = shutil.disk_usage(formal_root).free
        else:
            free_bytes = None
    else:
        canary_root, free_bytes = None, None
    return {
        "status": "PASS",
        "current_git_commit": current_git_commit(root),
        "worktree_clean": bool(require_clean_worktree),
        "canary_manifest": canary_manifest,
        "input_identity_verified": bool(require_data_identity),
        "results_root": str(results_root) if results_root is not None else None,
        "engineering_canary_root": str(canary_root) if canary_root is not None else None,
        "available_bytes": free_bytes,
        "result_storage_capability_checked": bool(check_result_storage_capability),
        "sampler_calls": 0,
    }


def os_access_writable(path: Path) -> bool:
    """Avoid a probe write before gates pass; prior server preflight owns probes."""

    import os

    return os.access(path, os.W_OK | os.X_OK)


def synthetic_canary_input(unit: Mapping[str, Any], *, n_cells: int = 160, n_features: int = 12) -> CanaryInput:
    """Create a tiny deterministic input that exercises the real sampler path."""

    if n_cells < 32 or n_features < 3:
        raise ValueError("Synthetic canary input requires at least 32 units and three expression features.")
    seed = int.from_bytes(sha256(str(unit["execution_unit_id"]).encode("utf-8")).digest()[:8], "big")
    rng = np.random.default_rng(seed)
    expression = rng.poisson(2.0, size=(n_cells, n_features)).astype(float)
    expression[:, 0] += np.linspace(0.0, 4.0, n_cells)
    coordinates = np.column_stack((np.arange(n_cells) % 16, np.arange(n_cells) // 16)).astype(float)
    cell_ids = np.asarray([f"synthetic_{index:04d}" for index in range(n_cells)], dtype=str)
    payload = _canonical_json(
        {
            "unit": str(unit["execution_unit_id"]),
            "n_cells": n_cells,
            "n_features": n_features,
            "seed": int(seed),
        }
    )
    return CanaryInput(
        cell_ids=cell_ids,
        expression_embedding=expression,
        coordinates=coordinates,
        input_hash=sha256(payload).hexdigest(),
        adapter_id=f"synthetic_{unit['adapter']}",
    )


def _validate_canary_input(value: CanaryInput) -> None:
    n = len(value.cell_ids)
    if n < 2 or value.coordinates.shape != (n, 2) or value.expression_embedding.shape[0] != n:
        raise CanaryPreflightError("Canary input dimensions are inconsistent.")
    if len(set(map(str, value.cell_ids))) != n or not np.isfinite(value.coordinates).all() or not np.isfinite(value.expression_embedding).all():
        raise CanaryPreflightError("Canary input identifiers, coordinates, or expression values are invalid.")


def _frozen_dataset_record(bundle: Mapping[str, Any], dataset_id: str) -> Mapping[str, Any]:
    records = [row for row in bundle["dataset_freeze"]["datasets"] if str(row["dataset_id"]) == dataset_id]
    if len(records) != 1:
        raise CanaryPreflightError(f"Synthetic canary dataset is not uniquely frozen: {dataset_id}")
    return records[0]


def frozen_target_n_for_unit(bundle: Mapping[str, Any], unit: Mapping[str, Any]) -> int:
    """Read one exact registered target size; never recompute it from a fraction."""

    matches = [
        row
        for row in bundle["fraction_matrix"]["rows"]
        if str(row["dataset_id"]) == str(unit["dataset_id"])
        and str(row["sample_id"]) == str(unit["sample_id"])
        and float(row["fraction"]) == float(unit["fraction"])
        and bool(row["formal_execution_allowed"])
    ]
    if len(matches) != 1:
        raise CanaryPreflightError("Frozen canary unit has no unique executable final_target_n.")
    return int(matches[0]["final_target_n"])


def prepare_frozen_canary_unit_input(
    *,
    unit: Mapping[str, Any],
    bundle: Mapping[str, Any],
    data_root: str | Path,
    preprocessing_config: Mapping[str, Any],
    code_commit: str,
) -> FrozenCanaryPreparedInput:
    """Wire a frozen raw adapter to the appropriate protocol object.

    A later, separately authorized real canary may call this function only
    after frozen file identity verification.  It has no sampler, storage, or
    output side effect on its own.
    """

    dataset = _frozen_dataset_record(bundle, str(unit["dataset_id"]))
    raw_population = load_frozen_unit_raw_input(
        execution_unit=unit,
        dataset_freeze=bundle["dataset_freeze"],
        data_root=data_root,
    )
    targeted_panel = bool(dataset["targeted_panel"])
    panel_manifest_name = str(dataset["panel_gene_manifest"]) if targeted_panel else None
    target_n = frozen_target_n_for_unit(bundle, unit)
    inference_population = prepare_inference_population(
        raw_population,
        config=preprocessing_config,
        dataset_id=str(unit["dataset_id"]),
        sample_id=str(unit["sample_id"]),
        targeted_panel=targeted_panel,
        panel_manifest_name=panel_manifest_name,
        code_commit=code_commit,
    )
    if str(unit["task"]) == "representation":
        representation_input = prepare_representation_input(
            raw_population,
            config=preprocessing_config,
            dataset_id=str(unit["dataset_id"]),
            sample_id=str(unit["sample_id"]),
            target_n=target_n,
            targeted_panel=targeted_panel,
            panel_manifest_name=panel_manifest_name,
            code_commit=code_commit,
        )
        spatial_design = representation_input.spatial_design
    else:
        representation_input = None
        spatial_design = build_frozen_spatial_design(
            inference_population,
            target_n=target_n,
            config=preprocessing_config,
        )
    return FrozenCanaryPreparedInput(
        execution_unit_id=str(unit["execution_unit_id"]),
        target_n=target_n,
        raw_population=raw_population,
        inference_population=inference_population,
        representation_input=representation_input,
        spatial_design=spatial_design,
    )


def _synthetic_raw_population(unit: Mapping[str, Any], value: CanaryInput, *, targeted_panel: bool) -> FormalRawInput:
    source_files = ("synthetic_matrix.h5", "synthetic_coordinates.parquet")
    if targeted_panel:
        source_files = (*source_files, "gene_panel.json")
    return FormalRawInput(
        cell_ids=value.cell_ids,
        expression_matrix=sparse.csr_matrix(value.expression_embedding),
        coordinates=value.coordinates,
        adapter_id=value.adapter_id,
        source_files=source_files,
        source_identity_sha256=value.input_hash,
        gene_ids=np.asarray([f"synthetic_gene_{index:04d}" for index in range(value.expression_embedding.shape[1])], dtype=str),
    )


def _draw_for_unit(
    unit: Mapping[str, Any],
    value: CanaryInput,
    *,
    bundle: Mapping[str, Any],
    preprocessing_config: Mapping[str, Any],
    code_commit: str,
) -> tuple[Any, dict[str, Any]]:
    _validate_canary_input(value)
    target_n = max(4, int(np.floor(len(value.cell_ids) * float(unit["fraction"]))))
    target_n = min(target_n, len(value.cell_ids))
    dataset = _frozen_dataset_record(bundle, str(unit["dataset_id"]))
    targeted_panel = bool(dataset["targeted_panel"])
    panel_manifest_name = str(dataset["panel_gene_manifest"]) if targeted_panel else None
    raw_population = _synthetic_raw_population(unit, value, targeted_panel=targeted_panel)
    inference_population = prepare_inference_population(
        raw_population,
        config=preprocessing_config,
        dataset_id=str(unit["dataset_id"]),
        sample_id=str(unit["sample_id"]),
        targeted_panel=targeted_panel,
        panel_manifest_name=panel_manifest_name,
        code_commit=code_commit,
    )
    if str(unit["task"]) == "representation":
        representation_input = prepare_representation_input(
            raw_population,
            config=preprocessing_config,
            dataset_id=str(unit["dataset_id"]),
            sample_id=str(unit["sample_id"]),
            target_n=target_n,
            targeted_panel=targeted_panel,
            panel_manifest_name=panel_manifest_name,
            code_commit=code_commit,
        )
        strata = representation_input.spatial_design.stratum_ids
        quotas = representation_input.spatial_design.quotas
        expression_embedding = representation_input.expression_embedding
        preprocessing_manifest = representation_input.preprocessing_manifest
    elif str(unit["method"]) == "uniform_srs":
        strata = np.full(len(value.cell_ids), "global", dtype=object)
        quotas = {"global": target_n}
        expression_embedding = np.empty((len(value.cell_ids), 0), dtype=float)
        preprocessing_manifest = inference_population.preprocessing_manifest
    else:
        spatial_design = build_frozen_spatial_design(
            inference_population,
            target_n=target_n,
            config=preprocessing_config,
        )
        strata = spatial_design.stratum_ids
        quotas = spatial_design.quotas
        expression_embedding = np.empty((len(value.cell_ids), 0), dtype=float)
        preprocessing_manifest = dict(inference_population.preprocessing_manifest)
        preprocessing_manifest["spatial_design"] = {
            "n_x": spatial_design.partition.n_x,
            "n_y": spatial_design.partition.n_y,
            "nonempty_strata": len(spatial_design.partition.stratum_audit),
            "quota_sum": sum(spatial_design.quotas.values()),
        }
    draw = run_registered_r2_method(
        method_id=str(unit["method"]),
        cell_ids=value.cell_ids,
        coordinates=value.coordinates,
        spatial_strata=strata,
        quotas=quotas,
        expression_embedding=expression_embedding,
        target_n=target_n,
        dataset_id=f"synthetic_{unit['dataset_id']}",
        target_fraction=float(unit["fraction"]),
        benchmark_repeat_seed=int(unit["seed"]),
    )
    return draw, {
        "synthetic_target_n": target_n,
        "spatial_quotas": quotas,
        "spatial_strata_count": len(quotas),
        "preprocessing_manifest": preprocessing_manifest,
        "preprocessing_protocol_id": preprocessing_manifest["protocol_id"],
        "preprocessing_cache_key": preprocessing_manifest["preprocessing_cache_key"],
    }


def _serialise_selected(draw: Any) -> str:
    return draw.selected_cells.to_csv(index=False, lineterminator="\n")


def _stage_success_attempt(
    publisher: AppendOnlyRunPublisher,
    *,
    unit: Mapping[str, Any],
    manifest: Mapping[str, Any],
    input_identity_sha256: str,
    adapter_id: str,
    source_files: Sequence[str],
    synthetic_input: bool,
    preprocessing_manifest: Mapping[str, Any],
    draw: Any,
    runtime: Mapping[str, Any],
) -> Any:
    attempt = publisher.begin(
        run_id=f"canary_{unit['execution_unit_id']}",
        method_id=str(unit["method"]),
        config_hash=str(manifest["canary_manifest_sha256"]),
        code_commit=str(runtime["sampler_code_commit"]),
    )
    publisher.backend.mark_running(attempt)
    publisher.backend.stage_json(
        attempt,
        "input_manifest.json",
        {
            "engineering_only": True,
            "execution_unit_id": unit["execution_unit_id"],
            "input_identity_sha256": input_identity_sha256,
            "adapter_id": adapter_id,
            "source_files": list(source_files),
            "synthetic_input": bool(synthetic_input),
            "preprocessing_manifest": dict(preprocessing_manifest),
        },
    )
    publisher.backend.stage_json(
        attempt,
        "runtime_manifest.json",
        {
            "engineering_only": True,
            "execution_unit": dict(unit),
            "canary_manifest_sha256": manifest["canary_manifest_sha256"],
            "input_manifest_sha256": manifest["input_manifest_sha256"],
            "benchmark_config_sha256": manifest["benchmark_config_sha256"],
            "freeze_manifest_sha256": manifest["freeze_manifest_sha256"],
            "sampler_called": True,
            "sampler_registry_id": draw.method_id,
            **dict(runtime),
        },
    )
    publisher.backend.stage_text(attempt, "method_output/selected_cells.csv", _serialise_selected(draw))
    publisher.backend.stage_json(
        attempt,
        "method_output/metadata.json",
        {"engineering_only": True, "method_id": draw.method_id, "metadata": dict(draw.metadata)},
    )
    publisher.backend.stage_json(
        attempt,
        "endpoint_output/engineering_endpoint_status.json",
        {"engineering_only": True, "endpoint_set": list(unit["endpoint_set"]), "scientific_summary": "not_generated"},
    )
    publisher.backend.stage_json(attempt, "logs/runtime.json", {"engineering_only": True, **dict(runtime)})
    return publisher.backend.publish(attempt, previous_status="RUNNING")


def _stage_failure_attempt(
    publisher: AppendOnlyRunPublisher,
    *,
    unit: Mapping[str, Any],
    manifest: Mapping[str, Any],
    code_commit: str,
    error: BaseException,
    interrupted: bool,
    traceback_text: str | None = None,
) -> Any:
    attempt = publisher.begin(
        run_id=f"canary_{unit['execution_unit_id']}",
        method_id=str(unit["method"]),
        config_hash=str(manifest["canary_manifest_sha256"]),
        code_commit=code_commit,
    )
    publisher.backend.mark_running(attempt)
    publisher.backend.stage_json(
        attempt,
        "logs/failure.json",
        {
            "engineering_only": True,
            "execution_unit_id": unit["execution_unit_id"],
            "interrupted": interrupted,
            "error_type": type(error).__name__,
            "error": str(error),
            "traceback": traceback_text,
        },
    )
    return publisher.backend.publish_failure(
        attempt,
        previous_status="RUNNING",
        incomplete=interrupted,
        error={"error_type": type(error).__name__, "message": str(error)},
    )


def run_synthetic_canary(
    *,
    repo_root: str | Path,
    local_staging_root: str | Path,
    engineering_results_root: str | Path,
    resume: bool = False,
    retry_failed: bool = False,
    input_provider: Callable[[Mapping[str, Any]], CanaryInput] = synthetic_canary_input,
    interrupt_after_sampler_calls: int | None = None,
    fail_unit_id: str | None = None,
) -> dict[str, Any]:
    """Exercise all six frozen units with synthetic data and real samplers.

    It is the only executable path in this change set.  Production raw-input
    adapter execution remains separately authorized; this prevents a test or
    accidental local invocation from touching real external inputs.
    """

    root = Path(repo_root)
    bundle = load_freeze_bundle(root)
    preprocessing_config = load_formal_preprocessing_config(root)
    units, manifest = frozen_canary_units(root, bundle)
    for unit in units:
        validate_unit_method_capability(unit, bundle["benchmark"])
    storage = SSHFSAppendOnlyBackend(
        StorageConfig(
            local_staging_root=Path(local_staging_root),
            remote_results_root=Path(engineering_results_root),
            backend="sshfs_append_only",
        )
    )
    code_commit = current_git_commit(root)
    rows: list[dict[str, Any]] = []
    sampler_calls = 0
    for unit in units:
        run_id = f"canary_{unit['execution_unit_id']}"
        existing = storage.replay_events().get(run_id)
        if storage.has_verified_success(run_id):
            rows.append({"execution_unit_id": unit["execution_unit_id"], "status": "SKIPPED_ALREADY_SUCCESS", "sampler_called": False})
            continue
        if existing and existing.get("status") in {"FAIL", "FAILURE", "INCOMPLETE", "INTERRUPTED", "PUBLISH_FAILED"} and not (resume and retry_failed):
            stored_status = str(existing["status"])
            visible_status = "FAILURE" if stored_status == "FAIL" else ("INCOMPLETE" if stored_status == "INTERRUPTED" else stored_status)
            rows.append({"execution_unit_id": unit["execution_unit_id"], "status": visible_status, "sampler_called": False})
            continue
        start = time.perf_counter()
        tracemalloc.start()
        publisher = AppendOnlyRunPublisher(storage)
        try:
            value = input_provider(unit)
            if str(unit["execution_unit_id"]) == str(fail_unit_id):
                raise RuntimeError("Injected synthetic canary failure.")
            draw, sampling_audit = _draw_for_unit(
                unit,
                value,
                bundle=bundle,
                preprocessing_config=preprocessing_config,
                code_commit=code_commit,
            )
            sampler_calls += 1
            if interrupt_after_sampler_calls is not None and sampler_calls >= interrupt_after_sampler_calls:
                raise CanaryInterrupted("Injected interruption after a sampler call.")
            _, peak_bytes = tracemalloc.get_traced_memory()
            elapsed = time.perf_counter() - start
            runtime = {
                "runtime_seconds": elapsed,
                "peak_memory_bytes": int(peak_bytes),
                "sampler_code_commit": code_commit,
                "seed": int(unit["seed"]),
                "output_hash": sha256(_serialise_selected(draw).encode("utf-8")).hexdigest(),
                "exit_status": "SUCCESS",
                **sampling_audit,
            }
            _stage_success_attempt(
                publisher,
                unit=unit,
                manifest=manifest,
                input_identity_sha256=value.input_hash,
                adapter_id=value.adapter_id,
                source_files=(),
                synthetic_input=True,
                preprocessing_manifest=sampling_audit["preprocessing_manifest"],
                draw=draw,
                runtime=runtime,
            )
            rows.append({"execution_unit_id": unit["execution_unit_id"], "status": "SUCCESS", "sampler_called": True, **runtime})
        except CanaryInterrupted as error:
            _stage_failure_attempt(
                publisher,
                unit=unit,
                manifest=manifest,
                code_commit=code_commit,
                error=error,
                interrupted=True,
                traceback_text=traceback.format_exc(),
            )
            rows.append({"execution_unit_id": unit["execution_unit_id"], "status": "INCOMPLETE", "sampler_called": True})
            break
        except Exception as error:
            _stage_failure_attempt(
                publisher,
                unit=unit,
                manifest=manifest,
                code_commit=code_commit,
                error=error,
                interrupted=False,
                traceback_text=traceback.format_exc(),
            )
            rows.append({"execution_unit_id": unit["execution_unit_id"], "status": "FAILURE", "sampler_called": False})
        finally:
            tracemalloc.stop()
    counts = {status: sum(row["status"] == status for row in rows) for status in sorted({row["status"] for row in rows})}
    status = "CANARY_SUCCESS" if counts.get("SUCCESS", 0) + counts.get("SKIPPED_ALREADY_SUCCESS", 0) == CANARY_UNIT_COUNT else (
        "CANARY_INCOMPLETE" if counts.get("INCOMPLETE", 0) else "CANARY_PARTIAL_FAILURE"
    )
    summary = {
        "engineering_only": True,
        "status": status,
        "frozen_unit_count": CANARY_UNIT_COUNT,
        "unit_status_counts": counts,
        "sampler_calls": sampler_calls,
        "resume": bool(resume),
        "retry_failed": bool(retry_failed),
        "canary_manifest_sha256": manifest["canary_manifest_sha256"],
        "units": rows,
        "scientific_summary": "not_generated",
    }
    storage.publish_immutable_provenance(
        provenance_id=f"engineering_canary_summary_{int(time.time_ns())}",
        artifacts={"engineering_canary_summary.json": _canonical_json(summary)},
        metadata={"engineering_only": True, "status": status, "scientific_summary": "not_generated"},
    )
    return summary


def _draw_prepared_real_unit(unit: Mapping[str, Any], prepared: FrozenCanaryPreparedInput) -> tuple[Any, dict[str, Any]]:
    """Dispatch one already-authorized real unit through existing frozen methods."""

    raw = prepared.raw_population
    if str(unit["task"]) == "representation":
        if prepared.representation_input is None:
            raise CanaryPreflightError("Representation unit is missing its frozen representation input.")
        spatial_strata = prepared.representation_input.spatial_design.stratum_ids
        quotas = prepared.representation_input.spatial_design.quotas
        embedding = prepared.representation_input.expression_embedding
        preprocessing_manifest = prepared.representation_input.preprocessing_manifest
    elif str(unit["method"]) == "uniform_srs":
        spatial_strata = np.full(raw.n_obs, "global", dtype=object)
        quotas = {"global": prepared.target_n}
        embedding = np.empty((raw.n_obs, 0), dtype=float)
        preprocessing_manifest = prepared.inference_population.preprocessing_manifest
    else:
        spatial_strata = prepared.spatial_design.stratum_ids
        quotas = prepared.spatial_design.quotas
        embedding = np.empty((raw.n_obs, 0), dtype=float)
        preprocessing_manifest = dict(prepared.inference_population.preprocessing_manifest)
        preprocessing_manifest["spatial_design"] = {
            "n_x": prepared.spatial_design.partition.n_x,
            "n_y": prepared.spatial_design.partition.n_y,
            "nonempty_strata": len(prepared.spatial_design.partition.stratum_audit),
            "quota_sum": sum(prepared.spatial_design.quotas.values()),
        }
    draw = run_registered_r2_method(
        method_id=str(unit["method"]),
        cell_ids=raw.cell_ids,
        coordinates=raw.coordinates,
        spatial_strata=spatial_strata,
        quotas=quotas,
        expression_embedding=embedding,
        target_n=prepared.target_n,
        dataset_id=str(unit["dataset_id"]),
        target_fraction=float(unit["fraction"]),
        benchmark_repeat_seed=int(unit["seed"]),
    )
    return draw, {
        "frozen_target_n": prepared.target_n,
        "spatial_quotas": quotas,
        "spatial_strata_count": len(quotas),
        "preprocessing_manifest": preprocessing_manifest,
        "preprocessing_protocol_id": preprocessing_manifest["protocol_id"],
        "preprocessing_cache_key": preprocessing_manifest["preprocessing_cache_key"],
    }


def run_authorized_real_canary(
    *,
    repo_root: str | Path,
    authorization: CanaryAuthorization,
    data_root: str | Path,
    formal_results_root: str | Path,
    local_staging_root: str | Path,
    max_workers: int = 1,
    threads_per_worker: int = 1,
    resume: bool = False,
    retry_failed: bool = False,
) -> dict[str, Any]:
    """Run only the six frozen real-data engineering canary units.

    All authorization and frozen-input identity checks finish before this
    function creates a storage backend or a run attempt.  It is intentionally
    separate from every formal Representation, Inference, and summary phase.
    """

    root = Path(repo_root)
    bundle = load_freeze_bundle(root)
    validate_freeze_bundle(bundle)
    units, manifest = frozen_canary_units(root, bundle)
    for unit in units:
        validate_unit_method_capability(unit, bundle["benchmark"])
    preprocessing_config = load_formal_preprocessing_config(root)
    policy = load_canary_runner_config(root)
    validate_canary_authorization(
        authorization,
        bundle=bundle,
        canary_units=units,
        canary_manifest=manifest,
        preprocessing_config=preprocessing_config,
        global_runner_policy=policy,
        phase="canary",
        max_workers=max_workers,
        threads_per_worker=threads_per_worker,
        requested_overrides={
            "method": None,
            "fraction": None,
            "seed": None,
            "sample": None,
            "dataset": None,
            "endpoint": None,
            "execution_unit": None,
        },
        result_subdirectory=ENGINEERING_DIRECTORY,
    )
    preflight = verify_canary_preflight(
        repo_root=root,
        data_root=data_root,
        results_root=formal_results_root,
        require_data_identity=True,
        require_clean_worktree=True,
        check_result_storage_capability=False,
    )
    storage = SSHFSAppendOnlyBackend(
        StorageConfig(
            local_staging_root=Path(local_staging_root),
            remote_results_root=Path(formal_results_root) / ENGINEERING_DIRECTORY,
            backend="sshfs_append_only",
        )
    )
    code_commit = current_git_commit(root)
    rows: list[dict[str, Any]] = []
    sampler_calls = 0
    for unit in units:
        run_id = f"canary_{unit['execution_unit_id']}"
        existing = storage.replay_events().get(run_id)
        if storage.has_verified_success(run_id):
            rows.append({"execution_unit_id": unit["execution_unit_id"], "status": "SKIPPED_ALREADY_SUCCESS", "sampler_called": False})
            continue
        if existing and existing.get("status") in {"FAIL", "FAILURE", "INCOMPLETE", "INTERRUPTED", "PUBLISH_FAILED"} and not (resume and retry_failed):
            stored_status = str(existing["status"])
            visible_status = "FAILURE" if stored_status == "FAIL" else ("INCOMPLETE" if stored_status == "INTERRUPTED" else stored_status)
            rows.append({"execution_unit_id": unit["execution_unit_id"], "status": visible_status, "sampler_called": False})
            continue
        start = time.perf_counter()
        tracemalloc.start()
        publisher = AppendOnlyRunPublisher(storage)
        try:
            prepared = prepare_frozen_canary_unit_input(
                unit=unit,
                bundle=bundle,
                data_root=data_root,
                preprocessing_config=preprocessing_config,
                code_commit=code_commit,
            )
            draw, sampling_audit = _draw_prepared_real_unit(unit, prepared)
            sampler_calls += 1
            _, peak_bytes = tracemalloc.get_traced_memory()
            runtime = {
                "runtime_seconds": time.perf_counter() - start,
                "peak_memory_bytes": int(peak_bytes),
                "sampler_code_commit": code_commit,
                "seed": int(unit["seed"]),
                "output_hash": sha256(_serialise_selected(draw).encode("utf-8")).hexdigest(),
                "exit_status": "SUCCESS",
                "authorization_sha256": authorization.authorization_sha256,
                "real_data_execution": True,
                **sampling_audit,
            }
            _stage_success_attempt(
                publisher,
                unit=unit,
                manifest=manifest,
                input_identity_sha256=prepared.raw_population.source_identity_sha256,
                adapter_id=prepared.raw_population.adapter_id,
                source_files=prepared.raw_population.source_files,
                synthetic_input=False,
                preprocessing_manifest=sampling_audit["preprocessing_manifest"],
                draw=draw,
                runtime=runtime,
            )
            rows.append({"execution_unit_id": unit["execution_unit_id"], "status": "SUCCESS", "sampler_called": True, **runtime})
        except Exception as error:
            _stage_failure_attempt(
                publisher,
                unit=unit,
                manifest=manifest,
                code_commit=code_commit,
                error=error,
                interrupted=False,
                traceback_text=traceback.format_exc(),
            )
            rows.append({"execution_unit_id": unit["execution_unit_id"], "status": "FAILURE", "sampler_called": False})
        finally:
            tracemalloc.stop()
    counts = {status: sum(row["status"] == status for row in rows) for status in sorted({row["status"] for row in rows})}
    status = "CANARY_SUCCESS" if counts.get("SUCCESS", 0) + counts.get("SKIPPED_ALREADY_SUCCESS", 0) == CANARY_UNIT_COUNT else "CANARY_PARTIAL_FAILURE"
    summary = {
        "engineering_only": True,
        "real_data_execution": True,
        "authorization_sha256": authorization.authorization_sha256,
        "status": status,
        "frozen_unit_count": CANARY_UNIT_COUNT,
        "unit_status_counts": counts,
        "sampler_calls": sampler_calls,
        "resume": bool(resume),
        "retry_failed": bool(retry_failed),
        "canary_manifest_sha256": manifest["canary_manifest_sha256"],
        "units": rows,
        "scientific_summary": "not_generated",
        "preflight": preflight,
    }
    storage.publish_immutable_provenance(
        provenance_id=f"engineering_real_canary_summary_{int(time.time_ns())}",
        artifacts={"engineering_canary_summary.json": _canonical_json(summary)},
        metadata={
            "engineering_only": True,
            "real_data_execution": True,
            "status": status,
            "scientific_summary": "not_generated",
        },
    )
    return summary


__all__ = [
    "CANARY_BASE_COMMIT",
    "CANARY_CONFIG_PATH",
    "CANARY_RUNNER_CONFIG_PATH",
    "CANARY_STATUSES",
    "CanaryInput",
    "CanaryInterrupted",
    "CanaryManifestDriftError",
    "CanaryMethodCapabilityError",
    "CanaryPreflightError",
    "FrozenCanaryPreparedInput",
    "current_git_commit",
    "frozen_canary_units",
    "frozen_target_n_for_unit",
    "load_canary_runner_config",
    "prepare_frozen_canary_unit_input",
    "run_authorized_real_canary",
    "run_synthetic_canary",
    "synthetic_canary_input",
    "validate_unit_method_capability",
    "verify_canary_preflight",
]
