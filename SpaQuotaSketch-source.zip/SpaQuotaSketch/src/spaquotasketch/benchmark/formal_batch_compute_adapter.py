"""Thin local-output adapter for the frozen formal Representation unit path."""
from __future__ import annotations
from hashlib import sha256
from pathlib import Path
import time, tracemalloc
from typing import Any, Mapping
from .formal_multiplatform_canary_runner import _draw_prepared_real_unit, prepare_frozen_canary_unit_input
from .formal_multiplatform_representation_runner import _build_formal_success_artifacts

def formal_batch_compute_adapter(unit_spec: Mapping[str, Any], local_output_dir: Path, runtime_context: Mapping[str, Any]) -> Mapping[str, Path]:
    """Run the existing single-unit formal path and write only local artifacts."""
    prepared=prepare_frozen_canary_unit_input(unit=unit_spec,bundle=runtime_context['bundle'],data_root=runtime_context['data_root'],preprocessing_config=runtime_context['preprocessing_config'],code_commit=runtime_context['code_commit'])
    start=time.perf_counter();tracemalloc.start()
    try:
        draw,audit=_draw_prepared_real_unit(unit_spec,prepared);_,peak=tracemalloc.get_traced_memory()
    finally: tracemalloc.stop()
    runtime={'runtime_seconds':time.perf_counter()-start,'peak_memory_bytes':int(peak),'sampler_code_commit':runtime_context['code_commit'],'seed':int(unit_spec['seed']),'output_hash':sha256(draw.selected_cells.to_csv(index=False,lineterminator='\n').encode()).hexdigest(),'exit_status':'SUCCESS','authorization_sha256':runtime_context['authorization_sha256'],'real_data_execution':True,**audit}
    artifacts=_build_formal_success_artifacts(unit=unit_spec,manifest=runtime_context['manifest'],input_identity_sha256=prepared.raw_population.source_identity_sha256,adapter_id=prepared.raw_population.adapter_id,source_files=prepared.raw_population.source_files,preprocessing_manifest=audit['preprocessing_manifest'],draw=draw,runtime=runtime)
    paths={}
    for name,payload in artifacts.items():
        path=local_output_dir/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(payload);paths[name]=path
    return paths
