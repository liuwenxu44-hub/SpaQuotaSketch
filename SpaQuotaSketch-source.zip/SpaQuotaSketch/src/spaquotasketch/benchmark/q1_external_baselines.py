"""Frozen-input entrypoints for external Q1 expression-space baselines."""

from __future__ import annotations

from typing import Iterable

import numpy as np

from .q1_input_fingerprints import validate_frozen_pca_input


def run_geosketch_on_frozen_pca(
    cell_ids: Iterable[object],
    pca_values: np.ndarray,
    *,
    expected_ordered_cell_id_sha256: str,
    expected_pca_matrix_sha256: str,
    target_n: int,
    seed: int,
) -> np.ndarray:
    """Run GeoSketch only after verifying the registered PCA row order.

    Annotation labels are intentionally absent from this interface.
    """
    values = np.asarray(pca_values, dtype=np.float64)
    validate_frozen_pca_input(
        cell_ids,
        values,
        expected_ordered_cell_id_sha256=expected_ordered_cell_id_sha256,
        expected_pca_matrix_sha256=expected_pca_matrix_sha256,
    )
    if not 1 <= int(target_n) <= values.shape[0]:
        raise ValueError("target_n must be between one and the number of PCA rows.")
    import geosketch

    selected = np.asarray(geosketch.gs(values, int(target_n), seed=int(seed)), dtype=int)
    if selected.size != int(target_n) or np.unique(selected).size != int(target_n):
        raise RuntimeError("GeoSketch did not return exactly target_n unique indices.")
    if selected.min(initial=0) < 0 or selected.max(initial=-1) >= values.shape[0]:
        raise RuntimeError("GeoSketch returned an out-of-range index.")
    return selected
