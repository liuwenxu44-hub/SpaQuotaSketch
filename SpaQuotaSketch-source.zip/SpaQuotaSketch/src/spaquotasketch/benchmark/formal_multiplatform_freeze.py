"""Build and validate the frozen external multi-platform benchmark plan.

This module is intentionally configuration-only.  It does not import a sampler,
open a qualified expression matrix, or create a benchmark result directory.
"""

from __future__ import annotations

from hashlib import sha256
import json
from pathlib import Path
import subprocess
from typing import Any, Iterable, Mapping

import yaml

from spaquotasketch.samplers.registry import get_method_metadata


FORMAL_DATASET_STATUSES = frozenset({"FULLY_QUALIFIED", "FULLY_QUALIFIED_LIMITED_ENDPOINTS"})
FORMAL_METHODS = (
    "quota_completed_representation_mode",
    "uniform_srs",
    "spatial_stratified_srs",
    "spatial_pivotal",
)
REPRESENTATION_METHODS = FORMAL_METHODS
INFERENCE_METHODS = ("uniform_srs", "spatial_stratified_srs", "spatial_pivotal")
FROZEN_FRACTIONS = (0.005, 0.01, 0.02, 0.05, 0.1)
INPUT_ROOT_PLACEHOLDER = "${SPAQUOTASKETCH_EXTERNAL_INPUT_ROOT}"
RESULTS_ROOT_PLACEHOLDER = "${SPAQUOTASKETCH_RESULTS_ROOT}/formal_multiplatform_benchmark_v1"


class FreezeValidationError(ValueError):
    """Raised when a proposed formal plan conflicts with frozen evidence."""


def load_yaml(path: str | Path) -> dict[str, Any]:
    """Load one tracked YAML mapping with a clear error for malformed input."""
    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, Mapping):
        raise FreezeValidationError(f"Expected a YAML mapping in {path}.")
    return dict(payload)


def canonical_sha256(value: Any) -> str:
    """Hash JSON with a fixed representation, independent of YAML formatting."""
    content = json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
    return sha256(content.encode("utf-8")).hexdigest()


def repository_commit(repo_root: str | Path) -> str:
    """Return the exact repository commit that is frozen into the plan."""
    return subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=Path(repo_root), text=True, encoding="utf-8"
    ).strip()


def _source_candidates(pool: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    candidates = list(pool.get("primary_candidates", [])) + list(pool.get("backup_candidates", []))
    return {str(item["candidate_id"]): item for item in candidates}


def _dataset_by_id(batch: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    return {str(item["candidate_id"]): item for item in batch["datasets"]}


def _sample_by_key(status: Mapping[str, Any]) -> dict[tuple[str, str], Mapping[str, Any]]:
    return {(str(item["dataset_id"]), str(item["sample_id"])): item for item in status["samples"]}


def _checksum_by_path(checksums: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    return {str(item["relative_path"]): item for item in checksums["files"]}


def _platform_family(platform: str) -> str:
    if platform.startswith("Xenium"):
        return "Xenium_family"
    if platform.startswith("Visium"):
        return "Visium_family"
    return platform


def _file_requirement(file_specification: Mapping[str, Any]) -> tuple[bool, bool]:
    role = str(file_specification["role"])
    required = bool(file_specification.get("required", True))
    if role == "PANEL_DEFINITION":
        return required, required
    return True, True


def _availability(sample_record: Mapping[str, Any]) -> tuple[list[float], list[float], dict[str, str]]:
    available: list[float] = []
    unavailable: list[float] = []
    reasons: dict[str, str] = {}
    for record in sample_record.get("structural_feasibility") or []:
        fraction = float(record["fraction"])
        if bool(record["input_structurally_feasible"]):
            available.append(fraction)
        else:
            unavailable.append(fraction)
            reasons[f"{fraction:.3f}"] = "STRUCTURALLY_INFEASIBLE_FROM_QUALIFICATION"
    return available, unavailable, reasons


def _endpoint_rows(dataset: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Declare only input-supported endpoints, retaining structural missingness."""
    dataset_id = str(dataset["dataset_id"])
    targeted = bool(dataset["targeted_panel"])
    stratum = "TARGETED_PANEL_STRATUM" if targeted else "WTS_STRATUM"
    common = {
        "dataset_id": dataset_id,
        "aggregation_group": stratum,
        "statistical_unit": "dataset_then_sample_then_seed",
        "targeted_panel_comparable": targeted,
    }

    def row(endpoint: str, *, task: str, available: bool, primary: bool, reason: str, required: list[str]) -> dict[str, Any]:
        return {
            **common,
            "endpoint": endpoint,
            "task": task,
            "available": available,
            "primary": primary if available else False,
            "secondary": bool(available and not primary),
            "prohibited": not available,
            "reason": reason,
            "required_input": required,
            "endpoint_restriction": (
                "panel_genes_only; aggregate_within_dataset_standardized_effects_or_rank"
                if targeted and available and "expression" in endpoint
                else "none"
            ),
        }

    rows = [
        row("expression_state_coverage", task="representation", available=True, primary=True,
            reason="expression_matrix_and_frozen_reference_embedding_available", required=["expression_matrix"]),
        row("spatial_coverage", task="representation", available=True, primary=True,
            reason="spatial_coordinates_and_unique_aligned_ids_available", required=["spatial_coordinates", "unit_ids"]),
        row("cell_type_proportion_error", task="representation", available=False, primary=False,
            reason="NOT_AVAILABLE_NO_LABEL", required=["cell_type_label"]),
        row("spatial_domain_distribution_error", task="representation", available=False, primary=False,
            reason="NOT_AVAILABLE_NO_DOMAIN", required=["spatial_domain_label"]),
        row("neighborhood_preservation", task="representation", available=False, primary=False,
            reason="NOT_AVAILABLE_NO_GROUND_TRUTH", required=["frozen_neighborhood_reference"]),
        row("rare_state_recall", task="representation", available=False, primary=False,
            reason="NOT_AVAILABLE_NO_LABEL", required=["rare_state_label"]),
        row("downstream_task_preservation", task="representation", available=False, primary=False,
            reason="NOT_AVAILABLE_NO_GROUND_TRUTH", required=["frozen_downstream_reference"]),
        row("gene_mean_error", task="inference", available=True, primary=True,
            reason="full_population_gene_means_are_definable", required=["expression_matrix", "inclusion_probability"]),
        row("gene_total_error", task="inference", available=True, primary=True,
            reason="full_population_gene_totals_are_definable", required=["expression_matrix", "inclusion_probability"]),
        row("expression_program_mean_error", task="inference", available=False, primary=False,
            reason="NOT_AVAILABLE_NO_GROUND_TRUTH", required=["preregistered_expression_programs"]),
        row("cell_type_proportion_error", task="inference", available=False, primary=False,
            reason="NOT_AVAILABLE_NO_LABEL", required=["cell_type_label", "inclusion_probability"]),
        row("spatial_domain_proportion_error", task="inference", available=False, primary=False,
            reason="NOT_AVAILABLE_NO_DOMAIN", required=["spatial_domain_label", "inclusion_probability"]),
        row("confidence_interval_coverage", task="inference", available=False, primary=False,
            reason="NOT_AVAILABLE_NO_GROUND_TRUTH", required=["registered_interval_estimator"]),
        row("standard_error_calibration", task="inference", available=False, primary=False,
            reason="NOT_AVAILABLE_NO_GROUND_TRUTH", required=["registered_standard_error_estimator"]),
        row("design_diagnostics", task="inference", available=True, primary=False,
            reason="first_order_probability_and_weight_diagnostics_are_registered", required=["inclusion_probability", "sampling_weight"]),
    ]
    return rows


def _method_record(method_id: str) -> dict[str, Any]:
    metadata = get_method_metadata(method_id).values
    return {
        "registry_id": method_id,
        "implementation_module": metadata.get("implementation_entrypoint", f"spaquotasketch.framework:{method_id}"),
        "capability": {
            "supported_modes": list(metadata["supported_modes"]),
            "uses_expression": bool(metadata["uses_expression"]),
            "uses_spatial_coordinates": bool(metadata["uses_spatial_coordinates"]),
            "probability_design": metadata["probability_design"],
            "supports_ht": bool(metadata["supports_ht"]),
            "supports_hajek": bool(metadata["supports_hajek"]),
        },
        "formal_or_legacy": metadata["legacy_status"],
        "representation_allowed": "representation" in metadata["supported_modes"],
        "inference_allowed": "inference" in metadata["supported_modes"],
        "inclusion_probability_available": bool(metadata["has_positive_inclusion_probability"]),
        "sampling_weight_allowed": bool(metadata["returns_sampling_weight"]),
        "version": metadata["algorithm_version"],
        "parameter_defaults": "public_frozen_defaults_only",
        "dataset_specific_parameter_changes_allowed": False,
    }


def build_freeze_bundle(repo_root: str | Path, *, code_commit: str | None = None) -> dict[str, Any]:
    """Derive every formal record from the qualification status authority."""
    root = Path(repo_root)
    status = load_yaml(root / "configs/final_external_dataset_status.yaml")
    checksums = load_yaml(root / "configs/final_external_input_checksums.yaml")
    batch = load_yaml(root / "configs/final_external_input_batch_qualification.yaml")
    pool = load_yaml(root / "configs/final_external_candidate_pool.yaml")
    protocol = load_yaml(root / "configs/multiplatform_benchmark_protocol.yaml")
    if status.get("final_decision") != "READY_TO_FREEZE_FORMAL_BENCHMARK_INPUTS":
        raise FreezeValidationError("Formal input status is not ready to freeze.")

    qualified = [item for item in status["datasets"] if item["final_status"] in FORMAL_DATASET_STATUSES]
    if len(qualified) != 6:
        raise FreezeValidationError(f"Expected exactly 6 qualified formal datasets, found {len(qualified)}.")
    sources = _source_candidates(pool)
    batch_datasets = _dataset_by_id(batch)
    samples = _sample_by_key(status)
    checksum_records = _checksum_by_path(checksums)
    dataset_freeze: list[dict[str, Any]] = []
    manifest_files: list[dict[str, Any]] = []
    fraction_rows: list[dict[str, Any]] = []
    endpoint_rows: list[dict[str, Any]] = []

    for qualified_record in qualified:
        dataset_id = str(qualified_record["dataset_id"])
        dataset = batch_datasets[dataset_id]
        source = sources[dataset_id]
        frozen_sample_ids = [
            str(item["sample_id"])
            for item in dataset["samples"]
            if samples[(dataset_id, str(item["sample_id"]))]["status"].startswith("SAMPLE_INPUT_FULLY_QUALIFIED")
        ]
        if len(frozen_sample_ids) != int(qualified_record["successful_sample_count"]):
            raise FreezeValidationError(f"Qualified sample count changed for {dataset_id}.")
        if not frozen_sample_ids:
            raise FreezeValidationError(f"No qualified samples remain for {dataset_id}.")
        targeted = bool(dataset["targeted_panel"])
        data_record = {
            "dataset_id": dataset_id,
            "public_name": source["source_study_id"],
            "accession_or_official_source": source["source_url"],
            "platform": dataset["platform"],
            "platform_family": _platform_family(str(dataset["platform"])),
            "platform_paradigm": dataset["platform_paradigm"],
            "species": dataset["species"],
            "tissue": str(dataset["tissue_or_disease"]),
            "disease_context": str(dataset["tissue_or_disease"]),
            "resolution_class": dataset["measurement_unit"],
            "targeted_or_transcriptome": "TARGETED_PANEL" if targeted else "WHOLE_TRANSCRIPTOME_OR_NEAR_WHOLE_TRANSCRIPTOME",
            "targeted_panel": targeted,
            "qualification_status": qualified_record["final_status"],
            "formal_external_eligible": True,
            "frozen_sample_ids": frozen_sample_ids,
            "frozen_sample_count": len(frozen_sample_ids),
            "independent_patient_or_animal_count": dataset["independent_donor_or_animal_count"],
            "excluded_sample_ids": [],
            "exclusion_reasons": [],
            "input_root_placeholder": INPUT_ROOT_PLACEHOLDER,
            "input_directory": dataset["input_directory"],
            "adapter_id": dataset["adapter"],
            "input_manifest": "configs/formal_multiplatform_input_manifest.yaml",
            "input_file_relative_paths": [],
            "input_file_sizes": [],
            "input_sha256": [],
            "available_fractions": [],
            "unavailable_fractions": [],
            "unavailable_fraction_reasons": {},
            "representation_capability": True,
            "inference_capability": True,
            "limited_endpoints": bool(dataset["limited_endpoints"]),
            "license_status": dataset["license_status"],
            "development_trace_status": "confirmed_no_local_development_trace",
            "endpoint_stratum": "TARGETED_PANEL_STRATUM" if targeted else "WTS_STRATUM",
            "panel_name": "gene_panel.json" if targeted else None,
            "panel_version": "not_declared_in_minimal_processed_input" if targeted else None,
            "panel_gene_manifest": "gene_panel.json" if targeted else None,
            "panel_gene_count": None,
            "endpoint_restrictions": (
                ["panel_genes_only", "cross_dataset_aggregate_uses_within_dataset_standardized_effect_or_rank"]
                if targeted
                else []
            ),
        }
        for sample_id in frozen_sample_ids:
            sample = next(item for item in dataset["samples"] if item["sample_id"] == sample_id)
            sample_record = samples[(dataset_id, sample_id)]
            available, unavailable, unavailable_reasons = _availability(sample_record)
            if len(available) < 3:
                raise FreezeValidationError(f"{dataset_id}/{sample_id} has fewer than three feasible fractions.")
            data_record["available_fractions"] = available
            data_record["unavailable_fractions"] = unavailable
            data_record["unavailable_fraction_reasons"] = unavailable_reasons
            expression = sample_record.get("expression") or {}
            data_record["panel_gene_count"] = expression.get("gene_count") if targeted else None
            for feasibility in sample_record.get("structural_feasibility") or []:
                fraction = float(feasibility["fraction"])
                fraction_rows.append(
                    {
                        "dataset_id": dataset_id,
                        "sample_id": sample_id,
                        "fraction": fraction,
                        "raw_target_n": int(feasibility["target_n"]),
                        "final_target_n": int(feasibility["target_n"]),
                        "structurally_feasible": bool(feasibility["input_structurally_feasible"]),
                        "formal_execution_allowed": bool(feasibility["input_structurally_feasible"]),
                        "exclusion_reason": None if feasibility["input_structurally_feasible"] else "STRUCTURALLY_INFEASIBLE_FROM_QUALIFICATION",
                    }
                )
            for specification in sample["files"]:
                relative_path = f"{dataset['input_directory']}/{specification['filename']}"
                checksum = checksum_records.get(relative_path)
                if checksum is None:
                    raise FreezeValidationError(f"Missing checksum record for {relative_path}.")
                representation_required, inference_required = _file_requirement(specification)
                manifest_files.append(
                    {
                        "relative_path": relative_path,
                        "size_bytes": int(checksum["bytes"]),
                        "sha256": checksum["sha256"],
                        "file_role": specification["role"],
                        "sample_id": sample_id,
                        "dataset_id": dataset_id,
                        "required_for_representation": representation_required,
                        "required_for_inference": inference_required,
                        "source_url_or_accession": source["source_url"],
                        "received_version": "minimal_processed_input_batch_001",
                        "checksum_source": "official" if checksum.get("official_checksum_algorithm") else "project_received_checksum",
                        "immutable_by_policy": True,
                        "overwrite_prohibited": True,
                    }
                )
        data_record["input_file_relative_paths"] = [item["relative_path"] for item in manifest_files if item["dataset_id"] == dataset_id]
        data_record["input_file_sizes"] = [item["size_bytes"] for item in manifest_files if item["dataset_id"] == dataset_id]
        data_record["input_sha256"] = [item["sha256"] for item in manifest_files if item["dataset_id"] == dataset_id]
        dataset_freeze.append(data_record)
        endpoint_rows.extend(_endpoint_rows(data_record))

    manifest_files.sort(key=lambda item: (item["dataset_id"], item["sample_id"], item["relative_path"]))
    input_manifest_hash = canonical_sha256(manifest_files)
    protocol_seeds = list(protocol["replicates"]["formal_outer_seeds"])
    if protocol_seeds != list(range(10)):
        raise FreezeValidationError("The existing protocol does not provide the required fixed ten seeds.")
    seeds = {
        "seed_set_id": "formal_outer_seeds_protocol_v1",
        "generation_rule": "Read unchanged from configs/multiplatform_benchmark_protocol.yaml; no generation occurred.",
        "seeds": protocol_seeds,
        "shared_across_methods": True,
        "shared_across_tasks": True,
        "frozen_before_benchmark": True,
    }
    seeds["seed_manifest_sha256"] = canonical_sha256({key: value for key, value in seeds.items() if key != "seed_manifest_sha256"})
    methods = [_method_record(method_id) for method_id in FORMAL_METHODS]
    execution_units = build_execution_units(dataset_freeze, fraction_rows, endpoint_rows, protocol_seeds, input_manifest_hash)
    commit = code_commit or repository_commit(root)
    benchmark = {
        "schema_version": 1,
        "benchmark_id": "formal_multiplatform_benchmark_v1",
        "status": "frozen_not_executed",
        "code_commit": commit,
        "source_protocol_sha256": canonical_sha256(protocol),
        "source_qualification_status_sha256": canonical_sha256(status),
        "input_manifest_sha256": input_manifest_hash,
        "dataset_freeze": "configs/formal_multiplatform_dataset_freeze.yaml",
        "fraction_matrix": "configs/formal_dataset_fraction_matrix.yaml",
        "endpoint_matrix": "configs/formal_dataset_endpoint_matrix.yaml",
        "seed_manifest": "configs/formal_multiplatform_seeds.yaml",
        "execution_units": "configs/formal_multiplatform_execution_units.yaml",
        "results_root_placeholder": RESULTS_ROOT_PLACEHOLDER,
        "storage_backend": "sshfs_append_only",
        "methods": methods,
        "representation_methods": list(REPRESENTATION_METHODS),
        "inference_methods": list(INFERENCE_METHODS),
        "fractions": list(FROZEN_FRACTIONS),
        "comparison_plan": {
            "representation_primary": ["quota_completed_representation_mode", "spatial_stratified_srs"],
            "representation_secondary": ["uniform_srs", "spatial_pivotal"],
            "inference_probability_methods": list(INFERENCE_METHODS),
            "forbid_representation_from_design_based_inference": True,
        },
        "statistical_hierarchy": {
            "seed": "technical_repeat_within_sample_fraction_not_biological_replicate",
            "sample": "within_dataset_spatial_or_biological_repeat",
            "patient_or_animal": "higher_level_biological_repeat_when_available",
            "dataset": "cross_platform_evidence_unit",
            "summary_order": ["within_sample_seed_summary", "within_dataset_sample_summary", "cross_dataset_summary"],
            "primary_reporting": ["paired_effect", "direction_consistency", "uncertainty", "dataset_level_results"],
            "optional_auxiliary_tests": ["paired_permutation_or_wilcoxon", "dataset_level_sign_consistency", "dataset_level_bootstrap_interval"],
        },
        "execution_phases": {
            "preflight": "validate_inputs_and_configuration_without_sampling",
            "representation": "run_representation_units_only_after_explicit_authorization",
            "inference": "run_probability_units_only_after_explicit_authorization",
            "summarize": "read_successful_immutable_units_only",
        },
        "cache_plan": ["input_parsing", "frozen_expression_representation", "spatial_strata", "method_result", "endpoint_calculation", "dataset_summary"],
        "stopping_rules": {
            "immediate_hold": ["input_manifest_change", "method_registry_change", "code_commit_change", "formal_dataset_identity_change", "execution_config_change", "undeclared_development_trace", "invalid_inclusion_probability", "silent_output_overwrite"],
            "unit_failure_continue": ["sample_runtime_format_error", "seed_failure", "endpoint_not_computable", "resource_shortage"],
            "not_a_stop_reason": ["method_performs_poorly", "no_significance", "opposite_dataset_direction", "limited_endpoint_weaker", "representation_not_universally_best"],
        },
        "missing_endpoint_policy": ["NOT_APPLICABLE", "NOT_AVAILABLE_BY_PANEL", "NOT_AVAILABLE_NO_LABEL", "NOT_AVAILABLE_NO_DOMAIN", "NOT_AVAILABLE_NO_GROUND_TRUTH"],
        "no_missing_endpoint_imputation": True,
        "real_sampler_run": False,
        "real_benchmark_result_created": False,
    }
    benchmark["benchmark_config_sha256"] = canonical_sha256({key: value for key, value in benchmark.items() if key != "benchmark_config_sha256"})
    exclusions = _build_exclusions(status, batch)
    freeze_manifest = {
        "schema_version": 1,
        "freeze_id": "formal_multiplatform_benchmark_freeze_v1",
        "source_qualification_status": "configs/final_external_dataset_status.yaml",
        "source_qualification_decision": status["final_decision"],
        "source_protocol_sha256": benchmark["source_protocol_sha256"],
        "formal_dataset_ids": [item["dataset_id"] for item in dataset_freeze],
        "formal_dataset_count": len(dataset_freeze),
        "input_manifest_sha256": input_manifest_hash,
        "seed_manifest_sha256": seeds["seed_manifest_sha256"],
        "benchmark_config_sha256": benchmark["benchmark_config_sha256"],
        "code_commit": commit,
        "exclusions": exclusions,
        "real_sampler_run": False,
        "real_benchmark_result_created": False,
    }
    freeze_manifest["freeze_manifest_sha256"] = canonical_sha256({key: value for key, value in freeze_manifest.items() if key != "freeze_manifest_sha256"})
    return {
        "dataset_freeze": {"schema_version": 1, "datasets": dataset_freeze, "exclusions": exclusions},
        "input_manifest": {"schema_version": 1, "algorithm": "sha256", "files": manifest_files, "formal_input_manifest_sha256": input_manifest_hash},
        "fraction_matrix": {"schema_version": 1, "fractions": list(FROZEN_FRACTIONS), "rows": fraction_rows},
        "endpoint_matrix": {"schema_version": 1, "rows": endpoint_rows},
        "seeds": seeds,
        "execution_units": {"schema_version": 1, "units": execution_units, "counts": execution_counts(execution_units)},
        "benchmark": benchmark,
        "freeze_manifest": freeze_manifest,
    }


def _build_exclusions(status: Mapping[str, Any], batch: Mapping[str, Any]) -> dict[str, Any]:
    excluded_datasets = [
        {"dataset_id": row["dataset_id"], "qualification_status": row["final_status"], "reason": row["primary_limitation"]}
        for row in status["datasets"]
        if row["final_status"] not in FORMAL_DATASET_STATUSES
    ]
    excluded_samples = [
        {"dataset_id": row["dataset_id"], "sample_id": row["sample_id"], "status": row["status"], "reasons": row.get("reasons", [])}
        for row in status["samples"]
        if not row["status"].startswith("SAMPLE_INPUT_FULLY_QUALIFIED")
    ]
    excluded_non_enrolled = [
        {"record_id": row.get("record_id"), "final_status": row.get("final_status"), "reason": row.get("reason")}
        for row in batch.get("non_enrolled_records", [])
    ]
    return {"datasets": excluded_datasets, "samples": excluded_samples, "non_enrolled_records": excluded_non_enrolled}


def build_execution_units(
    datasets: Iterable[Mapping[str, Any]],
    fraction_rows: Iterable[Mapping[str, Any]],
    endpoint_rows: Iterable[Mapping[str, Any]],
    seeds: Iterable[int],
    input_manifest_hash: str,
) -> list[dict[str, Any]]:
    """Create deterministic, paired execution units without starting a run."""
    fraction_lookup = {(row["dataset_id"], row["sample_id"]): [] for row in fraction_rows}
    for row in fraction_rows:
        if bool(row["formal_execution_allowed"]):
            fraction_lookup[(row["dataset_id"], row["sample_id"])].append(row)
    endpoint_lookup: dict[tuple[str, str], list[str]] = {}
    for row in endpoint_rows:
        if bool(row["available"]):
            endpoint_lookup.setdefault((str(row["dataset_id"]), str(row["task"])), []).append(str(row["endpoint"]))
    units: list[dict[str, Any]] = []
    for dataset in datasets:
        resource_class = "large_memory" if any(size >= 1_000_000_000 for size in dataset["input_file_sizes"]) else "standard"
        for sample_id in dataset["frozen_sample_ids"]:
            for fraction_row in fraction_lookup[(dataset["dataset_id"], sample_id)]:
                for task, methods in (("representation", REPRESENTATION_METHODS), ("inference", INFERENCE_METHODS)):
                    for method in methods:
                        for seed in seeds:
                            identity = "|".join((dataset["dataset_id"], sample_id, task, method, f"{float(fraction_row['fraction']):.3f}", str(seed)))
                            unit_id = "fmv1_" + sha256(identity.encode("utf-8")).hexdigest()[:16]
                            units.append(
                                {
                                    "execution_unit_id": unit_id,
                                    "dataset_id": dataset["dataset_id"],
                                    "sample_id": sample_id,
                                    "platform": dataset["platform"],
                                    "task": task,
                                    "method": method,
                                    "fraction": float(fraction_row["fraction"]),
                                    "seed": int(seed),
                                    "input_manifest_hash": input_manifest_hash,
                                    "adapter": dataset["adapter_id"],
                                    "endpoint_set": endpoint_lookup[(dataset["dataset_id"], task)],
                                    "expected_output_dir": f"{RESULTS_ROOT_PLACEHOLDER}/{dataset['dataset_id']}/{sample_id}/{task}/{method}/fraction_{float(fraction_row['fraction']):.3f}/seed_{int(seed):02d}",
                                    "resource_class": resource_class,
                                    "execution_allowed": True,
                                    "exclusion_reason": None,
                                }
                            )
    return units


def execution_counts(units: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
    items = list(units)
    return {
        "representation_execution_units": sum(item["task"] == "representation" for item in items),
        "inference_execution_units": sum(item["task"] == "inference" for item in items),
        "total_execution_units": len(items),
        "per_dataset": {
            dataset_id: sum(item["dataset_id"] == dataset_id for item in items)
            for dataset_id in sorted({str(item["dataset_id"]) for item in items})
        },
        "per_platform": {
            platform: sum(item["platform"] == platform for item in items)
            for platform in sorted({str(item["platform"]) for item in items})
        },
    }


def verify_frozen_input_files(manifest: Mapping[str, Any], data_root: str | Path) -> None:
    """Reject any missing, moved, resized, or changed file before a future run."""
    root = Path(data_root)
    for record in manifest["files"]:
        path = root / str(record["relative_path"])
        if not path.is_file():
            raise FreezeValidationError(f"Frozen input is missing: {record['relative_path']}")
        if path.stat().st_size != int(record["size_bytes"]):
            raise FreezeValidationError(f"Frozen input size changed: {record['relative_path']}")
        digest_builder = sha256()
        with path.open("rb") as handle:
            while chunk := handle.read(1024 * 1024):
                digest_builder.update(chunk)
        digest = digest_builder.hexdigest()
        if digest != record["sha256"]:
            raise FreezeValidationError(f"Frozen input SHA256 changed: {record['relative_path']}")


def validate_freeze_bundle(bundle: Mapping[str, Any]) -> None:
    """Validate the locked plan without reading data or invoking any sampler."""
    datasets = list(bundle["dataset_freeze"]["datasets"])
    if len(datasets) != 6:
        raise FreezeValidationError("Formal dataset freeze must contain exactly six datasets.")
    statuses = [item["qualification_status"] for item in datasets]
    if statuses.count("FULLY_QUALIFIED") != 2 or statuses.count("FULLY_QUALIFIED_LIMITED_ENDPOINTS") != 4:
        raise FreezeValidationError("Formal status split must remain 2 fully qualified and 4 limited endpoints.")
    if any(not item["formal_external_eligible"] for item in datasets):
        raise FreezeValidationError("Every frozen dataset must be formally eligible.")
    formal_ids = {item["dataset_id"] for item in datasets}
    prohibited = {"slideseqv2_mouse_diabetic_kidney_gse190094", "visium_ffpe_human_prostate_invasive_carcinoma_2021", "visium_ffpe_human_cervical_cancer_2022", "visium_v2_human_colon_cancer_p2"}
    if formal_ids & prohibited:
        raise FreezeValidationError("A frozen excluded dataset entered the formal set.")
    if "GSM5713332" in {sample for item in datasets for sample in item["frozen_sample_ids"]}:
        raise FreezeValidationError("GSM5713332 cannot enter the formal set.")
    methods = [item["registry_id"] for item in bundle["benchmark"]["methods"]]
    if methods != list(FORMAL_METHODS):
        raise FreezeValidationError("Formal method list changed.")
    if bundle["benchmark"]["inference_methods"] != list(INFERENCE_METHODS):
        raise FreezeValidationError("Inference methods must be exactly the three probability methods.")
    if bundle["benchmark"]["fractions"] != list(FROZEN_FRACTIONS):
        raise FreezeValidationError("Frozen fractions changed.")
    if len(bundle["seeds"]["seeds"]) != 10 or bundle["seeds"]["seeds"] != list(range(10)):
        raise FreezeValidationError("Frozen seed set changed.")
    manifest_files = bundle["input_manifest"]["files"]
    if bundle["input_manifest"]["formal_input_manifest_sha256"] != canonical_sha256(manifest_files):
        raise FreezeValidationError("Formal input manifest hash is inconsistent.")
    benchmark = bundle["benchmark"]
    if benchmark["benchmark_config_sha256"] != canonical_sha256(
        {key: value for key, value in benchmark.items() if key != "benchmark_config_sha256"}
    ):
        raise FreezeValidationError("Benchmark configuration hash is inconsistent.")
    seeds = bundle["seeds"]
    if seeds["seed_manifest_sha256"] != canonical_sha256(
        {key: value for key, value in seeds.items() if key != "seed_manifest_sha256"}
    ):
        raise FreezeValidationError("Seed manifest hash is inconsistent.")
    freeze_manifest = bundle["freeze_manifest"]
    if freeze_manifest["freeze_manifest_sha256"] != canonical_sha256(
        {key: value for key, value in freeze_manifest.items() if key != "freeze_manifest_sha256"}
    ):
        raise FreezeValidationError("Freeze manifest hash is inconsistent.")
    for row in bundle["fraction_matrix"]["rows"]:
        if row["fraction"] not in FROZEN_FRACTIONS:
            raise FreezeValidationError("Fraction matrix contains an unregistered fraction.")
        if row["formal_execution_allowed"] and int(row["final_target_n"]) < 100:
            raise FreezeValidationError("A formal execution unit violates the target_n minimum.")
    for dataset in datasets:
        allowed = [row for row in bundle["fraction_matrix"]["rows"] if row["dataset_id"] == dataset["dataset_id"] and row["formal_execution_allowed"]]
        if len(allowed) < 3:
            raise FreezeValidationError("Every formal sample requires at least three feasible fractions.")
    if any(item["task"] == "inference" and item["method"] == "quota_completed_representation_mode" for item in bundle["execution_units"]["units"]):
        raise FreezeValidationError("Representation mode cannot enter inference execution units.")
    if any(item["task"] == "representation" and item["method"] not in REPRESENTATION_METHODS for item in bundle["execution_units"]["units"]):
        raise FreezeValidationError("Representation execution uses an unregistered method.")
    for row in bundle["endpoint_matrix"]["rows"]:
        if row["prohibited"] and row["available"]:
            raise FreezeValidationError("An endpoint cannot be both available and prohibited.")
    if bundle["benchmark"]["real_sampler_run"] or bundle["benchmark"]["real_benchmark_result_created"]:
        raise FreezeValidationError("Freeze artifacts must not claim a real benchmark run.")


def write_yaml_new_or_equal(path: str | Path, payload: Mapping[str, Any]) -> None:
    """Create a tracked freeze artifact once, or require identical regeneration."""
    content = yaml.safe_dump(dict(payload), allow_unicode=False, sort_keys=False)
    target = Path(path)
    if target.exists():
        if target.read_text(encoding="utf-8") != content:
            raise FreezeValidationError(f"Refusing to overwrite different freeze artifact: {target}")
        return
    with target.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(content)


def load_freeze_bundle(repo_root: str | Path) -> dict[str, Any]:
    """Load the written freeze artifacts without consulting any data directory."""
    root = Path(repo_root)
    targets = {
        "dataset_freeze": "configs/formal_multiplatform_dataset_freeze.yaml",
        "input_manifest": "configs/formal_multiplatform_input_manifest.yaml",
        "fraction_matrix": "configs/formal_dataset_fraction_matrix.yaml",
        "endpoint_matrix": "configs/formal_dataset_endpoint_matrix.yaml",
        "seeds": "configs/formal_multiplatform_seeds.yaml",
        "execution_units": "configs/formal_multiplatform_execution_units.yaml",
        "benchmark": "configs/formal_multiplatform_benchmark_v1.yaml",
        "freeze_manifest": "configs/formal_multiplatform_freeze_manifest.yaml",
    }
    return {key: load_yaml(root / relative) for key, relative in targets.items()}
