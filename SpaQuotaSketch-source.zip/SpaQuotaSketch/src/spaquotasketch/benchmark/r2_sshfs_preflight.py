"""Reusable preflight checks for the future immutable pancreas R2 execution."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from typing import Any, Mapping

from ..result_storage import sha256_file
from ..samplers.registry import require_runnable_method
from .r2_method_adapter import FORMAL_R2_METHODS


class R2SshfsPreflightError(RuntimeError):
    """Raised when a required execution guard does not pass."""


def _git(project_root: Path, *arguments: str, check: bool = True) -> str:
    completed = subprocess.run(
        ["git", *arguments],
        cwd=project_root,
        check=check,
        capture_output=True,
        text=True,
    )
    return completed.stdout.strip()


def _check(name: str, passed: bool, detail: str) -> dict[str, Any]:
    return {"name": name, "passed": bool(passed), "detail": str(detail)}


def _input_metadata(path: Path, *, cell_group_column: str, required_obsm_key: str) -> dict[str, Any]:
    import anndata as ad

    if not path.is_file():
        raise FileNotFoundError(f"Input h5ad does not exist: {path}")
    backed = ad.read_h5ad(path, backed="r")
    try:
        obs_columns = [str(value) for value in backed.obs.columns]
        obsm_keys = [str(value) for value in backed.obsm.keys()]
        if cell_group_column not in obs_columns:
            raise ValueError(f"Missing required evaluation column: {cell_group_column}")
        if required_obsm_key not in obsm_keys:
            raise ValueError(f"Missing required coordinate key: {required_obsm_key}")
        return {
            "n_cells": int(backed.n_obs),
            "n_genes": int(backed.n_vars),
            "obs_columns": obs_columns,
            "obsm_keys": obsm_keys,
        }
    finally:
        backed.file.close()


def run_r2_sshfs_preflight(
    *,
    project_root: str | Path,
    config: Mapping[str, Any],
    input_h5ad: str | Path,
    future_remote_directory: str | Path,
    run_tests: bool = False,
    pytest_temp_root: str | Path | None = None,
    require_future_directory_absent: bool = True,
) -> dict[str, Any]:
    """Run the nine frozen checks without creating a new result directory.

    The caller receives every check result.  A failed guard raises only after
    all non-destructive checks have been recorded.
    """

    root = Path(project_root).resolve()
    preflight = config.get("preflight", {})
    if not isinstance(preflight, Mapping):
        raise R2SshfsPreflightError("preflight must be a mapping")
    input_path = Path(input_h5ad)
    future_directory = Path(future_remote_directory)
    checks: list[dict[str, Any]] = []

    branch = _git(root, "branch", "--show-current")
    head = _git(root, "rev-parse", "HEAD")
    expected_branch = str(preflight.get("expected_branch", branch))
    ancestors = [str(value) for value in preflight.get("required_ancestor_commits", [])]
    ancestor_passed = True
    for revision in ancestors:
        completed = subprocess.run(
            ["git", "merge-base", "--is-ancestor", revision, "HEAD"],
            cwd=root,
            capture_output=True,
            text=True,
        )
        ancestor_passed = ancestor_passed and completed.returncode == 0
    checks.append(
        _check(
            "branch_and_head",
            branch == expected_branch and ancestor_passed,
            f"branch={branch}; head={head}; required_ancestors={','.join(ancestors)}",
        )
    )

    require_clean = bool(preflight.get("require_clean_worktree", True))
    status = _git(root, "status", "--porcelain")
    checks.append(
        _check(
            "git_worktree",
            not require_clean or not status,
            "clean" if not status else status,
        )
    )

    if run_tests:
        command = [sys.executable, "-m", "pytest", ".\\tests", "-q", "-p", "no:cacheprovider"]
        if pytest_temp_root is not None:
            command.append(f'--basetemp={Path(pytest_temp_root)}')
        completed = subprocess.run(command, cwd=root, capture_output=True, text=True)
        detail = (completed.stdout + completed.stderr).strip()
        checks.append(_check("full_pytest", completed.returncode == 0, detail[-2000:]))
    else:
        checks.append(_check("full_pytest", True, "not run by this preflight invocation"))

    registry_ok = True
    registry_detail: list[str] = []
    for method_id in FORMAL_R2_METHODS:
        try:
            metadata = require_runnable_method(method_id)
            registry_detail.append(f"{method_id}:{metadata['implementation_status']}")
        except Exception as error:  # pragma: no cover - defensive preflight reporting
            registry_ok = False
            registry_detail.append(f"{method_id}:{type(error).__name__}:{error}")
    checks.append(_check("method_registry", registry_ok, "; ".join(registry_detail)))

    try:
        input_metadata = _input_metadata(
            input_path,
            cell_group_column=str(config["input"]["cell_group_column"]),
            required_obsm_key=str(config["input"].get("required_obsm_key", "spatial")),
        )
        checks.append(_check("input_readability", True, str(input_metadata)))
    except Exception as error:
        input_metadata = {}
        checks.append(_check("input_readability", False, f"{type(error).__name__}: {error}"))

    expected_input_sha = str(preflight.get("expected_input_sha256", ""))
    observed_input_sha = sha256_file(input_path) if input_path.is_file() else ""
    checks.append(
        _check(
            "input_checksum",
            not expected_input_sha or observed_input_sha == expected_input_sha,
            f"observed={observed_input_sha}; expected={expected_input_sha}",
        )
    )

    historical_ok = True
    historical_details: list[str] = []
    files = preflight.get("historical_files", {})
    if not isinstance(files, Mapping):
        historical_ok = False
        historical_details.append("historical_files is not a mapping")
    else:
        for label, specification in files.items():
            if not isinstance(specification, Mapping):
                historical_ok = False
                historical_details.append(f"{label}:invalid specification")
                continue
            path = Path(str(specification.get("path", "")))
            expected = str(specification.get("sha256", ""))
            observed = sha256_file(path) if path.is_file() else ""
            passed = bool(path.is_file() and expected and observed == expected)
            historical_ok = historical_ok and passed
            historical_details.append(f"{label}:{'ok' if passed else 'mismatch_or_missing'}")
    checks.append(_check("historical_r1_r2_hashes", historical_ok, "; ".join(historical_details)))

    tag = str(preflight.get("protected_tag", "checkpoint-task-aware-framework-2026-07-16"))
    expected_tag_target = str(preflight.get("expected_tag_target", ""))
    try:
        observed_tag_target = _git(root, "rev-parse", f"{tag}^{{}}")
        tag_ok = not expected_tag_target or observed_tag_target == expected_tag_target
        tag_detail = f"{tag}={observed_tag_target}"
    except subprocess.CalledProcessError as error:
        tag_ok = False
        tag_detail = f"missing tag: {error}"
    checks.append(_check("protected_tag", tag_ok, tag_detail))

    checks.append(
        _check(
            "future_directory_absent" if require_future_directory_absent else "existing_directory_allowed_for_resume",
            (not future_directory.exists()) if require_future_directory_absent else future_directory.is_dir(),
            f"future_directory={future_directory}",
        )
    )

    result = {
        "project_root": str(root),
        "branch": branch,
        "head": head,
        "input_h5ad": str(input_path),
        "input_metadata": input_metadata,
        "future_remote_directory": str(future_directory),
        "checks": checks,
        "passed": bool(all(check["passed"] for check in checks)),
    }
    if not result["passed"]:
        failed = ", ".join(check["name"] for check in checks if not check["passed"])
        raise R2SshfsPreflightError(f"R2 SSHFS preflight failed: {failed}")
    return result


__all__ = ["R2SshfsPreflightError", "run_r2_sshfs_preflight"]
