"""Plotting helpers."""

from __future__ import annotations

from pathlib import Path
from typing import Any


def save_spatial_scatter(coords: Any, output_path: str | Path, color: Any = None, title: str | None = None) -> None:
    """Save a basic spatial scatter plot."""
    import numpy as np
    import matplotlib.pyplot as plt

    from .utils import ensure_parent_dir, refuse_overwrite

    output = Path(output_path)
    ensure_parent_dir(output)
    refuse_overwrite(output)

    points = np.asarray(coords)
    if points.ndim != 2 or points.shape[1] < 2:
        raise ValueError("coords must be a two-dimensional array with at least two columns.")

    fig, ax = plt.subplots(figsize=(5, 5))
    ax.scatter(points[:, 0], points[:, 1], s=2, c=color)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    if title:
        ax.set_title(title)
    fig.tight_layout()
    fig.savefig(output, dpi=200)
    plt.close(fig)
