"""Baseline sampling methods."""

from __future__ import annotations

from collections import defaultdict
from typing import Hashable


def random_sample_ids(ids: list[Hashable], target_n: int, seed: int = 0) -> list[Hashable]:
    """Randomly sample ids without replacement."""
    import random

    if target_n < 0:
        raise ValueError("target_n must be non-negative.")
    n_take = min(target_n, len(ids))
    return random.Random(seed).sample(list(ids), n_take)


def random_sample_indices(n_obs: int, target_n: int, seed: int = 0) -> list[int]:
    """Randomly sample row indices without replacement."""
    import numpy as np

    if n_obs < 0:
        raise ValueError("n_obs must be non-negative.")
    n_take = min(max(int(target_n), 0), int(n_obs))
    if n_take == 0:
        return []
    rng = np.random.default_rng(seed)
    return rng.choice(int(n_obs), size=n_take, replace=False).tolist()


def expression_only_leverage(embedding, target_n: int, seed: int = 0) -> list[int]:
    """Run leverage-score sampling using only expression-derived embedding."""
    from .candidate_pool import leverage_score_sample

    return leverage_score_sample(embedding, target_n, seed=seed)


def standard_leverage_score_sample(expression_basis, target_n: int, seed: int = 0) -> list[int]:
    """Sample from row leverage scores of a low-rank expression basis.

    ``expression_basis`` should be a left singular-vector basis, not a PC score
    matrix whose components have unequal singular-value scaling. This is the
    baseline required for the post-V1 spatial-transcriptomics comparison.
    """
    return sample_from_score_values(row_leverage_scores(expression_basis), target_n, seed=seed)


def row_leverage_scores(expression_basis):
    """Return non-negative row leverage values for an expression basis."""
    import numpy as np

    basis = np.asarray(expression_basis, dtype=float)
    if basis.ndim != 2 or basis.shape[0] == 0:
        raise ValueError("expression_basis must be a non-empty two-dimensional array.")
    if not np.isfinite(basis).all():
        raise ValueError("expression_basis must be finite.")
    return np.square(basis).sum(axis=1)


def sample_from_score_values(score_values, target_n: int, seed: int = 0) -> list[int]:
    """Draw a fixed-size sample without replacement from positive score values."""
    import numpy as np

    scores = np.asarray(score_values, dtype=float).reshape(-1)
    if scores.size == 0:
        return []
    if not np.isfinite(scores).all() or np.any(scores < 0):
        raise ValueError("score_values must be finite and non-negative.")
    target_n = min(max(int(target_n), 0), int(scores.size))
    if target_n == 0:
        return []
    if float(scores.sum()) <= 0:
        probabilities = None
    else:
        probabilities = scores / scores.sum()
    rng = np.random.default_rng(seed)
    return rng.choice(scores.size, size=target_n, replace=False, p=probabilities).tolist()


def spatially_smoothed_leverage_scores(
    expression_basis,
    spatial_coordinates,
    n_neighbors: int = 15,
):
    """Return kNN-smoothed row leverage scores without drawing a sample.

    Separating score construction from drawing lets repeated technical seeds use
    the identical spatial representation rather than recomputing it for every
    seed and sampling fraction.
    """
    import numpy as np
    from sklearn.neighbors import NearestNeighbors

    basis = np.asarray(expression_basis, dtype=float)
    coordinates = np.asarray(spatial_coordinates, dtype=float)
    if basis.ndim != 2 or basis.shape[0] == 0:
        raise ValueError("expression_basis must be a non-empty two-dimensional array.")
    if coordinates.ndim != 2 or coordinates.shape[0] != basis.shape[0] or coordinates.shape[1] < 2:
        raise ValueError("spatial_coordinates must provide two coordinates for every basis row.")
    if not np.isfinite(basis).all() or not np.isfinite(coordinates[:, :2]).all():
        raise ValueError("expression_basis and spatial_coordinates must be finite.")
    if n_neighbors < 1:
        raise ValueError("n_neighbors must be at least one.")

    n_obs = basis.shape[0]
    if n_obs == 1:
        return row_leverage_scores(basis)
    n_query = min(int(n_neighbors) + 1, n_obs)
    neighbours = NearestNeighbors(n_neighbors=n_query).fit(coordinates[:, :2]).kneighbors(
        coordinates[:, :2],
        return_distance=False,
    )
    smoothed = np.empty_like(basis, dtype=float)
    for row, indices in enumerate(neighbours):
        smoothed[row] = basis[np.asarray(indices, dtype=int)].mean(axis=0)
    return row_leverage_scores(smoothed)


def spatially_smoothed_leverage_score_sample(
    expression_basis,
    spatial_coordinates,
    target_n: int,
    seed: int = 0,
    n_neighbors: int = 15,
) -> list[int]:
    """Sample leverage scores after smoothing a low-rank basis over spatial kNN.

    The prespecified spatial weight matrix assigns equal mass to each
    observation and its available nearest neighbours, including itself. Row
    scores are then squared norms of the smoothed basis. This is a transparent
    kNN-weight implementation of the generic ``W U`` construction; it is not
    presented as a byte-for-byte reimplementation of another study's private
    preprocessing or spatial-weight choices. This evaluation baseline does not
    impose SpaQuotaSketch spatial quotas.
    """
    return sample_from_score_values(
        spatially_smoothed_leverage_scores(
            expression_basis,
            spatial_coordinates,
            n_neighbors=n_neighbors,
        ),
        target_n,
        seed=seed,
    )


def expression_only_sample_indices(embedding, target_n: int, seed: int = 0) -> list[int]:
    """Sample cells using only expression information."""
    return expression_only_leverage(embedding, target_n, seed=seed)


def spatial_only_sample_indices(
    bin_ids: list[Hashable],
    target_n: int,
    seed: int = 0,
) -> tuple[list[int], dict[str, object]]:
    """Sample cells by spatial bin quotas using only spatial positions."""
    import random

    from .quota_sampling import compute_bin_quotas

    if target_n < 0:
        raise ValueError("target_n must be non-negative.")
    n_obs = len(bin_ids)
    target_n = min(int(target_n), n_obs)
    if target_n == 0:
        return [], {"n_selected": 0, "n_bins": 0, "n_insufficient_bins": 0, "n_filled_shortfall": 0}

    quotas = compute_bin_quotas(bin_ids, target_n)
    indices_by_bin: dict[Hashable, list[int]] = defaultdict(list)
    for index, bin_id in enumerate(bin_ids):
        indices_by_bin[bin_id].append(index)

    rng = random.Random(seed)
    selected: list[int] = []
    insufficient_bins: list[dict[str, object]] = []
    for bin_id, quota in quotas.items():
        available = indices_by_bin.get(bin_id, [])
        n_take = min(int(quota), len(available))
        if n_take < int(quota):
            insufficient_bins.append(
                {"bin_id": bin_id, "quota": int(quota), "available_cells": len(available)}
            )
        if n_take:
            selected.extend(rng.sample(available, n_take))

    n_filled_shortfall = 0
    if len(selected) < target_n:
        selected_set = set(selected)
        remaining = [index for index in range(n_obs) if index not in selected_set]
        n_fill = min(target_n - len(selected), len(remaining))
        if n_fill:
            selected.extend(rng.sample(remaining, n_fill))
            n_filled_shortfall = n_fill

    report = {
        "n_selected": len(selected),
        "n_bins": len(quotas),
        "n_insufficient_bins": len(insufficient_bins),
        "insufficient_bins": insufficient_bins,
        "n_filled_shortfall": n_filled_shortfall,
    }
    return selected[:target_n], report


def uniform_sampling_weights(n_original: int, n_selected: int) -> list[float]:
    """Return one inverse-probability weight for each selected cell."""
    if n_original < 0 or n_selected < 0:
        raise ValueError("n_original and n_selected must be non-negative.")
    if n_selected == 0:
        return []
    return [float(n_original / n_selected)] * n_selected


def run_record(method: str, selected_ids: list[Hashable], runtime_seconds: float | None = None):
    """Create a standard record for a baseline run."""
    return {
        "method": method,
        "n_selected": len(selected_ids),
        "runtime_seconds": runtime_seconds,
    }
