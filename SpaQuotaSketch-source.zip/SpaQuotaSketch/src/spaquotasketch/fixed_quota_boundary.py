"""Controlled boundary simulations for fixed spatial-quota probability sampling.

This module is intentionally *not* another expression-aware sampler.  It is a
positive-control and failure-boundary experiment: both designs share identical
spatial strata and integer quotas, while the correlation between a supplied
score and a known target is controlled by the simulator.  The ``oracle`` score
is labelled as a positive control and is never a permitted analysis method for
real data.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Sequence

import numpy as np
import pandas as pd

from .v2_1.sampling import SamplingPlan, build_sampling_plan, draw_fixed_size_sample


Alignment = Literal["independent", "proxy", "oracle_positive_control"]
RarePattern = Literal["scattered", "clustered"]

EQUAL_PROBABILITY_PIVOTAL = "equal_probability_pivotal"
SCORE_WEIGHTED_FIXED_QUOTA = "score_weighted_fixed_quota"
METHOD_IDS = (EQUAL_PROBABILITY_PIVOTAL, SCORE_WEIGHTED_FIXED_QUOTA)


@dataclass(frozen=True)
class FixedQuotaBoundaryPopulation:
    """A population with a known rare-target total and an external score."""

    coordinates: np.ndarray
    spatial_strata: np.ndarray
    rare_target: np.ndarray
    score: np.ndarray
    alignment: str
    rare_pattern: str
    metadata: dict[str, float | int | str]


def _require_choice(value: str, allowed: Sequence[str], label: str) -> None:
    if value not in allowed:
        options = ", ".join(allowed)
        raise ValueError(f"{label} must be one of {options}; received {value!r}.")


def generate_fixed_quota_boundary_population(
    *,
    grid_side: int,
    cells_per_stratum: int,
    rare_frequency: float,
    rare_pattern: RarePattern,
    alignment: Alignment,
    seed: int,
) -> FixedQuotaBoundaryPopulation:
    """Generate a spatial population with a controllable score-target relation.

    ``independent`` mimics a score unrelated to the estimand. ``proxy`` is an
    imperfect but informative score. ``oracle_positive_control`` is a labelled
    benchmark control showing what a genuinely target-aligned score could do;
    it must not be described as unsupervised expression weighting.
    """
    grid_side, cells_per_stratum = int(grid_side), int(cells_per_stratum)
    rare_frequency = float(rare_frequency)
    _require_choice(
        str(rare_pattern), ("scattered", "clustered"), "rare_pattern"
    )
    _require_choice(
        str(alignment),
        ("independent", "proxy", "oracle_positive_control"),
        "alignment",
    )
    if grid_side < 1 or cells_per_stratum < 2:
        raise ValueError("grid_side must be positive and cells_per_stratum must be at least two.")
    if not 0 < rare_frequency < 1:
        raise ValueError("rare_frequency must be strictly between zero and one.")

    rng = np.random.default_rng(int(seed))
    n_strata = grid_side * grid_side
    n_cells = n_strata * cells_per_stratum
    strata: list[str] = []
    coordinate_parts: list[np.ndarray] = []
    for y_index in range(grid_side):
        for x_index in range(grid_side):
            label = f"x{x_index:02d}_y{y_index:02d}"
            strata.extend([label] * cells_per_stratum)
            coordinate_parts.append(
                np.column_stack(
                    [
                        (x_index + rng.uniform(0.0, 1.0, cells_per_stratum)) / grid_side,
                        (y_index + rng.uniform(0.0, 1.0, cells_per_stratum)) / grid_side,
                    ]
                )
            )
    coordinates = np.vstack(coordinate_parts).astype(np.float64, copy=False)
    spatial_strata = np.asarray(strata, dtype=object)
    rare_target = np.zeros(n_cells, dtype=float)
    n_rare = int(round(n_cells * rare_frequency))
    n_rare = max(1, min(n_cells - 1, n_rare))
    if rare_pattern == "scattered":
        # Spread the target across all strata without conditioning on the score.
        base = n_rare // n_strata
        remainder = n_rare % n_strata
        chosen: list[np.ndarray] = []
        for order, stratum in enumerate(sorted(set(spatial_strata.tolist()))):
            positions = np.flatnonzero(spatial_strata == stratum)
            take = base + (1 if order < remainder else 0)
            chosen.append(rng.choice(positions, size=take, replace=False))
        rare_indices = np.concatenate(chosen)
    else:
        # Keep the same global prevalence but concentrate the target in 20% of strata.
        labels = sorted(set(spatial_strata.tolist()))
        n_hot = max(1, int(round(len(labels) * 0.20)))
        hot = rng.choice(np.asarray(labels, dtype=object), size=n_hot, replace=False)
        capacity = np.concatenate([np.flatnonzero(spatial_strata == label) for label in hot])
        if n_rare > capacity.size:
            raise ValueError("clustered rare target exceeds the selected hot-stratum capacity.")
        rare_indices = rng.choice(capacity, size=n_rare, replace=False)
    rare_target[np.asarray(rare_indices, dtype=int)] = 1.0

    target_z = (rare_target - rare_target.mean()) / (rare_target.std() + 1e-12)
    noise = rng.normal(0.0, 1.0, size=n_cells)
    if alignment == "independent":
        log_score = noise
    elif alignment == "proxy":
        log_score = 0.65 * target_z + np.sqrt(1.0 - 0.65**2) * noise
    else:
        # A near-oracle is deliberately separated from the real-data score.
        log_score = 1.75 * target_z + 0.10 * noise
    score = np.exp(np.clip(log_score, -5.0, 5.0))
    observed_correlation = float(np.corrcoef(score, rare_target)[0, 1])
    return FixedQuotaBoundaryPopulation(
        coordinates=coordinates,
        spatial_strata=spatial_strata,
        rare_target=rare_target,
        score=score,
        alignment=str(alignment),
        rare_pattern=str(rare_pattern),
        metadata={
            "seed": int(seed),
            "grid_side": grid_side,
            "n_strata": n_strata,
            "cells_per_stratum": cells_per_stratum,
            "n_cells": n_cells,
            "rare_frequency": rare_frequency,
            "n_rare": int(rare_target.sum()),
            "score_target_correlation": observed_correlation,
        },
    )


def _plans(
    population: FixedQuotaBoundaryPopulation,
    quota_per_stratum: int,
    *,
    max_weight_inflation: float,
) -> dict[str, SamplingPlan]:
    quota_per_stratum = int(quota_per_stratum)
    labels = sorted(set(population.spatial_strata.tolist()))
    capacities = {
        label: int(np.sum(population.spatial_strata == label)) for label in labels
    }
    if not 1 <= quota_per_stratum <= min(capacities.values()):
        raise ValueError("quota_per_stratum must be feasible in every spatial stratum.")
    quotas = {label: quota_per_stratum for label in labels}
    return {
        EQUAL_PROBABILITY_PIVOTAL: build_sampling_plan(
            population.spatial_strata,
            quotas,
            population.coordinates,
            np.ones(population.rare_target.size, dtype=float),
            method="v2_1_coordinate_only",
            max_weight_inflation=max_weight_inflation,
        ),
        SCORE_WEIGHTED_FIXED_QUOTA: build_sampling_plan(
            population.spatial_strata,
            quotas,
            population.coordinates,
            population.score,
            method="v2_1_inference",
            max_weight_inflation=max_weight_inflation,
        ),
    }


def _estimate_total(target: np.ndarray, selected: np.ndarray, plan: SamplingPlan) -> float:
    return float(np.sum(target[selected] / plan.inclusion_probability[selected]))


def _selected_ess_fraction(selected: np.ndarray, plan: SamplingPlan) -> float:
    weights = plan.sampling_weight[selected]
    effective_n = float(np.square(weights.sum()) / np.square(weights).sum())
    return effective_n / float(selected.size)


def run_fixed_quota_boundary_condition(
    population: FixedQuotaBoundaryPopulation,
    *,
    quota_per_stratum: int,
    n_draws: int,
    sampling_seed_base: int,
    max_weight_inflation: float = 4.0,
) -> pd.DataFrame:
    """Evaluate matched equal-probability and score-weighted pivotal designs.

    Rows are design-level summaries for one simulated population. Repeated
    draws estimate sampling variation only; users must aggregate over distinct
    population seeds before drawing a simulation-level conclusion.
    """
    n_draws = int(n_draws)
    if n_draws < 2:
        raise ValueError("n_draws must be at least two.")
    plans = _plans(
        population,
        quota_per_stratum,
        max_weight_inflation=float(max_weight_inflation),
    )
    target_total = float(population.rare_target.sum())
    rows: list[dict[str, float | int | str | bool]] = []
    for method_id, plan in plans.items():
        estimates = np.empty(n_draws, dtype=float)
        retained = np.empty(n_draws, dtype=float)
        ess = np.empty(n_draws, dtype=float)
        quota_ok = np.empty(n_draws, dtype=bool)
        for draw in range(n_draws):
            selected = draw_fixed_size_sample(
                plan, random_seed=int(sampling_seed_base) + draw
            )
            estimates[draw] = _estimate_total(population.rare_target, selected, plan)
            retained[draw] = float(population.rare_target[selected].sum())
            ess[draw] = _selected_ess_fraction(selected, plan)
            counts = pd.Series(population.spatial_strata[selected]).value_counts()
            quota_ok[draw] = bool(
                len(counts) == len(plan.quotas)
                and all(int(counts.get(label, 0)) == int(quota) for label, quota in plan.quotas.items())
            )
        error = estimates - target_total
        rows.append(
            {
                "method_id": method_id,
                "alignment": population.alignment,
                "rare_pattern": population.rare_pattern,
                "population_seed": int(population.metadata["seed"]),
                "n_cells": int(population.metadata["n_cells"]),
                "n_strata": int(population.metadata["n_strata"]),
                "quota_per_stratum": int(quota_per_stratum),
                "target_n": int(sum(plan.quotas.values())),
                "n_draws": n_draws,
                "rare_frequency": float(population.metadata["rare_frequency"]),
                "score_target_correlation": float(population.metadata["score_target_correlation"]),
                "true_rare_total": target_total,
                "mean_estimate": float(estimates.mean()),
                "relative_bias": float(error.mean() / target_total),
                "relative_rmse": float(np.sqrt(np.mean(np.square(error))) / target_total),
                "rare_retained_mean": float(retained.mean()),
                "rare_retained_at_least_once": float(np.mean(retained >= 1.0)),
                "mean_selected_ess_fraction": float(ess.mean()),
                "all_draws_exact_quota": bool(quota_ok.all()),
                "max_weight_inflation": float(max_weight_inflation),
            }
        )
    result = pd.DataFrame(rows)
    if not bool(result["all_draws_exact_quota"].all()):
        raise RuntimeError("a fixed-quota simulation draw violated its declared quota.")
    return result


def summarize_fixed_quota_boundary(units: pd.DataFrame) -> pd.DataFrame:
    """Aggregate matched methods at the independent population level."""
    required = {
        "method_id",
        "alignment",
        "rare_pattern",
        "population_seed",
        "quota_per_stratum",
        "relative_rmse",
        "score_target_correlation",
        "mean_selected_ess_fraction",
        "all_draws_exact_quota",
    }
    missing = required.difference(units.columns)
    if missing:
        raise ValueError(f"units is missing required columns: {sorted(missing)}")
    index = ["alignment", "rare_pattern", "population_seed", "quota_per_stratum"]
    table = units.pivot(index=index, columns="method_id", values="relative_rmse")
    if set(METHOD_IDS).difference(table.columns):
        raise ValueError("every population-condition unit must contain both declared methods.")
    ratio = (
        table[SCORE_WEIGHTED_FIXED_QUOTA] / table[EQUAL_PROBABILITY_PIVOTAL]
    ).rename("weighted_to_equal_probability_pivotal_rmse_ratio")
    population_rows = ratio.reset_index().merge(
        units.loc[units["method_id"] == SCORE_WEIGHTED_FIXED_QUOTA,
                  index + ["score_target_correlation", "mean_selected_ess_fraction", "all_draws_exact_quota"]],
        on=index,
        how="left",
        validate="one_to_one",
    )
    grouped = population_rows.groupby(
        ["alignment", "rare_pattern", "quota_per_stratum"], sort=True
    )
    summary = grouped.agg(
        n_independent_populations=("population_seed", "nunique"),
        median_weighted_to_equal_probability_pivotal_rmse_ratio=(
            "weighted_to_equal_probability_pivotal_rmse_ratio", "median"
        ),
        q25_weighted_to_equal_probability_pivotal_rmse_ratio=(
            "weighted_to_equal_probability_pivotal_rmse_ratio", lambda values: values.quantile(0.25)
        ),
        q75_weighted_to_equal_probability_pivotal_rmse_ratio=(
            "weighted_to_equal_probability_pivotal_rmse_ratio", lambda values: values.quantile(0.75)
        ),
        mean_weighted_to_equal_probability_pivotal_rmse_ratio=(
            "weighted_to_equal_probability_pivotal_rmse_ratio", "mean"
        ),
        minimum_weighted_to_equal_probability_pivotal_rmse_ratio=(
            "weighted_to_equal_probability_pivotal_rmse_ratio", "min"
        ),
        maximum_weighted_to_equal_probability_pivotal_rmse_ratio=(
            "weighted_to_equal_probability_pivotal_rmse_ratio", "max"
        ),
        mean_score_target_correlation=("score_target_correlation", "mean"),
        mean_weighted_ess_fraction=("mean_selected_ess_fraction", "mean"),
        exact_quota_all_populations=("all_draws_exact_quota", "all"),
    ).reset_index()
    return summary


__all__ = [
    "Alignment",
    "EQUAL_PROBABILITY_PIVOTAL",
    "FixedQuotaBoundaryPopulation",
    "METHOD_IDS",
    "RarePattern",
    "SCORE_WEIGHTED_FIXED_QUOTA",
    "generate_fixed_quota_boundary_population",
    "run_fixed_quota_boundary_condition",
    "summarize_fixed_quota_boundary",
]
