"""Command-line entry point for the task-aware public framework."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Sequence

import numpy as np

from .framework import FrameworkCompatibilityError, recommend, resolve_method, sample


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="spaquotasketch",
        description=(
            "Task-aware spatial transcriptomics sketching. Representation mode is not a "
            "probability sample; only inference mode returns valid sampling weights."
        ),
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    command = subparsers.add_parser(
        "sample",
        help="draw a task-aware sample from .npy expression and coordinate inputs",
        description=(
            "Representation mode uses expression-informed candidates and strict spatial quotas. "
            "It has no inclusion_probability or sampling_weight. Inference mode returns "
            "sampling_weight = 1 / inclusion_probability. The representation composition "
            "calibration factor is descriptive only. Inspect completion diagnostics."
        ),
    )
    command.add_argument("--mode", choices=("representation", "inference"), default="representation")
    command.add_argument("--method", help="explicit registered method compatible with --mode")
    target = command.add_mutually_exclusive_group(required=False)
    target.add_argument("--fraction", type=float, help="target fraction in (0, 1]")
    target.add_argument("--target-n", type=int, help="exact target number of cells")
    command.add_argument("--seed", type=int, default=0, help="master random seed")
    command.add_argument("--coordinates", help="two-column-or-more NumPy .npy coordinate matrix")
    command.add_argument("--expression", help="NumPy .npy expression matrix, required for representation mode")
    command.add_argument("--cell-ids", help="optional NumPy .npy array of unique cell identifiers")
    command.add_argument("--dataset-id", default="unnamed_dataset")
    command.add_argument("--output", help="new output directory; existing paths are never overwritten")
    command.add_argument(
        "--storage-backend",
        choices=("local_atomic", "sshfs_append_only"),
        default="local_atomic",
        help="record local or SSHFS append-only persistence intent in provenance",
    )
    command.add_argument("--downstream-goal", default="", help="plain-language downstream task for recommendation")
    command.add_argument(
        "--explain-recommendation",
        action="store_true",
        help="print a task recommendation with reasons and limits, without sampling",
    )
    command.add_argument(
        "--dry-run",
        action="store_true",
        help="validate method resolution only; do not execute an algorithm or write output",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    arguments = parser.parse_args(argv)
    if arguments.command != "sample":
        parser.error("Only the sample command is currently available.")
    available_inputs = []
    if arguments.coordinates:
        available_inputs.append("coordinates")
    if arguments.expression:
        available_inputs.append("expression")
    recommendation = recommend(
        downstream_goal=arguments.downstream_goal,
        needs_population_inference=arguments.mode == "inference",
        needs_expression_state_preservation=arguments.mode == "representation",
        needs_spatial_coverage=arguments.mode != "inference" or arguments.method != "uniform_srs",
        requires_sampling_weights=arguments.mode == "inference",
        sampling_fraction=arguments.fraction,
        available_inputs=available_inputs,
    )
    if arguments.explain_recommendation:
        print(json.dumps(recommendation.to_dict(), ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    try:
        resolved_method = resolve_method(mode=arguments.mode, method=arguments.method)
    except FrameworkCompatibilityError as error:
        parser.error(str(error))
    if arguments.dry_run:
        print(
            json.dumps(
                {
                    "dry_run": True,
                    "mode": arguments.mode,
                    "resolved_method": resolved_method,
                    "storage_backend": arguments.storage_backend,
                    "warning": "No sampling algorithm was executed and no output was written.",
                },
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
            )
        )
        return 0
    if arguments.fraction is None and arguments.target_n is None:
        parser.error("Specify exactly one of --fraction or --target-n unless using --dry-run.")
    if not arguments.output:
        parser.error("--output is required when sampling.")
    expression = _load_array(arguments.expression) if arguments.expression else None
    coordinates = _load_array(arguments.coordinates) if arguments.coordinates else None
    cell_ids = _load_array(arguments.cell_ids) if arguments.cell_ids else None
    result = sample(
        data=expression,
        coordinates=coordinates,
        cell_ids=cell_ids,
        fraction=arguments.fraction,
        target_n=arguments.target_n,
        mode=arguments.mode,
        method=resolved_method,
        random_state=arguments.seed,
        dataset_id=arguments.dataset_id,
        storage_backend=arguments.storage_backend,
    )
    _write_new_output(Path(arguments.output), result)
    print(
        json.dumps(
            {
                "output": str(Path(arguments.output)),
                "method_id": result.method_id,
                "mode": result.mode,
                "actual_n": result.actual_n,
                "sampling_weight_available": result.sampling_weight is not None,
            },
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
    )
    return 0


def _load_array(path: str) -> np.ndarray:
    return np.load(Path(path), allow_pickle=True)


def _write_new_output(output: Path, result) -> None:
    """Create a new output directory without replacing files on local or SSHFS storage."""
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite existing output path: {output}")
    output.mkdir(parents=True, exist_ok=False)
    selection_path = output / "selected_cells.csv"
    metadata_path = output / "sample_metadata.json"
    with selection_path.open("x", encoding="utf-8", newline="") as handle:
        result.selected_table().to_csv(handle, index=False)
    with metadata_path.open("x", encoding="utf-8") as handle:
        json.dump(result.metadata_dict(), handle, ensure_ascii=False, indent=2, sort_keys=True)
        handle.write("\n")


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
