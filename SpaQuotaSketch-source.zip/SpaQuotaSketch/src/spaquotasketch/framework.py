"""Public task-aware interface for the frozen SpaQuotaSketch samplers.

This module deliberately orchestrates registered methods without changing their
candidate-pool, quota, or probability-design definitions.  Representation and
inference are different tasks and therefore expose different result semantics.
"""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from typing import Any, Hashable, Mapping, Sequence
import subprocess
import time

import numpy as np
import pandas as pd

from .representation.quota_completed import (
    QuotaCompletedRepresentationResult,
    frozen_expression_strata,
    sample_quota_completed_representation,
)
from .samplers import (
    SamplingValidationError,
    sample_spatial_pivotal,
    sample_spatial_stratified_srs,
    sample_uniform_srs,
)
from .samplers.base import resolve_target_n
from .samplers.registry import default_registry_path, get_method_metadata
from .v2_1.quota import allocate_largest_remainder_quotas
from .v2_1.spatial import choose_adaptive_regular_partition


REPRESENTATION_MODE = "representation"
INFERENCE_MODE = "inference"
DEFAULT_METHODS = {
    REPRESENTATION_MODE: "quota_completed_representation_mode",
    INFERENCE_MODE: "spatial_stratified_srs",
}
_PUBLIC_INFERENCE_METHODS = {
    "uniform_srs",
    "spatial_stratified_srs",
    "spatial_pivotal",
}
_STORAGE_BACKENDS = {"local_atomic", "sshfs_append_only"}


class FrameworkCompatibilityError(ValueError):
    """Raised when a requested public mode and method cannot be combined."""


class DesignBasedEstimationError(ValueError):
    """Raised when a non-probability result is used for design-based estimation."""


@dataclass(frozen=True)
class Recommendation:
    """A transparent qualitative recommendation, not a performance guarantee."""

    recommended_mode: str
    recommended_method: str
    alternative_method: str | None
    rationale: tuple[str, ...]
    warnings: tuple[str, ...]
    unsupported_requests: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "recommended_mode": self.recommended_mode,
            "recommended_method": self.recommended_method,
            "alternative_method": self.alternative_method,
            "rationale": list(self.rationale),
            "warnings": list(self.warnings),
            "unsupported_requests": list(self.unsupported_requests),
        }


@dataclass(frozen=True)
class TaskAwareSampleResult:
    """One public sampling result with mode-specific, honest field semantics."""

    population_cell_ids: np.ndarray
    selected_cell_ids: np.ndarray
    selected_mask: np.ndarray
    method_id: str
    method_display_name: str
    mode: str
    algorithm_version: str
    target_n: int
    actual_n: int
    target_fraction: float
    random_state: int
    spatial_strata: np.ndarray
    stratum_quotas: Mapping[str, int]
    diagnostics: Mapping[str, Any]
    warnings: tuple[str, ...]
    provenance: Mapping[str, Any]
    candidate_source: Mapping[str, str] | None = None
    expression_stratum: np.ndarray | None = None
    completion_diagnostics: pd.DataFrame | None = None
    quality_status: str | None = None
    composition_calibration_factor: np.ndarray | None = None
    inclusion_probability: np.ndarray | None = None
    sampling_weight: np.ndarray | None = None
    supports_ht: bool = False
    supports_hajek: bool = False
    probability_diagnostics: Mapping[str, Any] | None = None
    design_metadata: Mapping[str, Any] | None = None

    def __post_init__(self) -> None:
        population = np.asarray(self.population_cell_ids, dtype=object).reshape(-1)
        selected = np.asarray(self.selected_cell_ids, dtype=object).reshape(-1)
        mask = np.asarray(self.selected_mask, dtype=bool).reshape(-1)
        strata = np.asarray(self.spatial_strata, dtype=object).reshape(-1)
        if population.size != mask.size or strata.size != mask.size:
            raise FrameworkCompatibilityError(
                "Population identifiers, selected_mask, and spatial_strata must align."
            )
        if selected.size != int(mask.sum()) or not np.array_equal(selected, population[mask]):
            raise FrameworkCompatibilityError(
                "selected_cell_ids must be exactly the population cells selected by selected_mask."
            )
        if int(self.actual_n) != selected.size or int(self.target_n) < int(self.actual_n):
            raise FrameworkCompatibilityError("target_n and actual_n are inconsistent with selection.")
        if self.mode not in {REPRESENTATION_MODE, INFERENCE_MODE}:
            raise FrameworkCompatibilityError("mode must be representation or inference.")
        if self.mode == REPRESENTATION_MODE:
            if self.inclusion_probability is not None or self.sampling_weight is not None:
                raise FrameworkCompatibilityError(
                    "Representation mode must not emit inclusion_probability or sampling_weight."
                )
            if self.supports_ht or self.supports_hajek:
                raise FrameworkCompatibilityError(
                    "Representation mode cannot claim design-based HT or Hajek support."
                )
        else:
            if self.inclusion_probability is None or self.sampling_weight is None:
                raise FrameworkCompatibilityError(
                    "Inference mode must return inclusion_probability and sampling_weight."
                )
            probability = np.asarray(self.inclusion_probability, dtype=float).reshape(-1)
            weight = np.asarray(self.sampling_weight, dtype=float).reshape(-1)
            if probability.size != population.size or weight.size != population.size:
                raise FrameworkCompatibilityError("Probability fields must cover the full population.")
            if np.any(probability <= 0) or np.any(probability > 1):
                raise FrameworkCompatibilityError(
                    "Public inference mode requires 0 < inclusion_probability <= 1 for every cell."
                )
            if not np.allclose(weight, 1.0 / probability, atol=1e-12, rtol=0):
                raise FrameworkCompatibilityError("sampling_weight must equal 1 / inclusion_probability.")
            object.__setattr__(self, "inclusion_probability", probability)
            object.__setattr__(self, "sampling_weight", weight)
        if self.composition_calibration_factor is not None:
            factor = np.asarray(self.composition_calibration_factor, dtype=float).reshape(-1)
            if factor.size != population.size:
                raise FrameworkCompatibilityError(
                    "composition_calibration_factor must cover the full population."
                )
            object.__setattr__(self, "composition_calibration_factor", factor)
        if self.expression_stratum is not None:
            expression_stratum = np.asarray(self.expression_stratum, dtype=object).reshape(-1)
            if expression_stratum.size != population.size:
                raise FrameworkCompatibilityError("expression_stratum must cover the full population.")
            object.__setattr__(self, "expression_stratum", expression_stratum)
        object.__setattr__(self, "population_cell_ids", population)
        object.__setattr__(self, "selected_cell_ids", selected)
        object.__setattr__(self, "selected_mask", mask)
        object.__setattr__(self, "spatial_strata", strata)

    def selected_table(self) -> pd.DataFrame:
        """Return only selected cells, omitting unavailable probability fields."""
        selected_positions = np.flatnonzero(self.selected_mask)
        table: dict[str, Any] = {
            "cell_id": self.selected_cell_ids,
            "selected": np.ones(self.actual_n, dtype=bool),
            "spatial_stratum": self.spatial_strata[selected_positions],
        }
        if self.expression_stratum is not None:
            table["expression_stratum"] = self.expression_stratum[selected_positions]
        if self.candidate_source is not None:
            table["candidate_source"] = [
                self.candidate_source.get(str(cell_id), "not_recorded")
                for cell_id in self.selected_cell_ids
            ]
        if self.composition_calibration_factor is not None:
            table["composition_calibration_factor"] = self.composition_calibration_factor[
                selected_positions
            ]
        if self.inclusion_probability is not None:
            table["inclusion_probability"] = self.inclusion_probability[selected_positions]
            table["sampling_weight"] = self.sampling_weight[selected_positions]
        return pd.DataFrame(table)

    def metadata_dict(self) -> dict[str, Any]:
        """Return JSON-ready metadata while preserving absent-field semantics."""
        return {
            "method_id": self.method_id,
            "method_display_name": self.method_display_name,
            "mode": self.mode,
            "algorithm_version": self.algorithm_version,
            "target_n": int(self.target_n),
            "actual_n": int(self.actual_n),
            "target_fraction": float(self.target_fraction),
            "random_state": int(self.random_state),
            "stratum_quotas": {str(key): int(value) for key, value in self.stratum_quotas.items()},
            "quality_status": self.quality_status,
            "supports_ht": bool(self.supports_ht),
            "supports_hajek": bool(self.supports_hajek),
            "has_inclusion_probability": self.inclusion_probability is not None,
            "has_sampling_weight": self.sampling_weight is not None,
            "diagnostics": _json_ready(self.diagnostics),
            "warnings": list(self.warnings),
            "provenance": _json_ready(self.provenance),
            "probability_diagnostics": _json_ready(self.probability_diagnostics or {}),
            "design_metadata": _json_ready(self.design_metadata or {}),
        }


def method_capabilities(method_id: str) -> Mapping[str, Any]:
    """Return one public capability record from the canonical method registry."""
    return get_method_metadata(method_id).values


def resolve_method(*, mode: str, method: str | None = None) -> str:
    """Resolve a public default and reject legacy or task-incompatible identities."""
    mode = str(mode).strip().lower()
    if mode not in DEFAULT_METHODS:
        raise FrameworkCompatibilityError(
            "mode must be 'representation' or 'inference'; these modes have different guarantees."
        )
    resolved = DEFAULT_METHODS[mode] if method is None else str(method).strip()
    metadata = get_method_metadata(resolved)
    supported_modes = set(metadata.values.get("supported_modes", ()))
    if mode not in supported_modes:
        declared = ", ".join(sorted(supported_modes)) or "no public mode"
        raise FrameworkCompatibilityError(
            f"Method '{resolved}' is not compatible with mode '{mode}' (registered modes: {declared}). "
            "Choose a method registered for the requested task; changing this changes method identity."
        )
    if metadata.values.get("legacy_status") != "current" or resolved not in {
        "quota_completed_representation_mode",
        *_PUBLIC_INFERENCE_METHODS,
    }:
        raise FrameworkCompatibilityError(
            f"Method '{resolved}' is legacy, experimental, or not part of the public task-aware API."
        )
    return resolved


def recommend(
    *,
    downstream_goal: str | None = None,
    needs_population_inference: bool = False,
    needs_expression_state_preservation: bool = False,
    needs_spatial_coverage: bool = False,
    requires_sampling_weights: bool = False,
    sampling_fraction: float | None = None,
    available_inputs: Sequence[str] = (),
) -> Recommendation:
    """Recommend a mode from user intent without pancreas-derived cutoffs."""
    goal = (downstream_goal or "").strip().lower()
    inputs = {str(value).strip().lower() for value in available_inputs}
    goal_is_inference = any(
        token in goal
        for token in ("composition", "proportion", "mean", "total", "population", "ht", "hajek")
    )
    goal_is_representation = any(
        token in goal
        for token in ("cluster", "umap", "embedding", "discovery", "rare", "domain", "representation")
    )
    choose_inference = bool(
        needs_population_inference or requires_sampling_weights or goal_is_inference
    )
    rationale: list[str] = []
    warnings: list[str] = []
    unsupported: list[str] = []
    if choose_inference:
        method = "spatial_stratified_srs"
        rationale.append(
            "The requested task needs probability-based population estimation, so the inference mode is selected."
        )
        rationale.append(
            "It provides positive first-order inclusion probabilities and weights equal to one divided by those probabilities."
        )
        if needs_expression_state_preservation or goal_is_representation:
            warnings.append(
                "Inference mode is not designed to maximize expression-state coverage; run representation mode separately for discovery."
            )
        if not needs_spatial_coverage:
            warnings.append(
                "Uniform SRS is an available alternative when spatial allocation is not needed."
            )
        alternative = "uniform_srs" if not needs_spatial_coverage else "spatial_pivotal"
    else:
        method = "quota_completed_representation_mode"
        rationale.append(
            "The requested task is exploratory representation, so the expression-informed representation mode is selected."
        )
        rationale.append(
            "It combines expression-stratified candidates with exact final spatial quotas."
        )
        warnings.append(
            "Representation mode does not provide inclusion probabilities, sampling weights, HT estimates, or Hajek estimates."
        )
        warnings.append(
            "Its composition calibration factor is descriptive only and is not an inverse inclusion probability."
        )
        alternative = "spatial_stratified_srs"
    if sampling_fraction is not None and not 0 < float(sampling_fraction) <= 1:
        unsupported.append("sampling_fraction must lie in (0, 1] when supplied.")
    if needs_spatial_coverage and inputs and not ({"coordinates", "spatial_coordinates"} & inputs):
        unsupported.append("Spatial coverage requires two-dimensional spatial coordinates.")
    if (needs_expression_state_preservation or goal_is_representation) and inputs and not (
        {"expression", "expression_matrix", "data", "embedding"} & inputs
    ):
        unsupported.append("Expression-state preservation requires an expression matrix or embedding.")
    return Recommendation(
        recommended_mode=INFERENCE_MODE if choose_inference else REPRESENTATION_MODE,
        recommended_method=method,
        alternative_method=alternative,
        rationale=tuple(rationale),
        warnings=tuple(warnings),
        unsupported_requests=tuple(unsupported),
    )


def sample(
    data: Any | None = None,
    coordinates: Sequence[Sequence[float]] | None = None,
    *,
    cell_ids: Sequence[Hashable] | None = None,
    fraction: float | None = None,
    target_n: int | None = None,
    mode: str = REPRESENTATION_MODE,
    method: str | None = None,
    random_state: int = 0,
    spatial_strata: Sequence[Hashable] | None = None,
    stratum_quotas: Mapping[Hashable, int] | None = None,
    dataset_id: str = "unnamed_dataset",
    storage_backend: str = "local_atomic",
) -> TaskAwareSampleResult:
    """Sample cells through the public task-aware framework.

    ``data`` is an AnnData-like object or an expression matrix for representation
    mode.  Inference mode only needs a population size (from data, coordinates,
    or cell_ids) and coordinates for spatial methods.  Automatic spatial
    partitions are deterministic functions of coordinates and target size.
    """
    started = time.perf_counter()
    _validate_storage_backend(storage_backend)
    resolved = resolve_method(mode=mode, method=method)
    ids, coordinates_array = _resolve_population_inputs(data, coordinates, cell_ids)
    n_population = int(ids.size)
    if n_population == 0:
        raise SamplingValidationError("The public framework requires at least one cell.")
    n_target = resolve_target_n(n_population, target_n=target_n, target_fraction=fraction)
    if n_target < 1:
        raise SamplingValidationError(
            "The public framework requires target_n of at least one so every cell can retain positive support in inference mode."
        )
    resolved_fraction = float(n_target / n_population if fraction is None else fraction)
    strata, quotas, partition_metadata = _resolve_spatial_design(
        method_id=resolved,
        coordinates=coordinates_array,
        target_n=n_target,
        spatial_strata=spatial_strata,
        stratum_quotas=stratum_quotas,
    )
    if resolved == "quota_completed_representation_mode":
        embedding = _expression_embedding(data)
        raw_result = sample_quota_completed_representation(
            cell_ids=ids.tolist(),
            expression_embedding=embedding,
            spatial_strata=strata.tolist(),
            quotas=quotas,
            target_n=n_target,
            dataset_id=str(dataset_id),
            target_fraction=resolved_fraction,
            benchmark_repeat_seed=int(random_state),
        )
        result = _representation_result(
            raw_result=raw_result,
            cell_ids=ids,
            spatial_strata=strata,
            quotas=quotas,
            embedding=embedding,
            target_n=n_target,
            target_fraction=resolved_fraction,
            random_state=random_state,
            partition_metadata=partition_metadata,
            storage_backend=storage_backend,
            elapsed_seconds=time.perf_counter() - started,
        )
    else:
        result = _inference_result(
            method_id=resolved,
            cell_ids=ids,
            coordinates=coordinates_array,
            spatial_strata=strata,
            quotas=quotas,
            target_n=n_target,
            target_fraction=resolved_fraction,
            random_state=random_state,
            partition_metadata=partition_metadata,
            storage_backend=storage_backend,
            elapsed_seconds=time.perf_counter() - started,
        )
    return result


def horvitz_thompson_total(result: TaskAwareSampleResult, values: Sequence[float]) -> float:
    """Estimate a population total from a valid public inference-mode result."""
    _require_design_based_result(result, "Horvitz-Thompson")
    outcome = _validate_outcome_values(result, values)
    return float(np.sum(outcome[result.selected_mask] / result.inclusion_probability[result.selected_mask]))


def hajek_mean(result: TaskAwareSampleResult, values: Sequence[float]) -> float:
    """Estimate a population mean or binary proportion from a public inference result."""
    _require_design_based_result(result, "Hajek")
    outcome = _validate_outcome_values(result, values)
    selected_weights = result.sampling_weight[result.selected_mask]
    return float(
        np.sum(outcome[result.selected_mask] * selected_weights) / np.sum(selected_weights)
    )


def _resolve_population_inputs(
    data: Any | None,
    coordinates: Sequence[Sequence[float]] | None,
    cell_ids: Sequence[Hashable] | None,
) -> tuple[np.ndarray, np.ndarray | None]:
    inferred_size: int | None = None
    inferred_ids: np.ndarray | None = None
    inferred_coordinates: np.ndarray | None = None
    if data is not None:
        if hasattr(data, "X"):
            inferred_size = int(data.X.shape[0])
            if hasattr(data, "obs_names"):
                inferred_ids = np.asarray([str(value) for value in data.obs_names], dtype=object)
            if coordinates is None and hasattr(data, "obsm") and "spatial" in data.obsm:
                inferred_coordinates = _validate_coordinates(data.obsm["spatial"], inferred_size)
        else:
            values = np.asarray(data)
            if values.ndim != 2:
                raise SamplingValidationError("data must be a two-dimensional expression matrix or AnnData-like object.")
            inferred_size = int(values.shape[0])
    coordinate_array = (
        _validate_coordinates(coordinates, inferred_size) if coordinates is not None else inferred_coordinates
    )
    if cell_ids is not None:
        ids = np.asarray([str(value) for value in cell_ids], dtype=object).reshape(-1)
    elif inferred_ids is not None:
        ids = inferred_ids
    elif inferred_size is not None:
        ids = np.asarray([f"cell_{index}" for index in range(inferred_size)], dtype=object)
    elif coordinate_array is not None:
        ids = np.asarray([f"cell_{index}" for index in range(coordinate_array.shape[0])], dtype=object)
    else:
        raise SamplingValidationError("Provide data, coordinates, or cell_ids to define the population.")
    if inferred_size is not None and ids.size != inferred_size:
        raise SamplingValidationError("cell_ids must contain one unique identifier per expression row.")
    if coordinate_array is not None and coordinate_array.shape[0] != ids.size:
        raise SamplingValidationError("coordinates must contain one row per cell_id.")
    if ids.size != len(set(ids.tolist())):
        raise SamplingValidationError("cell_ids must be unique.")
    return ids, coordinate_array


def _validate_coordinates(values: Sequence[Sequence[float]], expected_size: int | None) -> np.ndarray:
    coordinates = np.asarray(values, dtype=float)
    if coordinates.ndim != 2 or coordinates.shape[1] < 2:
        raise SamplingValidationError("coordinates must contain at least two numeric columns.")
    if expected_size is not None and coordinates.shape[0] != expected_size:
        raise SamplingValidationError("coordinates must contain one row per cell.")
    if not np.isfinite(coordinates[:, :2]).all():
        raise SamplingValidationError("coordinates must be finite.")
    return coordinates[:, :2]


def _expression_embedding(data: Any | None) -> np.ndarray:
    if data is None:
        raise SamplingValidationError(
            "Representation mode requires an expression matrix or AnnData-like object; it cannot use coordinates alone."
        )
    if hasattr(data, "X"):
        from .preprocess import compute_pca_embedding

        return np.asarray(compute_pca_embedding(data, n_components=30, random_state=0), dtype=float)
    values = np.asarray(data, dtype=float)
    if values.ndim != 2 or values.shape[0] < 2 or values.shape[1] < 2:
        raise SamplingValidationError(
            "Representation mode needs at least two cells and two expression features for its frozen PCA candidate stage."
        )
    if not np.isfinite(values).all():
        raise SamplingValidationError("expression data must be finite.")
    from sklearn.decomposition import PCA

    n_components = min(30, values.shape[0] - 1, values.shape[1])
    return np.asarray(PCA(n_components=n_components, random_state=0).fit_transform(values), dtype=float)


def _resolve_spatial_design(
    *,
    method_id: str,
    coordinates: np.ndarray | None,
    target_n: int,
    spatial_strata: Sequence[Hashable] | None,
    stratum_quotas: Mapping[Hashable, int] | None,
) -> tuple[np.ndarray, dict[str, int], dict[str, Any]]:
    if method_id == "uniform_srs":
        if spatial_strata is not None or stratum_quotas is not None:
            raise FrameworkCompatibilityError(
                "uniform_srs has no spatial strata or quotas. Use spatial_stratified_srs for a spatial design."
            )
        return np.asarray([], dtype=object), {"global": int(target_n)}, {"partition_source": "global"}
    if coordinates is None:
        raise SamplingValidationError(
            "This method requires spatial coordinates. Supplying coordinates changes only the spatial partition, not the frozen sampler."
        )
    if (spatial_strata is None) != (stratum_quotas is None):
        raise FrameworkCompatibilityError(
            "Provide spatial_strata and stratum_quotas together, or provide neither and allow the deterministic feasible partition."
        )
    if spatial_strata is not None and stratum_quotas is not None:
        strata = np.asarray([str(value) for value in spatial_strata], dtype=object).reshape(-1)
        if strata.size != coordinates.shape[0]:
            raise SamplingValidationError("spatial_strata must contain one value per coordinate row.")
        quotas = {str(key): int(value) for key, value in stratum_quotas.items()}
        if sum(quotas.values()) != int(target_n):
            raise SamplingValidationError("stratum_quotas must sum exactly to target_n.")
        if any(value < 1 for value in quotas.values()):
            raise SamplingValidationError(
                "The public task-aware interface requires positive quotas for every nonempty stratum to retain positive inclusion probabilities."
            )
        population_strata = set(strata.tolist())
        if set(quotas) != population_strata:
            raise SamplingValidationError("stratum_quotas must define exactly the nonempty spatial strata.")
        return strata, quotas, {"partition_source": "user_supplied_frozen"}
    partition = choose_adaptive_regular_partition(coordinates, target_n, minimum_quota=1)
    allocation = allocate_largest_remainder_quotas(partition.stratum_audit, target_n, minimum_quota=1)
    return (
        np.asarray(partition.stratum_ids, dtype=object),
        {str(key): int(value) for key, value in allocation.quotas.items()},
        {
            "partition_source": "sample_size_aware_regular_grid",
            "partition_shape": [int(partition.n_x), int(partition.n_y)],
            "partition_selection_reason": partition.selection_reason,
            "n_nonempty_strata": int(len(partition.stratum_audit)),
            "minimum_quota": 1,
        },
    )


def _representation_result(
    *,
    raw_result: QuotaCompletedRepresentationResult,
    cell_ids: np.ndarray,
    spatial_strata: np.ndarray,
    quotas: Mapping[str, int],
    embedding: np.ndarray,
    target_n: int,
    target_fraction: float,
    random_state: int,
    partition_metadata: Mapping[str, Any],
    storage_backend: str,
    elapsed_seconds: float,
) -> TaskAwareSampleResult:
    metadata = get_method_metadata("quota_completed_representation_mode")
    mask = np.zeros(cell_ids.size, dtype=bool)
    mask[np.asarray(raw_result.selected_indices, dtype=int)] = True
    sizes = {stratum: int(np.sum(spatial_strata == stratum)) for stratum in quotas}
    composition = np.asarray([sizes[stratum] / quotas[stratum] for stratum in spatial_strata], dtype=float)
    sources = {
        str(row.cell_id): str(row.candidate_source)
        for row in raw_result.selected_cells.itertuples(index=False)
    }
    global_diagnostics = dict(raw_result.global_diagnostics)
    fallback_count = int(global_diagnostics.get("fallback_strata_count", 0))
    diagnostics = {
        **_common_diagnostics(
            target_n=target_n,
            actual_n=int(mask.sum()),
            spatial_strata=spatial_strata,
            quotas=quotas,
            elapsed_seconds=elapsed_seconds,
        ),
        "completion_fraction": float(global_diagnostics.get("completion_fraction_of_final_sample", 0.0)),
        "deficient_strata_fraction": float(global_diagnostics.get("deficient_strata_fraction", 0.0)),
        "fallback_count": fallback_count,
        "quality_status": str(global_diagnostics.get("quality_status", "FAIL")),
        "expression_candidate_fraction": float(global_diagnostics.get("original_candidate_fraction", 0.0)),
        "quota_completion_status": str(global_diagnostics.get("saturation_status", "unknown")),
        "candidate_completion": _json_ready(global_diagnostics),
        "spatial_partition": _json_ready(partition_metadata),
    }
    status = str(global_diagnostics.get("quality_status", "FAIL"))
    warnings = [
        "Representation mode is a descriptive sketch and does not supply design-based inclusion probabilities or sampling weights.",
        "composition_calibration_factor is descriptive only; it is not an inverse inclusion probability.",
    ]
    if status != "PASS":
        warnings.append(f"Candidate completion quality status is {status}; inspect completion diagnostics before downstream use.")
    return TaskAwareSampleResult(
        population_cell_ids=cell_ids,
        selected_cell_ids=cell_ids[mask],
        selected_mask=mask,
        method_id=metadata.method_id,
        method_display_name=str(metadata["method_display_name"]),
        mode=REPRESENTATION_MODE,
        algorithm_version=str(metadata["algorithm_version"]),
        target_n=target_n,
        actual_n=int(mask.sum()),
        target_fraction=target_fraction,
        random_state=int(random_state),
        spatial_strata=spatial_strata,
        stratum_quotas=dict(quotas),
        diagnostics=diagnostics,
        warnings=tuple(warnings),
        provenance=_provenance(metadata.method_id, storage_backend),
        candidate_source=sources,
        expression_stratum=frozen_expression_strata(embedding),
        completion_diagnostics=raw_result.stratum_diagnostics.copy(),
        quality_status=status,
        composition_calibration_factor=composition,
        inclusion_probability=None,
        sampling_weight=None,
        supports_ht=False,
        supports_hajek=False,
        probability_diagnostics=None,
        design_metadata={
            "probability_design": "not_applicable_for_two_stage_representation_design",
            "composition_calibration_factor_semantics": metadata.values.get(
                "composition_calibration_factor_definition"
            ),
        },
    )


def _inference_result(
    *,
    method_id: str,
    cell_ids: np.ndarray,
    coordinates: np.ndarray | None,
    spatial_strata: np.ndarray,
    quotas: Mapping[str, int],
    target_n: int,
    target_fraction: float,
    random_state: int,
    partition_metadata: Mapping[str, Any],
    storage_backend: str,
    elapsed_seconds: float,
) -> TaskAwareSampleResult:
    metadata = get_method_metadata(method_id)
    if method_id == "uniform_srs":
        raw = sample_uniform_srs(cell_ids, target_n, random_seed=random_state)
        output_strata = np.full(cell_ids.size, "global", dtype=object)
        output_quotas = {"global": target_n}
    elif method_id == "spatial_stratified_srs":
        raw = sample_spatial_stratified_srs(cell_ids, spatial_strata, quotas, random_seed=random_state)
        output_strata = spatial_strata
        output_quotas = dict(quotas)
    elif method_id == "spatial_pivotal":
        raw = sample_spatial_pivotal(
            cell_ids,
            coordinates,
            spatial_strata,
            quotas,
            random_seed=random_state,
        )
        output_strata = spatial_strata
        output_quotas = dict(quotas)
    else:
        raise FrameworkCompatibilityError(f"Unsupported public inference method: {method_id}.")
    probability = np.asarray(raw.inclusion_probability, dtype=float)
    weight = np.asarray(raw.sampling_weight, dtype=float)
    probability_diagnostics = _probability_diagnostics(
        probability=probability,
        weight=weight,
        selected_mask=raw.selected_mask,
        spatial_strata=output_strata,
        quotas=output_quotas,
    )
    warnings = list(raw.warnings)
    if probability_diagnostics["weight_cv"] > 1.0:
        warnings.append("Sampling weights have high coefficient of variation; inspect effective sample size.")
    if probability_diagnostics["effective_sample_size"] < 0.5 * int(raw.actual_n):
        warnings.append("Weight dispersion materially reduces the Kish effective sample size.")
    if probability_diagnostics["pi_min"] < 0.01:
        warnings.append("Very small inclusion probabilities can make estimates sensitive to a few selected cells.")
    diagnostics = {
        **_common_diagnostics(
            target_n=target_n,
            actual_n=int(raw.actual_n),
            spatial_strata=output_strata,
            quotas=output_quotas,
            elapsed_seconds=elapsed_seconds,
        ),
        "spatial_partition": _json_ready(partition_metadata),
        "probability_diagnostics": probability_diagnostics,
    }
    return TaskAwareSampleResult(
        population_cell_ids=np.asarray(raw.population_cell_ids, dtype=object),
        selected_cell_ids=np.asarray(raw.selected_cell_ids, dtype=object),
        selected_mask=np.asarray(raw.selected_mask, dtype=bool),
        method_id=metadata.method_id,
        method_display_name=str(metadata["method_display_name"]),
        mode=INFERENCE_MODE,
        algorithm_version=str(metadata["algorithm_version"]),
        target_n=target_n,
        actual_n=int(raw.actual_n),
        target_fraction=target_fraction,
        random_state=int(random_state),
        spatial_strata=output_strata,
        stratum_quotas=output_quotas,
        diagnostics=diagnostics,
        warnings=tuple(warnings),
        provenance=_provenance(method_id, storage_backend),
        inclusion_probability=probability,
        sampling_weight=weight,
        supports_ht=bool(metadata["supports_ht"]),
        supports_hajek=bool(metadata["supports_hajek"]),
        probability_diagnostics=probability_diagnostics,
        design_metadata={
            "probability_design": metadata.values.get("probability_design"),
            "inclusion_probability_definition": metadata["inclusion_probability_definition"],
            "within_stratum_sampler": metadata["within_stratum_sampler"],
        },
    )


def _common_diagnostics(
    *,
    target_n: int,
    actual_n: int,
    spatial_strata: np.ndarray,
    quotas: Mapping[str, int],
    elapsed_seconds: float,
) -> dict[str, Any]:
    nonempty = [stratum for stratum in quotas if np.any(spatial_strata == stratum)]
    quota_errors = {
        str(stratum): int(np.sum(spatial_strata == stratum)) < int(quota)
        for stratum, quota in quotas.items()
    }
    return {
        "target_n": int(target_n),
        "actual_n": int(actual_n),
        "n_spatial_strata": int(len(nonempty)),
        "spatial_quota_infeasible_strata": [
            stratum for stratum, is_infeasible in quota_errors.items() if is_infeasible
        ],
        "runtime_seconds": float(elapsed_seconds),
        "process_peak_memory_bytes": _process_peak_memory_bytes(),
    }


def _probability_diagnostics(
    *,
    probability: np.ndarray,
    weight: np.ndarray,
    selected_mask: np.ndarray,
    spatial_strata: np.ndarray,
    quotas: Mapping[str, int],
) -> dict[str, Any]:
    selected_weights = weight[selected_mask]
    weight_cv = float(np.std(selected_weights, ddof=0) / np.mean(selected_weights)) if selected_weights.size else 0.0
    effective_sample_size = (
        float(np.sum(selected_weights) ** 2 / np.sum(selected_weights**2))
        if selected_weights.size
        else 0.0
    )
    quota_error = {
        str(stratum): float(probability[spatial_strata == stratum].sum() - quota)
        for stratum, quota in quotas.items()
    }
    return {
        "pi_min": float(np.min(probability)),
        "pi_max": float(np.max(probability)),
        "weight_cv": weight_cv,
        "max_weight": float(np.max(weight)),
        "effective_sample_size": effective_sample_size,
        "effective_sample_size_over_n": float(effective_sample_size / int(selected_mask.sum())),
        "per_stratum_pi_sum_quota_error": quota_error,
    }


def _require_design_based_result(result: TaskAwareSampleResult, estimator_name: str) -> None:
    if result.mode != INFERENCE_MODE or result.inclusion_probability is None:
        raise DesignBasedEstimationError(
            f"{estimator_name} estimation requires inference mode with defined inclusion probabilities. "
            "Representation mode is a descriptive sketch and has no valid probability weights."
        )


def _validate_outcome_values(result: TaskAwareSampleResult, values: Sequence[float]) -> np.ndarray:
    outcome = np.asarray(values, dtype=float).reshape(-1)
    if outcome.size != result.population_cell_ids.size or not np.isfinite(outcome).all():
        raise DesignBasedEstimationError("values must be finite and align with the full population order.")
    return outcome


def _validate_storage_backend(storage_backend: str) -> None:
    if storage_backend not in _STORAGE_BACKENDS:
        allowed = ", ".join(sorted(_STORAGE_BACKENDS))
        raise FrameworkCompatibilityError(f"storage_backend must be one of: {allowed}.")


def _provenance(method_id: str, storage_backend: str) -> dict[str, Any]:
    registry = default_registry_path()
    return {
        "method_registry": registry.name,
        "method_registry_sha256": sha256(registry.read_bytes()).hexdigest(),
        "method_id": method_id,
        "git_commit": _git_commit(),
        "storage_backend": storage_backend,
    }


def _git_commit() -> str | None:
    try:
        completed = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=Path(__file__).resolve().parents[2],
            check=True,
            capture_output=True,
            text=True,
            timeout=3,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    return completed.stdout.strip() or None


def _process_peak_memory_bytes() -> int | None:
    try:
        import psutil

        memory = psutil.Process().memory_info()
        return int(getattr(memory, "peak_wset", memory.rss))
    except (ImportError, OSError):
        return None


def _json_ready(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _json_ready(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_ready(item) for item in value]
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return [_json_ready(item) for item in value.tolist()]
    if isinstance(value, pd.DataFrame):
        return value.to_dict(orient="records")
    return value


__all__ = [
    "DEFAULT_METHODS",
    "DesignBasedEstimationError",
    "FrameworkCompatibilityError",
    "INFERENCE_MODE",
    "REPRESENTATION_MODE",
    "Recommendation",
    "TaskAwareSampleResult",
    "hajek_mean",
    "horvitz_thompson_total",
    "method_capabilities",
    "recommend",
    "resolve_method",
    "sample",
]
