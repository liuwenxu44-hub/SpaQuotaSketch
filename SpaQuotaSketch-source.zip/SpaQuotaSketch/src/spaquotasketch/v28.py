"""Cross-fitted fixed-margin graph-support candidate paths for SpaQuotaSketch."""

from __future__ import annotations

from collections import Counter, defaultdict
from typing import Hashable, Sequence

import numpy as np


DEFAULT_PATH_FRACTIONS = (0.0, 0.25, 0.5, 0.75, 1.0)


def _validate_path_fractions(path_fractions: Sequence[float]) -> tuple[float, ...]:
    """Validate and normalize the requested fractions of feasible exchanges."""
    values = tuple(float(value) for value in path_fractions)
    if not values or any(not 0.0 <= value <= 1.0 for value in values):
        raise ValueError("path_fractions must be non-empty values in [0, 1].")
    if tuple(sorted(set(values))) != values or values[0] != 0.0:
        raise ValueError("path_fractions must be unique, sorted, and start with 0.0.")
    return values


def fixed_margin_graph_support_path(
    source_selected_indices: Sequence[int],
    spatial_bin_ids: Sequence[Hashable],
    expression_bin_ids: Sequence[Hashable],
    state_ids: Sequence[Hashable],
    knn_indices,
    path_fractions: Sequence[float] = DEFAULT_PATH_FRACTIONS,
) -> list[tuple[str, list[int], dict[str, object]]]:
    """Generate fixed-margin candidates with progressively stronger graph support.

    The source selection defines an exact quota for every tuple of spatial bin,
    selection-view expression bin, and selection-view expression state.  Within
    each tuple, a source cell can only be exchanged for an unselected cell from
    the same tuple.  Exchanges are ordered by the increase in directed neighbor
    support in a graph built solely from the selection gene view.

    The function intentionally performs no gene-statistic or downstream-label
    checks.  Those checks belong to the independent holdout view in the caller.
    """
    n_obs = len(spatial_bin_ids)
    if len(expression_bin_ids) != n_obs or len(state_ids) != n_obs:
        raise ValueError("All fixed-margin identifiers must have the same length.")
    fractions = _validate_path_fractions(path_fractions)
    neighbors = np.asarray(knn_indices, dtype=int)
    if neighbors.ndim != 2 or neighbors.shape[0] != n_obs or neighbors.shape[1] < 1:
        raise ValueError("knn_indices must have one non-empty row per observation.")
    if neighbors.min(initial=0) < 0 or neighbors.max(initial=-1) >= n_obs:
        raise ValueError("knn_indices contains an invalid observation index.")

    source = np.asarray(source_selected_indices, dtype=int)
    if (
        source.ndim != 1
        or source.size == 0
        or source.size != np.unique(source).size
        or source.min(initial=0) < 0
        or source.max(initial=-1) >= n_obs
    ):
        raise ValueError("source_selected_indices must contain unique valid observation indices.")

    stratum_ids = list(zip(spatial_bin_ids, expression_bin_ids, state_ids))
    source_mask = np.zeros(n_obs, dtype=bool)
    source_mask[source] = True
    source_plan = Counter(stratum_ids[index] for index in source)
    indices_by_stratum: dict[tuple[Hashable, Hashable, Hashable], list[int]] = defaultdict(list)
    for index, stratum in enumerate(stratum_ids):
        indices_by_stratum[stratum].append(index)

    indegree = np.bincount(neighbors.reshape(-1), minlength=n_obs).astype(int)
    exchanges: list[tuple[int, int, int]] = []
    for stratum, quota in source_plan.items():
        population = np.asarray(indices_by_stratum[stratum], dtype=int)
        selected = population[source_mask[population]]
        unselected = population[~source_mask[population]]
        if selected.size != quota:
            raise RuntimeError("Source quota plan is internally inconsistent.")
        if selected.size == population.size:
            continue
        remove_order = selected[np.lexsort((selected, indegree[selected]))]
        add_order = unselected[np.lexsort((unselected, -indegree[unselected]))]
        for removed, added in zip(remove_order, add_order):
            gain = int(indegree[added] - indegree[removed])
            if gain <= 0:
                break
            exchanges.append((gain, int(removed), int(added)))

    exchanges.sort(key=lambda item: (-item[0], item[2], item[1]))
    output: list[tuple[str, list[int], dict[str, object]]] = []
    for fraction in fractions:
        n_exchanges = int(np.floor(fraction * len(exchanges) + 1e-12))
        selected_mask = source_mask.copy()
        for _, removed, added in exchanges[:n_exchanges]:
            selected_mask[removed] = False
            selected_mask[added] = True
        selected = np.flatnonzero(selected_mask).astype(int)
        selected_plan = Counter(stratum_ids[index] for index in selected)
        if selected.size != source.size or selected_plan != source_plan:
            raise RuntimeError("Graph-support path changed a fixed source quota.")
        represented = selected_mask | selected_mask[neighbors].any(axis=1)
        name = f"path_{int(round(fraction * 100)):03d}"
        output.append(
            (
                name,
                selected.tolist(),
                {
                    "candidate_name": name,
                    "path_fraction": float(fraction),
                    "n_selected": int(selected.size),
                    "n_feasible_graph_exchanges": int(len(exchanges)),
                    "n_applied_graph_exchanges": int(n_exchanges),
                    "fixed_margin_definition": "spatial_expression_state_selection_view",
                    "fixed_margins_preserved": True,
                    "mean_selection_graph_indegree": float(indegree[selected].mean()),
                    "selection_graph_neighbor_coverage": float(represented.mean()),
                    "selection_objective": "ordered_positive_directed_knn_support_exchanges",
                },
            )
        )
    return output


__all__ = ["DEFAULT_PATH_FRACTIONS", "fixed_margin_graph_support_path"]
