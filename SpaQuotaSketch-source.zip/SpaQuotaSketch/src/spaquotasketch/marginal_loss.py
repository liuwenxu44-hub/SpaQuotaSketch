"""Marginal-loss spatial-expression sampling."""

from __future__ import annotations

from collections import Counter, defaultdict
from math import ceil, sqrt
from typing import Hashable

from .calibrated import calibrate_sampling_weights, split_quota
from .soft_balance import minmax_scale, proportional_quotas


def statistical_expression_caps(
    expression_bin_ids: list[Hashable],
    target_n: int,
    cap_z: float = 2.0,
    cap_floor: int = 1,
) -> dict[Hashable, int]:
    """Compute expression-bin caps from expected binomial sampling variation."""
    if target_n < 0:
        raise ValueError("target_n must be non-negative.")
    if cap_z < 0:
        raise ValueError("cap_z must be non-negative.")
    if cap_floor < 0:
        raise ValueError("cap_floor must be non-negative.")

    counts = Counter(expression_bin_ids)
    n_obs = len(expression_bin_ids)
    if n_obs == 0:
        return {}

    caps: dict[Hashable, int] = {}
    finite_population = (n_obs - target_n) / (n_obs - 1) if n_obs > 1 else 0.0
    finite_population = max(0.0, finite_population)
    for bin_id, count in counts.items():
        p = count / n_obs
        expected = target_n * p
        variance = target_n * p * (1.0 - p) * finite_population
        cap = ceil(expected + cap_z * sqrt(max(0.0, variance)))
        caps[bin_id] = max(int(cap_floor), ceil(expected), int(cap))
    return caps


def _representative_costs(indices_by_spatial: dict[Hashable, list[int]], features):
    import numpy as np

    values = np.asarray(features)
    costs = np.zeros(values.shape[0], dtype=float)
    for indices in indices_by_spatial.values():
        if not indices:
            continue
        local = values[indices]
        centroid = local.mean(axis=0)
        distances = np.linalg.norm(local - centroid, axis=1)
        costs[indices] = minmax_scale(distances)
    return costs


def _squared_deficit_delta(quota: int, current_count: int) -> float:
    denominator = max(1, int(quota))
    current = max(0.0, (quota - current_count) / denominator)
    next_value = max(0.0, (quota - current_count - 1) / denominator)
    return current * current - next_value * next_value


def _squared_overage_delta(cap: int, current_count: int) -> float:
    denominator = max(1, int(cap))
    current = max(0.0, (current_count - cap) / denominator)
    next_value = max(0.0, (current_count + 1 - cap) / denominator)
    return next_value * next_value - current * current


def _local_diversity_delta(local_target: int, current_unique: int) -> float:
    denominator = max(1, int(local_target))
    current = max(0.0, (local_target - current_unique) / denominator)
    next_value = max(0.0, (local_target - current_unique - 1) / denominator)
    return current * current - next_value * next_value


def marginal_loss_sample(
    spatial_bin_ids: list[Hashable],
    expression_bin_ids: list[Hashable],
    features,
    target_n: int,
    seed: int = 0,
    base_fraction: float = 0.75,
    cap_z: float = 2.0,
    cap_floor: int = 1,
    jitter_scale: float = 1e-12,
) -> tuple[list[int], dict[str, object]]:
    """Sample by greedily choosing cells with the largest marginal loss decrease."""
    import numpy as np

    if len(spatial_bin_ids) != len(expression_bin_ids):
        raise ValueError("spatial_bin_ids and expression_bin_ids must have the same length.")
    if len(spatial_bin_ids) != len(features):
        raise ValueError("features must have one row per observation.")
    if not (0 <= base_fraction <= 1):
        raise ValueError("base_fraction must be in [0, 1].")
    if jitter_scale < 0:
        raise ValueError("jitter_scale must be non-negative.")

    n_obs = len(spatial_bin_ids)
    target_n = min(max(int(target_n), 0), n_obs)
    if target_n == 0:
        return [], {"n_selected": 0, "n_filled_shortfall": 0}

    rng = np.random.default_rng(seed)
    spatial_quotas = proportional_quotas(spatial_bin_ids, target_n)
    expression_quotas = proportional_quotas(expression_bin_ids, target_n)
    expression_caps = statistical_expression_caps(
        expression_bin_ids,
        target_n=target_n,
        cap_z=cap_z,
        cap_floor=cap_floor,
    )

    indices_by_spatial: dict[Hashable, list[int]] = defaultdict(list)
    local_expression_bins: dict[Hashable, set[Hashable]] = defaultdict(set)
    for index, spatial_bin_id in enumerate(spatial_bin_ids):
        indices_by_spatial[spatial_bin_id].append(index)
        local_expression_bins[spatial_bin_id].add(expression_bin_ids[index])

    local_targets = {
        spatial_bin_id: min(int(spatial_quotas.get(spatial_bin_id, 0)), len(expression_bins))
        for spatial_bin_id, expression_bins in local_expression_bins.items()
    }
    representative_costs = _representative_costs(indices_by_spatial, features)

    selected: list[int] = []
    selected_set: set[int] = set()
    selected_expression_counts: Counter[Hashable] = Counter()
    selected_local_expression_bins: dict[Hashable, set[Hashable]] = defaultdict(set)
    n_base_selected = 0
    n_marginal_selected = 0
    n_over_cap_choices = 0

    n_expression_bins = max(1, len(expression_quotas))
    n_spatial_bins = max(1, len(spatial_quotas))
    target_n_float = float(max(1, target_n))

    def candidate_delta(index: int, spatial_bin_id: Hashable) -> float:
        expression_bin_id = expression_bin_ids[index]
        current_expression_count = selected_expression_counts[expression_bin_id]

        expression_gain = _squared_deficit_delta(
            int(expression_quotas[expression_bin_id]),
            int(current_expression_count),
        ) / n_expression_bins

        local_gain = 0.0
        local_target = int(local_targets.get(spatial_bin_id, 0))
        if (
            local_target > 0
            and expression_bin_id not in selected_local_expression_bins[spatial_bin_id]
        ):
            local_gain = _local_diversity_delta(
                local_target,
                len(selected_local_expression_bins[spatial_bin_id]),
            ) / n_spatial_bins

        overage_penalty = _squared_overage_delta(
            int(expression_caps[expression_bin_id]),
            int(current_expression_count),
        ) / n_expression_bins
        representative_penalty = float(representative_costs[index]) / target_n_float
        jitter = float(rng.random() * jitter_scale)
        return expression_gain + local_gain - overage_penalty - representative_penalty + jitter

    def choose_best(candidate_indices: list[int], spatial_bin_id: Hashable) -> int:
        deltas = np.array([candidate_delta(index, spatial_bin_id) for index in candidate_indices])
        best_position = int(np.argmax(deltas))
        return int(candidate_indices[best_position])

    def add_index(index: int, source: str) -> None:
        nonlocal n_base_selected, n_marginal_selected
        selected.append(int(index))
        selected_set.add(int(index))
        spatial_bin_id = spatial_bin_ids[index]
        expression_bin_id = expression_bin_ids[index]
        selected_expression_counts[expression_bin_id] += 1
        selected_local_expression_bins[spatial_bin_id].add(expression_bin_id)
        if source == "base":
            n_base_selected += 1
        else:
            n_marginal_selected += 1

    for spatial_bin_id, quota in sorted(spatial_quotas.items(), key=lambda item: len(indices_by_spatial[item[0]]), reverse=True):
        if quota <= 0:
            continue
        base_quota, marginal_quota = split_quota(int(quota), base_fraction)
        available = [index for index in indices_by_spatial[spatial_bin_id] if index not in selected_set]
        n_base = min(int(base_quota), len(available))
        if n_base:
            base_indices = rng.choice(available, size=n_base, replace=False).astype(int).tolist()
            for index in base_indices:
                add_index(index, source="base")

        for _ in range(int(marginal_quota)):
            candidates = [
                index for index in indices_by_spatial[spatial_bin_id] if index not in selected_set
            ]
            if not candidates:
                break
            index = choose_best(candidates, spatial_bin_id)
            if selected_expression_counts[expression_bin_ids[index]] >= expression_caps[expression_bin_ids[index]]:
                n_over_cap_choices += 1
            add_index(index, source="marginal")

    n_filled_shortfall = 0
    while len(selected) < target_n:
        candidates = [index for index in range(n_obs) if index not in selected_set]
        if not candidates:
            break
        # The spatial-bin argument is only used for local diversity. At this stage,
        # candidates may come from any bin, so each cell is scored in its own bin.
        deltas = np.array([candidate_delta(index, spatial_bin_ids[index]) for index in candidates])
        index = int(candidates[int(np.argmax(deltas))])
        if selected_expression_counts[expression_bin_ids[index]] >= expression_caps[expression_bin_ids[index]]:
            n_over_cap_choices += 1
        add_index(index, source="marginal")
        n_filled_shortfall += 1

    selected = selected[:target_n]
    selected_spatial_bins = [spatial_bin_ids[index] for index in selected]
    selected_expression_bins = [expression_bin_ids[index] for index in selected]
    over_cap_bins = [
        str(bin_id)
        for bin_id, count in selected_expression_counts.items()
        if count > expression_caps.get(bin_id, 0)
    ]
    report = {
        "n_selected": len(selected),
        "n_spatial_bins": len(set(spatial_bin_ids)),
        "n_expression_bins": len(set(expression_bin_ids)),
        "n_selected_spatial_bins": len(set(selected_spatial_bins)),
        "n_selected_expression_bins": len(set(selected_expression_bins)),
        "n_base_selected": int(n_base_selected),
        "n_marginal_selected": int(n_marginal_selected),
        "n_filled_shortfall": int(n_filled_shortfall),
        "n_over_cap_choices": int(n_over_cap_choices),
        "n_over_cap_expression_bins": len(over_cap_bins),
        "over_cap_expression_bins": over_cap_bins[:20],
        "base_fraction": float(base_fraction),
        "cap_z": float(cap_z),
        "cap_floor": int(cap_floor),
        "jitter_scale": float(jitter_scale),
        "loss_terms": {
            "expression_deficit": "mean squared normalized expression-bin deficit",
            "local_diversity": "mean squared normalized local expression-state deficit",
            "expression_overage": "mean squared normalized expression-bin cap excess",
            "representative_cost": "mean normalized distance to spatial-bin expression centroid",
        },
    }
    return selected, report


__all__ = [
    "calibrate_sampling_weights",
    "marginal_loss_sample",
    "statistical_expression_caps",
]
