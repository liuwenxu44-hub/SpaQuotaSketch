"""Metrics for preserving annotated cell groups across spatial locations."""

from __future__ import annotations

from collections import Counter
from typing import Hashable, Sequence


def _normalized(counter: Counter[Hashable]) -> dict[Hashable, float]:
    total = float(sum(counter.values()))
    if total <= 0:
        return {}
    return {key: float(value / total) for key, value in counter.items()}


def _l1_error(reference: dict[Hashable, float], observed: dict[Hashable, float]) -> float:
    return float(
        sum(abs(reference.get(key, 0.0) - observed.get(key, 0.0)) for key in set(reference) | set(observed))
    )


def spatial_group_fidelity(
    cell_groups: Sequence[Hashable],
    spatial_bin_ids: Sequence[Hashable],
    selected_indices: Sequence[int],
    selected_weights: Sequence[float] | None = None,
) -> tuple[dict[str, float | int], list[dict[str, object]]]:
    """Measure joint cell-group and spatial-distribution preservation.

    Cell-group labels are evaluation-only inputs. They are not used to choose
    the selected indices.
    """
    n_obs = len(cell_groups)
    if len(spatial_bin_ids) != n_obs:
        raise ValueError("cell_groups and spatial_bin_ids must have equal length.")
    selected = [int(index) for index in selected_indices]
    if len(set(selected)) != len(selected) or any(index < 0 or index >= n_obs for index in selected):
        raise ValueError("selected_indices must be unique valid observation indices.")
    if selected_weights is None:
        weights = [1.0] * len(selected)
    else:
        weights = [float(value) for value in selected_weights]
        if len(weights) != len(selected):
            raise ValueError("selected_weights must match selected_indices length.")
        if any(value < 0 for value in weights) or sum(weights) <= 0:
            raise ValueError("selected_weights must be non-negative with positive total.")

    full_joint = Counter(zip(cell_groups, spatial_bin_ids))
    selected_joint: Counter[tuple[Hashable, Hashable]] = Counter()
    for index, weight in zip(selected, weights):
        selected_joint[(cell_groups[index], spatial_bin_ids[index])] += weight

    full_joint_proportions = _normalized(full_joint)
    selected_joint_proportions = _normalized(selected_joint)
    all_groups = sorted(set(cell_groups), key=str)
    group_rows: list[dict[str, object]] = []
    within_group_errors: list[float] = []
    group_coverages: list[float] = []
    for group in all_groups:
        full_bins = Counter(
            {bin_id: count for (label, bin_id), count in full_joint.items() if label == group}
        )
        selected_bins = Counter(
            {bin_id: count for (label, bin_id), count in selected_joint.items() if label == group}
        )
        full_distribution = _normalized(full_bins)
        selected_distribution = _normalized(selected_bins)
        within_error = _l1_error(full_distribution, selected_distribution) if selected_distribution else 2.0
        coverage = len(set(full_bins).intersection(selected_bins)) / max(1, len(full_bins))
        within_group_errors.append(within_error)
        group_coverages.append(coverage)
        group_rows.append(
            {
                "cell_group": str(group),
                "full_n_cells": int(sum(full_bins.values())),
                "selected_mass": float(sum(selected_bins.values())),
                "within_group_spatial_l1_error": float(within_error),
                "within_group_spatial_coverage": float(coverage),
            }
        )

    summary = {
        "joint_spatial_group_l1_error": _l1_error(full_joint_proportions, selected_joint_proportions),
        "mean_within_group_spatial_l1_error": float(sum(within_group_errors) / max(1, len(within_group_errors))),
        "mean_within_group_spatial_coverage": float(sum(group_coverages) / max(1, len(group_coverages))),
        "n_cell_groups": int(len(all_groups)),
        "n_selected": int(len(selected)),
    }
    return summary, group_rows


__all__ = ["spatial_group_fidelity"]
