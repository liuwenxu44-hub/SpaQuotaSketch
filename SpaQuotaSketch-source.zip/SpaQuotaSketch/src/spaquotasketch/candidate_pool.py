"""Candidate pool generation helpers."""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable, Sequence
from typing import Hashable


def merge_selected_ids(selections: Iterable[Iterable[Hashable]]) -> list[Hashable]:
    """Merge selected ids from multiple runs while preserving first-seen order."""
    seen: set[Hashable] = set()
    merged: list[Hashable] = []
    for selected in selections:
        for item in selected:
            if item not in seen:
                seen.add(item)
                merged.append(item)
    return merged


def build_candidate_report(selected_by_seed: dict[int, list[Hashable]], n_total: int) -> dict[str, object]:
    """Create a small summary for a candidate pool."""
    candidate_ids = merge_selected_ids(selected_by_seed.values())
    return {
        "n_total": int(n_total),
        "n_seeds": len(selected_by_seed),
        "n_candidates": len(candidate_ids),
        "candidate_fraction": len(candidate_ids) / n_total if n_total else 0.0,
        "seeds": sorted(selected_by_seed),
    }


def leverage_score_sample(embedding, n_select: int, seed: int = 0) -> list[int]:
    """Sample rows with probability proportional to squared embedding norm."""
    return capped_leverage_score_sample(embedding, n_select, seed=seed, score_cap_quantile=None)


def leverage_scores(embedding):
    """Compute one expression-distance score per observation."""
    import numpy as np

    values = np.asarray(embedding)
    if values.ndim != 2:
        raise ValueError("Embedding must be a two-dimensional array.")
    return np.sum(values * values, axis=1)


def leverage_probabilities(embedding, score_cap_quantile: float | None = None):
    """Compute sampling probabilities from expression-distance scores."""
    import numpy as np

    scores = leverage_scores(embedding).astype(float)
    if score_cap_quantile is not None:
        if not (0 < score_cap_quantile <= 1):
            raise ValueError("score_cap_quantile must be in (0, 1].")
        cap = float(np.quantile(scores, score_cap_quantile))
        scores = np.minimum(scores, cap)
    if float(scores.sum()) <= 0:
        return None
    return scores / scores.sum()


def capped_leverage_score_sample(
    embedding,
    n_select: int,
    seed: int = 0,
    score_cap_quantile: float | None = None,
) -> list[int]:
    """Sample rows using expression-distance scores with an optional score cap."""
    import numpy as np

    n_obs = len(embedding)
    n_select = min(max(int(n_select), 0), n_obs)
    if n_select == 0:
        return []
    rng = np.random.default_rng(seed)
    probabilities = leverage_probabilities(embedding, score_cap_quantile=score_cap_quantile)
    return rng.choice(n_obs, size=n_select, replace=False, p=probabilities).tolist()


def random_sample_indices(n_obs: int, n_select: int, seed: int = 0) -> list[int]:
    """Randomly sample row indices without replacement."""
    import numpy as np

    if n_obs < 0:
        raise ValueError("n_obs must be non-negative.")
    n_select = min(max(int(n_select), 0), int(n_obs))
    if n_select == 0:
        return []
    rng = np.random.default_rng(seed)
    return rng.choice(int(n_obs), size=n_select, replace=False).tolist()


def proportional_stratified_sample_indices(
    strata: Sequence[Hashable],
    n_select: int,
    seed: int = 0,
) -> list[int]:
    """Sample within expression strata while retaining every stratum when possible."""
    import numpy as np

    n_obs = len(strata)
    n_select = min(max(int(n_select), 0), n_obs)
    if n_select == 0:
        return []

    indices_by_stratum: dict[Hashable, list[int]] = defaultdict(list)
    for index, stratum in enumerate(strata):
        indices_by_stratum[stratum].append(index)
    stratum_ids = list(indices_by_stratum)

    if n_select < len(stratum_ids):
        rng = np.random.default_rng(seed)
        sizes = np.asarray([len(indices_by_stratum[item]) for item in stratum_ids], dtype=float)
        selected_positions = rng.choice(
            len(stratum_ids), size=n_select, replace=False, p=sizes / sizes.sum()
        )
        return [
            int(rng.choice(indices_by_stratum[stratum_ids[position]]))
            for position in selected_positions
        ]

    quotas = {stratum: 1 for stratum in stratum_ids}
    remaining = n_select - len(stratum_ids)
    available = {stratum: len(indices) - 1 for stratum, indices in indices_by_stratum.items()}
    total_available = sum(available.values())
    if remaining and total_available:
        raw = {
            stratum: remaining * available[stratum] / total_available for stratum in stratum_ids
        }
        increments = {stratum: int(raw[stratum]) for stratum in stratum_ids}
        for stratum in stratum_ids:
            quotas[stratum] += increments[stratum]
        n_left = remaining - sum(increments.values())
        order = sorted(stratum_ids, key=lambda item: raw[item] - increments[item], reverse=True)
        for stratum in order[:n_left]:
            quotas[stratum] += 1

    rng = np.random.default_rng(seed)
    selected: list[int] = []
    for stratum in stratum_ids:
        selected.extend(
            int(index)
            for index in rng.choice(
                indices_by_stratum[stratum], size=quotas[stratum], replace=False
            ).tolist()
        )
    return selected


def expression_sample_indices(
    embedding,
    n_select: int,
    seed: int = 0,
    method: str = "leverage",
    expression_fraction: float = 0.7,
    score_cap_quantile: float | None = None,
    strata: Sequence[Hashable] | None = None,
) -> list[int]:
    """Sample row indices using an expression-derived embedding."""
    method = method.lower().replace("_", "-")
    if method == "random":
        return random_sample_indices(len(embedding), n_select, seed=seed)
    if method in {"stratified", "expression-stratified", "expression-strata"}:
        if strata is None:
            raise ValueError("stratified candidate sampling requires expression strata.")
        if len(strata) != len(embedding):
            raise ValueError("strata must have one entry per embedding row.")
        return proportional_stratified_sample_indices(strata, n_select, seed=seed)
    if method in {"leverage", "leverage-score", "leverage-score-sampling"}:
        return capped_leverage_score_sample(
            embedding,
            n_select,
            seed=seed,
            score_cap_quantile=score_cap_quantile,
        )
    if method in {"mixed", "mixed-expression-random"}:
        return mixed_expression_random_sample_indices(
            embedding,
            n_select,
            seed=seed,
            expression_fraction=expression_fraction,
            score_cap_quantile=score_cap_quantile,
        )
    raise ValueError(f"Unsupported candidate sampling method: {method}")


def mixed_expression_random_sample_indices(
    embedding,
    n_select: int,
    seed: int = 0,
    expression_fraction: float = 0.7,
    score_cap_quantile: float | None = 0.95,
) -> list[int]:
    """Sample a fixed-size mix of expression-prioritized and random observations."""
    import numpy as np

    if not (0 <= expression_fraction <= 1):
        raise ValueError("expression_fraction must be in [0, 1].")
    n_obs = len(embedding)
    n_select = min(max(int(n_select), 0), n_obs)
    if n_select == 0:
        return []

    n_expression = min(n_select, int(round(n_select * expression_fraction)))
    n_random = n_select - n_expression
    expression_selected = capped_leverage_score_sample(
        embedding,
        n_expression,
        seed=seed,
        score_cap_quantile=score_cap_quantile,
    )
    selected_set = set(expression_selected)
    remaining = [index for index in range(n_obs) if index not in selected_set]
    rng = np.random.default_rng(seed + 10_000)
    if n_random > 0 and remaining:
        random_selected = rng.choice(remaining, size=min(n_random, len(remaining)), replace=False).tolist()
    else:
        random_selected = []
    selected = expression_selected + [int(index) for index in random_selected]

    if len(selected) < n_select:
        selected_set = set(selected)
        remaining = [index for index in range(n_obs) if index not in selected_set]
        n_fill = min(n_select - len(selected), len(remaining))
        if n_fill:
            selected.extend(rng.choice(remaining, size=n_fill, replace=False).tolist())
    return [int(index) for index in selected[:n_select]]


def build_candidate_pool(
    embedding,
    n_select_per_seed: int,
    seeds: Iterable[int],
    method: str = "leverage",
    expression_fraction: float = 0.7,
    score_cap_quantile: float | None = None,
    strata: Sequence[Hashable] | None = None,
) -> tuple[list[int], dict[int, list[int]]]:
    """Run expression sampling over multiple seeds and merge the selected indices."""
    selected_by_seed: dict[int, list[int]] = {}
    for seed in seeds:
        selected_by_seed[int(seed)] = expression_sample_indices(
            embedding,
            n_select=n_select_per_seed,
            seed=int(seed),
            method=method,
            expression_fraction=expression_fraction,
            score_cap_quantile=score_cap_quantile,
            strata=strata,
        )
    return merge_selected_ids(selected_by_seed.values()), selected_by_seed
