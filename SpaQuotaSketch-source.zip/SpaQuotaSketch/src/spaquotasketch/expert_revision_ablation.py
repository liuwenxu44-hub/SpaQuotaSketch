"""Post-V1 component ablation helpers for SpaQuotaSketch confirmation runs.

These functions do not alter the frozen V1 workflow.  They make the candidate
stage and quota-completion stage separately observable while holding the
spatial partition and its exact quota vector fixed across the relevant arms.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import math
from typing import Any, Hashable, Mapping, Sequence

import numpy as np
from scipy import sparse

from .baselines import standard_leverage_score_sample, spatially_smoothed_leverage_score_sample
from .candidate_pool import proportional_stratified_sample_indices
from .core_workflow import bin_ids_for_indices, build_candidates_until_quota_feasible
from .quota_sampling import sample_by_quota
from .representation.quota_completed import (
    CANDIDATE_FRACTION_PER_SEED,
    MAXIMUM_INTERNAL_SEED_BUDGET,
    candidate_pool_seed_set,
    complete_candidate_deficits,
)
from .spatial_bins import rectangular_grid_bins


DIRECT_SPATIAL_QUOTA_SRS = "direct_spatial_quota_srs"
EXPRESSION_STRATIFIED_SRS = "expression_stratified_srs"
CANDIDATE_QUOTA_NO_COMPLETION = "candidate_quota_no_completion"
CANDIDATE_QUOTA_WITH_COMPLETION = "candidate_quota_with_completion"
STANDARD_LEVERAGE_SCORE = "standard_leverage_score"
SPATIALLY_SMOOTHED_LEVERAGE_SCORE = "spatially_smoothed_leverage_score"

METHOD_IDS = (
    DIRECT_SPATIAL_QUOTA_SRS,
    EXPRESSION_STRATIFIED_SRS,
    CANDIDATE_QUOTA_NO_COMPLETION,
    CANDIDATE_QUOTA_WITH_COMPLETION,
    STANDARD_LEVERAGE_SCORE,
    SPATIALLY_SMOOTHED_LEVERAGE_SCORE,
)


@dataclass(frozen=True)
class AblationSelection:
    """One component arm, including an explicit status for infeasible sampling."""

    method_id: str
    status: str
    selected_indices: np.ndarray
    diagnostics: dict[str, Any]


def expression_grid_strata(expression_embedding: Any, grid_size: int) -> np.ndarray:
    """Return a declared square expression grid from the first two components."""
    embedding = np.asarray(expression_embedding, dtype=float)
    grid_size = int(grid_size)
    if grid_size < 1:
        raise ValueError("grid_size must be at least one.")
    if embedding.ndim != 2 or embedding.shape[0] < 1 or embedding.shape[1] < 2:
        raise ValueError("expression_embedding must be a nonempty matrix with at least two columns.")
    if not np.isfinite(embedding).all():
        raise ValueError("expression_embedding must be finite.")
    return np.asarray(
        rectangular_grid_bins(embedding[:, :2], n_x=grid_size, n_y=grid_size),
        dtype=object,
    )


def _validate_common_inputs(
    *,
    cell_ids: Sequence[Hashable],
    expression_embedding: Any,
    expression_basis: Any,
    spatial_coordinates: Any,
    spatial_strata: Sequence[Hashable],
    quotas: Mapping[Hashable, int],
    target_n: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, dict[str, int]]:
    ids = np.asarray([str(value) for value in cell_ids], dtype=str)
    embedding = np.asarray(expression_embedding, dtype=float)
    basis = np.asarray(expression_basis, dtype=float)
    coordinates = np.asarray(spatial_coordinates, dtype=float)
    spatial = np.asarray([str(value) for value in spatial_strata], dtype=object)
    final_quotas = {str(key): int(value) for key, value in quotas.items()}
    n_obs = ids.size
    if n_obs < 1 or len(set(ids.tolist())) != n_obs:
        raise ValueError("cell_ids must be nonempty and unique.")
    if embedding.ndim != 2 or basis.ndim != 2 or embedding.shape[0] != n_obs or basis.shape[0] != n_obs:
        raise ValueError("expression inputs must provide one row for every cell.")
    if coordinates.ndim != 2 or coordinates.shape[0] != n_obs or coordinates.shape[1] < 2:
        raise ValueError("spatial_coordinates must provide two coordinates for every cell.")
    if spatial.size != n_obs or set(spatial.tolist()) != set(final_quotas):
        raise ValueError("spatial_strata and quotas must cover the same nonempty strata.")
    if not (1 <= int(target_n) <= n_obs) or sum(final_quotas.values()) != int(target_n):
        raise ValueError("target_n and quotas must define the same feasible positive sample size.")
    if any(value < 1 for value in final_quotas.values()):
        raise ValueError("every spatial quota must be positive.")
    return ids, embedding, basis, coordinates[:, :2], spatial, final_quotas


def component_ablation_selections(
    *,
    cell_ids: Sequence[Hashable],
    expression_embedding: Any,
    expression_basis: Any,
    spatial_coordinates: Any,
    spatial_strata: Sequence[Hashable],
    quotas: Mapping[Hashable, int],
    target_n: int,
    dataset_id: str,
    target_fraction: float,
    benchmark_repeat_seed: int,
    expression_grid_size: int,
    smoothing_neighbors: int = 15,
) -> dict[str, AblationSelection]:
    """Run the four required component arms and two leverage-score comparators.

    The direct spatial arm and both candidate-plus-quota arms share exactly the
    supplied spatial strata and target quota vector.  The no-completion arm is
    intentionally reported as infeasible rather than being silently filled.
    """
    ids, embedding, basis, coordinates, spatial, final_quotas = _validate_common_inputs(
        cell_ids=cell_ids,
        expression_embedding=expression_embedding,
        expression_basis=expression_basis,
        spatial_coordinates=spatial_coordinates,
        spatial_strata=spatial_strata,
        quotas=quotas,
        target_n=target_n,
    )
    expression_strata = expression_grid_strata(embedding, expression_grid_size)
    n_obs = ids.size
    all_indices = list(range(n_obs))
    results: dict[str, AblationSelection] = {}

    direct, direct_report = sample_by_quota(
        all_indices,
        spatial.tolist(),
        final_quotas,
        seed=int(benchmark_repeat_seed),
    )
    results[DIRECT_SPATIAL_QUOTA_SRS] = AblationSelection(
        DIRECT_SPATIAL_QUOTA_SRS,
        "ok",
        np.asarray(direct, dtype=int),
        {"quota_report": direct_report, "spatial_quota_shared": True},
    )

    expression_only = proportional_stratified_sample_indices(
        expression_strata.tolist(),
        int(target_n),
        seed=int(benchmark_repeat_seed),
    )
    results[EXPRESSION_STRATIFIED_SRS] = AblationSelection(
        EXPRESSION_STRATIFIED_SRS,
        "ok",
        np.asarray(expression_only, dtype=int),
        {"expression_grid_size": int(expression_grid_size), "spatial_quota_shared": False},
    )

    seeds = candidate_pool_seed_set(int(benchmark_repeat_seed))
    per_seed = int(math.ceil(n_obs * CANDIDATE_FRACTION_PER_SEED))
    candidates, selected_by_seed, history, coverage, feasibility = build_candidates_until_quota_feasible(
        embedding=embedding,
        all_bin_ids=spatial.tolist(),
        final_quotas=final_quotas,
        n_select_per_seed=per_seed,
        seeds=seeds,
        method="stratified",
        candidate_strata=expression_strata.tolist(),
    )
    candidate_bins = bin_ids_for_indices(candidates, spatial.tolist())
    candidate_selected, candidate_report = sample_by_quota(
        candidates,
        candidate_bins,
        final_quotas,
        seed=int(benchmark_repeat_seed),
    )
    common_candidate_diagnostics = {
        "expression_grid_size": int(expression_grid_size),
        "candidate_pool_size": int(len(candidates)),
        "candidate_fraction": float(len(candidates) / n_obs),
        "internal_seed_count_used": int(len(selected_by_seed)),
        "internal_seed_budget": int(MAXIMUM_INTERNAL_SEED_BUDGET),
        "candidate_history": history,
        "candidate_coverage": coverage,
        "candidate_quota_feasibility": feasibility,
        "quota_report": candidate_report,
        "spatial_quota_shared": True,
    }
    if candidate_report["n_insufficient_bins"] or len(candidate_selected) != int(target_n):
        results[CANDIDATE_QUOTA_NO_COMPLETION] = AblationSelection(
            CANDIDATE_QUOTA_NO_COMPLETION,
            "infeasible_without_completion",
            np.asarray([], dtype=int),
            common_candidate_diagnostics,
        )
    else:
        results[CANDIDATE_QUOTA_NO_COMPLETION] = AblationSelection(
            CANDIDATE_QUOTA_NO_COMPLETION,
            "ok",
            np.asarray(candidate_selected, dtype=int),
            common_candidate_diagnostics,
        )

    completion = complete_candidate_deficits(
        candidate_indices=candidates,
        cell_ids=ids.tolist(),
        spatial_strata=spatial.tolist(),
        quotas=final_quotas,
        expression_strata=expression_strata.tolist(),
        dataset_id=str(dataset_id),
        target_fraction=float(target_fraction),
        benchmark_repeat_seed=int(benchmark_repeat_seed),
        target_n=int(target_n),
    )
    completed_bins = bin_ids_for_indices(completion.completed_candidate_indices, spatial.tolist())
    completed_selected, completed_report = sample_by_quota(
        completion.completed_candidate_indices,
        completed_bins,
        final_quotas,
        seed=int(benchmark_repeat_seed),
    )
    if completed_report["n_insufficient_bins"] or len(completed_selected) != int(target_n):
        raise RuntimeError("quota completion failed to return the declared exact target size.")
    results[CANDIDATE_QUOTA_WITH_COMPLETION] = AblationSelection(
        CANDIDATE_QUOTA_WITH_COMPLETION,
        "ok",
        np.asarray(completed_selected, dtype=int),
        {
            **common_candidate_diagnostics,
            "completed_candidate_pool_size": int(len(completion.completed_candidate_indices)),
            "completion_global_diagnostics": completion.global_diagnostics,
            "completion_stratum_diagnostics": completion.stratum_diagnostics.to_dict(orient="records"),
            "quota_report": completed_report,
        },
    )

    standard = standard_leverage_score_sample(basis, int(target_n), seed=int(benchmark_repeat_seed))
    results[STANDARD_LEVERAGE_SCORE] = AblationSelection(
        STANDARD_LEVERAGE_SCORE,
        "ok",
        np.asarray(standard, dtype=int),
        {"spatial_quota_shared": False, "expression_grid_size": None},
    )
    smoothed = spatially_smoothed_leverage_score_sample(
        basis,
        coordinates,
        int(target_n),
        seed=int(benchmark_repeat_seed),
        n_neighbors=int(smoothing_neighbors),
    )
    results[SPATIALLY_SMOOTHED_LEVERAGE_SCORE] = AblationSelection(
        SPATIALLY_SMOOTHED_LEVERAGE_SCORE,
        "ok",
        np.asarray(smoothed, dtype=int),
        {"spatial_quota_shared": False, "expression_grid_size": None, "smoothing_neighbors": int(smoothing_neighbors)},
    )
    return results


def total_variation_distance(labels: Sequence[Hashable], selected_indices: Sequence[int]) -> float:
    """Return the total-variation distance between population and sketch labels."""
    values = [str(value) for value in labels]
    selected = [int(index) for index in selected_indices]
    if not values or not selected:
        return float("nan")
    full_counts = Counter(values)
    selected_counts = Counter(values[index] for index in selected)
    n_full, n_selected = len(values), len(selected)
    return float(
        0.5
        * sum(
            abs(full_counts[key] / n_full - selected_counts[key] / n_selected)
            for key in set(full_counts).union(selected_counts)
        )
    )


def normalized_expression_fidelity(
    normalized_log1p_matrix: sparse.spmatrix,
    selected_indices: Sequence[int],
) -> dict[str, float]:
    """Compare unweighted sketch and population gene means/detection fractions."""
    matrix = normalized_log1p_matrix.tocsr(copy=False)
    selected = np.asarray(selected_indices, dtype=int)
    if matrix.shape[0] == 0 or selected.size == 0:
        return {"gene_mean_l1_error": float("nan"), "gene_detection_l1_error": float("nan")}
    full_mean = np.asarray(matrix.mean(axis=0)).reshape(-1)
    selected_mean = np.asarray(matrix[selected].mean(axis=0)).reshape(-1)
    full_detection = matrix.getnnz(axis=0).astype(float) / matrix.shape[0]
    selected_detection = matrix[selected].getnnz(axis=0).astype(float) / selected.size
    return {
        "gene_mean_l1_error": float(np.abs(full_mean - selected_mean).sum() / max(float(full_mean.sum()), 1e-12)),
        "gene_detection_l1_error": float(np.abs(full_detection - selected_detection).sum() / max(float(full_detection.sum()), 1e-12)),
    }


__all__ = [
    "AblationSelection",
    "CANDIDATE_QUOTA_NO_COMPLETION",
    "CANDIDATE_QUOTA_WITH_COMPLETION",
    "DIRECT_SPATIAL_QUOTA_SRS",
    "EXPRESSION_STRATIFIED_SRS",
    "METHOD_IDS",
    "SPATIALLY_SMOOTHED_LEVERAGE_SCORE",
    "STANDARD_LEVERAGE_SCORE",
    "component_ablation_selections",
    "expression_grid_strata",
    "normalized_expression_fidelity",
    "total_variation_distance",
]
