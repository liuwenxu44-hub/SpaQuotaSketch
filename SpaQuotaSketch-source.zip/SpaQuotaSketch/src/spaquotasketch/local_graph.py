"""Constraint-preserving local-neighborhood refinement for spatial sketches."""

from __future__ import annotations

from collections import defaultdict
from typing import Hashable, Sequence

import numpy as np


def _standardize(values: np.ndarray) -> np.ndarray:
    scale = values.std(axis=0)
    scale[scale <= np.finfo(float).eps] = 1.0
    return (values - values.mean(axis=0, keepdims=True)) / scale


def _moment_loss(sum_values, sum_squares, n_selected: int, reference_mean, reference_variance) -> float:
    mean = sum_values / n_selected
    variance = np.maximum(sum_squares / n_selected - mean**2, 0.0)
    mean_scale = np.sqrt(np.maximum(reference_variance, 1e-12))
    variance_scale = np.maximum(reference_variance, 1e-12)
    mean_error = np.mean(((mean - reference_mean) / mean_scale) ** 2)
    variance_error = np.mean(((variance - reference_variance) / variance_scale) ** 2)
    return float(mean_error + variance_error)


def _local_graph(coordinates: np.ndarray, expression: np.ndarray, n_neighbors: int):
    """Build a locally scaled spatial-expression neighbor graph.

    Each block is standardized and divided by the square root of its dimension, so
    spatial position and expression contribute equally without a hand-set weight.
    """
    from sklearn.neighbors import NearestNeighbors

    n_obs = coordinates.shape[0]
    n_neighbors = min(max(1, int(n_neighbors)), n_obs)
    spatial = _standardize(coordinates) / np.sqrt(coordinates.shape[1])
    expression = _standardize(expression) / np.sqrt(expression.shape[1])
    features = np.concatenate([spatial, expression], axis=1)
    model = NearestNeighbors(n_neighbors=n_neighbors, algorithm="auto")
    distances, neighbors = model.fit(features).kneighbors(features, return_distance=True)
    nonzero = distances[distances > np.finfo(float).eps]
    scale = float(np.median(nonzero)) if nonzero.size else 1.0
    affinity = np.exp(-0.5 * (distances / max(scale, np.finfo(float).eps)) ** 2)
    return neighbors.astype(int), affinity.astype(float)


def _coverage(neighbors: np.ndarray, affinity: np.ndarray, selected: np.ndarray) -> np.ndarray:
    return np.max(affinity * selected[neighbors], axis=1)


def constrained_local_neighbor_refine(
    spatial_bin_ids: Sequence[Hashable],
    expression_bin_ids: Sequence[Hashable],
    spatial_coordinates,
    normalized_features,
    moment_features,
    initial_selected_indices: Sequence[int],
    n_neighbors: int = 12,
    max_swaps_per_spatial_bin: int = 4,
    candidate_pool_size: int = 4,
    moment_loss_relative_tolerance: float = 0.01,
) -> tuple[list[int], dict[str, object]]:
    """Improve local graph coverage without changing spatial/expression-bin counts.

    A proposed replacement is confined to one spatial-bin/expression-bin stratum.
    It therefore preserves both sets of quotas exactly. The replacement is accepted
    only when it improves local neighbor coverage and keeps global first/second
    expression moments within a small relative tolerance of the V11 starting set.
    """
    coordinates = np.asarray(spatial_coordinates, dtype=float)
    expression = np.asarray(normalized_features, dtype=float)
    moments = np.asarray(moment_features, dtype=float)
    n_obs = len(spatial_bin_ids)
    if len(expression_bin_ids) != n_obs:
        raise ValueError("Spatial and expression bin ids must have the same length.")
    if coordinates.shape[0] != n_obs or expression.shape[0] != n_obs or moments.shape[0] != n_obs:
        raise ValueError("All feature arrays must have one row per observation.")
    if not (np.isfinite(coordinates).all() and np.isfinite(expression).all() and np.isfinite(moments).all()):
        raise ValueError("Local-neighborhood refinement requires finite inputs.")
    if not 0 <= moment_loss_relative_tolerance:
        raise ValueError("moment_loss_relative_tolerance must be non-negative.")

    selected = np.zeros(n_obs, dtype=bool)
    initial = np.asarray(initial_selected_indices, dtype=int)
    if initial.size != len(set(initial.tolist())) or initial.size == 0:
        raise ValueError("initial_selected_indices must be non-empty and unique.")
    if initial.min() < 0 or initial.max() >= n_obs:
        raise ValueError("initial_selected_indices contain an out-of-range value.")
    selected[initial] = True
    n_selected = int(initial.size)

    reference_mean = moments.mean(axis=0)
    reference_variance = moments.var(axis=0)
    current_sum = moments[selected].sum(axis=0)
    current_squares = np.square(moments[selected]).sum(axis=0)
    baseline_moment_loss = _moment_loss(
        current_sum, current_squares, n_selected, reference_mean, reference_variance
    )
    moment_limit = baseline_moment_loss * (1.0 + moment_loss_relative_tolerance) + 1e-12

    by_spatial: dict[Hashable, list[int]] = defaultdict(list)
    for index, bin_id in enumerate(spatial_bin_ids):
        by_spatial[bin_id].append(index)

    initial_spatial_counts = {key: int(selected[np.asarray(value, dtype=int)].sum()) for key, value in by_spatial.items()}
    initial_expression_counts: dict[Hashable, int] = defaultdict(int)
    for index in initial.tolist():
        initial_expression_counts[expression_bin_ids[index]] += 1

    initial_graph_score = 0.0
    final_graph_score = 0.0
    accepted_swaps: list[dict[str, object]] = []
    n_positive_graph_candidates = 0
    n_rejected_for_moments = 0

    for spatial_bin_id, local_indices_list in by_spatial.items():
        local_indices = np.asarray(local_indices_list, dtype=int)
        if local_indices.size <= 1 or not selected[local_indices].any():
            continue
        neighbors, affinity = _local_graph(
            coordinates[local_indices], expression[local_indices], n_neighbors=n_neighbors
        )
        local_selected = selected[local_indices].copy()
        initial_graph_score += float(_coverage(neighbors, affinity, local_selected).sum())
        local_strata: dict[Hashable, list[int]] = defaultdict(list)
        for position, global_index in enumerate(local_indices.tolist()):
            local_strata[expression_bin_ids[global_index]].append(position)

        for _ in range(max(0, int(max_swaps_per_spatial_bin))):
            current_coverage = _coverage(neighbors, affinity, local_selected)
            current_score = float(current_coverage.sum())
            best: tuple[float, int, int, np.ndarray, np.ndarray] | None = None
            for stratum_positions_list in local_strata.values():
                stratum_positions = np.asarray(stratum_positions_list, dtype=int)
                removable = stratum_positions[local_selected[stratum_positions]]
                candidates = stratum_positions[~local_selected[stratum_positions]]
                if removable.size == 0 or candidates.size == 0:
                    continue

                removal_losses: list[tuple[float, int]] = []
                for remove_position in removable.tolist():
                    trial = local_selected.copy()
                    trial[remove_position] = False
                    removal_losses.append((current_score - float(_coverage(neighbors, affinity, trial).sum()), remove_position))
                _, remove_position = min(removal_losses, key=lambda item: (item[0], item[1]))

                addition_scores: list[tuple[float, int]] = []
                for candidate_position in candidates.tolist():
                    trial = local_selected.copy()
                    trial[candidate_position] = True
                    addition_scores.append((float(_coverage(neighbors, affinity, trial).sum()) - current_score, candidate_position))
                candidate_positions = [
                    position
                    for _, position in sorted(addition_scores, key=lambda item: (-item[0], item[1]))[
                        : max(1, int(candidate_pool_size))
                    ]
                ]

                for candidate_position in candidate_positions:
                    trial = local_selected.copy()
                    trial[remove_position] = False
                    trial[candidate_position] = True
                    trial_coverage = _coverage(neighbors, affinity, trial)
                    gain = float(trial_coverage.sum() - current_score)
                    if gain <= 1e-12:
                        continue
                    n_positive_graph_candidates += 1
                    removed_global = int(local_indices[remove_position])
                    candidate_global = int(local_indices[candidate_position])
                    trial_sum = current_sum - moments[removed_global] + moments[candidate_global]
                    trial_squares = (
                        current_squares
                        - np.square(moments[removed_global])
                        + np.square(moments[candidate_global])
                    )
                    trial_moment_loss = _moment_loss(
                        trial_sum,
                        trial_squares,
                        n_selected,
                        reference_mean,
                        reference_variance,
                    )
                    if trial_moment_loss > moment_limit:
                        n_rejected_for_moments += 1
                        continue
                    if best is None or gain > best[0]:
                        best = (gain, remove_position, candidate_position, trial_sum, trial_squares)

            if best is None:
                break
            gain, remove_position, candidate_position, current_sum, current_squares = best
            removed_global = int(local_indices[remove_position])
            candidate_global = int(local_indices[candidate_position])
            local_selected[remove_position] = False
            local_selected[candidate_position] = True
            selected[removed_global] = False
            selected[candidate_global] = True
            accepted_swaps.append(
                {
                    "spatial_bin_id": str(spatial_bin_id),
                    "removed_index": removed_global,
                    "added_index": candidate_global,
                    "local_graph_gain": gain,
                }
            )
        final_graph_score += float(_coverage(neighbors, affinity, local_selected).sum())

    refined = np.flatnonzero(selected).astype(int)
    if refined.size != n_selected:
        raise RuntimeError("Local-neighborhood refinement changed the requested sample size.")
    for spatial_bin_id, local_indices_list in by_spatial.items():
        if int(selected[np.asarray(local_indices_list, dtype=int)].sum()) != initial_spatial_counts[spatial_bin_id]:
            raise RuntimeError("Local-neighborhood refinement changed a spatial quota.")
    final_expression_counts: dict[Hashable, int] = defaultdict(int)
    for index in refined.tolist():
        final_expression_counts[expression_bin_ids[index]] += 1
    if dict(final_expression_counts) != dict(initial_expression_counts):
        raise RuntimeError("Local-neighborhood refinement changed an expression-bin quota.")

    final_moment_loss = _moment_loss(
        current_sum, current_squares, n_selected, reference_mean, reference_variance
    )
    return refined.tolist(), {
        "n_selected": n_selected,
        "n_accepted_swaps": len(accepted_swaps),
        "n_positive_graph_candidates": int(n_positive_graph_candidates),
        "n_rejected_for_moments": int(n_rejected_for_moments),
        "local_graph_score_before": float(initial_graph_score),
        "local_graph_score_after": float(final_graph_score),
        "local_graph_score_gain": float(final_graph_score - initial_graph_score),
        "moment_loss_before": float(baseline_moment_loss),
        "moment_loss_after": float(final_moment_loss),
        "moment_loss_limit": float(moment_limit),
        "n_neighbors": int(n_neighbors),
        "max_swaps_per_spatial_bin": int(max_swaps_per_spatial_bin),
        "candidate_pool_size": int(candidate_pool_size),
        "moment_loss_relative_tolerance": float(moment_loss_relative_tolerance),
        "constraint_preservation": "exact spatial-bin and expression-bin selected counts",
        "accepted_swaps": accepted_swaps,
    }


__all__ = ["constrained_local_neighbor_refine"]
