"""Transparent fixed-quota probability designs for real-data confirmation.

The three plans created here always share the same spatial strata and integer
quota vector: direct spatial simple random sampling, equal-probability local
pivotal sampling, and bounded SVD-leverage weighting. The direct spatial arm
is explicit because it is the key baseline for any added expression-aware
sampling complexity.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Hashable, Mapping, Sequence

import numpy as np
from scipy import sparse

from .v2_1.sampling import SamplingPlan, build_sampling_plan, draw_fixed_size_sample


DIRECT_SPATIAL_QUOTA_SRS = "direct_spatial_quota_srs"
EQUAL_PROBABILITY_FIXED_QUOTA = "equal_probability_fixed_quota"
LEVERAGE_WEIGHTED_FIXED_QUOTA = "leverage_weighted_fixed_quota"
METHOD_IDS = (
    DIRECT_SPATIAL_QUOTA_SRS,
    EQUAL_PROBABILITY_FIXED_QUOTA,
    LEVERAGE_WEIGHTED_FIXED_QUOTA,
)


@dataclass(frozen=True)
class FixedQuotaProbabilitySelection:
    method_id: str
    selected_indices: np.ndarray
    inclusion_probability: np.ndarray
    sampling_weight: np.ndarray
    diagnostics: dict[str, float | int | str | bool]


def leverage_score_values(expression_basis: Any) -> np.ndarray:
    """Return strictly positive row leverage scores from an orthonormal basis."""
    basis = np.asarray(expression_basis, dtype=float)
    if basis.ndim != 2 or basis.shape[0] < 1 or basis.shape[1] < 1:
        raise ValueError("expression_basis must be a nonempty two-dimensional array.")
    if not np.isfinite(basis).all():
        raise ValueError("expression_basis must be finite.")
    score = np.square(basis).sum(axis=1)
    positive_floor = max(float(np.finfo(float).eps), float(np.median(score)) * 1e-12)
    return np.maximum(score, positive_floor)


def fixed_quota_probability_plans(
    *,
    expression_embedding: Any,
    expression_basis: Any,
    spatial_strata: Sequence[Hashable],
    quotas: Mapping[Hashable, int],
    max_weight_inflation: float = 4.0,
) -> dict[str, SamplingPlan]:
    """Build the seed-independent pivotal plans used by the matched designs.

    Spatial neighbour edges and projected probabilities depend on the input,
    quota vector, and weight bound, but not on a sampler seed. Separating this
    step avoids rebuilding identical plans for technical repeat draws.
    """
    embedding = np.asarray(expression_embedding, dtype=float)
    basis = np.asarray(expression_basis, dtype=float)
    strata = np.asarray([str(value) for value in spatial_strata], dtype=object)
    quota_map = {str(key): int(value) for key, value in quotas.items()}
    if embedding.ndim != 2 or embedding.shape[0] != strata.size:
        raise ValueError("expression_embedding and spatial_strata must have matching rows.")
    if basis.shape[0] != strata.size:
        raise ValueError("expression_basis and spatial_strata must have matching rows.")
    if set(strata.tolist()) != set(quota_map):
        raise ValueError("quotas must exactly cover nonempty spatial strata.")
    score = leverage_score_values(basis)
    return {
        EQUAL_PROBABILITY_FIXED_QUOTA: build_sampling_plan(
            strata,
            quota_map,
            embedding,
            np.ones(strata.size, dtype=float),
            method="v2_1_coordinate_only",
            max_weight_inflation=float(max_weight_inflation),
        ),
        LEVERAGE_WEIGHTED_FIXED_QUOTA: build_sampling_plan(
            strata,
            quota_map,
            embedding,
            score,
            method="v2_1_inference",
            max_weight_inflation=float(max_weight_inflation),
        ),
    }


def fixed_quota_probability_selections(
    *,
    expression_embedding: Any,
    expression_basis: Any,
    spatial_strata: Sequence[Hashable],
    quotas: Mapping[Hashable, int],
    seed: int,
    max_weight_inflation: float = 4.0,
    precomputed_pivotal_plans: Mapping[str, SamplingPlan] | None = None,
) -> dict[str, FixedQuotaProbabilitySelection]:
    """Draw matched direct-SRS, equal-pivotal, and leverage-weighted samples."""
    embedding = np.asarray(expression_embedding, dtype=float)
    basis = np.asarray(expression_basis, dtype=float)
    strata = np.asarray([str(value) for value in spatial_strata], dtype=object)
    quota_map = {str(key): int(value) for key, value in quotas.items()}
    if embedding.ndim != 2 or embedding.shape[0] != strata.size:
        raise ValueError("expression_embedding and spatial_strata must have matching rows.")
    if basis.shape[0] != strata.size:
        raise ValueError("expression_basis and spatial_strata must have matching rows.")
    if set(strata.tolist()) != set(quota_map):
        raise ValueError("quotas must exactly cover nonempty spatial strata.")
    if precomputed_pivotal_plans is None:
        plans = fixed_quota_probability_plans(
            expression_embedding=embedding,
            expression_basis=basis,
            spatial_strata=strata,
            quotas=quota_map,
            max_weight_inflation=float(max_weight_inflation),
        )
    else:
        plans = dict(precomputed_pivotal_plans)
        required = {EQUAL_PROBABILITY_FIXED_QUOTA, LEVERAGE_WEIGHTED_FIXED_QUOTA}
        if set(plans) != required:
            raise ValueError("precomputed_pivotal_plans must contain exactly the two pivotal plans.")
        for plan in plans.values():
            if (
                plan.inclusion_probability.size != strata.size
                or plan.quotas != quota_map
                or not np.array_equal(plan.spatial_strata, strata)
            ):
                raise ValueError("precomputed pivotal plan does not match the current input and quotas.")
    selections: dict[str, FixedQuotaProbabilitySelection] = {}
    direct_probability = np.zeros(strata.size, dtype=float)
    direct_parts: list[np.ndarray] = []
    direct_rng = np.random.default_rng(
        int(np.random.SeedSequence([int(seed), 0]).generate_state(1)[0])
    )
    for stratum in sorted(quota_map):
        positions = np.flatnonzero(strata == stratum)
        quota = int(quota_map[stratum])
        direct_probability[positions] = quota / positions.size
        local = (
            positions
            if quota == positions.size
            else direct_rng.choice(positions, size=quota, replace=False)
        )
        direct_parts.append(np.asarray(local, dtype=int))
    direct_selected = np.sort(np.concatenate(direct_parts))
    direct_weights = 1.0 / direct_probability
    direct_quota_ok = all(
        int(np.sum(strata[direct_selected] == stratum)) == int(quota)
        for stratum, quota in quota_map.items()
    )
    if direct_selected.size != sum(quota_map.values()) or not direct_quota_ok:
        raise RuntimeError("direct spatial SRS violated the declared quota vector.")
    direct_selected_weights = direct_weights[direct_selected]
    selections[DIRECT_SPATIAL_QUOTA_SRS] = FixedQuotaProbabilitySelection(
        method_id=DIRECT_SPATIAL_QUOTA_SRS,
        selected_indices=direct_selected,
        inclusion_probability=direct_probability,
        sampling_weight=direct_weights,
        diagnostics={
            "target_n": int(direct_selected.size),
            "all_spatial_quotas_exact": bool(direct_quota_ok),
            "mean_selected_ess_fraction": 1.0,
            "maximum_to_median_selected_weight": float(
                direct_selected_weights.max() / np.median(direct_selected_weights)
            ),
            "probability_solver": "within_stratum_simple_random_sampling",
        },
    )
    for order, (method_id, plan) in enumerate(plans.items()):
        selected = draw_fixed_size_sample(
            plan, random_seed=int(np.random.SeedSequence([int(seed), order]).generate_state(1)[0])
        )
        selected_strata = strata[selected]
        quota_ok = all(
            int(np.sum(selected_strata == stratum)) == int(quota)
            for stratum, quota in quota_map.items()
        )
        if selected.size != sum(quota_map.values()) or not quota_ok:
            raise RuntimeError("fixed-quota probability sampler violated the declared quota vector.")
        selected_weights = plan.sampling_weight[selected]
        selected_ess = float(
            np.square(selected_weights.sum()) / np.square(selected_weights).sum() / selected.size
        )
        selections[method_id] = FixedQuotaProbabilitySelection(
            method_id=method_id,
            selected_indices=selected,
            inclusion_probability=plan.inclusion_probability,
            sampling_weight=plan.sampling_weight,
            diagnostics={
                "target_n": int(selected.size),
                "all_spatial_quotas_exact": bool(quota_ok),
                "mean_selected_ess_fraction": selected_ess,
                "maximum_to_median_selected_weight": float(
                    selected_weights.max() / np.median(selected_weights)
                ),
                "probability_solver": str(plan.probability_solver),
            },
        )
    return selections


def hajek_normalized_expression_fidelity(
    normalized_log1p_matrix: sparse.spmatrix,
    selected_indices: Sequence[int],
    sampling_weight: Sequence[float],
) -> dict[str, float]:
    """Compare inverse-probability-weighted sample means with full-population means."""
    matrix = normalized_log1p_matrix.tocsr(copy=False)
    selected = np.asarray(selected_indices, dtype=int)
    weights = np.asarray(sampling_weight, dtype=float)[selected]
    if matrix.shape[0] == 0 or selected.size == 0 or weights.size != selected.size:
        raise ValueError("matrix, selected indices, and sampling weights must align and be nonempty.")
    if not np.all(np.isfinite(weights)) or np.any(weights <= 0):
        raise ValueError("sampling weights must be finite and positive.")
    full_mean = np.asarray(matrix.mean(axis=0)).reshape(-1)
    weighted_mean = np.asarray(matrix[selected].T @ weights).reshape(-1) / weights.sum()
    full_detection = matrix.getnnz(axis=0).astype(float) / matrix.shape[0]
    selected_detection = matrix[selected].copy()
    selected_detection.data = np.ones_like(selected_detection.data, dtype=float)
    weighted_detection = (
        np.asarray(selected_detection.T @ weights).reshape(-1) / weights.sum()
    )
    return {
        "gene_mean_l1_error_hajek": float(
            np.abs(full_mean - weighted_mean).sum() / max(float(full_mean.sum()), 1e-12)
        ),
        "gene_detection_l1_error_hajek": float(
            np.abs(full_detection - weighted_detection).sum()
            / max(float(full_detection.sum()), 1e-12)
        ),
    }


def score_technical_diagnostics(
    *,
    expression_basis: Any,
    raw_matrix: Any,
) -> dict[str, float]:
    """Quantify whether leverage scores primarily track library-size proxies."""
    score = leverage_score_values(expression_basis)
    matrix = sparse.csr_matrix(raw_matrix)
    total_counts = np.asarray(matrix.sum(axis=1)).reshape(-1)
    detected_features = matrix.getnnz(axis=1).astype(float)

    def correlation(first: np.ndarray, second: np.ndarray) -> float:
        value = float(np.corrcoef(first, second)[0, 1])
        return value if np.isfinite(value) else 0.0

    return {
        "score_total_counts_correlation": correlation(score, total_counts),
        "score_detected_features_correlation": correlation(score, detected_features),
        "zero_total_count_fraction": float(np.mean(total_counts == 0)),
        "total_counts_q50": float(np.quantile(total_counts, 0.50)),
        "total_counts_q99": float(np.quantile(total_counts, 0.99)),
        "detected_features_q50": float(np.quantile(detected_features, 0.50)),
        "detected_features_q99": float(np.quantile(detected_features, 0.99)),
        "score_q50": float(np.quantile(score, 0.50)),
        "score_q95": float(np.quantile(score, 0.95)),
        "score_q99": float(np.quantile(score, 0.99)),
    }


__all__ = [
    "DIRECT_SPATIAL_QUOTA_SRS",
    "EQUAL_PROBABILITY_FIXED_QUOTA",
    "FixedQuotaProbabilitySelection",
    "LEVERAGE_WEIGHTED_FIXED_QUOTA",
    "METHOD_IDS",
    "fixed_quota_probability_selections",
    "fixed_quota_probability_plans",
    "hajek_normalized_expression_fidelity",
    "leverage_score_values",
    "score_technical_diagnostics",
]
