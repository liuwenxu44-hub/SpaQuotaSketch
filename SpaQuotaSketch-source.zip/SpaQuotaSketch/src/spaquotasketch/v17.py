"""V17 hierarchical allocation with spatial-state and expression-grid balance."""

from __future__ import annotations

from collections import Counter, defaultdict
from typing import Hashable, Sequence

import numpy as np

from .soft_balance import proportional_quotas
from .v15 import (
    _fine_spatial_quotas,
    _hierarchical_state_quotas,
    _l1_error,
    _minimum_cost_joint_allocation,
    _state_quotas,
    candidate_metrics,
)


def _fill_row_shortfall(
    row_quotas: dict[Hashable, int],
    state_quotas: dict[Hashable, int],
    pair_indices: dict[tuple[Hashable, Hashable], list[int]],
    planned_counts: dict[tuple[Hashable, Hashable], int],
) -> tuple[dict[tuple[Hashable, Hashable], int], int]:
    """Fill a rare infeasible flow remainder while keeping row quotas exact."""
    planned = Counter(planned_counts)
    by_row = Counter()
    by_state = Counter()
    for (row, state), count in planned.items():
        by_row[row] += int(count)
        by_state[state] += int(count)
    relaxed = 0
    for row, quota in row_quotas.items():
        remaining = int(quota) - int(by_row[row])
        while remaining > 0:
            candidates = [
                state
                for (candidate_row, state), values in pair_indices.items()
                if candidate_row == row
                and len(values) > int(planned[(candidate_row, state)])
            ]
            if not candidates:
                raise RuntimeError("Could not fill a row quota after flow relaxation.")
            state = max(
                candidates,
                key=lambda candidate: (
                    int(state_quotas.get(candidate, 0)) - int(by_state[candidate]),
                    len(pair_indices[(row, candidate)]) - int(planned[(row, candidate)]),
                    str(candidate),
                ),
            )
            planned[(row, state)] += 1
            by_row[row] += 1
            by_state[state] += 1
            remaining -= 1
            relaxed += 1
    return dict(planned), int(relaxed)


def _sample_from_plan(
    triple_indices: dict[tuple[Hashable, Hashable, Hashable], list[int]],
    triple_plan: dict[tuple[Hashable, Hashable, Hashable], int],
    seed: int,
) -> list[int]:
    rng = np.random.default_rng(seed)
    selected: list[int] = []
    for triple, count in triple_plan.items():
        if count <= 0:
            continue
        available = np.asarray(triple_indices[triple], dtype=int)
        chosen = available if count >= available.size else rng.choice(available, size=count, replace=False)
        selected.extend(chosen.astype(int).tolist())
    return sorted(selected)


def build_v17_plan(
    primary_spatial_bin_ids: Sequence[Hashable],
    fine_spatial_bin_ids: Sequence[Hashable],
    expression_bin_ids: Sequence[Hashable],
    coarse_state_ids: Sequence[Hashable],
    fine_state_ids: Sequence[Hashable],
    target_n: int,
    fine_min_population: int = 20,
) -> tuple[
    dict[tuple[Hashable, Hashable, Hashable], list[int]],
    dict[tuple[Hashable, Hashable, Hashable], int],
    dict[str, object],
]:
    """Build V17's three-stage, four-structure integer allocation plan.

    Stage 1 preserves the primary-spatial by fine-state structure. Stage 2
    refines it to fine spatial bins. Stage 3 adds the original expression-grid
    totals without changing either spatial-state margin.
    """
    n_obs = len(primary_spatial_bin_ids)
    if not (
        len(fine_spatial_bin_ids)
        == len(expression_bin_ids)
        == len(coarse_state_ids)
        == len(fine_state_ids)
        == n_obs
    ):
        raise ValueError("All label sequences must have the same length.")
    target_n = min(max(int(target_n), 0), n_obs)
    if target_n == 0:
        return {}, {}, {"n_selected": 0}

    primary_quotas = proportional_quotas(list(primary_spatial_bin_ids), target_n)
    _, global_state_quotas = _hierarchical_state_quotas(
        coarse_state_ids,
        fine_state_ids,
        target_n,
    )
    primary_state_indices: dict[tuple[Hashable, Hashable], list[int]] = defaultdict(list)
    by_primary: dict[Hashable, list[int]] = defaultdict(list)
    fine_by_primary: dict[Hashable, set[Hashable]] = defaultdict(set)
    for index, (primary, fine, state) in enumerate(
        zip(primary_spatial_bin_ids, fine_spatial_bin_ids, fine_state_ids)
    ):
        primary_state_indices[(primary, state)].append(index)
        by_primary[primary].append(index)
        fine_by_primary[primary].add(fine)
    primary_state_counts = {pair: len(indices) for pair, indices in primary_state_indices.items()}
    primary_state_plan, primary_state_flow, primary_state_cost = _minimum_cost_joint_allocation(
        primary_quotas,
        global_state_quotas,
        primary_state_counts,
    )
    primary_state_relaxation = 0
    if primary_state_flow < target_n:
        primary_state_plan, primary_state_relaxation = _fill_row_shortfall(
            primary_quotas,
            global_state_quotas,
            primary_state_indices,
            primary_state_plan,
        )

    fine_quotas: dict[Hashable, int] = {}
    fine_summary = {
        "n_occupied_fine_bins": 0,
        "n_reachable_fine_bins": 0,
        "n_reachable_fine_bins_protected": 0,
    }
    for primary, indices in by_primary.items():
        local_fine = [fine_spatial_bin_ids[index] for index in indices]
        local_quotas, local_summary = _fine_spatial_quotas(
            local_fine,
            int(primary_quotas[primary]),
            min_population=fine_min_population,
        )
        fine_quotas.update(local_quotas)
        for key in fine_summary:
            fine_summary[key] += local_summary[key]
    if sum(fine_quotas.values()) != target_n:
        raise RuntimeError("Fine spatial quotas did not reach the requested target.")

    fine_state_plan: dict[tuple[Hashable, Hashable], int] = {}
    fine_state_flow_units = 0
    fine_state_relaxation = 0
    fine_state_cost = 0
    for primary, indices in by_primary.items():
        local_rows = {fine: int(fine_quotas[fine]) for fine in fine_by_primary[primary]}
        local_states = {
            state: int(quota)
            for (candidate_primary, state), quota in primary_state_plan.items()
            if candidate_primary == primary and quota > 0
        }
        pair_indices: dict[tuple[Hashable, Hashable], list[int]] = defaultdict(list)
        for index in indices:
            pair_indices[(fine_spatial_bin_ids[index], fine_state_ids[index])].append(index)
        pair_counts = {pair: len(values) for pair, values in pair_indices.items()}
        local_plan, flow_units, flow_cost = _minimum_cost_joint_allocation(
            local_rows,
            local_states,
            pair_counts,
        )
        if flow_units < int(primary_quotas[primary]):
            local_plan, relaxed = _fill_row_shortfall(
                local_rows,
                local_states,
                pair_indices,
                local_plan,
            )
            fine_state_relaxation += relaxed
        fine_state_flow_units += flow_units
        if flow_cost is not None:
            fine_state_cost += int(flow_cost)
        fine_state_plan.update({pair: int(count) for pair, count in local_plan.items() if count > 0})
    if sum(fine_state_plan.values()) != target_n:
        raise RuntimeError("Fine spatial-state quotas did not reach the requested target.")

    expression_quotas = _state_quotas(
        expression_bin_ids,
        target_n,
        minimum_one=True,
    )
    triple_indices: dict[tuple[Hashable, Hashable, Hashable], list[int]] = defaultdict(list)
    for index, (fine, state, expression) in enumerate(
        zip(fine_spatial_bin_ids, fine_state_ids, expression_bin_ids)
    ):
        triple_indices[(fine, state, expression)].append(index)
    row_expression_indices: dict[
        tuple[tuple[Hashable, Hashable], Hashable], list[int]
    ] = defaultdict(list)
    for (fine, state, expression), indices in triple_indices.items():
        row_expression_indices[((fine, state), expression)].extend(indices)
    row_expression_counts = {pair: len(values) for pair, values in row_expression_indices.items()}
    expression_plan, expression_flow, expression_cost = _minimum_cost_joint_allocation(
        fine_state_plan,
        expression_quotas,
        row_expression_counts,
    )
    expression_relaxation = 0
    if expression_flow < target_n:
        expression_plan, expression_relaxation = _fill_row_shortfall(
            fine_state_plan,
            expression_quotas,
            row_expression_indices,
            expression_plan,
        )
    triple_plan = {
        (fine, state, expression): int(count)
        for ((fine, state), expression), count in expression_plan.items()
        if count > 0
    }
    if sum(triple_plan.values()) != target_n:
        raise RuntimeError("V17 allocation plan did not reach the requested target.")
    return dict(triple_indices), triple_plan, {
        "n_selected": target_n,
        "primary_state_flow_units": int(primary_state_flow),
        "primary_state_flow_feasible": bool(primary_state_flow == target_n),
        "primary_state_quota_relaxation_cells": int(primary_state_relaxation),
        "primary_state_joint_allocation_cost": primary_state_cost,
        "fine_state_flow_units": int(fine_state_flow_units),
        "fine_state_flow_feasible": bool(fine_state_flow_units == target_n),
        "fine_state_quota_relaxation_cells": int(fine_state_relaxation),
        "fine_state_joint_allocation_cost": int(fine_state_cost),
        "expression_flow_units": int(expression_flow),
        "expression_flow_feasible": bool(expression_flow == target_n),
        "expression_quota_relaxation_cells": int(expression_relaxation),
        "expression_joint_allocation_cost": expression_cost,
        "candidate_construction": "primary_state_then_fine_state_then_expression_grid_minimum_cost_flows",
        **fine_summary,
    }


def sample_v17_plan(
    triple_indices: dict[tuple[Hashable, Hashable, Hashable], list[int]],
    triple_plan: dict[tuple[Hashable, Hashable, Hashable], int],
    seed: int,
) -> list[int]:
    """Choose concrete cells from a fixed V17 allocation plan."""
    return _sample_from_plan(triple_indices, triple_plan, seed)


def v17_candidate_metrics(
    primary_spatial_bin_ids: Sequence[Hashable],
    fine_spatial_bin_ids: Sequence[Hashable],
    expression_bin_ids: Sequence[Hashable],
    coarse_state_ids: Sequence[Hashable],
    fine_state_ids: Sequence[Hashable],
    selected_indices: Sequence[int],
    expression_features,
    gene_view_a_mean_error: float = 0.0,
    gene_view_b_mean_error: float = 0.0,
) -> dict[str, float]:
    """Unlabeled candidate metrics for V17 selection."""
    selected = np.asarray(selected_indices, dtype=int)
    metrics = candidate_metrics(
        primary_spatial_bin_ids,
        fine_spatial_bin_ids,
        coarse_state_ids,
        fine_state_ids,
        selected,
        expression_features,
        gene_view_a_mean_error=gene_view_a_mean_error,
        gene_view_b_mean_error=gene_view_b_mean_error,
    )
    full_primary_state = list(zip(primary_spatial_bin_ids, fine_state_ids))
    selected_primary_state = [
        (primary_spatial_bin_ids[index], fine_state_ids[index]) for index in selected
    ]
    full_primary_expression = list(zip(primary_spatial_bin_ids, expression_bin_ids))
    selected_primary_expression = [
        (primary_spatial_bin_ids[index], expression_bin_ids[index]) for index in selected
    ]
    metrics["primary_state_l1"] = _l1_error(full_primary_state, selected_primary_state)
    metrics["primary_state_coverage_penalty"] = 1.0 - len(
        set(full_primary_state).intersection(selected_primary_state)
    ) / max(1, len(set(full_primary_state)))
    metrics["expression_bin_l1"] = _l1_error(
        expression_bin_ids,
        [expression_bin_ids[index] for index in selected],
    )
    metrics["primary_expression_l1"] = _l1_error(
        full_primary_expression,
        selected_primary_expression,
    )
    return metrics


__all__ = ["build_v17_plan", "sample_v17_plan", "v17_candidate_metrics"]
