"""Confidence-constrained exchange sampling for spatial transcriptomics."""

from __future__ import annotations

from collections import Counter
from math import ceil, exp, floor, lgamma, sqrt
from statistics import NormalDist
from typing import Hashable

from .soft_balance import proportional_quotas


def _log_comb(n: int, k: int) -> float:
    if k < 0 or k > n:
        return float("-inf")
    return lgamma(n + 1) - lgamma(k + 1) - lgamma(n - k + 1)


def finite_population_inclusion_probability(
    population_size: int,
    state_size: int,
    sample_size: int,
) -> float:
    """Return the probability of observing a state in sampling without replacement."""
    population_size = int(population_size)
    state_size = int(state_size)
    sample_size = int(sample_size)
    if population_size < 0 or state_size < 0 or sample_size < 0:
        raise ValueError("population_size, state_size, and sample_size must be non-negative.")
    if state_size > population_size or sample_size > population_size:
        raise ValueError("state_size and sample_size cannot exceed population_size.")
    if state_size == 0 or sample_size == 0:
        return 0.0
    if sample_size > population_size - state_size:
        return 1.0
    log_missing = _log_comb(population_size - state_size, sample_size) - _log_comb(
        population_size, sample_size
    )
    return min(1.0, max(0.0, -expm1_safe(log_missing)))


def expm1_safe(value: float) -> float:
    """Compute exp(value) - 1 without requiring a numeric dependency at import time."""
    if value < -50.0:
        return -1.0
    return exp(value) - 1.0


def stratified_expression_intervals(
    spatial_bin_ids: list[Hashable],
    expression_bin_ids: list[Hashable],
    spatial_quotas: dict[Hashable, int],
    confidence_level: float = 0.95,
) -> dict[Hashable, dict[str, float | int | bool]]:
    """Compute expression-count targets and confidence bounds under spatial quotas."""
    if len(spatial_bin_ids) != len(expression_bin_ids):
        raise ValueError("spatial_bin_ids and expression_bin_ids must have the same length.")
    if not (0 < confidence_level < 1):
        raise ValueError("confidence_level must be in (0, 1).")

    spatial_counts = Counter(spatial_bin_ids)
    pair_counts = Counter(zip(spatial_bin_ids, expression_bin_ids))
    expression_counts = Counter(expression_bin_ids)
    z_value = NormalDist().inv_cdf(0.5 + confidence_level / 2.0)

    result: dict[Hashable, dict[str, float | int | bool]] = {}
    for expression_bin_id, population_count in expression_counts.items():
        expected = 0.0
        variance = 0.0
        reachable = False
        log_missing_probability = 0.0
        certain_inclusion = False

        for spatial_bin_id, population_size in spatial_counts.items():
            quota = min(int(spatial_quotas.get(spatial_bin_id, 0)), int(population_size))
            state_size = int(pair_counts.get((spatial_bin_id, expression_bin_id), 0))
            if quota <= 0 or state_size <= 0:
                continue
            reachable = True
            probability = state_size / population_size
            expected += quota * probability
            if population_size > 1:
                variance += (
                    quota
                    * probability
                    * (1.0 - probability)
                    * (population_size - quota)
                    / (population_size - 1)
                )
            if quota > population_size - state_size:
                certain_inclusion = True
            elif not certain_inclusion:
                log_missing_probability += _log_comb(
                    population_size - state_size, quota
                ) - _log_comb(population_size, quota)

        standard_deviation = sqrt(max(0.0, variance))
        lower = max(0, ceil(expected - z_value * standard_deviation - 0.5))
        upper = floor(expected + z_value * standard_deviation + 0.5)
        if reachable:
            upper = max(1, upper)
        upper = min(int(population_count), max(0, int(upper)))
        lower = min(int(lower), int(upper))
        if certain_inclusion:
            inclusion_probability = 1.0
        elif reachable:
            inclusion_probability = min(
                1.0,
                max(0.0, -expm1_safe(log_missing_probability)),
            )
        else:
            inclusion_probability = 0.0

        result[expression_bin_id] = {
            "population_count": int(population_count),
            "expected_count": float(expected),
            "variance": float(variance),
            "standard_deviation": float(standard_deviation),
            "lower_bound": int(lower),
            "upper_bound": int(upper),
            "reachable": bool(reachable),
            "inclusion_probability": float(inclusion_probability),
        }
    return result


def _validate_inputs(
    spatial_bin_ids: list[Hashable],
    expression_bin_ids: list[Hashable],
    features,
    confidence_level: float,
) -> None:
    import numpy as np

    if len(spatial_bin_ids) != len(expression_bin_ids):
        raise ValueError("spatial_bin_ids and expression_bin_ids must have the same length.")
    values = np.asarray(features)
    if values.ndim != 2 or values.shape[0] != len(spatial_bin_ids):
        raise ValueError("features must be a two-dimensional array with one row per observation.")
    if not np.isfinite(values).all():
        raise ValueError("features must not contain NaN or infinite values.")
    if not (0 < confidence_level < 1):
        raise ValueError("confidence_level must be in (0, 1).")


def confidence_constrained_exchange_sample(
    spatial_bin_ids: list[Hashable],
    expression_bin_ids: list[Hashable],
    features,
    target_n: int,
    seed: int = 0,
    confidence_level: float = 0.95,
    preserve_second_moment: bool = True,
    sampling_probabilities=None,
    initial_selected_indices=None,
) -> tuple[list[int], dict[str, object]]:
    """Sample with exact spatial quotas and lexicographic, confidence-bounded exchanges."""
    import numpy as np

    _validate_inputs(spatial_bin_ids, expression_bin_ids, features, confidence_level)
    n_obs = len(spatial_bin_ids)
    target_n = min(max(int(target_n), 0), n_obs)
    if target_n == 0:
        return [], {"n_selected": 0, "n_exchanges": 0}

    values = np.asarray(features, dtype=float)
    probabilities = None
    if sampling_probabilities is not None:
        probabilities = np.asarray(sampling_probabilities, dtype=float).reshape(-1)
        if probabilities.shape[0] != n_obs:
            raise ValueError("sampling_probabilities must have one value per observation.")
        if not np.isfinite(probabilities).all() or np.any(probabilities < 0):
            raise ValueError("sampling_probabilities must be finite and non-negative.")
        if float(probabilities.sum()) <= 0:
            raise ValueError("sampling_probabilities must have a positive sum.")
    provided_selected = None
    if initial_selected_indices is not None:
        provided_selected = np.asarray(initial_selected_indices, dtype=int).reshape(-1)
        if provided_selected.size != target_n:
            raise ValueError("initial_selected_indices must have target_n entries.")
        if (
            provided_selected.size != np.unique(provided_selected).size
            or provided_selected.min(initial=0) < 0
            or provided_selected.max(initial=-1) >= n_obs
        ):
            raise ValueError("initial_selected_indices must be unique valid observation indices.")
    rng = np.random.default_rng(seed)
    tie_break = rng.random(n_obs)

    spatial_labels = list(dict.fromkeys(spatial_bin_ids))
    expression_labels = list(dict.fromkeys(expression_bin_ids))
    spatial_lookup = {label: position for position, label in enumerate(spatial_labels)}
    expression_lookup = {label: position for position, label in enumerate(expression_labels)}
    spatial_codes = np.asarray([spatial_lookup[label] for label in spatial_bin_ids], dtype=int)
    expression_codes = np.asarray([expression_lookup[label] for label in expression_bin_ids], dtype=int)
    n_spatial = len(spatial_labels)
    n_expression = len(expression_labels)

    quota_by_label = proportional_quotas(spatial_bin_ids, target_n)
    quotas = np.asarray([quota_by_label[label] for label in spatial_labels], dtype=int)
    indices_by_spatial = [np.flatnonzero(spatial_codes == code) for code in range(n_spatial)]
    spatial_sizes = np.asarray([indices.size for indices in indices_by_spatial], dtype=int)

    pair_counts = np.zeros((n_spatial, n_expression), dtype=int)
    np.add.at(pair_counts, (spatial_codes, expression_codes), 1)
    expression_population_counts = pair_counts.sum(axis=0)

    interval_by_label = stratified_expression_intervals(
        spatial_bin_ids,
        expression_bin_ids,
        quota_by_label,
        confidence_level=confidence_level,
    )
    expected_counts = np.asarray(
        [interval_by_label[label]["expected_count"] for label in expression_labels], dtype=float
    )
    count_variances = np.asarray(
        [interval_by_label[label]["variance"] for label in expression_labels], dtype=float
    )
    lower_bounds = np.asarray(
        [interval_by_label[label]["lower_bound"] for label in expression_labels], dtype=int
    )
    upper_bounds = np.asarray(
        [interval_by_label[label]["upper_bound"] for label in expression_labels], dtype=int
    )
    reachable_expression = np.asarray(
        [interval_by_label[label]["reachable"] for label in expression_labels], dtype=bool
    )

    local_detectable = np.zeros((n_spatial, n_expression), dtype=bool)
    for spatial_code in range(n_spatial):
        population_size = int(spatial_sizes[spatial_code])
        quota = int(quotas[spatial_code])
        if quota <= 0:
            continue
        for expression_code in np.flatnonzero(pair_counts[spatial_code] > 0):
            probability = finite_population_inclusion_probability(
                population_size,
                int(pair_counts[spatial_code, expression_code]),
                quota,
            )
            local_detectable[spatial_code, expression_code] = probability >= confidence_level

    feature_mean = values.mean(axis=0)
    feature_scale = values.std(axis=0)
    feature_scale[feature_scale <= np.finfo(float).eps] = 1.0
    standardized = (values - feature_mean) / feature_scale
    if preserve_second_moment:
        auxiliary = np.concatenate([standardized, standardized * standardized], axis=1)
    else:
        auxiliary = standardized

    auxiliary_target = np.zeros(auxiliary.shape[1], dtype=float)
    auxiliary_variance = np.zeros(auxiliary.shape[1], dtype=float)
    for spatial_code, indices in enumerate(indices_by_spatial):
        quota = int(quotas[spatial_code])
        population_size = int(indices.size)
        if quota <= 0 or population_size <= 0:
            continue
        local = auxiliary[indices]
        auxiliary_target += quota * local.mean(axis=0)
        if population_size > 1:
            auxiliary_variance += (
                quota
                * (population_size - quota)
                / (population_size - 1)
                * local.var(axis=0)
            )

    active_count = count_variances > np.finfo(float).eps
    active_auxiliary = auxiliary_variance > np.finfo(float).eps
    count_inverse_variance = np.zeros(n_expression, dtype=float)
    auxiliary_inverse_variance = np.zeros(auxiliary.shape[1], dtype=float)
    count_inverse_variance[active_count] = 1.0 / count_variances[active_count]
    auxiliary_inverse_variance[active_auxiliary] = 1.0 / auxiliary_variance[active_auxiliary]
    n_balance_terms = max(1, int(active_count.sum() + active_auxiliary.sum()))

    selected_mask = np.zeros(n_obs, dtype=bool)
    selected_by_spatial: list[list[int]] = [[] for _ in range(n_spatial)]
    n_probability_fallback_bins = 0
    if provided_selected is not None:
        selected_mask[provided_selected] = True
        provided_spatial_counts = np.bincount(
            spatial_codes[selected_mask], minlength=n_spatial
        )
        if not np.array_equal(provided_spatial_counts, quotas):
            raise ValueError("initial_selected_indices must satisfy exact spatial quotas.")
        for spatial_code in range(n_spatial):
            selected_by_spatial[spatial_code] = np.flatnonzero(
                selected_mask & (spatial_codes == spatial_code)
            ).astype(int).tolist()
    else:
        for spatial_code, indices in enumerate(indices_by_spatial):
            quota = int(quotas[spatial_code])
            if quota <= 0:
                continue
            local_probabilities = None
            if probabilities is not None:
                local_values = probabilities[indices]
                if (
                    float(local_values.sum()) > 0
                    and int(np.count_nonzero(local_values)) >= quota
                ):
                    local_probabilities = local_values / local_values.sum()
                else:
                    n_probability_fallback_bins += 1
            chosen = rng.choice(
                indices,
                size=quota,
                replace=False,
                p=local_probabilities,
            ).astype(int).tolist()
            selected_by_spatial[spatial_code] = chosen
            selected_mask[chosen] = True

    expression_counts = np.bincount(
        expression_codes[selected_mask], minlength=n_expression
    ).astype(int)
    local_counts = np.zeros((n_spatial, n_expression), dtype=int)
    np.add.at(
        local_counts,
        (spatial_codes[selected_mask], expression_codes[selected_mask]),
        1,
    )
    auxiliary_sum = auxiliary[selected_mask].sum(axis=0)

    def count_slack_loss(counts: np.ndarray) -> float:
        below = np.maximum(0, lower_bounds - counts)
        above = np.maximum(0, counts - upper_bounds)
        scale = np.maximum(1.0, np.sqrt(count_variances))
        return float(np.sum(((below + above) / scale) ** 2))

    def balance_loss() -> float:
        count_residual = expression_counts - expected_counts
        auxiliary_residual = auxiliary_sum - auxiliary_target
        value = float(np.dot(count_residual * count_residual, count_inverse_variance))
        value += float(
            np.dot(auxiliary_residual * auxiliary_residual, auxiliary_inverse_variance)
        )
        return value / n_balance_terms

    def expression_balance_delta(in_code: int, out_code: int) -> float:
        if in_code == out_code:
            return 0.0
        delta = 0.0
        for code, change in ((in_code, 1), (out_code, -1)):
            residual = expression_counts[code] - expected_counts[code]
            delta += ((residual + change) ** 2 - residual**2) * count_inverse_variance[code]
        return float(delta)

    def auxiliary_balance_deltas(incoming: np.ndarray, outgoing: int) -> np.ndarray:
        difference = auxiliary[incoming] - auxiliary[outgoing]
        residual = auxiliary_sum - auxiliary_target
        return (
            2.0 * (difference * auxiliary_inverse_variance).dot(residual)
            + (difference * difference).dot(auxiliary_inverse_variance)
        )

    def swap_slack_delta(in_code: int, out_code: int) -> float:
        if in_code == out_code:
            return 0.0
        current = expression_counts.copy()
        before = count_slack_loss(current)
        current[in_code] += 1
        current[out_code] -= 1
        return count_slack_loss(current) - before

    disturbed_spatial_bins: set[int] = set()

    def apply_swap(incoming: int, outgoing: int, track_disturbance: bool = True) -> None:
        nonlocal auxiliary_sum
        spatial_code = int(spatial_codes[incoming])
        if spatial_code != int(spatial_codes[outgoing]):
            raise RuntimeError("An exchange must stay inside one spatial bin.")
        in_code = int(expression_codes[incoming])
        out_code = int(expression_codes[outgoing])
        selected_mask[incoming] = True
        selected_mask[outgoing] = False
        position = selected_by_spatial[spatial_code].index(outgoing)
        selected_by_spatial[spatial_code][position] = incoming
        expression_counts[in_code] += 1
        expression_counts[out_code] -= 1
        local_counts[spatial_code, in_code] += 1
        local_counts[spatial_code, out_code] -= 1
        auxiliary_sum = auxiliary_sum + auxiliary[incoming] - auxiliary[outgoing]
        if track_disturbance:
            disturbed_spatial_bins.add(spatial_code)

    def best_pair_for_incoming_expression(
        expression_code: int,
        require_global_gain: bool,
        prioritize_slack: bool = False,
    ) -> tuple[int, int] | None:
        if expression_counts[expression_code] + 1 > upper_bounds[expression_code]:
            return None
        best: tuple[tuple[float, ...], int, int] | None = None
        for spatial_code in np.flatnonzero(pair_counts[:, expression_code] > 0):
            if quotas[spatial_code] <= 0:
                continue
            incoming = indices_by_spatial[spatial_code]
            incoming = incoming[
                (~selected_mask[incoming]) & (expression_codes[incoming] == expression_code)
            ]
            if incoming.size == 0:
                continue
            for outgoing in selected_by_spatial[spatial_code]:
                out_code = int(expression_codes[outgoing])
                if out_code == expression_code:
                    continue
                if expression_counts[out_code] - 1 < lower_bounds[out_code]:
                    continue
                if require_global_gain and expression_counts[out_code] <= 1:
                    continue
                slack_delta = swap_slack_delta(expression_code, out_code)
                if slack_delta > 1e-12:
                    continue

                local_delta = 0.0
                if local_detectable[spatial_code, expression_code] and local_counts[
                    spatial_code, expression_code
                ] == 0:
                    local_delta -= 1.0
                if local_detectable[spatial_code, out_code] and local_counts[
                    spatial_code, out_code
                ] == 1:
                    local_delta += 1.0

                auxiliary_deltas = auxiliary_balance_deltas(incoming, outgoing)
                expression_delta = expression_balance_delta(expression_code, out_code)
                total_deltas = (auxiliary_deltas + expression_delta) / n_balance_terms
                position = int(np.argmin(total_deltas + tie_break[incoming] * 1e-15))
                candidate = int(incoming[position])
                if prioritize_slack:
                    key = (
                        float(slack_delta),
                        float(local_delta),
                        float(total_deltas[position]),
                        float(tie_break[candidate]),
                    )
                else:
                    key = (
                        float(local_delta),
                        float(total_deltas[position]),
                        float(tie_break[candidate]),
                    )
                if best is None or key < best[0]:
                    best = (key, candidate, int(outgoing))
        return None if best is None else (best[1], best[2])

    def best_pair_for_outgoing_expression(expression_code: int) -> tuple[int, int] | None:
        best: tuple[tuple[float, ...], int, int] | None = None
        for spatial_code in np.flatnonzero(local_counts[:, expression_code] > 0):
            incoming_all = indices_by_spatial[spatial_code]
            incoming_all = incoming_all[~selected_mask[incoming_all]]
            if incoming_all.size == 0:
                continue
            outgoing_all = [
                index
                for index in selected_by_spatial[spatial_code]
                if expression_codes[index] == expression_code
            ]
            for outgoing in outgoing_all:
                incoming_codes = expression_codes[incoming_all]
                allowed = (incoming_codes != expression_code) & (
                    expression_counts[incoming_codes] + 1 <= upper_bounds[incoming_codes]
                )
                incoming = incoming_all[allowed]
                if incoming.size == 0:
                    continue
                incoming_codes = expression_codes[incoming]
                auxiliary_deltas = auxiliary_balance_deltas(incoming, outgoing)
                for in_code in np.unique(incoming_codes):
                    slack_delta = swap_slack_delta(int(in_code), expression_code)
                    if slack_delta >= -1e-12:
                        continue
                    positions = np.flatnonzero(incoming_codes == in_code)
                    expression_delta = expression_balance_delta(int(in_code), expression_code)
                    total_deltas = (
                        auxiliary_deltas[positions] + expression_delta
                    ) / n_balance_terms
                    local_position = int(
                        np.argmin(total_deltas + tie_break[incoming[positions]] * 1e-15)
                    )
                    position = int(positions[local_position])
                    candidate = int(incoming[position])
                    key = (
                        float(slack_delta),
                        float(total_deltas[local_position]),
                        float(tie_break[candidate]),
                    )
                    if best is None or key < best[0]:
                        best = (key, candidate, int(outgoing))
        return None if best is None else (best[1], best[2])

    initial_slack_loss = count_slack_loss(expression_counts)
    initial_balance_loss = balance_loss()
    initial_expression_coverage = int(np.sum(expression_counts > 0))
    initial_local_detectable_coverage = int(np.sum(local_detectable & (local_counts > 0)))

    n_repair_exchanges = 0
    while True:
        under = np.flatnonzero(expression_counts < lower_bounds)
        if under.size == 0:
            break
        current_slack = count_slack_loss(expression_counts)
        best: tuple[float, float, int, int] | None = None
        for expression_code in under:
            pair = best_pair_for_incoming_expression(
                int(expression_code),
                require_global_gain=False,
                prioritize_slack=True,
            )
            if pair is None:
                continue
            incoming, outgoing = pair
            in_code = int(expression_codes[incoming])
            out_code = int(expression_codes[outgoing])
            slack_delta = swap_slack_delta(in_code, out_code)
            if slack_delta >= -1e-12:
                continue
            candidate = (
                float(slack_delta),
                float(tie_break[incoming]),
                int(incoming),
                int(outgoing),
            )
            if best is None or candidate < best:
                best = candidate
        if best is None:
            break
        apply_swap(best[2], best[3])
        n_repair_exchanges += 1
        if count_slack_loss(expression_counts) >= current_slack - 1e-12:
            break

    while True:
        over = np.flatnonzero(expression_counts > upper_bounds)
        if over.size == 0:
            break
        current_slack = count_slack_loss(expression_counts)
        best: tuple[float, float, int, int] | None = None
        for expression_code in over:
            pair = best_pair_for_outgoing_expression(int(expression_code))
            if pair is None:
                continue
            incoming, outgoing = pair
            in_code = int(expression_codes[incoming])
            out_code = int(expression_codes[outgoing])
            slack_delta = swap_slack_delta(in_code, out_code)
            if slack_delta >= -1e-12:
                continue
            candidate = (
                float(slack_delta),
                float(tie_break[incoming]),
                int(incoming),
                int(outgoing),
            )
            if best is None or candidate < best:
                best = candidate
        if best is None:
            break
        apply_swap(best[2], best[3])
        n_repair_exchanges += 1
        if count_slack_loss(expression_counts) >= current_slack - 1e-12:
            break

    missing_expression = [
        code
        for code in range(n_expression)
        if reachable_expression[code] and expression_counts[code] == 0
    ]
    missing_expression.sort(
        key=lambda code: (
            int(np.sum((pair_counts[:, code] > 0) & (quotas > 0))),
            int(expression_population_counts[code]),
            str(expression_labels[code]),
        )
    )
    n_global_coverage_exchanges = 0
    for expression_code in missing_expression:
        if expression_counts[expression_code] > 0:
            continue
        pair = best_pair_for_incoming_expression(expression_code, require_global_gain=True)
        if pair is None:
            continue
        apply_swap(*pair)
        n_global_coverage_exchanges += 1

    n_local_coverage_exchanges = 0
    missing_local = list(zip(*np.where(local_detectable & (local_counts == 0))))
    missing_local.sort(
        key=lambda pair: (
            int(pair_counts[pair[0], pair[1]]),
            str(spatial_labels[pair[0]]),
            str(expression_labels[pair[1]]),
        )
    )
    for spatial_code, expression_code in missing_local:
        if local_counts[spatial_code, expression_code] > 0:
            continue
        if expression_counts[expression_code] + 1 > upper_bounds[expression_code]:
            continue
        incoming = indices_by_spatial[spatial_code]
        incoming = incoming[
            (~selected_mask[incoming]) & (expression_codes[incoming] == expression_code)
        ]
        if incoming.size == 0:
            continue

        best: tuple[float, float, int, int] | None = None
        for outgoing in selected_by_spatial[spatial_code]:
            out_code = int(expression_codes[outgoing])
            if out_code == expression_code:
                continue
            if expression_counts[out_code] <= 1:
                continue
            if expression_counts[out_code] - 1 < lower_bounds[out_code]:
                continue
            if local_detectable[spatial_code, out_code] and local_counts[
                spatial_code, out_code
            ] <= 1:
                continue
            slack_delta = swap_slack_delta(expression_code, out_code)
            if slack_delta > 1e-12:
                continue
            auxiliary_deltas = auxiliary_balance_deltas(incoming, outgoing)
            expression_delta = expression_balance_delta(expression_code, out_code)
            total_deltas = (auxiliary_deltas + expression_delta) / n_balance_terms
            position = int(np.argmin(total_deltas + tie_break[incoming] * 1e-15))
            candidate = int(incoming[position])
            key = (float(total_deltas[position]), float(tie_break[candidate]), candidate, outgoing)
            if best is None or key < best:
                best = key
        if best is not None:
            apply_swap(best[2], best[3])
            n_local_coverage_exchanges += 1

    post_coverage_balance_loss = balance_loss()
    n_balance_exchanges = 0
    balance_passes = 0
    disturbance_exchanges = (
        n_repair_exchanges + n_global_coverage_exchanges + n_local_coverage_exchanges
    )
    safety_limit = disturbance_exchanges
    while balance_loss() > 1e-12 and n_balance_exchanges < safety_limit:
        n_changed = 0
        balance_passes += 1
        for spatial_code in sorted(disturbed_spatial_bins):
            all_indices = indices_by_spatial[spatial_code]
            incoming_all = all_indices[~selected_mask[all_indices]]
            if incoming_all.size == 0:
                continue
            best: tuple[float, float, int, int] | None = None
            for outgoing in tuple(selected_by_spatial[spatial_code]):
                out_code = int(expression_codes[outgoing])
                incoming_codes = expression_codes[incoming_all]
                allowed = np.ones(incoming_all.size, dtype=bool)
                different = incoming_codes != out_code
                allowed &= (~different) | (
                    (expression_counts[incoming_codes] + 1 <= upper_bounds[incoming_codes])
                    & (expression_counts[out_code] - 1 >= lower_bounds[out_code])
                )
                if expression_counts[out_code] <= 1:
                    allowed &= ~different
                if local_detectable[spatial_code, out_code] and local_counts[
                    spatial_code, out_code
                ] <= 1:
                    allowed &= ~different
                detectable_incoming = local_detectable[spatial_code, incoming_codes]
                missing_detectable = detectable_incoming & (
                    local_counts[spatial_code, incoming_codes] == 0
                )
                allowed &= (~different) | (~detectable_incoming) | missing_detectable | (
                    local_counts[spatial_code, incoming_codes] > 0
                )
                incoming = incoming_all[allowed]
                if incoming.size == 0:
                    continue

                auxiliary_deltas = auxiliary_balance_deltas(incoming, outgoing)
                incoming_codes_allowed = expression_codes[incoming]
                expression_deltas = np.asarray(
                    [expression_balance_delta(int(code), out_code) for code in incoming_codes_allowed],
                    dtype=float,
                )
                total_deltas = (auxiliary_deltas + expression_deltas) / n_balance_terms
                position = int(np.argmin(total_deltas + tie_break[incoming] * 1e-15))
                if total_deltas[position] >= -1e-12:
                    continue
                candidate = int(incoming[position])
                key = (
                    float(total_deltas[position]),
                    float(tie_break[candidate]),
                    candidate,
                    int(outgoing),
                )
                if best is None or key < best:
                    best = key
            if best is not None:
                apply_swap(best[2], best[3], track_disturbance=False)
                n_balance_exchanges += 1
                n_changed += 1
                if n_balance_exchanges >= safety_limit:
                    break
        if n_changed == 0:
            break

    selected = np.flatnonzero(selected_mask).astype(int).tolist()
    selected.sort()
    final_slack_loss = count_slack_loss(expression_counts)
    final_balance_loss = balance_loss()
    represented_expression = expression_counts > 0
    represented_local = local_counts > 0
    over_bound = expression_counts > upper_bounds
    under_bound = expression_counts < lower_bounds

    interval_summary = {
        str(label): {
            **interval_by_label[label],
            "selected_count": int(expression_counts[code]),
        }
        for code, label in enumerate(expression_labels)
    }
    report = {
        "n_selected": len(selected),
        "n_spatial_bins": n_spatial,
        "n_expression_bins": n_expression,
        "n_selected_spatial_bins": int(np.sum(quotas > 0)),
        "n_selected_expression_bins": int(np.sum(represented_expression)),
        "n_reachable_expression_bins": int(np.sum(reachable_expression)),
        "n_detectable_local_states": int(np.sum(local_detectable)),
        "n_selected_detectable_local_states": int(np.sum(local_detectable & represented_local)),
        "n_exchanges": int(
            n_repair_exchanges
            + n_global_coverage_exchanges
            + n_local_coverage_exchanges
            + n_balance_exchanges
        ),
        "n_repair_exchanges": int(n_repair_exchanges),
        "n_global_coverage_exchanges": int(n_global_coverage_exchanges),
        "n_local_coverage_exchanges": int(n_local_coverage_exchanges),
        "n_balance_exchanges": int(n_balance_exchanges),
        "n_balance_passes": int(balance_passes),
        "balance_safety_limit": int(safety_limit),
        "balance_safety_limit_reached": bool(
            safety_limit > 0
            and n_balance_exchanges >= safety_limit
            and final_balance_loss > 1e-12
        ),
        "confidence_level": float(confidence_level),
        "normal_quantile": float(NormalDist().inv_cdf(0.5 + confidence_level / 2.0)),
        "preserve_second_moment": bool(preserve_second_moment),
        "initial_sampling_mode": (
            "provided_selection"
            if provided_selected is not None
            else "weighted_probabilities"
            if probabilities is not None
            else "uniform"
        ),
        "n_probability_fallback_bins": int(n_probability_fallback_bins),
        "initial_expression_coverage": float(initial_expression_coverage / max(1, n_expression)),
        "final_expression_coverage": float(np.sum(represented_expression) / max(1, n_expression)),
        "initial_detectable_local_coverage": float(
            initial_local_detectable_coverage / max(1, int(np.sum(local_detectable)))
        ),
        "final_detectable_local_coverage": float(
            np.sum(local_detectable & represented_local) / max(1, int(np.sum(local_detectable)))
        ),
        "initial_constraint_slack_loss": float(initial_slack_loss),
        "final_constraint_slack_loss": float(final_slack_loss),
        "initial_standardized_balance_loss": float(initial_balance_loss),
        "post_coverage_standardized_balance_loss": float(post_coverage_balance_loss),
        "final_standardized_balance_loss": float(final_balance_loss),
        "balance_refinement_improvement": float(
            post_coverage_balance_loss - final_balance_loss
        ),
        "n_expression_bins_below_bound": int(np.sum(under_bound)),
        "n_expression_bins_above_bound": int(np.sum(over_bound)),
        "objective_order": [
            "exact sample size and spatial quotas",
            "minimize confidence-bound slack",
            "maximize reachable global expression-state coverage",
            "maximize statistically detectable local-state coverage",
            "reduce variance-standardized expression moment loss",
        ],
        "manual_score_weights": None,
        "expression_intervals": interval_summary,
    }
    return selected, report


__all__ = [
    "confidence_constrained_exchange_sample",
    "finite_population_inclusion_probability",
    "stratified_expression_intervals",
]
