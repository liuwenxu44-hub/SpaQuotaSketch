"""Structured feasibility errors for the Version 2 prototype."""

from __future__ import annotations

from typing import Any


class V2FeasibilityError(ValueError):
    """An input or mathematical feasibility condition was not satisfied."""

    def __init__(self, code: str, message: str, **details: Any) -> None:
        super().__init__(f"{code}: {message}")
        self.code = str(code)
        self.message = str(message)
        self.details = details

    def to_dict(self) -> dict[str, Any]:
        return {
            "feasibility_status": "infeasible",
            "error_code": self.code,
            "message": self.message,
            "details": self.details,
            "constraint_relaxation": "none",
        }
