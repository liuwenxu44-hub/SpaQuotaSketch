"""Constraint-based Version 2 discovery mode."""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass
from typing import Hashable, Mapping, Sequence

import numpy as np
import pandas as pd

from .quotas import allocate_bounded_quotas


@dataclass(frozen=True)
class DiscoveryResult:
    selected_indices: np.ndarray
    expression_state: np.ndarray
    spatial_grid: np.ndarray
    spatial_quotas: dict[Hashable, int]
    allocation: dict[tuple[Hashable, Hashable], int]
    conditional_inclusion_probability: np.ndarray
    constraint_report: pd.DataFrame
    report: dict[str, object]


def _cross_counts(
    spatial_grid: Sequence[Hashable],
    expression_state: Sequence[Hashable],
) -> dict[tuple[Hashable, Hashable], int]:
    return dict(Counter(zip(spatial_grid, expression_state)))


def check_discovery_feasibility(
    cross_counts: Mapping[tuple[Hashable, Hashable], int],
    quotas: Mapping[Hashable, int],
    target_minimums: Mapping[Hashable, int],
) -> tuple[bool, dict[str, object]]:
    """Check rare-state lower bounds by maximum flow and return diagnostics."""
    import networkx as nx

    state_totals: Counter[Hashable] = Counter()
    for (_, state), count in cross_counts.items():
        state_totals[state] += int(count)
    minima = {state: int(value) for state, value in target_minimums.items()}
    invalid = {
        str(state): {"target_minimum": value, "state_size": int(state_totals.get(state, 0))}
        for state, value in minima.items()
        if value < 0 or value > int(state_totals.get(state, 0))
    }
    total_minimum = int(sum(minima.values()))
    target_n = int(sum(int(value) for value in quotas.values()))
    if invalid or total_minimum > target_n:
        return False, {
            "feasibility_status": "infeasible",
            "error_code": "DISCOVERY_INFEASIBLE",
            "invalid_state_minimums": invalid,
            "total_target_minimum": total_minimum,
            "target_n": target_n,
            "constraint_relaxation": "none",
        }
    if total_minimum == 0:
        return True, {
            "feasibility_status": "feasible",
            "required_flow": 0,
            "achieved_flow": 0,
            "constraint_relaxation": "none",
        }

    graph = nx.DiGraph()
    source, sink = ("source", 0), ("sink", 0)
    for grid, quota in quotas.items():
        graph.add_edge(source, ("grid", grid), capacity=int(quota))
    for (grid, state), count in cross_counts.items():
        if int(minima.get(state, 0)) > 0:
            graph.add_edge(
                ("grid", grid),
                ("state", state),
                capacity=int(count),
            )
    for state, minimum in minima.items():
        if minimum > 0:
            graph.add_edge(("state", state), sink, capacity=int(minimum))

    achieved, flow = nx.maximum_flow(graph, source, sink)
    if int(achieved) == total_minimum:
        return True, {
            "feasibility_status": "feasible",
            "required_flow": total_minimum,
            "achieved_flow": int(achieved),
            "constraint_relaxation": "none",
        }

    _, partition = nx.minimum_cut(graph, source, sink)
    reachable, non_reachable = partition
    deficits = {}
    for state, minimum in minima.items():
        if minimum <= 0:
            continue
        state_flow = sum(
            int(flow.get(("grid", grid), {}).get(("state", state), 0))
            for grid in quotas
        )
        if state_flow < minimum:
            deficits[str(state)] = {
                "target_minimum": int(minimum),
                "maximum_flow_received": int(state_flow),
                "shortfall": int(minimum - state_flow),
            }
    return False, {
        "feasibility_status": "infeasible",
        "error_code": "DISCOVERY_INFEASIBLE",
        "required_flow": total_minimum,
        "achieved_flow": int(achieved),
        "state_deficits": deficits,
        "cut_reachable_states": sorted(
            str(node[1]) for node in reachable if isinstance(node, tuple) and node[0] == "state"
        ),
        "cut_blocked_states": sorted(
            str(node[1]) for node in non_reachable if isinstance(node, tuple) and node[0] == "state"
        ),
        "constraint_relaxation": "none",
    }


def solve_integer_transport(
    cross_counts: Mapping[tuple[Hashable, Hashable], int],
    quotas: Mapping[Hashable, int],
    target_minimums: Mapping[Hashable, int],
    *,
    cost_scale: int = 1_000_000,
    epsilon: float = 1e-9,
) -> tuple[dict[tuple[Hashable, Hashable], int], dict[str, object]]:
    """Solve the approved separable convex integer transportation objective."""
    import networkx as nx

    feasible, feasibility = check_discovery_feasibility(
        cross_counts, quotas, target_minimums
    )
    if not feasible:
        return {}, feasibility

    state_totals: Counter[Hashable] = Counter()
    grid_totals: Counter[Hashable] = Counter()
    states: set[Hashable] = set()
    for (grid, state), count in cross_counts.items():
        state_totals[state] += int(count)
        grid_totals[grid] += int(count)
        states.add(state)
    ordered_states = sorted(states, key=str)
    minima = {state: int(target_minimums.get(state, 0)) for state in ordered_states}
    target_n = int(sum(int(value) for value in quotas.values()))
    total_minimum = int(sum(minima.values()))

    graph = nx.MultiDiGraph()
    sink = ("sink", 0)
    graph.add_node(sink, demand=target_n - total_minimum)
    for grid, quota in quotas.items():
        graph.add_node(("grid", grid), demand=-int(quota))
    for state in ordered_states:
        minimum = int(minima[state])
        graph.add_node(("state", state), demand=minimum)
        graph.add_edge(
            ("state", state),
            sink,
            key="remainder",
            capacity=int(state_totals[state] - minimum),
            weight=0,
        )

    for (grid, state), count in sorted(
        cross_counts.items(), key=lambda item: (str(item[0][0]), str(item[0][1]))
    ):
        quota = int(quotas[grid])
        capacity = min(int(count), quota)
        target = quota * int(count) / int(grid_totals[grid])
        denominator = target + float(epsilon)
        for unit in range(1, capacity + 1):
            previous = ((unit - 1) - target) ** 2 / denominator
            current = (unit - target) ** 2 / denominator
            marginal_cost = int(round((current - previous) * int(cost_scale)))
            graph.add_edge(
                ("grid", grid),
                ("state", state),
                key=unit,
                capacity=1,
                weight=marginal_cost,
            )

    try:
        objective_cost, flow = nx.network_simplex(graph)
    except (nx.NetworkXUnfeasible, nx.NetworkXError) as error:
        return {}, {
            "feasibility_status": "optimization_failed",
            "error_code": "DISCOVERY_OPTIMIZATION_FAILED",
            "message": str(error),
            "constraint_relaxation": "none",
        }

    allocation: dict[tuple[Hashable, Hashable], int] = {}
    for grid, state in sorted(
        cross_counts, key=lambda pair: (str(pair[0]), str(pair[1]))
    ):
        edge_flow = flow.get(("grid", grid), {}).get(("state", state), {})
        if isinstance(edge_flow, dict):
            value = int(sum(int(item) for item in edge_flow.values()))
        else:
            value = int(edge_flow)
        allocation[(grid, state)] = value

    for grid, quota in quotas.items():
        achieved = sum(
            value for (item_grid, _), value in allocation.items() if item_grid == grid
        )
        if achieved != int(quota):
            return {}, {
                "feasibility_status": "optimization_failed",
                "error_code": "DISCOVERY_GRID_QUOTA_MISMATCH",
                "spatial_grid": str(grid),
                "spatial_quota": int(quota),
                "achieved": int(achieved),
                "constraint_relaxation": "none",
            }
    achieved_states = Counter()
    for (_, state), value in allocation.items():
        achieved_states[state] += int(value)
    for state, minimum in target_minimums.items():
        if achieved_states[state] < int(minimum):
            return {}, {
                "feasibility_status": "optimization_failed",
                "error_code": "DISCOVERY_STATE_MINIMUM_MISMATCH",
                "expression_state": str(state),
                "target_minimum": int(minimum),
                "achieved_count": int(achieved_states[state]),
                "constraint_relaxation": "none",
            }
    return allocation, {
        **feasibility,
        "objective_cost_scaled": int(objective_cost),
        "cost_scale": int(cost_scale),
    }


def run_discovery(
    spatial_grid: Sequence[Hashable],
    expression_state: Sequence[Hashable],
    target_n: int,
    target_minimums: Mapping[Hashable, int],
    *,
    seed: int = 0,
) -> DiscoveryResult:
    """Run exact spatial quotas with hard expression-state lower bounds."""
    grids = np.asarray(list(spatial_grid), dtype=object)
    states = np.asarray(list(expression_state), dtype=object)
    if grids.size != states.size:
        raise ValueError("spatial_grid and expression_state must align.")
    quotas = allocate_bounded_quotas(grids.tolist(), int(target_n), require_positive=True)
    cross_counts = _cross_counts(grids.tolist(), states.tolist())
    allocation, feasibility = solve_integer_transport(
        cross_counts, quotas, target_minimums
    )
    state_totals = Counter(states.tolist())
    if not allocation:
        records = [
            {
                "expression_state": str(state),
                "target_minimum": int(target_minimums.get(state, 0)),
                "achieved_count": 0,
                "feasibility_status": feasibility["feasibility_status"],
                "constraint_relaxation": "none",
            }
            for state in sorted(state_totals, key=str)
        ]
        return DiscoveryResult(
            selected_indices=np.asarray([], dtype=int),
            expression_state=states,
            spatial_grid=grids,
            spatial_quotas=quotas,
            allocation={},
            conditional_inclusion_probability=np.zeros(states.size, dtype=float),
            constraint_report=pd.DataFrame.from_records(records),
            report={
                "mode": "discovery",
                "target_n": int(target_n),
                "n_selected": 0,
                **feasibility,
            },
        )

    positions: dict[tuple[Hashable, Hashable], list[int]] = defaultdict(list)
    for index, pair in enumerate(zip(grids.tolist(), states.tolist())):
        positions[pair].append(index)
    rng = np.random.default_rng(seed)
    selected_parts: list[np.ndarray] = []
    conditional = np.zeros(states.size, dtype=float)
    for pair, available in positions.items():
        n_take = int(allocation.get(pair, 0))
        available_array = np.asarray(available, dtype=int)
        probability = n_take / available_array.size
        conditional[available_array] = probability
        if n_take:
            selected_parts.append(
                rng.choice(available_array, size=n_take, replace=False).astype(int)
            )
    selected = np.sort(np.concatenate(selected_parts)) if selected_parts else np.asarray([], dtype=int)
    achieved_states = Counter(states[selected].tolist())
    constraint_records = [
        {
            "expression_state": str(state),
            "target_minimum": int(target_minimums.get(state, 0)),
            "achieved_count": int(achieved_states.get(state, 0)),
            "feasibility_status": "feasible",
            "constraint_relaxation": "none",
        }
        for state in sorted(state_totals, key=str)
    ]
    report = {
        "mode": "discovery",
        "target_n": int(target_n),
        "n_selected": int(selected.size),
        "n_spatial_grids": int(len(quotas)),
        "n_expression_states": int(len(state_totals)),
        "n_target_states": int(sum(int(value) > 0 for value in target_minimums.values())),
        "feasibility_status": "feasible",
        "constraint_relaxation": "none",
        **feasibility,
    }
    return DiscoveryResult(
        selected_indices=selected,
        expression_state=states,
        spatial_grid=grids,
        spatial_quotas=quotas,
        allocation=allocation,
        conditional_inclusion_probability=conditional,
        constraint_report=pd.DataFrame.from_records(constraint_records),
        report=report,
    )
