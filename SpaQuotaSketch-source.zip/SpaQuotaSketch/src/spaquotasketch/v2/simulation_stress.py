"""Reproducible synthetic populations and metrics for Version 2 stress tests."""

from __future__ import annotations

import math
import os
import threading
import time
from collections import Counter, defaultdict
from dataclasses import dataclass
from typing import Any, Callable, Mapping, Sequence

import numpy as np
import pandas as pd

from ..candidate_pool import capped_leverage_score_sample
from ..core_workflow import bin_ids_for_indices, build_candidates_until_quota_feasible
from ..metrics import relative_mean_absolute_error, weighted_column_mean
from ..quota_sampling import compute_bin_quotas, sample_by_quota
from ..spatial_bins import rectangular_grid_bins
from .discovery import run_discovery
from .errors import V2FeasibilityError
from .expression import consensus_expression_states, normalized_svd
from .inference import run_inference
from .quotas import allocate_bounded_quotas


SEPARATION = {"none": 0.0, "weak": 0.45, "medium": 1.25, "strong": 2.5}
NOISE = {"low": 0.20, "medium": 0.55, "high": 1.00}
DROPOUT = {"low": 0.10, "medium": 0.40, "high": 0.70}
CORRELATION = {
    "independent": 0.0,
    "weak": 0.25,
    "moderate": 0.55,
    "high": 0.85,
    "gradient_driven": 1.0,
    "exact_overlap": 1.0,
}


@dataclass(frozen=True)
class SimulationPopulation:
    expression: Any
    coordinates: np.ndarray
    true_state: np.ndarray
    rare_mask: np.ndarray
    gradient: np.ndarray
    density: np.ndarray
    metadata: dict[str, object]


def measure_call(callback: Callable[[], Any], interval_seconds: float = 0.02):
    """Return result, elapsed seconds, start memory and peak memory in MiB."""
    import psutil

    process = psutil.Process(os.getpid())
    start = float(process.memory_info().rss) / (1024 * 1024)
    peak = {"value": start}
    stop = threading.Event()

    def monitor() -> None:
        while not stop.is_set():
            peak["value"] = max(
                peak["value"], float(process.memory_info().rss) / (1024 * 1024)
            )
            time.sleep(interval_seconds)
        peak["value"] = max(
            peak["value"], float(process.memory_info().rss) / (1024 * 1024)
        )

    thread = threading.Thread(target=monitor, daemon=True)
    started = time.perf_counter()
    thread.start()
    try:
        result = callback()
    finally:
        stop.set()
        thread.join()
    return result, time.perf_counter() - started, start, float(peak["value"])


def _clip_coordinates(values: np.ndarray) -> np.ndarray:
    return np.clip(values, 0.0001, 0.9999).astype(np.float32, copy=False)


def _coordinates(structure: str, n_cells: int, rng: np.random.Generator) -> np.ndarray:
    uniform = lambda n: rng.uniform(0.0, 1.0, size=(n, 2))
    if structure == "uniform":
        return uniform(n_cells).astype(np.float32)
    if structure == "high_low_density":
        dense_n = int(round(n_cells * 0.70))
        centers = np.asarray([[0.25, 0.30], [0.72, 0.70]], dtype=float)
        assignment = rng.integers(0, len(centers), size=dense_n)
        dense = centers[assignment] + rng.normal(0, 0.065, size=(dense_n, 2))
        return _clip_coordinates(np.vstack([dense, uniform(n_cells - dense_n)]))
    if structure == "stripes":
        x_value = rng.uniform(0, 1, n_cells)
        stripe = rng.integers(0, 4, n_cells)
        y_value = (stripe + rng.normal(0.5, 0.10, n_cells)) / 4
        return _clip_coordinates(np.column_stack([x_value, y_value]))
    if structure == "radial":
        theta = rng.uniform(0, 2 * np.pi, n_cells)
        radius = np.clip(rng.normal(0.32, 0.14, n_cells), 0.02, 0.48)
        return _clip_coordinates(
            np.column_stack([0.5 + radius * np.cos(theta), 0.5 + radius * np.sin(theta)])
        )
    if structure == "islands":
        centers = np.asarray([[0.22, 0.24], [0.72, 0.25], [0.30, 0.75], [0.74, 0.73]])
        assignment = rng.integers(0, len(centers), n_cells)
        return _clip_coordinates(centers[assignment] + rng.normal(0, 0.075, (n_cells, 2)))
    if structure == "continuous_gradient":
        x_value = rng.beta(1.6, 1.2, n_cells)
        return _clip_coordinates(np.column_stack([x_value, rng.uniform(0, 1, n_cells)]))
    if structure == "tissue_boundary":
        side = rng.integers(0, 2, n_cells)
        x_value = np.where(
            side == 0,
            rng.uniform(0.02, 0.45, n_cells),
            rng.uniform(0.55, 0.98, n_cells),
        )
        return _clip_coordinates(np.column_stack([x_value, rng.uniform(0, 1, n_cells)]))
    if structure == "irregular_outline":
        values: list[np.ndarray] = []
        needed = n_cells
        while needed:
            proposal = uniform(max(needed * 2, 128))
            x_value, y_value = proposal[:, 0], proposal[:, 1]
            inside = (
                ((x_value - 0.48) / 0.47) ** 2 + ((y_value - 0.51) / 0.39) ** 2 < 1
            ) & (y_value > 0.12 + 0.12 * np.sin(7 * x_value))
            accepted = proposal[inside][:needed]
            values.append(accepted)
            needed -= accepted.shape[0]
        return _clip_coordinates(np.vstack(values))
    raise ValueError(f"Unsupported global_spatial_structure: {structure}")


def _density_score(coordinates: np.ndarray) -> np.ndarray:
    centers = np.asarray([[0.25, 0.30], [0.72, 0.70]], dtype=float)
    squared = np.min(
        np.square(coordinates[:, None, :] - centers[None, :, :]).sum(axis=2), axis=1
    )
    return np.exp(-squared / 0.02)


def _ranked_choice(score: np.ndarray, n_take: int, rng: np.random.Generator) -> np.ndarray:
    jitter = rng.uniform(0, 1e-8, score.size)
    return np.argsort(-(score + jitter), kind="stable")[:n_take]


def _assign_rare_positions(
    coordinates: np.ndarray,
    n_rare: int,
    structure: str,
    density: np.ndarray,
    rng: np.random.Generator,
) -> np.ndarray:
    if n_rare == 0:
        return np.asarray([], dtype=int)
    n_cells = coordinates.shape[0]
    if structure == "uniform_scattered":
        return np.sort(rng.choice(n_cells, size=n_rare, replace=False))
    if structure == "compact_cluster":
        selected = np.sort(rng.choice(n_cells, size=n_rare, replace=False))
        coordinates[selected] = _clip_coordinates(
            np.asarray([0.72, 0.27]) + rng.normal(0, 0.012, size=(n_rare, 2))
        )
        return selected
    if structure == "multiple_small_clusters":
        selected = np.sort(rng.choice(n_cells, size=n_rare, replace=False))
        centers = np.asarray([[0.20, 0.25], [0.80, 0.28], [0.32, 0.76], [0.74, 0.72]])
        assignment = rng.integers(0, len(centers), n_rare)
        coordinates[selected] = _clip_coordinates(
            centers[assignment] + rng.normal(0, 0.010, size=(n_rare, 2))
        )
        return selected
    if structure == "tissue_edge":
        return np.sort(_ranked_choice(1.0 - coordinates[:, 0], n_rare, rng))
    if structure == "transition_zone":
        return np.sort(_ranked_choice(-np.abs(coordinates[:, 0] - 0.5), n_rare, rng))
    if structure == "single_grid":
        selected = np.sort(rng.choice(n_cells, size=n_rare, replace=False))
        coordinates[selected] = _clip_coordinates(
            np.asarray([0.475, 0.475]) + rng.normal(0, 0.0018, size=(n_rare, 2))
        )
        return selected
    if structure == "multiple_grids":
        selected = np.sort(rng.choice(n_cells, size=n_rare, replace=False))
        centers = np.asarray([[0.225, 0.225], [0.775, 0.225], [0.225, 0.775], [0.775, 0.775]])
        assignment = rng.integers(0, len(centers), n_rare)
        coordinates[selected] = _clip_coordinates(
            centers[assignment] + rng.normal(0, 0.004, size=(n_rare, 2))
        )
        return selected
    if structure == "high_density_region":
        return np.sort(_ranked_choice(density, n_rare, rng))
    if structure == "low_density_region":
        return np.sort(_ranked_choice(-density, n_rare, rng))
    raise ValueError(f"Unsupported rare_spatial_structure: {structure}")


def _spatial_common_state(coordinates: np.ndarray, structure: str) -> np.ndarray:
    x_value, y_value = coordinates[:, 0], coordinates[:, 1]
    if structure == "stripes":
        return np.clip((y_value * 4).astype(int), 0, 3)
    if structure == "radial":
        angle = (np.arctan2(y_value - 0.5, x_value - 0.5) + np.pi) / (2 * np.pi)
        return np.clip((angle * 4).astype(int), 0, 3)
    if structure == "islands":
        centers = np.asarray([[0.22, 0.24], [0.72, 0.25], [0.30, 0.75], [0.74, 0.73]])
        return np.square(coordinates[:, None, :] - centers[None, :, :]).sum(axis=2).argmin(axis=1)
    if structure in {"continuous_gradient", "tissue_boundary"}:
        return np.clip((x_value * 4).astype(int), 0, 3)
    if structure == "high_low_density":
        return ((x_value > 0.5).astype(int) + 2 * (y_value > 0.5).astype(int))
    return np.clip(((x_value > 0.5).astype(int) + 2 * (y_value > 0.5).astype(int)), 0, 3)


def generate_population(
    scenario: Mapping[str, object],
    n_cells: int,
    *,
    seed: int,
) -> SimulationPopulation:
    """Generate count data with known spatial and rare-state truth."""
    from scipy import sparse

    rng = np.random.default_rng(int(seed))
    n_cells = int(n_cells)
    n_genes = int(scenario.get("n_genes", 32))
    coordinates = _coordinates(str(scenario["global_spatial_structure"]), n_cells, rng)
    density = _density_score(coordinates)
    rare_frequency = float(scenario["rare_frequency"])
    n_rare = int(round(n_cells * rare_frequency))
    rare_indices = _assign_rare_positions(
        coordinates,
        n_rare,
        str(scenario["rare_spatial_structure"]),
        density,
        rng,
    )
    rare_mask = np.zeros(n_cells, dtype=bool)
    rare_mask[rare_indices] = True
    density = _density_score(coordinates)

    spatial_state = _spatial_common_state(
        coordinates, str(scenario["global_spatial_structure"])
    )
    random_state = rng.integers(0, int(scenario.get("n_common_states", 4)), n_cells)
    relation = str(scenario["expression_spatial_relation"])
    strength = CORRELATION[relation]
    common_state = np.where(rng.random(n_cells) < strength, spatial_state, random_state)
    true_state = np.asarray([f"common_{value}" for value in common_state], dtype=object)
    true_state[rare_mask] = "rare"

    base = rng.normal(0.0, 0.25, n_genes).astype(np.float32)
    state_effect = rng.normal(0.0, 0.45, size=(4, n_genes)).astype(np.float32)
    log_rate = base[None, :] + state_effect[common_state]
    gradient_loadings = rng.normal(0.0, 0.25, n_genes).astype(np.float32)
    if relation in {"gradient_driven", "high", "exact_overlap", "moderate", "weak"}:
        log_rate += (
            strength * (coordinates[:, [0]] - 0.5) * gradient_loadings[None, :]
        ).astype(np.float32)
    separation = SEPARATION[str(scenario["rare_separability"])]
    if n_rare and separation:
        rare_effect = np.zeros(n_genes, dtype=np.float32)
        split = max(2, n_genes // 4)
        rare_effect[:split] = separation
        rare_effect[split : 2 * split] = -0.55 * separation
        log_rate[rare_mask] += rare_effect
    log_rate += rng.normal(
        0.0, NOISE[str(scenario["technical_noise"])], size=log_rate.shape
    ).astype(np.float32)
    library_size = rng.lognormal(0.0, 0.28, n_cells).astype(np.float32)
    rates = np.exp(np.clip(log_rate, -4.0, 3.5)) * library_size[:, None]
    counts = rng.poisson(rates).astype(np.int32, copy=False)
    dropout = DROPOUT[str(scenario["dropout_level"])]
    if dropout:
        remove = rng.random(counts.shape) < (dropout * counts / (counts + 1.0))
        counts[remove] = 0
    expression = sparse.csr_matrix(counts)
    spatial_grid = rectangular_grid_bins(coordinates, n_x=20, n_y=20)
    rare_grid_count = len(set(np.asarray(spatial_grid, dtype=object)[rare_mask].tolist())) if n_rare else 0
    metadata = {
        "n_cells": n_cells,
        "n_genes": n_genes,
        "rare_count": int(n_rare),
        "rare_frequency_realized": float(n_rare / n_cells),
        "rare_spatial_grid_count": int(rare_grid_count),
        "seed": int(seed),
    }
    return SimulationPopulation(
        expression=expression,
        coordinates=coordinates,
        true_state=true_state,
        rare_mask=rare_mask,
        gradient=coordinates[:, 0].astype(float),
        density=density,
        metadata=metadata,
    )


def target_size(n_cells: int, fraction: float) -> int:
    return max(1, min(int(n_cells), int(round(int(n_cells) * float(fraction)))))


def _weight_metrics(weights: np.ndarray | None) -> dict[str, float]:
    if weights is None or weights.size == 0:
        return {
            "weight_min": np.nan,
            "weight_max": np.nan,
            "weight_mean": np.nan,
            "weight_std": np.nan,
            "weight_cv": np.nan,
            "weight_max_to_median": np.nan,
            "kish_effective_sample_size": np.nan,
            "weight_top_1pct_share": np.nan,
            "extreme_weight_fraction": np.nan,
        }
    median = float(np.median(weights))
    top_n = max(1, int(math.ceil(weights.size * 0.01)))
    return {
        "weight_min": float(weights.min()),
        "weight_max": float(weights.max()),
        "weight_mean": float(weights.mean()),
        "weight_std": float(weights.std(ddof=0)),
        "weight_cv": float(weights.std(ddof=0) / weights.mean()),
        "weight_max_to_median": float(weights.max() / median) if median > 0 else np.inf,
        "kish_effective_sample_size": float(weights.sum() ** 2 / np.square(weights).sum()),
        "weight_top_1pct_share": float(np.sort(weights)[-top_n:].sum() / weights.sum()),
        "extreme_weight_fraction": float(np.mean(weights >= 4 * median)) if median > 0 else np.nan,
    }


def _relative_rmse(reference: np.ndarray, observed: np.ndarray) -> float:
    scale = float(np.mean(np.abs(reference))) + 1e-12
    return float(np.sqrt(np.mean(np.square(reference - observed))) / scale)


def _relative_signed_error(reference: np.ndarray, observed: np.ndarray) -> float:
    """Signed, scale-normalized error for repeated-sampling bias summaries."""
    scale = float(np.mean(np.abs(reference))) + 1e-12
    return float(np.mean(observed - reference) / scale)


def _state_spatial_l1(
    true_state: np.ndarray, grid: np.ndarray, selected: np.ndarray
) -> float:
    values = []
    for state in np.unique(true_state):
        full_mask = true_state == state
        selected_mask = true_state[selected] == state
        if not np.any(selected_mask):
            values.append(1.0)
            continue
        full_counts = Counter(grid[full_mask].tolist())
        selected_counts = Counter(grid[selected][selected_mask].tolist())
        full_total = sum(full_counts.values())
        selected_total = sum(selected_counts.values())
        values.append(
            sum(
                abs(full_counts[item] / full_total - selected_counts[item] / selected_total)
                for item in set(full_counts) | set(selected_counts)
            )
        )
    return float(np.mean(values)) if values else 0.0


def _state_proportion_l1(true_state: np.ndarray, selected: np.ndarray) -> float:
    full = Counter(true_state.tolist())
    sampled = Counter(true_state[selected].tolist())
    if not selected.size:
        return 1.0
    return float(
        sum(
            abs(full[state] / true_state.size - sampled[state] / selected.size)
            for state in set(full) | set(sampled)
        )
    )


def _gradient_error(matrix, selected: np.ndarray, coordinates: np.ndarray) -> float:
    from scipy import sparse

    boundaries = np.linspace(0, 1, 11)
    full_values, sample_values = [], []
    for start, end in zip(boundaries[:-1], boundaries[1:]):
        full_mask = (coordinates[:, 0] >= start) & (
            coordinates[:, 0] < end if end < 1 else coordinates[:, 0] <= end
        )
        sample_mask = full_mask[selected]
        if full_mask.sum() < 2 or sample_mask.sum() < 2:
            continue
        if sparse.issparse(matrix):
            full_values.append(float(matrix[full_mask, 0].mean()))
            sample_values.append(float(matrix[selected[sample_mask], 0].mean()))
        else:
            full_values.append(float(np.mean(matrix[full_mask, 0])))
            sample_values.append(float(np.mean(matrix[selected[sample_mask], 0])))
    if len(full_values) < 3 or np.std(full_values) == 0 or np.std(sample_values) == 0:
        return np.nan
    return float(1.0 - np.corrcoef(full_values, sample_values)[0, 1])


def _full_reference(population: SimulationPopulation) -> dict[str, Any]:
    matrix = population.expression
    total = np.asarray(matrix.sum(axis=0)).reshape(-1).astype(float)
    mean = total / matrix.shape[0]
    low = mean <= np.quantile(mean, 0.25)
    high = mean >= np.quantile(mean, 0.75)
    local_mask = population.coordinates[:, 0] < 0.5
    local_total = np.asarray(matrix[local_mask].sum(axis=0)).reshape(-1).astype(float)
    states, counts = np.unique(population.true_state, return_counts=True)
    state_proportion = {state: count / matrix.shape[0] for state, count in zip(states, counts)}
    return {
        "gene_total": total,
        "gene_mean": mean,
        "low_gene": low,
        "high_gene": high,
        "local_total": local_total,
        "local_n": int(local_mask.sum()),
        "state_proportion": state_proportion,
    }


def _estimator_metrics(
    population: SimulationPopulation,
    selected: np.ndarray,
    weights: np.ndarray | None,
    reference: Mapping[str, Any],
) -> dict[str, float]:
    matrix = population.expression
    if not selected.size:
        return {
            "unweighted_gene_mean_relative_error": np.nan,
            "unweighted_gene_mean_relative_rmse": np.nan,
            "unweighted_gene_mean_relative_signed_error": np.nan,
            "ht_gene_total_relative_error": np.nan,
            "ht_gene_total_relative_rmse": np.nan,
            "ht_gene_total_relative_signed_error": np.nan,
            "hajek_gene_mean_relative_error": np.nan,
            "hajek_gene_mean_relative_rmse": np.nan,
            "hajek_gene_mean_relative_signed_error": np.nan,
            "ht_low_gene_total_relative_rmse": np.nan,
            "ht_low_gene_total_relative_signed_error": np.nan,
            "ht_high_gene_total_relative_rmse": np.nan,
            "ht_high_gene_total_relative_signed_error": np.nan,
            "ht_local_gene_total_relative_rmse": np.nan,
            "ht_local_gene_total_relative_signed_error": np.nan,
            "ht_state_proportion_l1": np.nan,
            "ht_rare_proportion_absolute_error": np.nan,
            "ht_rare_proportion_signed_error": np.nan,
        }
    selected_matrix = matrix[selected]
    unweighted_mean = np.asarray(selected_matrix.mean(axis=0)).reshape(-1)
    result = {
        "unweighted_gene_mean_relative_error": relative_mean_absolute_error(
            reference["gene_mean"], unweighted_mean
        ),
        "unweighted_gene_mean_relative_rmse": _relative_rmse(
            reference["gene_mean"], unweighted_mean
        ),
        "unweighted_gene_mean_relative_signed_error": _relative_signed_error(
            reference["gene_mean"], unweighted_mean
        ),
    }
    if weights is None:
        return {
            **result,
            "ht_gene_total_relative_error": np.nan,
            "ht_gene_total_relative_rmse": np.nan,
            "ht_gene_total_relative_signed_error": np.nan,
            "hajek_gene_mean_relative_error": np.nan,
            "hajek_gene_mean_relative_rmse": np.nan,
            "hajek_gene_mean_relative_signed_error": np.nan,
            "ht_low_gene_total_relative_rmse": np.nan,
            "ht_low_gene_total_relative_signed_error": np.nan,
            "ht_high_gene_total_relative_rmse": np.nan,
            "ht_high_gene_total_relative_signed_error": np.nan,
            "ht_local_gene_total_relative_rmse": np.nan,
            "ht_local_gene_total_relative_signed_error": np.nan,
            "ht_state_proportion_l1": np.nan,
            "ht_rare_proportion_absolute_error": np.nan,
            "ht_rare_proportion_signed_error": np.nan,
        }
    estimated_total = np.asarray(selected_matrix.T.dot(weights)).reshape(-1)
    estimated_mean = estimated_total / matrix.shape[0]
    hajek_mean = weighted_column_mean(selected_matrix, weights)
    low, high = reference["low_gene"], reference["high_gene"]
    local_indicator = population.coordinates[selected, 0] < 0.5
    local_estimated = np.asarray(selected_matrix[local_indicator].T.dot(weights[local_indicator])).reshape(-1)
    estimated_state = {
        state: float(weights[population.true_state[selected] == state].sum() / matrix.shape[0])
        for state in reference["state_proportion"]
    }
    state_l1 = sum(
        abs(reference["state_proportion"][state] - estimated_state[state])
        for state in reference["state_proportion"]
    )
    rare_true = float(population.rare_mask.mean())
    rare_estimated = float(weights[population.rare_mask[selected]].sum() / matrix.shape[0])
    return {
        **result,
        "ht_gene_total_relative_error": relative_mean_absolute_error(
            reference["gene_total"], estimated_total
        ),
        "ht_gene_total_relative_rmse": _relative_rmse(reference["gene_total"], estimated_total),
        "ht_gene_total_relative_signed_error": _relative_signed_error(
            reference["gene_total"], estimated_total
        ),
        "hajek_gene_mean_relative_error": relative_mean_absolute_error(
            reference["gene_mean"], hajek_mean
        ),
        "hajek_gene_mean_relative_rmse": _relative_rmse(reference["gene_mean"], hajek_mean),
        "hajek_gene_mean_relative_signed_error": _relative_signed_error(
            reference["gene_mean"], hajek_mean
        ),
        "ht_low_gene_total_relative_rmse": _relative_rmse(
            reference["gene_total"][low], estimated_total[low]
        ),
        "ht_low_gene_total_relative_signed_error": _relative_signed_error(
            reference["gene_total"][low], estimated_total[low]
        ),
        "ht_high_gene_total_relative_rmse": _relative_rmse(
            reference["gene_total"][high], estimated_total[high]
        ),
        "ht_high_gene_total_relative_signed_error": _relative_signed_error(
            reference["gene_total"][high], estimated_total[high]
        ),
        "ht_local_gene_total_relative_rmse": _relative_rmse(
            reference["local_total"], local_estimated
        ),
        "ht_local_gene_total_relative_signed_error": _relative_signed_error(
            reference["local_total"], local_estimated
        ),
        "ht_state_proportion_l1": float(state_l1),
        "ht_rare_proportion_absolute_error": float(abs(rare_true - rare_estimated)),
        "ht_rare_proportion_signed_error": float(rare_estimated - rare_true),
    }


def _representation_and_states(
    population: SimulationPopulation,
    config: Mapping[str, Any],
    *,
    build_states: bool,
) -> tuple[Any, np.ndarray | None, pd.DataFrame | None, dict[str, Any], dict[str, float]]:
    components = int(config["methods"]["v2_inference"]["n_components"])
    representation, expression_seconds, _, expression_peak = measure_call(
        lambda: normalized_svd(population.expression, n_components=components, random_state=0)
    )
    states: np.ndarray | None = None
    state_table: pd.DataFrame | None = None
    state_report: dict[str, Any] = {"state_generation_status": "not_requested"}
    state_seconds, state_peak = 0.0, expression_peak
    if build_states:
        params = config["methods"]["v2_discovery"]
        try:
            (states, state_table, state_report), state_seconds, _, state_peak = measure_call(
                lambda: consensus_expression_states(
                    representation.embedding,
                    n_neighbors=int(params["state_neighbors"]),
                    resolution=float(params["state_resolution"]),
                    state_seeds=config["random_seeds"]["state_seeds"],
                    graph_seed=0,
                    min_state_size=int(params["state_min_size"]),
                    min_stability=float(params["state_min_stability"]),
                )
            )
            state_report = {**state_report, "state_generation_status": "ok"}
        except Exception as error:  # Diagnostic failure is a required simulation outcome.
            state_report = {
                "state_generation_status": "failed",
                "state_generation_error_type": type(error).__name__,
                "state_generation_error": str(error),
            }
    return representation, states, state_table, state_report, {
        "expression_preprocessing_seconds": float(expression_seconds),
        "expression_preprocessing_peak_mb": float(expression_peak),
        "state_identification_seconds": float(state_seconds),
        "state_identification_peak_mb": float(state_peak),
    }


def _unsupervised_target_metrics(
    population: SimulationPopulation,
    states: np.ndarray | None,
    state_table: pd.DataFrame | None,
    config: Mapping[str, Any],
) -> tuple[dict[str, int], dict[str, float | str]]:
    if states is None or state_table is None:
        return {}, {
            "rare_identification_status": "state_generation_failed",
            "rare_identification_recall": np.nan,
            "rare_identification_precision": np.nan,
            "false_positive_target_states": np.nan,
            "no_rare_false_trigger": np.nan,
            "state_truth_adjusted_rand": np.nan,
        }
    from sklearn.metrics import adjusted_rand_score

    parameters = config["methods"]["v2_discovery"]
    targets = state_table.loc[
        (~state_table["is_background"])
        & (state_table["frequency"] <= float(parameters["rare_frequency_upper_bound"])),
        "expression_state",
    ].astype(str)
    target_minimums = {
        state: min(
            int(parameters["rare_minimum"]),
            int(state_table.loc[state_table["expression_state"] == state, "n_cells"].iloc[0]),
        )
        for state in targets
    }
    predicted_target = np.isin(states.astype(str), list(target_minimums))
    truth = population.rare_mask
    if truth.any():
        recall = float(np.mean(predicted_target[truth]))
        precision = float(np.mean(truth[predicted_target])) if predicted_target.any() else 0.0
        status = "identified" if recall >= 0.60 and precision >= 0.50 else "identification_failed"
        false_trigger = 0.0
    else:
        recall, precision = np.nan, np.nan
        status = "no_true_rare"
        false_trigger = float(bool(target_minimums))
    false_positive_states = 0
    for state in target_minimums:
        mask = states.astype(str) == state
        if not truth.any() or float(np.mean(truth[mask])) < 0.5:
            false_positive_states += 1
    return target_minimums, {
        "rare_identification_status": status,
        "rare_identification_recall": recall,
        "rare_identification_precision": precision,
        "false_positive_target_states": float(false_positive_states),
        "no_rare_false_trigger": false_trigger,
        "state_truth_adjusted_rand": float(adjusted_rand_score(population.true_state, states)),
    }


def _coordinate_design(
    grid: np.ndarray, target_n: int, seed: int) -> tuple[np.ndarray, np.ndarray | None, dict[str, int], str]:
    require_positive = target_n >= len(set(grid.tolist()))
    quotas = allocate_bounded_quotas(
        grid.tolist(), target_n, require_positive=require_positive
    )
    selected, _ = sample_by_quota(
        list(range(grid.size)), grid.tolist(), quotas, seed=seed
    )
    counts = Counter(grid.tolist())
    probability = np.asarray([quotas[item] / counts[item] for item in grid], dtype=float)
    weights = 1.0 / probability[np.asarray(selected, dtype=int)] if np.all(probability > 0) else None
    return np.sort(np.asarray(selected, dtype=int)), weights, quotas, (
        "positive_quota" if require_positive else "zero_quota_allowed"
    )


def _formal_baseline_design(
    embedding: np.ndarray, grid: np.ndarray, target_n: int, seed: int, config: Mapping[str, Any]
) -> tuple[np.ndarray, dict[str, object]]:
    parameters = config["methods"]["formal_baseline"]
    quotas = compute_bin_quotas(grid.tolist(), target_n)
    strata_grid = parameters["expression_strata_grid"]
    strata = rectangular_grid_bins(
        embedding[:, :2], n_x=int(strata_grid[0]), n_y=int(strata_grid[1])
    )
    seeds = list(range(seed * int(parameters["candidate_seed_range"][1]), (seed + 1) * int(parameters["candidate_seed_range"][1])))
    n_per_seed = max(1, int(math.ceil(embedding.shape[0] * float(parameters["candidate_fraction_per_seed"]))))
    candidates, selected_by_seed, _, _, feasibility = build_candidates_until_quota_feasible(
        embedding=embedding,
        all_bin_ids=grid.tolist(),
        final_quotas=quotas,
        n_select_per_seed=n_per_seed,
        seeds=seeds,
        method="stratified",
        candidate_strata=strata,
    )
    if feasibility["n_insufficient_bins"]:
        raise V2FeasibilityError(
            "FORMAL_BASELINE_CANDIDATE_INFEASIBLE",
            "Formal baseline candidate pool could not satisfy final spatial quotas.",
            **feasibility,
        )
    candidate_grid = bin_ids_for_indices(candidates, grid.tolist())
    selected, quota_report = sample_by_quota(candidates, candidate_grid, quotas, seed=seed)
    return np.sort(np.asarray(selected, dtype=int)), {
        "formal_n_candidates": int(len(candidates)),
        "formal_candidate_seeds_used": int(len(selected_by_seed)),
        "formal_quota_shortfall": int(quota_report["n_insufficient_bins"]),
    }


def _geosketch_design(embedding: np.ndarray, target_n: int, seed: int) -> np.ndarray:
    import geosketch

    values = np.asarray(embedding, dtype=float).copy()
    return np.sort(np.asarray(geosketch.gs(values, int(target_n), seed=int(seed)), dtype=int))


def _run_selection(
    method: str,
    population: SimulationPopulation,
    embedding: np.ndarray,
    expression_score: np.ndarray,
    grid: np.ndarray,
    target_n: int,
    seed: int,
    config: Mapping[str, Any],
    unsupervised_states: np.ndarray | None,
    unsupervised_minimums: Mapping[str, int],
) -> tuple[np.ndarray, np.ndarray | None, np.ndarray | None, dict[str, object]]:
    n_cells = population.expression.shape[0]
    if method == "uniform_random":
        selected = np.sort(np.random.default_rng(seed).choice(n_cells, target_n, replace=False))
        probability = np.full(n_cells, target_n / n_cells, dtype=float)
        return selected, probability, 1.0 / probability[selected], {"feasibility_status": "feasible"}
    if method == "coordinate_only_quota":
        selected, weights, quotas, quota_mode = _coordinate_design(grid, target_n, seed)
        counts = Counter(grid.tolist())
        probability = np.asarray([quotas[item] / counts[item] for item in grid], dtype=float)
        return selected, probability, weights, {
            "feasibility_status": "feasible",
            "coordinate_quota_mode": quota_mode,
            "spatial_quotas": quotas,
        }
    if method == "formal_baseline":
        selected, details = _formal_baseline_design(embedding, grid, target_n, seed, config)
        return selected, None, None, {"feasibility_status": "feasible", **details}
    if method == "leverage_score":
        selected = np.sort(
            np.asarray(capped_leverage_score_sample(embedding, target_n, seed=seed), dtype=int)
        )
        return selected, None, None, {"feasibility_status": "feasible"}
    if method == "geosketch":
        selected = _geosketch_design(embedding, target_n, seed)
        return selected, None, None, {"feasibility_status": "feasible", "geosketch_version": "1.3"}
    if method == "v2_inference":
        parameters = config["methods"]["v2_inference"]
        result = run_inference(
            grid,
            expression_score,
            embedding,
            target_n,
            max_weight_inflation=float(parameters["max_weight_inflation"]),
            seed=seed,
            local_neighbors=int(parameters["local_neighbors"]),
        )
        return result.selected_indices, result.inclusion_probability, result.sampling_weight, {
            **result.report,
            "spatial_quotas": result.spatial_quotas,
        }
    if method == "v2_discovery":
        if unsupervised_states is None:
            raise V2FeasibilityError(
                "UNSUPERVISED_STATE_UNAVAILABLE",
                "The full discovery pipeline cannot run because state generation failed.",
            )
        result = run_discovery(
            grid, unsupervised_states, target_n, unsupervised_minimums, seed=seed
        )
        return result.selected_indices, None, None, {
            **result.report,
            "spatial_quotas": result.spatial_quotas,
        }
    if method == "oracle_discovery":
        rare_frequency = float(population.rare_mask.mean())
        threshold = float(config["methods"]["v2_discovery"]["rare_frequency_upper_bound"])
        minimums = (
            {"rare": min(int(population.rare_mask.sum()), int(config["methods"]["v2_discovery"]["rare_minimum"]))}
            if population.rare_mask.any() and rare_frequency <= threshold
            else {}
        )
        result = run_discovery(grid, population.true_state, target_n, minimums, seed=seed)
        return result.selected_indices, None, None, {
            **result.report,
            "spatial_quotas": result.spatial_quotas,
            "oracle_target_minimums": minimums,
        }
    raise ValueError(f"Unsupported method: {method}")


def _quota_metrics(
    selected: np.ndarray,
    grid: np.ndarray,
    probability: np.ndarray | None,
    report: Mapping[str, object],
) -> dict[str, float]:
    quotas = report.get("spatial_quotas")
    if quotas is None:
        return {
            "spatial_quota_satisfied": np.nan,
            "grid_probability_sum_max_error": np.nan,
            "inclusion_probability_min": np.nan if probability is None else float(probability.min()),
            "inclusion_probability_max": np.nan if probability is None else float(probability.max()),
        }
    counts = Counter(grid[selected].tolist())
    satisfied = all(counts.get(key, 0) == value for key, value in quotas.items())
    probability_error = np.nan
    if probability is not None:
        probability_error = max(
            abs(float(probability[grid == key].sum()) - float(value)) for key, value in quotas.items()
        )
    return {
        "spatial_quota_satisfied": float(satisfied),
        "grid_probability_sum_max_error": probability_error,
        "inclusion_probability_min": np.nan if probability is None else float(probability.min()),
        "inclusion_probability_max": np.nan if probability is None else float(probability.max()),
    }


def run_population_experiment(
    design: Mapping[str, Any],
    scenario: Mapping[str, Any],
    *,
    n_cells: int,
    population_index: int,
    sampling_repeats: int,
    full_unsupervised_discovery: bool,
    methods: Sequence[str] = (
        "uniform_random",
        "coordinate_only_quota",
        "formal_baseline",
        "leverage_score",
        "geosketch",
        "v2_inference",
        "v2_discovery",
        "oracle_discovery",
    ),
) -> tuple[pd.DataFrame, dict[str, object]]:
    """Run one immutable population job; caller owns resumable file writing."""
    population_seed = int(design["random_seeds"]["population_seed_base"]) + int(population_index) + 1000 * int(n_cells)
    population, generation_seconds, _, generation_peak = measure_call(
        lambda: generate_population(scenario, n_cells, seed=population_seed)
    )
    grid = np.asarray(rectangular_grid_bins(population.coordinates, n_x=20, n_y=20), dtype=object)
    representation, detected_states, state_table, state_report, preprocessing = _representation_and_states(
        population, design, build_states=full_unsupervised_discovery
    )
    detected_minimums, detection_metrics = _unsupervised_target_metrics(
        population, detected_states, state_table, design
    )
    reference = _full_reference(population)
    rows: list[dict[str, object]] = []
    for fraction in design["factor_levels"]["sampling_fraction"]:
        n_selected_target = target_size(n_cells, float(fraction))
        for repeat in range(int(sampling_repeats)):
            sampling_seed = (
                int(design["random_seeds"]["sampling_seed_base"])
                + 100000 * int(population_index)
                + 1000 * int(round(float(fraction) * 10000))
                + repeat
            )
            for method in methods:
                started = time.perf_counter()
                try:
                    (selected, probability, weights, report), core_seconds, core_start, core_peak = measure_call(
                        lambda method=method, seed=sampling_seed: _run_selection(
                            method,
                            population,
                            representation.embedding,
                            representation.expression_score,
                            grid,
                            n_selected_target,
                            seed,
                            design,
                            detected_states,
                            detected_minimums,
                        )
                    )
                    status = str(report.get("feasibility_status", "feasible"))
                    if status != "feasible":
                        selected = np.asarray(selected, dtype=int)
                    base = {
                        **scenario,
                        "n_cells": int(n_cells),
                        "population_index": int(population_index),
                        "population_seed": population_seed,
                        "sampling_fraction": float(fraction),
                        "sampling_repeat": int(repeat),
                        "sampling_seed": int(sampling_seed),
                        "method": method,
                        "target_n": int(n_selected_target),
                        "n_selected": int(selected.size),
                        "feasibility_status": status,
                        "constraint_relaxation": str(report.get("constraint_relaxation", "not_applicable")),
                        "generation_seconds_shared": float(generation_seconds),
                        "generation_peak_mb_shared": float(generation_peak),
                        **preprocessing,
                        **detection_metrics,
                        "core_sampling_seconds": float(core_seconds),
                        "core_peak_delta_mb": float(core_peak - core_start),
                        "end_to_end_seconds_estimate": float(
                            generation_seconds
                            + preprocessing["expression_preprocessing_seconds"]
                            + preprocessing["state_identification_seconds"]
                            + core_seconds
                        ),
                    }
                    if status == "feasible" and selected.size:
                        metrics_started = time.perf_counter()
                        selected_states = population.true_state[selected]
                        spatial_coverage = len(set(grid[selected].tolist())) / len(set(grid.tolist()))
                        state_coverage = len(set(selected_states.tolist())) / len(set(population.true_state.tolist()))
                        rare_count = int(population.rare_mask[selected].sum())
                        base.update(
                            {
                                "actual_sample_size_exact": float(selected.size == n_selected_target),
                                "spatial_coverage": float(spatial_coverage),
                                "true_state_coverage": float(state_coverage),
                                "true_state_proportion_l1_unweighted": _state_proportion_l1(
                                    population.true_state, selected
                                ),
                                "within_state_spatial_l1": _state_spatial_l1(population.true_state, grid, selected),
                                "gradient_preservation_error": _gradient_error(
                                    population.expression, selected, population.coordinates
                                ),
                                "rare_selected_count": rare_count,
                                "rare_omitted": float(population.rare_mask.any() and rare_count == 0),
                                "rare_retention_fraction": float(
                                    rare_count / population.rare_mask.sum()
                                ) if population.rare_mask.any() else np.nan,
                                **_quota_metrics(selected, grid, probability, report),
                                **_weight_metrics(weights),
                                **_estimator_metrics(population, selected, weights, reference),
                            }
                        )
                        if method in {"v2_discovery", "oracle_discovery"}:
                            base["discovery_target_minimum_total"] = int(
                                sum(report.get("oracle_target_minimums", detected_minimums).values())
                            )
                            base["discovery_rare_constraint_satisfied"] = float(
                                status == "feasible"
                            )
                        base["metric_calculation_seconds"] = float(
                            time.perf_counter() - metrics_started
                        )
                    else:
                        metrics_started = time.perf_counter()
                        base.update(
                            {
                                "actual_sample_size_exact": 0.0,
                                "spatial_coverage": np.nan,
                                "true_state_coverage": np.nan,
                                "true_state_proportion_l1_unweighted": np.nan,
                                "within_state_spatial_l1": np.nan,
                                "gradient_preservation_error": np.nan,
                                "rare_selected_count": 0,
                                "rare_omitted": np.nan,
                                "rare_retention_fraction": np.nan,
                                **_quota_metrics(np.asarray([], dtype=int), grid, probability, report),
                                **_weight_metrics(weights),
                                **_estimator_metrics(population, np.asarray([], dtype=int), None, reference),
                            }
                        )
                        base["metric_calculation_seconds"] = float(
                            time.perf_counter() - metrics_started
                        )
                    base.update(
                        {
                            "method_wall_seconds": float(time.perf_counter() - started),
                            "error_code": "",
                            "error_message": "",
                            "report_json": json_safe(report),
                        }
                    )
                except Exception as error:
                    base = {
                        **scenario,
                        "n_cells": int(n_cells),
                        "population_index": int(population_index),
                        "population_seed": population_seed,
                        "sampling_fraction": float(fraction),
                        "sampling_repeat": int(repeat),
                        "sampling_seed": int(sampling_seed),
                        "method": method,
                        "target_n": int(n_selected_target),
                        "n_selected": 0,
                        "feasibility_status": (
                            "infeasible"
                            if isinstance(error, V2FeasibilityError)
                            else "failed"
                        ),
                        "constraint_relaxation": "none",
                        "generation_seconds_shared": float(generation_seconds),
                        "generation_peak_mb_shared": float(generation_peak),
                        **preprocessing,
                        **detection_metrics,
                        "method_wall_seconds": float(time.perf_counter() - started),
                        "error_code": getattr(error, "code", type(error).__name__),
                        "error_message": str(error),
                        "report_json": json_safe(getattr(error, "to_dict", lambda: {})()),
                    }
                rows.append(base)
    diagnostics = {
        "scenario_id": scenario["scenario_id"],
        "n_cells": int(n_cells),
        "population_index": int(population_index),
        "population": population.metadata,
        "state_report": state_report,
        "unsupervised_detection": detection_metrics,
        "unsupervised_target_minimums": detected_minimums,
        "n_occupied_spatial_grids": int(len(set(grid.tolist()))),
        "design_sha256": design["design_sha256"],
    }
    return pd.DataFrame(rows), diagnostics


def json_safe(value: object) -> str:
    import json

    return json.dumps(value, ensure_ascii=False, default=str, sort_keys=True)


def calibration_experiment(
    design: Mapping[str, Any], scenario: Mapping[str, Any]
) -> pd.DataFrame:
    """Empirically check prescribed inclusion probabilities on a tracked cell subset."""
    calibration = design["calibration"]
    n_cells = int(calibration["n_cells"])
    population = generate_population(
        scenario,
        n_cells,
        seed=int(design["random_seeds"]["calibration_seed_base"]),
    )
    grid = np.asarray(rectangular_grid_bins(population.coordinates, n_x=20, n_y=20), dtype=object)
    representation = normalized_svd(population.expression, n_components=30, random_state=0)
    result = run_inference(
        grid,
        representation.expression_score,
        representation.embedding,
        target_size(n_cells, float(calibration["fraction"])),
        max_weight_inflation=float(design["methods"]["v2_inference"]["max_weight_inflation"]),
        seed=0,
    )
    tracked = np.linspace(0, n_cells - 1, int(calibration["tracked_cells"]), dtype=int)
    hits = np.zeros(tracked.size, dtype=int)
    for draw in range(int(calibration["draws"])):
        sample = run_inference(
            grid,
            representation.expression_score,
            representation.embedding,
            target_size(n_cells, float(calibration["fraction"])),
            max_weight_inflation=float(design["methods"]["v2_inference"]["max_weight_inflation"]),
            seed=int(design["random_seeds"]["calibration_seed_base"]) + draw,
        ).selected_indices
        hits += np.isin(tracked, sample)
    empirical = hits / int(calibration["draws"])
    return pd.DataFrame(
        {
            "scenario_id": scenario["scenario_id"],
            "cell_index": tracked,
            "theoretical_inclusion_probability": result.inclusion_probability[tracked],
            "empirical_inclusion_frequency": empirical,
            "absolute_error": np.abs(result.inclusion_probability[tracked] - empirical),
            "draws": int(calibration["draws"]),
        }
    )


__all__ = [
    "SimulationPopulation",
    "calibration_experiment",
    "generate_population",
    "measure_call",
    "run_population_experiment",
    "target_size",
]
