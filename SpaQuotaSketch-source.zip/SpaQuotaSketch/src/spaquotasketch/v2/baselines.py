"""Reproducible comparison methods used by the Version 2 prototype."""

from __future__ import annotations

import numpy as np


def spatially_smoothed_leverage_scores(
    left_singular_basis: np.ndarray,
    spatial_coordinates: np.ndarray,
    *,
    n_neighbors: int = 15,
) -> np.ndarray:
    """Return leverage scores after equal-weight spatial k-neighbor smoothing.

    This follows the method description in the 2026 NAR benchmark. The exact
    neighbor matrix is stated explicitly because no author reference code was
    available when this prototype was written.
    """
    from sklearn.neighbors import NearestNeighbors

    basis = np.asarray(left_singular_basis, dtype=float)
    coordinates = np.asarray(spatial_coordinates, dtype=float)
    if basis.ndim != 2 or coordinates.ndim != 2:
        raise ValueError("basis and spatial_coordinates must be two-dimensional.")
    if basis.shape[0] != coordinates.shape[0]:
        raise ValueError("basis and spatial_coordinates must have matching rows.")
    if basis.shape[0] == 0:
        return np.asarray([], dtype=float)
    k = min(max(int(n_neighbors), 1), basis.shape[0])
    neighbors = NearestNeighbors(n_neighbors=k).fit(coordinates)
    indices = neighbors.kneighbors(return_distance=False)
    smoothed_basis = basis[indices].mean(axis=1)
    scores = np.square(smoothed_basis, dtype=float).sum(axis=1)
    return np.maximum(scores, np.finfo(float).eps)


def probability_weighted_sample(
    scores: np.ndarray,
    target_n: int,
    *,
    seed: int = 0,
) -> np.ndarray:
    """Draw a fixed number without replacement using normalized soft scores."""
    values = np.asarray(scores, dtype=float).reshape(-1)
    target_n = int(target_n)
    if not 0 <= target_n <= values.size:
        raise ValueError("target_n must be between zero and the population size.")
    if not np.isfinite(values).all() or np.any(values < 0) or float(values.sum()) <= 0:
        raise ValueError("scores must be finite, nonnegative, and have positive sum.")
    if target_n == 0:
        return np.asarray([], dtype=int)
    rng = np.random.default_rng(seed)
    probabilities = values / float(values.sum())
    return np.sort(
        rng.choice(values.size, size=target_n, replace=False, p=probabilities).astype(int)
    )


__all__ = ["probability_weighted_sample", "spatially_smoothed_leverage_scores"]
