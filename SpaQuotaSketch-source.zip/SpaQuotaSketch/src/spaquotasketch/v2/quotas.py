"""Shared bounded spatial quota allocation for Version 2."""

from __future__ import annotations

from collections import Counter
from typing import Hashable, Sequence

from .errors import V2FeasibilityError


def allocate_bounded_quotas(
    spatial_grid: Sequence[Hashable],
    target_n: int,
    *,
    require_positive: bool = True,
) -> dict[Hashable, int]:
    """Allocate integer quotas close to proportional targets under hard bounds."""
    counts = Counter(spatial_grid)
    n_total = int(sum(counts.values()))
    target_n = int(target_n)
    if n_total == 0:
        raise V2FeasibilityError(
            "EMPTY_OR_INVALID_GRID",
            "No occupied spatial grid contains a cell.",
        )
    if not 1 <= target_n <= n_total:
        raise V2FeasibilityError(
            "INVALID_TARGET_SAMPLE_SIZE",
            "target_n must be between 1 and the population size.",
            target_n=target_n,
            population_size=n_total,
        )

    ordered_grids = list(counts)
    lower = 1 if require_positive else 0
    if require_positive and target_n < len(ordered_grids):
        raise V2FeasibilityError(
            "POSITIVE_PROBABILITY_REQUIRES_N_GE_GRIDS",
            "A positive quota for every occupied grid requires target_n >= number of grids.",
            target_n=target_n,
            n_occupied_grids=len(ordered_grids),
        )

    targets = {
        grid: target_n * int(counts[grid]) / n_total
        for grid in ordered_grids
    }
    quotas = {
        grid: min(int(counts[grid]), max(lower, int(targets[grid])))
        for grid in ordered_grids
    }

    while sum(quotas.values()) < target_n:
        candidates = [
            grid for grid in ordered_grids if quotas[grid] < int(counts[grid])
        ]
        if not candidates:
            raise V2FeasibilityError(
                "QUOTA_ALLOCATION_INFEASIBLE",
                "No grid has capacity for the remaining sample quota.",
                target_n=target_n,
                allocated=sum(quotas.values()),
            )
        chosen = max(
            candidates,
            key=lambda grid: (targets[grid] - quotas[grid], int(counts[grid]), str(grid)),
        )
        quotas[chosen] += 1

    while sum(quotas.values()) > target_n:
        candidates = [
            grid for grid in ordered_grids if quotas[grid] > lower
        ]
        if not candidates:
            raise V2FeasibilityError(
                "QUOTA_ALLOCATION_INFEASIBLE",
                "No grid can release quota without violating its lower bound.",
                target_n=target_n,
                allocated=sum(quotas.values()),
                lower_bound=lower,
            )
        chosen = max(
            candidates,
            key=lambda grid: (quotas[grid] - targets[grid], quotas[grid], str(grid)),
        )
        quotas[chosen] -= 1

    if sum(quotas.values()) != target_n:
        raise V2FeasibilityError(
            "QUOTA_SUM_MISMATCH",
            "Allocated quotas do not sum to target_n.",
            target_n=target_n,
            allocated=sum(quotas.values()),
        )
    for grid, quota in quotas.items():
        if quota < lower or quota > counts[grid]:
            raise V2FeasibilityError(
                "GRID_QUOTA_EXCEEDS_CAPACITY",
                "A spatial quota violates its lower or upper bound.",
                spatial_grid=str(grid),
                quota=int(quota),
                lower_bound=lower,
                grid_size=int(counts[grid]),
            )
    return quotas
