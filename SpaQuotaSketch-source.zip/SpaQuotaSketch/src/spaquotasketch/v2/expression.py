"""Label-free expression representations for the Version 2 prototype."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Sequence

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class ExpressionRepresentation:
    embedding: np.ndarray
    expression_score: np.ndarray
    singular_values: np.ndarray
    report: dict[str, object]


def _normalized_log1p(matrix, target_sum: float):
    from scipy import sparse

    if sparse.issparse(matrix):
        values = matrix.astype(np.float32, copy=True).tocsr()
        totals = np.asarray(values.sum(axis=1)).reshape(-1)
        scale = np.divide(
            float(target_sum),
            totals,
            out=np.zeros_like(totals, dtype=np.float32),
            where=totals > 0,
        )
        values = sparse.diags(scale, dtype=np.float32).dot(values).tocsr()
        values.data = np.log1p(values.data)
        return values

    values = np.asarray(matrix, dtype=np.float32)
    totals = values.sum(axis=1)
    scale = np.divide(
        float(target_sum),
        totals,
        out=np.zeros_like(totals, dtype=np.float32),
        where=totals > 0,
    )
    return np.log1p(values * scale[:, None]).astype(np.float32, copy=False)


def normalized_svd(
    matrix,
    *,
    n_components: int = 30,
    target_sum: float = 10_000.0,
    random_state: int = 0,
    score_quantiles: tuple[float, float] = (0.01, 0.99),
) -> ExpressionRepresentation:
    """Normalize counts, log-transform, and compute an SVD leverage score."""
    from scipy import sparse
    from sklearn.decomposition import PCA, TruncatedSVD

    transformed = _normalized_log1p(matrix, target_sum)
    n_components = min(int(n_components), min(transformed.shape) - 1)
    if n_components < 1:
        raise ValueError("At least two cells and two features are required.")
    if sparse.issparse(transformed):
        model = TruncatedSVD(n_components=n_components, random_state=random_state)
    else:
        model = PCA(n_components=n_components, random_state=random_state)
    embedding = np.asarray(model.fit_transform(transformed), dtype=np.float32)
    singular_values = np.asarray(model.singular_values_, dtype=float)
    basis = embedding / np.maximum(singular_values, np.finfo(float).eps)
    scores = np.square(basis, dtype=float).sum(axis=1)
    low_q, high_q = score_quantiles
    if not (0 <= low_q <= high_q <= 1):
        raise ValueError("score_quantiles must satisfy 0 <= low <= high <= 1.")
    low, high = np.quantile(scores, [low_q, high_q])
    scores = np.clip(scores, max(float(low), np.finfo(float).eps), max(float(high), np.finfo(float).eps))
    scores = np.maximum(scores, np.finfo(float).eps)
    return ExpressionRepresentation(
        embedding=embedding,
        expression_score=scores,
        singular_values=singular_values,
        report={
            "normalization": "library_size_10000_log1p",
            "decomposition": "TruncatedSVD" if sparse.issparse(transformed) else "PCA",
            "n_components": int(n_components),
            "random_state": int(random_state),
            "expression_score": "winsorized_svd_leverage",
            "score_quantiles": [float(low_q), float(high_q)],
        },
    )


def consensus_expression_states(
    embedding: np.ndarray,
    *,
    n_neighbors: int = 15,
    resolution: float = 1.0,
    state_seeds: Sequence[int] = (0, 1, 2),
    graph_seed: int = 0,
    min_state_size: int = 20,
    min_stability: float = 0.8,
) -> tuple[np.ndarray, pd.DataFrame, dict[str, object]]:
    """Build consensus graph states without using biological labels."""
    import anndata as ad
    import scanpy as sc

    values = np.asarray(embedding, dtype=np.float32)
    if values.ndim != 2 or values.shape[0] < 2:
        raise ValueError("embedding must contain at least two rows.")
    seeds = [int(seed) for seed in state_seeds]
    if not seeds:
        raise ValueError("state_seeds must contain at least one seed.")
    n_neighbors = min(max(int(n_neighbors), 2), values.shape[0] - 1)
    if min_state_size < 1:
        raise ValueError("min_state_size must be positive.")
    if not 0 <= min_stability <= 1:
        raise ValueError("min_stability must be in [0, 1].")

    state_data = ad.AnnData(X=values)
    sc.pp.neighbors(
        state_data,
        n_neighbors=n_neighbors,
        use_rep="X",
        random_state=int(graph_seed),
    )
    partitions: list[np.ndarray] = []
    cluster_sizes: list[Counter[str]] = []
    for run_index, seed in enumerate(seeds):
        key = f"v2_state_{run_index}"
        sc.tl.leiden(
            state_data,
            resolution=float(resolution),
            random_state=seed,
            key_added=key,
            flavor="igraph",
            directed=False,
            n_iterations=2,
        )
        labels = state_data.obs[key].astype(str).to_numpy()
        partitions.append(labels)
        cluster_sizes.append(Counter(labels.tolist()))

    signatures = list(zip(*(labels.tolist() for labels in partitions)))
    signature_counts = Counter(signatures)
    signature_stability = {
        signature: min(
            count / cluster_sizes[run][signature[run]]
            for run in range(len(seeds))
        )
        for signature, count in signature_counts.items()
    }
    stable_signatures = sorted(
        (
            signature
            for signature, count in signature_counts.items()
            if count >= int(min_state_size)
            and signature_stability[signature] >= float(min_stability)
        ),
        key=lambda signature: tuple(str(value) for value in signature),
    )
    name_by_signature = {
        signature: f"state_{index:04d}"
        for index, signature in enumerate(stable_signatures)
    }
    states = np.asarray(
        [name_by_signature.get(signature, "background") for signature in signatures],
        dtype=object,
    )
    state_counts = Counter(states.tolist())
    records: list[dict[str, object]] = []
    for state in sorted(state_counts):
        if state == "background":
            stability = float("nan")
        else:
            signature = stable_signatures[int(state.split("_")[1])]
            stability = float(signature_stability[signature])
        records.append(
            {
                "expression_state": state,
                "n_cells": int(state_counts[state]),
                "frequency": float(state_counts[state] / values.shape[0]),
                "stability": stability,
                "is_background": state == "background",
            }
        )
    report = {
        "method": "multi_seed_leiden_signature_consensus",
        "n_neighbors": int(n_neighbors),
        "resolution": float(resolution),
        "state_seeds": seeds,
        "graph_seed": int(graph_seed),
        "min_state_size": int(min_state_size),
        "min_stability": float(min_stability),
        "n_expression_states": int(len(state_counts)),
        "n_stable_states": int(len(stable_signatures)),
        "background_count": int(state_counts.get("background", 0)),
    }
    return states, pd.DataFrame.from_records(records), report
