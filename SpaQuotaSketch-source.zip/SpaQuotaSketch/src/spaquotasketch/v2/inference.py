"""Probability-based Version 2 inference mode."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
import heapq
from typing import Hashable, Sequence

import numpy as np

from .errors import V2FeasibilityError
from .quotas import allocate_bounded_quotas


@dataclass(frozen=True)
class InferenceResult:
    selected_indices: np.ndarray
    inclusion_probability: np.ndarray
    sampling_weight: np.ndarray
    spatial_grid: np.ndarray
    spatial_quotas: dict[Hashable, int]
    expression_score: np.ndarray
    report: dict[str, object]


def bounded_inclusion_probabilities(
    expression_score: Sequence[float],
    quota: int,
    *,
    max_weight_inflation: float = 1.0,
    tolerance: float = 1e-12,
) -> np.ndarray:
    """Project positive expression scores onto bounded inclusion probabilities."""
    scores = np.asarray(expression_score, dtype=float).reshape(-1)
    n_grid = int(scores.size)
    quota = int(quota)
    r_value = float(max_weight_inflation)
    if n_grid == 0:
        if quota == 0:
            return np.asarray([], dtype=float)
        raise V2FeasibilityError(
            "PROBABILITY_TARGET_INFEASIBLE",
            "A nonzero quota cannot be assigned to an empty grid.",
            quota=quota,
        )
    if not 1 <= quota <= n_grid:
        raise V2FeasibilityError(
            "PROBABILITY_TARGET_INFEASIBLE",
            "Inference mode requires 1 <= quota <= grid size.",
            quota=quota,
            grid_size=n_grid,
        )
    if not np.isfinite(scores).all() or np.any(scores <= 0):
        raise V2FeasibilityError(
            "INVALID_EXPRESSION_SCORE",
            "All expression scores must be finite and strictly positive.",
        )
    if not np.isfinite(r_value) or r_value < 1:
        raise ValueError("max_weight_inflation must be finite and at least 1.")
    if quota == n_grid:
        return np.ones(n_grid, dtype=float)

    lower = quota / (r_value * n_grid)
    upper = 1.0 - (n_grid - quota) / (r_value * n_grid)
    raw = quota * scores / float(scores.sum())

    if n_grid * lower > quota + tolerance or n_grid * upper < quota - tolerance:
        raise V2FeasibilityError(
            "PROBABILITY_TARGET_INFEASIBLE",
            "Probability bounds cannot sum to the requested quota.",
            quota=quota,
            grid_size=n_grid,
            lower=float(lower),
            upper=float(upper),
        )

    def projected_sum(scale: float) -> float:
        return float(np.clip(scale * raw, lower, upper).sum())

    low, high = 0.0, 1.0
    while projected_sum(high) < quota:
        high *= 2.0
        if high > 1e16:
            raise V2FeasibilityError(
                "PROBABILITY_TARGET_INFEASIBLE",
                "Failed to bracket the bounded probability projection.",
            )
    for _ in range(120):
        middle = (low + high) / 2.0
        if projected_sum(middle) < quota:
            low = middle
        else:
            high = middle
    probabilities = np.clip(((low + high) / 2.0) * raw, lower, upper)

    residual = float(quota - probabilities.sum())
    if abs(residual) > tolerance:
        free = np.flatnonzero(
            (probabilities > lower + tolerance) & (probabilities < upper - tolerance)
        )
        if free.size == 0:
            free = np.flatnonzero(
                probabilities < upper - tolerance
                if residual > 0
                else probabilities > lower + tolerance
            )
        if free.size:
            probabilities[free] += residual / free.size
            probabilities = np.clip(probabilities, lower, upper)

    if not np.isclose(probabilities.sum(), quota, atol=1e-9, rtol=0):
        raise V2FeasibilityError(
            "PROBABILITY_SUM_MISMATCH",
            "Projected inclusion probabilities do not sum to the grid quota.",
            quota=quota,
            probability_sum=float(probabilities.sum()),
        )
    if np.any(probabilities <= 0) or np.any(probabilities > 1):
        raise V2FeasibilityError(
            "NONPOSITIVE_INCLUSION_PROBABILITY",
            "Projected probabilities must be in (0, 1].",
        )
    return probabilities


def _pivotal_update(
    probabilities: np.ndarray,
    first: int,
    second: int,
    rng: np.random.Generator,
    tolerance: float,
) -> None:
    p_first = float(probabilities[first])
    p_second = float(probabilities[second])
    total = p_first + p_second
    if total < 1.0 - tolerance:
        if rng.random() < p_first / total:
            probabilities[first], probabilities[second] = total, 0.0
        else:
            probabilities[first], probabilities[second] = 0.0, total
    elif total > 1.0 + tolerance:
        denominator = 2.0 - total
        if rng.random() < (1.0 - p_second) / denominator:
            probabilities[first], probabilities[second] = 1.0, total - 1.0
        else:
            probabilities[first], probabilities[second] = total - 1.0, 1.0
    else:
        if rng.random() < p_first / total:
            probabilities[first], probabilities[second] = 1.0, 0.0
        else:
            probabilities[first], probabilities[second] = 0.0, 1.0

    probabilities[first] = float(np.clip(probabilities[first], 0.0, 1.0))
    probabilities[second] = float(np.clip(probabilities[second], 0.0, 1.0))


def _local_edges(embedding: np.ndarray, n_neighbors: int) -> list[tuple[float, int, int]]:
    from scipy.spatial import cKDTree

    values = np.asarray(embedding, dtype=float)
    n_rows = int(values.shape[0])
    if n_rows < 2:
        return []
    k = min(max(int(n_neighbors), 1) + 1, n_rows)
    distances, neighbors = cKDTree(values).query(values, k=k, workers=1)
    if k == 2:
        distances = np.asarray(distances)[:, None] if np.asarray(distances).ndim == 1 else distances
        neighbors = np.asarray(neighbors)[:, None] if np.asarray(neighbors).ndim == 1 else neighbors
    edge_map: dict[tuple[int, int], float] = {}
    for row in range(n_rows):
        for distance, neighbor in zip(
            np.asarray(distances[row]).reshape(-1)[1:],
            np.asarray(neighbors[row]).reshape(-1)[1:],
        ):
            neighbor = int(neighbor)
            if row == neighbor:
                continue
            edge = (min(row, neighbor), max(row, neighbor))
            edge_map[edge] = min(float(distance), edge_map.get(edge, float("inf")))
    return sorted(
        (distance, first, second)
        for (first, second), distance in edge_map.items()
    )


def local_pivotal_sample(
    inclusion_probability: Sequence[float],
    embedding: np.ndarray,
    *,
    seed: int = 0,
    n_neighbors: int = 8,
    tolerance: float = 1e-10,
    edge_order: Sequence[tuple[float, int, int]] | None = None,
) -> np.ndarray:
    """Draw a fixed-size local pivotal sample with prescribed marginals."""
    original = np.asarray(inclusion_probability, dtype=float).reshape(-1)
    values = np.asarray(embedding, dtype=float)
    if values.ndim != 2 or values.shape[0] != original.size:
        raise ValueError("embedding must have one row per inclusion probability.")
    if np.any(original < 0) or np.any(original > 1) or not np.isfinite(original).all():
        raise ValueError("inclusion probabilities must be finite and in [0, 1].")
    target = int(round(float(original.sum())))
    if not np.isclose(original.sum(), target, atol=1e-9, rtol=0):
        raise V2FeasibilityError(
            "PROBABILITY_SUM_MISMATCH",
            "Pivotal sampling requires an integer probability sum.",
            probability_sum=float(original.sum()),
        )

    work = original.copy()
    rng = np.random.default_rng(seed)

    def is_active(index: int) -> bool:
        return tolerance < work[index] < 1.0 - tolerance

    edges = list(edge_order) if edge_order is not None else _local_edges(values, n_neighbors)
    for _, first, second in edges:
        if is_active(first) and is_active(second):
            _pivotal_update(work, first, second, rng, tolerance)

    # The previous implementation rebuilt the complete active-index list after
    # every pivotal update.  That is quadratic in a large stratum.  A min-heap
    # retains exactly the same "two lowest active indices" update order while
    # making the completion phase O(N log N).  Preserving the order also keeps
    # fixed-seed samples reproducible against prior runs.
    active = [index for index in range(work.size) if is_active(index)]
    heapq.heapify(active)
    while len(active) >= 2:
        first = heapq.heappop(active)
        second = heapq.heappop(active)
        _pivotal_update(work, first, second, rng, tolerance)
        if is_active(first):
            heapq.heappush(active, first)
        if is_active(second):
            heapq.heappush(active, second)

    if active:
        index = heapq.heappop(active)
        if work[index] <= tolerance:
            work[index] = 0.0
        elif work[index] >= 1.0 - tolerance:
            work[index] = 1.0
        else:
            raise V2FeasibilityError(
                "PIVOTAL_NUMERICAL_RESIDUAL",
                "One unresolved fractional probability remained after pivotal updates.",
                residual=float(work[index]),
            )
    work[work <= tolerance] = 0.0
    work[work >= 1.0 - tolerance] = 1.0
    selected = np.flatnonzero(work == 1.0)
    if selected.size != target:
        raise V2FeasibilityError(
            "PIVOTAL_CARDINALITY_MISMATCH",
            "Pivotal output does not equal the prescribed fixed sample size.",
            target=target,
            selected=int(selected.size),
        )
    return selected.astype(int)


def run_inference(
    spatial_grid: Sequence[Hashable],
    expression_score: Sequence[float],
    embedding: np.ndarray,
    target_n: int,
    *,
    max_weight_inflation: float = 1.0,
    seed: int = 0,
    local_neighbors: int = 8,
) -> InferenceResult:
    """Run the independent-grid Version 2 inference design."""
    grids = np.asarray(list(spatial_grid), dtype=object)
    scores = np.asarray(expression_score, dtype=float).reshape(-1)
    values = np.asarray(embedding, dtype=float)
    if grids.size != scores.size or values.shape[0] != grids.size:
        raise ValueError("spatial_grid, expression_score, and embedding must align.")
    quotas = allocate_bounded_quotas(grids.tolist(), int(target_n), require_positive=True)

    positions_by_grid: dict[Hashable, list[int]] = defaultdict(list)
    for index, grid in enumerate(grids.tolist()):
        positions_by_grid[grid].append(index)

    inclusion = np.zeros(grids.size, dtype=float)
    selected_parts: list[np.ndarray] = []
    for grid_order, (grid, quota) in enumerate(quotas.items()):
        positions = np.asarray(positions_by_grid[grid], dtype=int)
        local_probabilities = bounded_inclusion_probabilities(
            scores[positions],
            quota,
            max_weight_inflation=max_weight_inflation,
        )
        inclusion[positions] = local_probabilities
        local_seed = int(np.random.SeedSequence([int(seed), grid_order]).generate_state(1)[0])
        local_selected = local_pivotal_sample(
            local_probabilities,
            values[positions],
            seed=local_seed,
            n_neighbors=local_neighbors,
        )
        selected_parts.append(positions[local_selected])

    selected = (
        np.sort(np.concatenate(selected_parts))
        if selected_parts
        else np.asarray([], dtype=int)
    )
    if selected.size != int(target_n):
        raise V2FeasibilityError(
            "PIVOTAL_CARDINALITY_MISMATCH",
            "Combined grid samples do not equal target_n.",
            target_n=int(target_n),
            selected=int(selected.size),
        )
    weights = 1.0 / inclusion[selected]
    expected_max = max_weight_inflation * max(
        len(positions_by_grid[grid]) / quota for grid, quota in quotas.items()
    )
    if float(weights.max(initial=0.0)) > expected_max + 1e-8:
        raise V2FeasibilityError(
            "WEIGHT_LIMIT_VIOLATION",
            "A sampling weight exceeds the configured inflation bound.",
            observed=float(weights.max()),
            expected_max=float(expected_max),
        )
    effective_n = float(weights.sum() ** 2 / np.square(weights).sum())
    weight_mean = float(weights.mean())
    weight_cv = float(weights.std(ddof=0) / weight_mean) if weight_mean > 0 else 0.0
    report = {
        "mode": "inference",
        "probability_mode": (
            "equal_probability_within_grid"
            if float(max_weight_inflation) == 1.0
            else "bounded_expression_importance"
        ),
        "feasibility_status": "feasible",
        "constraint_relaxation": "none",
        "target_n": int(target_n),
        "n_selected": int(selected.size),
        "n_spatial_grids": int(len(quotas)),
        "max_weight_inflation": float(max_weight_inflation),
        "min_inclusion_probability": float(inclusion.min()),
        "max_inclusion_probability": float(inclusion.max()),
        "min_sampling_weight": float(weights.min()),
        "max_sampling_weight": float(weights.max()),
        "sampling_weight_coefficient_of_variation": weight_cv,
        "effective_sample_size": effective_n,
        "sampling_weight_definition": "1 / inclusion_probability",
    }
    return InferenceResult(
        selected_indices=selected,
        inclusion_probability=inclusion,
        sampling_weight=weights,
        spatial_grid=grids,
        spatial_quotas=quotas,
        expression_score=scores,
        report=report,
    )
