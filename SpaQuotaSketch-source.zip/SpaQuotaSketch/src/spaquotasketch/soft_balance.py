"""Soft spatial-expression balanced sampling."""

from __future__ import annotations

from collections import Counter, defaultdict
from typing import Hashable


def minmax_scale(values):
    """Scale numeric values to [0, 1]."""
    import numpy as np

    array = np.asarray(values, dtype=float)
    if array.size == 0:
        return array
    lower = float(array.min())
    upper = float(array.max())
    if upper == lower:
        return np.zeros_like(array, dtype=float)
    return (array - lower) / (upper - lower)


def proportional_quotas(bin_ids: list[Hashable], target_n: int) -> dict[Hashable, int]:
    """Allocate integer quotas to bins in proportion to bin size."""
    if target_n < 0:
        raise ValueError("target_n must be non-negative.")

    counts = Counter(bin_ids)
    if target_n == 0 or not counts:
        return {bin_id: 0 for bin_id in counts}

    total = sum(counts.values())
    raw = {bin_id: target_n * count / total for bin_id, count in counts.items()}
    quotas = {bin_id: int(value) for bin_id, value in raw.items()}
    leftover = target_n - sum(quotas.values())
    order = sorted(raw, key=lambda key: raw[key] - quotas[key], reverse=True)
    for bin_id in order[:leftover]:
        quotas[bin_id] += 1
    return quotas


def _validate_weights(
    expression_weight: float,
    representative_weight: float,
    rarity_weight: float,
    jitter_weight: float,
) -> None:
    weights = [expression_weight, representative_weight, rarity_weight, jitter_weight]
    if any(weight < 0 for weight in weights):
        raise ValueError("score weights must be non-negative.")
    if sum(weights) <= 0:
        raise ValueError("at least one score weight must be positive.")


def _representative_scores(indices_by_spatial: dict[Hashable, list[int]], features) -> object:
    import numpy as np

    values = np.asarray(features)
    scores = np.zeros(values.shape[0], dtype=float)
    for indices in indices_by_spatial.values():
        if not indices:
            continue
        local = values[indices]
        centroid = local.mean(axis=0)
        distances = np.linalg.norm(local - centroid, axis=1)
        scores[indices] = 1.0 - minmax_scale(distances)
    return scores


def soft_balanced_sample(
    spatial_bin_ids: list[Hashable],
    expression_bin_ids: list[Hashable],
    features,
    target_n: int,
    seed: int = 0,
    expression_weight: float = 0.35,
    representative_weight: float = 0.45,
    rarity_weight: float = 0.15,
    jitter_weight: float = 0.05,
) -> tuple[list[int], dict[str, object]]:
    """Sample cells with spatial quotas and soft expression balance."""
    import numpy as np

    if len(spatial_bin_ids) != len(expression_bin_ids):
        raise ValueError("spatial_bin_ids and expression_bin_ids must have the same length.")
    if len(spatial_bin_ids) != len(features):
        raise ValueError("features must have one row per observation.")
    _validate_weights(expression_weight, representative_weight, rarity_weight, jitter_weight)

    n_obs = len(spatial_bin_ids)
    target_n = min(max(int(target_n), 0), n_obs)
    if target_n == 0:
        return [], {
            "n_selected": 0,
            "n_spatial_bins": len(set(spatial_bin_ids)),
            "n_expression_bins": len(set(expression_bin_ids)),
            "n_filled_shortfall": 0,
        }

    rng = np.random.default_rng(seed)
    spatial_counts = Counter(spatial_bin_ids)
    expression_counts = Counter(expression_bin_ids)
    spatial_quotas = proportional_quotas(spatial_bin_ids, target_n)
    expression_quotas = proportional_quotas(expression_bin_ids, target_n)

    indices_by_spatial: dict[Hashable, list[int]] = defaultdict(list)
    for index, bin_id in enumerate(spatial_bin_ids):
        indices_by_spatial[bin_id].append(index)

    representative_scores = _representative_scores(indices_by_spatial, features)
    rarity_raw = np.array([1.0 / expression_counts[bin_id] for bin_id in expression_bin_ids], dtype=float)
    rarity_scores = minmax_scale(rarity_raw)

    selected: list[int] = []
    selected_set: set[int] = set()
    selected_expression_counts: Counter[Hashable] = Counter()

    def score_candidates(candidate_indices: list[int]) -> object:
        expr_scores = np.array(
            [
                max(
                    0.0,
                    (
                        expression_quotas[expression_bin_ids[index]]
                        - selected_expression_counts[expression_bin_ids[index]]
                    )
                    / max(1, expression_quotas[expression_bin_ids[index]]),
                )
                for index in candidate_indices
            ],
            dtype=float,
        )
        jitter = rng.random(len(candidate_indices))
        return (
            expression_weight * expr_scores
            + representative_weight * representative_scores[candidate_indices]
            + rarity_weight * rarity_scores[candidate_indices]
            + jitter_weight * jitter
        )

    def take_best(candidate_indices: list[int]) -> int:
        scores = score_candidates(candidate_indices)
        best_position = int(np.argmax(scores))
        index = int(candidate_indices[best_position])
        selected.append(index)
        selected_set.add(index)
        selected_expression_counts[expression_bin_ids[index]] += 1
        return index

    for spatial_bin_id, _ in spatial_counts.most_common():
        quota = int(spatial_quotas[spatial_bin_id])
        if quota <= 0:
            continue
        for _ in range(quota):
            candidates = [
                index for index in indices_by_spatial[spatial_bin_id] if index not in selected_set
            ]
            if not candidates:
                break
            take_best(candidates)

    n_filled_shortfall = 0
    while len(selected) < target_n:
        candidates = [index for index in range(n_obs) if index not in selected_set]
        if not candidates:
            break
        take_best(candidates)
        n_filled_shortfall += 1

    selected_spatial_bins = [spatial_bin_ids[index] for index in selected]
    selected_expression_bins = [expression_bin_ids[index] for index in selected]
    report = {
        "n_selected": len(selected),
        "n_spatial_bins": len(set(spatial_bin_ids)),
        "n_expression_bins": len(set(expression_bin_ids)),
        "n_selected_spatial_bins": len(set(selected_spatial_bins)),
        "n_selected_expression_bins": len(set(selected_expression_bins)),
        "n_filled_shortfall": n_filled_shortfall,
        "expression_weight": float(expression_weight),
        "representative_weight": float(representative_weight),
        "rarity_weight": float(rarity_weight),
        "jitter_weight": float(jitter_weight),
    }
    return selected, report
