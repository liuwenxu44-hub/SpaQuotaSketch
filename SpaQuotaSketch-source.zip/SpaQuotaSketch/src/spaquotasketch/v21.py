"""V21 anchor repair: restore full-expression coverage from a V20 selection."""

from __future__ import annotations

from collections import Counter
from typing import Hashable, Sequence

from .constrained_exchange import confidence_constrained_exchange_sample


def repair_anchor_selection(
    anchor_selected_indices: Sequence[int],
    spatial_bin_ids: Sequence[Hashable],
    expression_bin_ids: Sequence[Hashable],
    expression_features,
    seed: int = 0,
    confidence_level: float = 0.95,
) -> tuple[list[int], dict[str, object]]:
    """Repair a V20 anchor under V11's full-expression confidence constraints."""
    anchor = [int(index) for index in anchor_selected_indices]
    n_obs = len(spatial_bin_ids)
    if (
        len(anchor) == 0
        or len(anchor) != len(set(anchor))
        or min(anchor) < 0
        or max(anchor) >= n_obs
        or len(expression_bin_ids) != n_obs
    ):
        raise ValueError("anchor selection and bin ids must describe the same observations.")
    selected, report = confidence_constrained_exchange_sample(
        spatial_bin_ids=list(spatial_bin_ids),
        expression_bin_ids=list(expression_bin_ids),
        features=expression_features,
        target_n=len(anchor),
        seed=seed,
        confidence_level=confidence_level,
        preserve_second_moment=True,
        initial_selected_indices=anchor,
    )
    anchor_spatial = Counter(spatial_bin_ids[index] for index in anchor)
    selected_spatial = Counter(spatial_bin_ids[index] for index in selected)
    if selected_spatial != anchor_spatial:
        raise RuntimeError("Anchor repair changed an exact spatial quota.")
    report = dict(report)
    report["anchor_replacements"] = int(len(set(anchor).symmetric_difference(selected)) // 2)
    report["anchor_overlap_fraction"] = float(len(set(anchor).intersection(selected)) / len(anchor))
    report["anchor_method"] = "v20_crossfit_consensus"
    report["objective_order"] = [
        "preserve the V20 anchor spatial quotas",
        "restore full-expression confidence bounds and coverage",
        "preserve statistically detectable local expression states",
        "reduce full-expression moment loss with the smallest feasible repair",
    ]
    return selected, report


__all__ = ["repair_anchor_selection"]
