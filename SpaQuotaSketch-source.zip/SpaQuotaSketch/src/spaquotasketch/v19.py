"""V19 graph-boundary selection inside fixed V17 strata."""

from __future__ import annotations

from collections import Counter
from typing import Hashable

import numpy as np


def _rank_positions(values: np.ndarray) -> np.ndarray:
    order = np.argsort(values, kind="stable")
    ranks = np.empty(values.size, dtype=int)
    ranks[order] = np.arange(values.size, dtype=int)
    return ranks


def graph_boundary_scores(
    expression_features,
    n_neighbors: int = 15,
    n_states: int = 32,
    seed: int = 0,
) -> dict[str, np.ndarray]:
    """Estimate unlabeled boundary and neighbor-influence scores from one gene view."""
    from sklearn.cluster import MiniBatchKMeans
    from sklearn.neighbors import NearestNeighbors

    values = np.asarray(expression_features, dtype=float)
    if values.ndim != 2 or values.shape[0] < 2 or not np.isfinite(values).all():
        raise ValueError("expression_features must be a finite two-dimensional array.")
    n_obs = values.shape[0]
    n_neighbors = min(max(1, int(n_neighbors)), n_obs - 1)
    n_states = min(max(1, int(n_states)), n_obs)
    scale = values.std(axis=0)
    scale[scale <= np.finfo(float).eps] = 1.0
    standardized = (values - values.mean(axis=0)) / scale
    state_ids = MiniBatchKMeans(
        n_clusters=n_states,
        batch_size=min(4096, n_obs),
        n_init=3,
        max_iter=100,
        random_state=seed,
    ).fit_predict(standardized)
    model = NearestNeighbors(n_neighbors=n_neighbors + 1, algorithm="auto")
    distances, neighbors = model.fit(standardized).kneighbors(standardized, return_distance=True)
    neighbor_distances = distances[:, 1:]
    neighbor_indices = neighbors[:, 1:]
    neighbor_states = state_ids[neighbor_indices]
    entropy = np.zeros(n_obs, dtype=float)
    for index, labels in enumerate(neighbor_states):
        counts = np.bincount(labels, minlength=n_states).astype(float)
        probabilities = counts[counts > 0] / labels.size
        entropy[index] = -np.sum(probabilities * np.log(probabilities)) / np.log(max(2, n_states))
    influence = np.bincount(neighbor_indices.reshape(-1), minlength=n_obs).astype(float)
    density_distance = neighbor_distances.mean(axis=1)
    return {
        "boundary_entropy": entropy,
        "neighbor_influence": influence,
        "density_distance": density_distance,
    }


def graph_boundary_selection(
    triple_indices: dict[tuple[Hashable, Hashable, Hashable], list[int]],
    triple_plan: dict[tuple[Hashable, Hashable, Hashable], int],
    expression_features,
    boundary_entropy,
    neighbor_influence,
    density_distance,
    strategy: str = "boundary",
) -> list[int]:
    """Choose boundary-aware cells while retaining every fixed V17 triple count."""
    features = np.asarray(expression_features, dtype=float)
    entropy = np.asarray(boundary_entropy, dtype=float)
    influence = np.asarray(neighbor_influence, dtype=float)
    density = np.asarray(density_distance, dtype=float)
    n_obs = features.shape[0]
    if not (
        entropy.shape == influence.shape == density.shape == (n_obs,)
        and np.isfinite(features).all()
        and np.isfinite(entropy).all()
        and np.isfinite(influence).all()
        and np.isfinite(density).all()
    ):
        raise ValueError("Graph scores must be finite one-dimensional arrays matching expression_features.")
    if strategy not in {"boundary", "boundary_diverse"}:
        raise ValueError("strategy must be boundary or boundary_diverse.")
    selected: list[int] = []
    for triple, quota in triple_plan.items():
        available = np.asarray(triple_indices[triple], dtype=int)
        target_n = int(quota)
        if target_n <= 0:
            continue
        if target_n > available.size:
            raise ValueError("A triple quota cannot exceed its available cells.")
        if target_n == available.size:
            selected.extend(available.tolist())
            continue
        priority = (
            _rank_positions(-entropy[available])
            + _rank_positions(-influence[available])
            + _rank_positions(density[available])
        )
        chosen_positions: list[int] = [int(np.argmin(priority))]
        while len(chosen_positions) < target_n:
            remaining = np.asarray(
                [index for index in range(available.size) if index not in chosen_positions],
                dtype=int,
            )
            if strategy == "boundary":
                next_position = int(remaining[np.argmin(priority[remaining])])
            else:
                chosen_features = features[available[np.asarray(chosen_positions, dtype=int)]]
                distances = np.linalg.norm(
                    features[available[remaining], None, :] - chosen_features[None, :, :],
                    axis=2,
                )
                nearest = distances.min(axis=1)
                combined = _rank_positions(priority[remaining]) + _rank_positions(-nearest)
                next_position = int(remaining[np.argmin(combined)])
            chosen_positions.append(next_position)
        selected.extend(available[np.asarray(chosen_positions, dtype=int)].tolist())
    if len(selected) != sum(triple_plan.values()) or len(set(selected)) != len(selected):
        raise RuntimeError("Graph-boundary selection did not preserve the requested sample size.")
    return sorted(selected)


def selected_graph_summary(
    selected_indices,
    boundary_entropy,
    neighbor_influence,
) -> dict[str, float]:
    """Summarize boundary and neighbor influence retained by a selected subset."""
    selected = np.asarray(selected_indices, dtype=int)
    entropy = np.asarray(boundary_entropy, dtype=float)
    influence = np.asarray(neighbor_influence, dtype=float)
    return {
        "selected_boundary_entropy_mean": float(entropy[selected].mean()),
        "selected_neighbor_influence_mean": float(influence[selected].mean()),
        "selected_neighbor_influence_coverage": float(
            influence[selected].sum() / max(np.finfo(float).eps, influence.sum())
        ),
    }


__all__ = [
    "graph_boundary_scores",
    "graph_boundary_selection",
    "selected_graph_summary",
]
