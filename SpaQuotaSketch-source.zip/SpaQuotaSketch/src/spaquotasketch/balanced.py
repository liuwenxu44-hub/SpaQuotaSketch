"""Balanced spatial-expression representative sampling."""

from __future__ import annotations

from collections import Counter, defaultdict
from typing import Hashable


def combine_bin_ids(primary_bin_ids: list[Hashable], secondary_bin_ids: list[Hashable]) -> list[str]:
    """Combine two bin assignments into one joint bin id."""
    if len(primary_bin_ids) != len(secondary_bin_ids):
        raise ValueError("primary_bin_ids and secondary_bin_ids must have the same length.")
    return [f"{primary}|{secondary}" for primary, secondary in zip(primary_bin_ids, secondary_bin_ids)]


def proportional_quotas(bin_ids: list[Hashable], target_n: int, min_quota: int = 0) -> dict[Hashable, int]:
    """Allocate quotas to bins in proportion to bin size."""
    if target_n < 0:
        raise ValueError("target_n must be non-negative.")
    if min_quota < 0:
        raise ValueError("min_quota must be non-negative.")

    counts = Counter(bin_ids)
    if not counts or target_n == 0:
        return {bin_id: 0 for bin_id in counts}

    non_empty = list(counts)
    quotas = {bin_id: 0 for bin_id in non_empty}
    if min_quota:
        guaranteed = min(target_n, len(non_empty) * min_quota)
        ordered = sorted(non_empty, key=lambda bin_id: counts[bin_id], reverse=True)
        for bin_id in ordered[:guaranteed]:
            quotas[bin_id] = 1

    assigned = sum(quotas.values())
    remaining = target_n - assigned
    if remaining <= 0:
        return quotas

    total = sum(counts.values())
    raw = {bin_id: remaining * count / total for bin_id, count in counts.items()}
    floors = {bin_id: int(value) for bin_id, value in raw.items()}
    for bin_id, value in floors.items():
        quotas[bin_id] += value
    leftover = target_n - sum(quotas.values())
    order = sorted(raw, key=lambda key: raw[key] - floors[key], reverse=True)
    for bin_id in order[:leftover]:
        quotas[bin_id] += 1
    return quotas


def representative_order(indices: list[int], features, rng) -> list[int]:
    """Order indices by distance to feature centroid, with tiny random jitter."""
    import numpy as np

    if not indices:
        return []
    values = np.asarray(features)[indices]
    centroid = values.mean(axis=0)
    distances = np.linalg.norm(values - centroid, axis=1)
    jitter = rng.random(len(indices)) * 1e-9
    order = np.argsort(distances + jitter)
    return [int(indices[position]) for position in order]


def balanced_representative_sample(
    spatial_bin_ids: list[Hashable],
    expression_bin_ids: list[Hashable],
    representative_features,
    target_n: int,
    seed: int = 0,
    min_joint_quota: int = 0,
) -> tuple[list[int], dict[str, object]]:
    """Sample representatives from joint spatial-expression bins."""
    import numpy as np

    if len(spatial_bin_ids) != len(expression_bin_ids):
        raise ValueError("spatial_bin_ids and expression_bin_ids must have the same length.")
    n_obs = len(spatial_bin_ids)
    target_n = min(max(int(target_n), 0), n_obs)
    if target_n == 0:
        return [], {"n_selected": 0, "n_joint_bins": 0, "n_filled_shortfall": 0}

    rng = np.random.default_rng(seed)
    joint_bin_ids = combine_bin_ids(spatial_bin_ids, expression_bin_ids)
    joint_quotas = proportional_quotas(joint_bin_ids, target_n, min_quota=min_joint_quota)

    indices_by_joint: dict[str, list[int]] = defaultdict(list)
    for index, bin_id in enumerate(joint_bin_ids):
        indices_by_joint[bin_id].append(index)

    selected: list[int] = []
    selected_set: set[int] = set()
    insufficient_bins: list[dict[str, object]] = []
    for bin_id, quota in joint_quotas.items():
        available = indices_by_joint.get(bin_id, [])
        ordered = representative_order(available, representative_features, rng)
        n_take = min(int(quota), len(ordered))
        if n_take < int(quota):
            insufficient_bins.append(
                {"bin_id": bin_id, "quota": int(quota), "available_cells": len(ordered)}
            )
        for index in ordered[:n_take]:
            selected.append(index)
            selected_set.add(index)

    n_filled_shortfall = 0
    if len(selected) < target_n:
        remaining = [index for index in range(n_obs) if index not in selected_set]
        ordered_remaining = representative_order(remaining, representative_features, rng)
        n_fill = min(target_n - len(selected), len(ordered_remaining))
        selected.extend(ordered_remaining[:n_fill])
        n_filled_shortfall = n_fill

    selected = selected[:target_n]
    selected_spatial_bins = [spatial_bin_ids[index] for index in selected]
    selected_expression_bins = [expression_bin_ids[index] for index in selected]
    selected_joint_bins = [joint_bin_ids[index] for index in selected]
    report = {
        "n_selected": len(selected),
        "n_spatial_bins": len(set(spatial_bin_ids)),
        "n_expression_bins": len(set(expression_bin_ids)),
        "n_joint_bins": len(set(joint_bin_ids)),
        "n_selected_spatial_bins": len(set(selected_spatial_bins)),
        "n_selected_expression_bins": len(set(selected_expression_bins)),
        "n_selected_joint_bins": len(set(selected_joint_bins)),
        "n_insufficient_joint_bins": len(insufficient_bins),
        "insufficient_joint_bins": insufficient_bins,
        "n_filled_shortfall": n_filled_shortfall,
        "min_joint_quota": int(min_joint_quota),
    }
    return selected, report
