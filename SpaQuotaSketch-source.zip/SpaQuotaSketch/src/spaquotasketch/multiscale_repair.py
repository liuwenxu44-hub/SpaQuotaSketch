"""Coverage repair that preserves coarse spatial and expression-state quotas."""

from __future__ import annotations

from collections import Counter, defaultdict
from heapq import heappop, heappush
from typing import Hashable, Sequence


def repair_fine_grid_coverage(
    anchor_selected_indices: Sequence[int],
    coarse_spatial_bin_ids: Sequence[Hashable],
    fine_spatial_bin_ids: Sequence[Hashable],
    expression_bin_ids: Sequence[Hashable],
    expression_features,
    max_repairs: int | None = None,
    strategy: str = "sequential",
    nearest_candidates: int = 8,
    knn_indices=None,
    require_graph_connected: bool = False,
    require_nonnegative_graph_coverage: bool = False,
) -> tuple[list[int], dict[str, object]]:
    """Cover additional fine spatial bins without changing coarse or expression counts.

    A replacement is allowed only inside the same coarse spatial bin and the same
    expression bin. This makes the repair a constrained tie-breaker rather than a
    new weighted objective: coarse spatial quotas and expression-bin counts remain
    exactly unchanged. The ``global_min_cost`` strategy ranks feasible exchanges by
    expression displacement before applying them. Optional graph guards require
    a new point to remain connected to the current sample and prevent a repair
    from lowering local neighbor coverage.
    """
    import numpy as np

    n_obs = len(coarse_spatial_bin_ids)
    if (
        len(fine_spatial_bin_ids) != n_obs
        or len(expression_bin_ids) != n_obs
        or np.asarray(expression_features).shape[0] != n_obs
    ):
        raise ValueError("All inputs must contain one row per observation.")
    anchor = sorted({int(index) for index in anchor_selected_indices})
    if not anchor or len(anchor) != len(anchor_selected_indices) or anchor[0] < 0 or anchor[-1] >= n_obs:
        raise ValueError("anchor_selected_indices must be unique valid observation indices.")
    if max_repairs is not None and int(max_repairs) < 0:
        raise ValueError("max_repairs must be non-negative when provided.")
    if strategy not in {"sequential", "global_min_cost"}:
        raise ValueError("strategy must be 'sequential' or 'global_min_cost'.")
    if nearest_candidates < 1:
        raise ValueError("nearest_candidates must be positive.")
    if (require_graph_connected or require_nonnegative_graph_coverage) and knn_indices is None:
        raise ValueError("knn_indices is required when a graph guard is enabled.")

    features = np.asarray(expression_features, dtype=float)
    if features.ndim != 2 or not np.isfinite(features).all():
        raise ValueError("expression_features must be a finite two-dimensional array.")

    selected = set(anchor)
    graph_state = (
        _build_graph_state(n_obs, knn_indices, selected)
        if knn_indices is not None
        else None
    )
    initial_coarse_counts = Counter(coarse_spatial_bin_ids[index] for index in anchor)
    initial_expression_counts = Counter(expression_bin_ids[index] for index in anchor)
    initial_fine_coverage = len({fine_spatial_bin_ids[index] for index in anchor})

    indices_by_coarse: dict[Hashable, list[int]] = defaultdict(list)
    for index, coarse_bin in enumerate(coarse_spatial_bin_ids):
        indices_by_coarse[coarse_bin].append(index)

    if strategy == "sequential":
        repairs, candidate_pair_count = _sequential_repairs(
            selected,
            indices_by_coarse,
            coarse_spatial_bin_ids,
            fine_spatial_bin_ids,
            expression_bin_ids,
            features,
            max_repairs,
        )
    else:
        repairs, candidate_pair_count = _global_min_cost_repairs(
            selected,
            indices_by_coarse,
            coarse_spatial_bin_ids,
            fine_spatial_bin_ids,
            expression_bin_ids,
            features,
            max_repairs,
            nearest_candidates,
            graph_state,
            require_graph_connected,
            require_nonnegative_graph_coverage,
        )

    repaired = sorted(selected)
    if Counter(coarse_spatial_bin_ids[index] for index in repaired) != initial_coarse_counts:
        raise RuntimeError("Fine-grid repair changed a coarse spatial quota.")
    if Counter(expression_bin_ids[index] for index in repaired) != initial_expression_counts:
        raise RuntimeError("Fine-grid repair changed an expression-bin count.")
    final_fine_coverage = len({fine_spatial_bin_ids[index] for index in repaired})
    graph_report = _graph_report(graph_state)
    return repaired, {
        "n_anchor_selected": len(anchor),
        "n_repairs": len(repairs),
        "initial_fine_spatial_bins_covered": int(initial_fine_coverage),
        "final_fine_spatial_bins_covered": int(final_fine_coverage),
        "fine_spatial_coverage_gain": int(final_fine_coverage - initial_fine_coverage),
        "preserved_coarse_spatial_quotas": True,
        "preserved_expression_bin_counts": True,
        "repair_strategy": strategy,
        "n_ranked_candidate_pairs": int(candidate_pair_count),
        "repair_rule": "same coarse spatial bin and same expression bin; minimum expression displacement replacement",
        "graph_guard": graph_report,
        "repairs": repairs,
    }


def _sequential_repairs(
    selected,
    indices_by_coarse,
    coarse_spatial_bin_ids,
    fine_spatial_bin_ids,
    expression_bin_ids,
    features,
    max_repairs,
):
    """Preserve V23 behavior for reproducibility."""
    import numpy as np

    repairs: list[dict[str, object]] = []
    candidate_pair_count = 0
    for coarse_bin, all_indices in indices_by_coarse.items():
        if max_repairs is not None and len(repairs) >= int(max_repairs):
            break
        selected_here = [index for index in all_indices if index in selected]
        fine_counts = Counter(fine_spatial_bin_ids[index] for index in selected_here)
        candidates_by_expression: dict[Hashable, list[int]] = defaultdict(list)
        for candidate in all_indices:
            if candidate in selected or fine_counts[fine_spatial_bin_ids[candidate]] > 0:
                continue
            candidates_by_expression[expression_bin_ids[candidate]].append(candidate)

        removable = [index for index in selected_here if fine_counts[fine_spatial_bin_ids[index]] > 1]
        for removed in removable:
            if max_repairs is not None and len(repairs) >= int(max_repairs):
                break
            expression_bin = expression_bin_ids[removed]
            candidates = candidates_by_expression.get(expression_bin, [])
            candidate_pair_count += len(candidates)
            if not candidates:
                continue
            candidate_array = np.asarray(candidates, dtype=int)
            distances = np.sum((features[candidate_array] - features[removed]) ** 2, axis=1)
            added = int(candidate_array[int(np.argmin(distances))])
            if not _apply_repair(
                selected,
                fine_counts,
                fine_spatial_bin_ids,
                removed,
                added,
            ):
                continue
            candidates_by_expression[expression_bin].remove(added)
            repairs.append(
                _repair_record(removed, added, coarse_bin, expression_bin, float(distances.min()))
            )
    return repairs, candidate_pair_count


def _global_min_cost_repairs(
    selected,
    indices_by_coarse,
    coarse_spatial_bin_ids,
    fine_spatial_bin_ids,
    expression_bin_ids,
    features,
    max_repairs,
    nearest_candidates,
    graph_state,
    require_graph_connected,
    require_nonnegative_graph_coverage,
):
    """Apply the lowest-displacement valid exchanges first across all strata."""
    import numpy as np
    from sklearn.neighbors import NearestNeighbors

    heap: list[tuple[float, int, int, Hashable, Hashable]] = []
    candidate_pair_count = 0
    fine_counts = Counter(fine_spatial_bin_ids[index] for index in selected)
    for coarse_bin, all_indices in indices_by_coarse.items():
        selected_here = [index for index in all_indices if index in selected]
        grouped_selected: dict[Hashable, list[int]] = defaultdict(list)
        grouped_candidates: dict[Hashable, list[int]] = defaultdict(list)
        for index in selected_here:
            if fine_counts[fine_spatial_bin_ids[index]] > 1:
                grouped_selected[expression_bin_ids[index]].append(index)
        for index in all_indices:
            if index not in selected and fine_counts[fine_spatial_bin_ids[index]] == 0:
                grouped_candidates[expression_bin_ids[index]].append(index)

        for expression_bin, candidates in grouped_candidates.items():
            removals = grouped_selected.get(expression_bin, [])
            if not removals:
                continue
            removal_array = np.asarray(removals, dtype=int)
            candidate_array = np.asarray(candidates, dtype=int)
            neighbor_count = min(int(nearest_candidates), removal_array.size)
            model = NearestNeighbors(n_neighbors=neighbor_count, metric="euclidean")
            model.fit(features[removal_array])
            distances, positions = model.kneighbors(features[candidate_array])
            for candidate_position, candidate in enumerate(candidate_array.tolist()):
                for distance, removal_position in zip(
                    distances[candidate_position].tolist(), positions[candidate_position].tolist()
                ):
                    squared_distance = float(distance * distance)
                    removed = int(removal_array[int(removal_position)])
                    heappush(heap, (squared_distance, removed, int(candidate), coarse_bin, expression_bin))
                    candidate_pair_count += 1

    repairs: list[dict[str, object]] = []
    while heap and (max_repairs is None or len(repairs) < int(max_repairs)):
        distance, removed, added, coarse_bin, expression_bin = heappop(heap)
        graph_gain = None
        if graph_state is not None:
            if require_graph_connected and not _is_connected_after_exchange(
                graph_state, removed, added
            ):
                graph_state["n_rejected_disconnected"] += 1
                continue
            graph_gain = _graph_coverage_gain(graph_state, removed, added)
            if require_nonnegative_graph_coverage and graph_gain < 0:
                graph_state["n_rejected_coverage_loss"] += 1
                continue
        if not _apply_repair(selected, fine_counts, fine_spatial_bin_ids, removed, added):
            continue
        if graph_state is not None:
            _apply_graph_exchange(graph_state, removed, added)
        repairs.append(
            _repair_record(
                removed,
                added,
                coarse_bin,
                expression_bin,
                distance,
                graph_coverage_gain=graph_gain,
            )
        )
    return repairs, candidate_pair_count


def _apply_repair(selected, fine_counts, fine_spatial_bin_ids, removed: int, added: int) -> bool:
    if removed not in selected or added in selected:
        return False
    removed_fine = fine_spatial_bin_ids[removed]
    added_fine = fine_spatial_bin_ids[added]
    if fine_counts[removed_fine] <= 1 or fine_counts[added_fine] != 0:
        return False
    selected.remove(removed)
    selected.add(added)
    fine_counts[removed_fine] -= 1
    fine_counts[added_fine] += 1
    return True


def _repair_record(
    removed: int,
    added: int,
    coarse_bin,
    expression_bin,
    squared_distance: float,
    graph_coverage_gain: int | None = None,
) -> dict[str, object]:
    record = {
        "removed_index": int(removed),
        "added_index": int(added),
        "coarse_spatial_bin": str(coarse_bin),
        "expression_bin": str(expression_bin),
        "squared_expression_distance": float(squared_distance),
    }
    if graph_coverage_gain is not None:
        record["graph_coverage_gain"] = int(graph_coverage_gain)
    return record


def _build_graph_state(n_obs: int, knn_indices, selected) -> dict[str, object]:
    import numpy as np

    neighbors = np.asarray(knn_indices, dtype=int)
    if neighbors.ndim != 2 or neighbors.shape[0] != n_obs or neighbors.shape[1] < 1:
        raise ValueError("knn_indices must be a non-empty two-dimensional array with one row per observation.")
    if neighbors.min(initial=0) < 0 or neighbors.max(initial=-1) >= n_obs:
        raise ValueError("knn_indices contains an invalid observation index.")
    reverse_neighbors: list[list[int]] = [[] for _ in range(n_obs)]
    for source, targets in enumerate(neighbors):
        for target in targets.tolist():
            reverse_neighbors[int(target)].append(source)
    supports = np.zeros(n_obs, dtype=int)
    for index in selected:
        supports[index] += 1
        for neighbor in reverse_neighbors[index]:
            supports[neighbor] += 1
    return {
        "neighbors": neighbors,
        "reverse_neighbors": reverse_neighbors,
        "supports": supports,
        "selected": set(selected),
        "initial_coverage": float(np.mean(supports > 0)),
        "n_rejected_disconnected": 0,
        "n_rejected_coverage_loss": 0,
    }


def _affected_graph_nodes(graph_state: dict[str, object], index: int) -> list[int]:
    return [int(index), *graph_state["reverse_neighbors"][index]]


def _graph_coverage_gain(graph_state: dict[str, object], removed: int, added: int) -> int:
    supports = graph_state["supports"]
    changes: dict[int, int] = defaultdict(int)
    for index in _affected_graph_nodes(graph_state, removed):
        changes[index] -= 1
    for index in _affected_graph_nodes(graph_state, added):
        changes[index] += 1
    return int(
        sum(
            int(supports[index] + change > 0) - int(supports[index] > 0)
            for index, change in changes.items()
        )
    )


def _is_connected_after_exchange(graph_state: dict[str, object], removed: int, added: int) -> bool:
    neighbors = graph_state["neighbors"]
    selected = graph_state["selected"]
    return any(int(neighbor) in selected and int(neighbor) != removed for neighbor in neighbors[added])


def _apply_graph_exchange(graph_state: dict[str, object], removed: int, added: int) -> None:
    supports = graph_state["supports"]
    graph_state["selected"].remove(removed)
    graph_state["selected"].add(added)
    for index in _affected_graph_nodes(graph_state, removed):
        supports[index] -= 1
    for index in _affected_graph_nodes(graph_state, added):
        supports[index] += 1


def _graph_report(graph_state: dict[str, object] | None) -> dict[str, object]:
    if graph_state is None:
        return {"enabled": False}
    supports = graph_state["supports"]
    return {
        "enabled": True,
        "n_neighbors": int(graph_state["neighbors"].shape[1]),
        "initial_local_coverage": float(graph_state["initial_coverage"]),
        "final_local_coverage": float((supports > 0).mean()),
        "n_rejected_disconnected": int(graph_state["n_rejected_disconnected"]),
        "n_rejected_coverage_loss": int(graph_state["n_rejected_coverage_loss"]),
    }


__all__ = ["repair_fine_grid_coverage"]
