"""Download integrity and input-level qualification helpers.

The functions in this module have a deliberately narrow boundary: they inspect
published input structure, identifiers, coordinates, and frozen sample-size
feasibility.  They do not transform expression values, run a sampler, calculate
method performance, or invoke downstream analysis.
"""

from __future__ import annotations

import csv
import gzip
import hashlib
import json
import math
import os
import shutil
import stat
from pathlib import Path
from typing import Any, Iterable

import h5py
import numpy as np


FROZEN_FRACTIONS = (0.005, 0.01, 0.02, 0.05, 0.10)
MINIMUM_TARGET_N = 100
MINIMUM_POSITIVE_STRATA = 4
TERMINAL_STATUSES = {
    "FULLY_QUALIFIED",
    "FULLY_QUALIFIED_LIMITED_ENDPOINTS",
    "REMAINS_CONDITIONALLY_QUALIFIED",
    "STRESS_TEST_ONLY",
    "EXCLUDED",
    "HOLD",
}


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    """Return the SHA256 of one file without loading it into memory."""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(chunk_size), b""):
            digest.update(block)
    return digest.hexdigest()


def create_non_overwriting_directory(root: Path, requested_name: str) -> Path:
    """Create a new directory, versioning its name rather than overwriting."""
    root.mkdir(parents=True, exist_ok=True)
    for number in range(1, 10_000):
        suffix = "" if number == 1 else f"_v{number}"
        candidate = root / f"{requested_name}{suffix}"
        # Some SSHFS mounts report an existing directory as permission denied
        # instead of FileExistsError. Avoid the mkdir call when it is visible.
        if candidate.exists():
            continue
        try:
            candidate.mkdir()
        except FileExistsError:
            continue
        return candidate
    raise RuntimeError(f"Could not allocate a new output directory under {root}.")


def _ensure_absent(path: Path) -> None:
    if path.exists():
        raise FileExistsError(f"Refusing to overwrite existing path: {path}")


def _write_json(path: Path, payload: Any) -> None:
    _ensure_absent(path)
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")


def append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    """Append a compact event record; event logs are intentionally append-only."""
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(payload, sort_keys=True))
        handle.write("\n")


def copy_with_sha256_verification(source: Path, destination: Path) -> dict[str, Any]:
    """Copy one staged file to a new destination and verify both byte streams.

    This intentionally avoids an atomic cross-filesystem replacement operation.
    The destination becomes a successful raw input only after its own checksum
    equals the local staging checksum.
    """
    _ensure_absent(destination)
    source_digest = sha256_file(source)
    shutil.copyfile(source, destination)
    destination_digest = sha256_file(destination)
    return {
        "source": str(source),
        "destination": str(destination),
        "source_sha256": source_digest,
        "destination_sha256": destination_digest,
        "match": source_digest == destination_digest,
        "bytes": destination.stat().st_size,
    }


def make_read_only(path: Path) -> bool:
    """Attempt to mark a raw input read-only and report whether it took effect."""
    path.chmod(stat.S_IREAD | stat.S_IRGRP | stat.S_IROTH)
    return not bool(path.stat().st_mode & stat.S_IWRITE)


def _open_text(path: Path):
    return gzip.open(path, "rt", encoding="utf-8", newline="") if path.suffix == ".gz" else path.open(
        "r", encoding="utf-8", newline=""
    )


def matrix_market_header(path: Path) -> dict[str, Any]:
    """Read Matrix Market dimensions and stored nonzero count without reading X."""
    with _open_text(path) as handle:
        banner = handle.readline().strip()
        if not banner.startswith("%%MatrixMarket matrix coordinate"):
            raise ValueError(f"Unsupported Matrix Market header in {path.name}")
        line = handle.readline()
        while line.startswith("%"):
            line = handle.readline()
        dimensions = line.strip().split()
        if len(dimensions) != 3:
            raise ValueError(f"Invalid Matrix Market dimensions in {path.name}")
    rows, columns, nnz = (int(value) for value in dimensions)
    return {"shape_rows": rows, "shape_columns": columns, "nnz": nnz, "storage": "matrix_market"}


def _decode(value: Any) -> str:
    if isinstance(value, bytes):
        return value.decode("utf-8")
    return str(value)


def _dataset_strings(dataset: h5py.Dataset) -> list[str]:
    values = dataset[()]
    if np.ndim(values) == 0:
        return [_decode(values)]
    return [_decode(value) for value in np.ravel(values)]


def _h5ad_column_values(obs: h5py.Group, name: str) -> list[str] | None:
    if name not in obs:
        return None
    item = obs[name]
    if isinstance(item, h5py.Dataset):
        return _dataset_strings(item)
    if isinstance(item, h5py.Group) and "codes" in item and "categories" in item:
        codes = np.asarray(item["codes"])
        categories = _dataset_strings(item["categories"])
        return [categories[int(code)] if int(code) >= 0 else "<missing>" for code in codes]
    return None


def _h5ad_matrix_summary(handle: h5py.File) -> dict[str, Any]:
    if "X" not in handle:
        raise ValueError("H5AD has no X matrix.")
    matrix = handle["X"]
    if isinstance(matrix, h5py.Dataset):
        shape = tuple(int(value) for value in matrix.shape)
        return {"shape_rows": shape[0], "shape_columns": shape[1], "nnz": None, "storage": "dense"}
    shape_value = matrix.attrs.get("shape")
    if shape_value is None:
        raise ValueError("Sparse H5AD X has no shape attribute.")
    shape = tuple(int(value) for value in shape_value)
    nnz = int(matrix["data"].shape[0]) if "data" in matrix else None
    return {"shape_rows": shape[0], "shape_columns": shape[1], "nnz": nnz, "storage": "sparse"}


def inspect_h5ad(path: Path) -> dict[str, Any]:
    """Inspect H5AD layout and metadata without loading its expression matrix."""
    with h5py.File(path, "r") as handle:
        matrix = _h5ad_matrix_summary(handle)
        if "obs" not in handle or not isinstance(handle["obs"], h5py.Group):
            raise ValueError("H5AD has no readable obs table.")
        obs = handle["obs"]
        index_name = obs.attrs.get("_index", "_index")
        if isinstance(index_name, bytes):
            index_name = index_name.decode("utf-8")
        unit_ids = _h5ad_column_values(obs, str(index_name))
        if unit_ids is None:
            unit_ids = _h5ad_column_values(obs, "_index")
        if unit_ids is None:
            raise ValueError("H5AD obs index is not readable.")

        metadata_fields = sorted(obs.keys())
        coordinate_values: np.ndarray | None = None
        coordinate_source = None
        if "obsm" in handle:
            obsm = handle["obsm"]
            preferred_coordinate_keys = (
                "spatial",
                "aligned_spatial_3D",
                "3d_align_spatial",
                "aligned_spatial_3D_mm",
                "aligned_spatial_3D_new",
            )
            for coordinate_key in preferred_coordinate_keys:
                if coordinate_key in obsm and isinstance(obsm[coordinate_key], h5py.Dataset):
                    coordinate_values = np.asarray(obsm[coordinate_key][()])
                    coordinate_source = f"obsm/{coordinate_key}"
                    break

        sample_fields = [name for name in ("sample_id", "sample", "batch", "donor_id", "stage") if name in obs]
        slice_fields = [name for name in ("slice_id", "slices", "slice", "section", "batch") if name in obs]
        label_fields = [
            name
            for name in metadata_fields
            if name.lower().replace("_", "")
            in {"celltype", "celltypes", "annotation", "celltypefinal", "heartanno", "heartregions", "cellbinspatialdomain"}
        ]
        cell_values = _h5ad_column_values(obs, "cell")
        batch_values = _h5ad_column_values(obs, "batch")
        unit_ids_unique = len(unit_ids) == len(set(unit_ids))
        unit_id_strategy = "obs_index" if unit_ids_unique else "unresolved"
        if (
            not unit_ids_unique
            and cell_values is not None
            and batch_values is not None
            and len(cell_values) != len(set(cell_values))
        ):
            composite = [f"{batch}:{cell}" for batch, cell in zip(batch_values, cell_values, strict=True)]
            if len(composite) == len(set(composite)):
                unit_ids_unique = True
                unit_id_strategy = "batch_plus_cell"

        sample_values = _h5ad_column_values(obs, sample_fields[0]) if sample_fields else None
        slice_values = _h5ad_column_values(obs, slice_fields[0]) if slice_fields else None
        slice_unit_counts = (
            {value: slice_values.count(value) for value in sorted(set(slice_values))}
            if slice_values
            else {"whole_input": len(unit_ids)}
        )
        coords_ok = (
            coordinate_values is not None
            and coordinate_values.ndim == 2
            and coordinate_values.shape[1] >= 2
            and coordinate_values.shape[0] == matrix["shape_rows"]
            and bool(np.isfinite(coordinate_values[:, :2]).all())
        )
        return {
            **matrix,
            "format": "h5ad",
            "file": str(path),
            "unit_count": len(unit_ids),
            "sample_id": path.stem,
            "unit_ids_unique": unit_ids_unique,
            "unit_id_strategy": unit_id_strategy,
            "coordinates_readable": coords_ok,
            "coordinates_source": coordinate_source,
            "coordinates_dimensions": int(coordinate_values.shape[1]) if coordinate_values is not None else 0,
            "coordinate_values": coordinate_values[:, :2] if coords_ok else None,
            "ids_coordinates_aligned": bool(coords_ok and len(unit_ids) == matrix["shape_rows"]),
            "sample_field": sample_fields[0] if sample_fields else None,
            "sample_count": len(set(sample_values)) if sample_values else 0,
            "slice_field": slice_fields[0] if slice_fields else None,
            "slice_count": len(set(slice_values)) if slice_values else 0,
            "slice_unit_counts": slice_unit_counts,
            "label_fields": ";".join(label_fields),
            "metadata_fields": ";".join(metadata_fields),
            "raw_counts_available": bool("raw" in handle or "counts" in handle.get("layers", {})),
            "normalized_expression_available": "UNKNOWN",
        }


def _line_ids(path: Path) -> list[str]:
    with _open_text(path) as handle:
        return [line.rstrip("\r\n").split("\t", 1)[0] for line in handle if line.strip()]


def _coordinate_csv_summary(path: Path) -> dict[str, Any]:
    """Read coordinate identifiers and finite coordinate values from one CSV."""
    with path.open("r", encoding="utf-8", newline="") as handle:
        sample = handle.read(4096)
        handle.seek(0)
        first_line = sample.splitlines()[0] if sample.splitlines() else ""
        header_tokens = [token.strip().lower() for token in first_line.split(",")]
        has_header = any("barcode" in token or "spot" in token or token in {"x", "y", "id"} for token in header_tokens)
        rows = list(csv.reader(handle))
    if has_header and rows:
        headers, rows = rows[0], rows[1:]
        lowered = [header.lower() for header in headers]
        id_index = next((index for index, name in enumerate(lowered) if "barcode" in name or "spot" in name or name == "id"), 0)
        coordinate_indices = [
            index
            for index, name in enumerate(lowered)
            if name in {"x", "y", "pxl_col_in_fullres", "pxl_row_in_fullres", "array_col", "array_row"}
        ]
    else:
        id_index = 0
        coordinate_indices = [4, 5] if rows and len(rows[0]) >= 6 else [1, 2]
    ids: list[str] = []
    finite = True
    coordinates: list[tuple[float, float]] = []
    for row in rows:
        if len(row) <= max([id_index, *coordinate_indices], default=0):
            continue
        ids.append(row[id_index])
        try:
            pair = (float(row[coordinate_indices[-2]]), float(row[coordinate_indices[-1]]))
            finite = finite and all(math.isfinite(value) for value in pair)
            coordinates.append(pair)
        except (TypeError, ValueError, IndexError):
            finite = False
    return {
        "ids": ids,
        "ids_unique": len(ids) == len(set(ids)),
        "coordinates_readable": bool(ids and coordinates and finite),
        "coordinates": np.asarray(coordinates, dtype=float) if coordinates else None,
    }


def _find_neighbor_file(directory: Path, prefixes: Iterable[str]) -> Path | None:
    candidates = [path for path in directory.iterdir() if path.is_file()]
    for prefix in prefixes:
        for candidate in candidates:
            if candidate.name.lower().startswith(prefix):
                return candidate
    return None


def inspect_mtx_bundle(matrix_path: Path) -> dict[str, Any]:
    """Inspect one MTX-plus-coordinate input without loading its sparse matrix."""
    summary = matrix_market_header(matrix_path)
    directory = matrix_path.parent
    name_lower = matrix_path.name.lower()
    prefix = name_lower.split("matrix.mtx", 1)[0]
    barcodes = next(
        (
            path
            for path in directory.iterdir()
            if path.is_file()
            and path.name.lower().startswith(prefix)
            and ("barcodes.tsv" in path.name.lower() or "barcodes.txt" in path.name.lower())
        ),
        _find_neighbor_file(directory, ("barcodes.tsv", "barcodes.txt")),
    )
    coordinates_file = next(
        (
            path
            for path in directory.rglob("*.csv")
            if "tissue_position" in path.name.lower() or "spatial" in path.name.lower()
        ),
        None,
    )
    barcode_ids = _line_ids(barcodes) if barcodes else []
    coordinate = _coordinate_csv_summary(coordinates_file) if coordinates_file else None
    coordinates_readable = bool(coordinate and coordinate["coordinates_readable"])
    ids_aligned = bool(
        barcodes
        and len(barcode_ids) == summary["shape_columns"]
        and len(barcode_ids) == len(set(barcode_ids))
        and coordinate
        and set(barcode_ids).issubset(set(coordinate["ids"]))
    )
    return {
        **summary,
        "format": "mtx_bundle",
        "file": str(matrix_path),
        "unit_count": summary["shape_columns"],
        "sample_id": matrix_path.name.split("_matrix", 1)[0],
        "unit_ids_unique": bool(barcodes and len(barcode_ids) == len(set(barcode_ids))),
        "unit_id_strategy": "barcode" if barcodes else "unresolved",
        "coordinates_readable": coordinates_readable,
        "coordinates_source": str(coordinates_file) if coordinates_file else None,
        "coordinates_dimensions": 2 if coordinates_readable else 0,
        "coordinate_values": coordinate["coordinates"] if coordinate and coordinates_readable else None,
        "ids_coordinates_aligned": ids_aligned,
        "sample_field": "archive_path",
        "sample_count": 1,
        "slice_field": "archive_path",
        "slice_count": 1,
        "slice_unit_counts": {matrix_path.name.split("_matrix", 1)[0]: summary["shape_columns"]},
        "label_fields": "",
        "metadata_fields": "",
        "raw_counts_available": "UNKNOWN",
        "normalized_expression_available": "UNKNOWN",
    }


def positive_quadrants(coordinates: np.ndarray | None) -> int:
    """Return occupied cells of a fixed 2 by 2 audit partition, not a sampler."""
    if coordinates is None or coordinates.ndim != 2 or coordinates.shape[0] == 0:
        return 0
    minimum = coordinates.min(axis=0)
    maximum = coordinates.max(axis=0)
    span = maximum - minimum
    if np.any(span <= 0):
        return 1
    bins = np.minimum(((coordinates - minimum) / span * 2).astype(int), 1)
    return len({(int(row[0]), int(row[1])) for row in bins})


def sampling_feasibility(unit_count: int, positive_spatial_strata: int) -> list[dict[str, Any]]:
    """Apply frozen target-n rules without constructing or running any sample."""
    records: list[dict[str, Any]] = []
    for fraction in FROZEN_FRACTIONS:
        target_n = math.floor(unit_count * fraction + 0.5)
        feasible = target_n >= MINIMUM_TARGET_N and target_n <= unit_count and positive_spatial_strata >= MINIMUM_POSITIVE_STRATA
        records.append(
            {
                "fraction": fraction,
                "target_n": target_n,
                "minimum_target_n_met": target_n >= MINIMUM_TARGET_N,
                "positive_spatial_strata": positive_spatial_strata,
                "minimum_spatial_strata_met": positive_spatial_strata >= MINIMUM_POSITIVE_STRATA,
                "input_structurally_feasible": feasible,
            }
        )
    return records


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    _ensure_absent(path)
    fields = sorted({key for row in rows for key in row}) if rows else ["empty"]
    with path.open("x", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _inventory(root: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for path in sorted(root.rglob("*")):
        if path.is_file():
            records.append(
                {
                    "relative_path": path.relative_to(root).as_posix(),
                    "bytes": path.stat().st_size,
                    "sha256": sha256_file(path),
                    "read_only": not bool(path.stat().st_mode & stat.S_IWRITE),
                }
            )
    return records


def record_download_failure(
    target_dir: Path,
    candidate: dict[str, Any],
    error_message: str,
    source_checksums: list[dict[str, Any]],
    local_checksums: list[dict[str, Any]],
) -> dict[str, Any]:
    """Write complete, non-overwriting HOLD records after a transfer failure."""
    source_path = target_dir / "checksums_source.json"
    local_path = target_dir / "checksums_local.json"
    if not source_path.exists():
        _write_json(source_path, source_checksums)
    if not local_path.exists():
        _write_json(local_path, local_checksums)
    summary_path = target_dir / "dataset_summary.csv"
    if not summary_path.exists():
        _write_csv(
            summary_path,
            [
                {
                    "candidate_id": candidate["candidate_id"],
                    "dataset_id": candidate["candidate_id"],
                    "version": candidate.get("source_version", "UNKNOWN"),
                    "accession": candidate.get("accession", "UNKNOWN"),
                    "tissue": candidate.get("tissue", "UNKNOWN"),
                    "species": candidate.get("species", "UNKNOWN"),
                    "platform": candidate.get("platform", "UNKNOWN"),
                    "measurement_unit": candidate.get("measurement_unit", "UNKNOWN"),
                    "patient_count": candidate.get("patient_count", "UNKNOWN"),
                    "sample_count": 0,
                    "slice_count": 0,
                    "total_unit_count": 0,
                    "gene_count": 0,
                    "input_files_found": 0,
                    "raw_counts_available": "UNKNOWN",
                    "normalized_expression_available": "UNKNOWN",
                    "all_expression_matrices_readable": False,
                    "all_coordinates_readable": False,
                    "all_ids_align": False,
                    "coordinates_available": False,
                    "labels_available": "UNKNOWN",
                    "domain_labels_available": "UNKNOWN",
                    "resource_class": candidate.get("resource_class", "UNKNOWN"),
                    "at_least_three_frozen_fractions_feasible": False,
                    "at_least_four_positive_audit_quadrants": False,
                    "final_status": "HOLD",
                    "reason": "download_failed",
                }
            ],
        )
    alignment_path = target_dir / "file_alignment_audit.csv"
    if not alignment_path.exists():
        _write_csv(
            alignment_path,
            [
                {
                    "candidate_id": candidate["candidate_id"],
                    "sample_id": "NOT_AVAILABLE",
                    "expression_unit_count": 0,
                    "coordinate_unit_count": 0,
                    "metadata_unit_count": 0,
                    "expression_coordinate_overlap": 0,
                    "expression_metadata_overlap": 0,
                    "duplicate_expression_ids": "UNKNOWN",
                    "duplicate_coordinate_ids": "UNKNOWN",
                    "duplicate_metadata_ids": "UNKNOWN",
                    "missing_coordinates": True,
                    "missing_expression": True,
                    "missing_labels": "UNKNOWN",
                    "alignment_status": "NOT_AVAILABLE_DOWNLOAD_FAILED",
                }
            ],
        )
    feasibility_path = target_dir / "sampling_feasibility.csv"
    if not feasibility_path.exists():
        _write_csv(
            feasibility_path,
            [
                {
                    "fraction": fraction,
                    "target_n": None,
                    "input_structurally_feasible": False,
                    "target_n_at_least_100": False,
                    "expected_selection_strata": 0,
                    "strata_at_least_4": False,
                    "quota_feasible": False,
                    "structurally_infeasible_reason": "not_available_download_failed",
                    "reason": "not_available_download_failed",
                }
                for fraction in FROZEN_FRACTIONS
            ],
        )
    inventory_path = target_dir / "file_inventory.csv"
    if not inventory_path.exists():
        _write_csv(inventory_path, _inventory(target_dir))
    status = {
        "candidate_id": candidate["candidate_id"],
        "final_status": "HOLD",
        "reasons": ["Minimal frozen source file was not retrievable without substituting another release."],
        "download_error": error_message,
        "input_level_only": True,
        "sampler_run": False,
        "benchmark_run": False,
    }
    status_path = target_dir / "qualification_status.json"
    if not status_path.exists():
        _write_json(status_path, status)
    return status


def audit_dataset_directory(target_dir: Path, candidate: dict[str, Any]) -> dict[str, Any]:
    """Create the required input-only CSV and JSON qualification records."""
    raw_dir = target_dir / "raw"
    extracted_dir = target_dir / "extracted_input"
    if not raw_dir.exists():
        raise FileNotFoundError(f"Raw input directory is missing: {raw_dir}")
    h5ad_files = sorted([*raw_dir.rglob("*.h5ad"), *extracted_dir.rglob("*.h5ad")] if extracted_dir.exists() else raw_dir.rglob("*.h5ad"))
    matrix_files = (
        sorted([*extracted_dir.rglob("*.mtx"), *extracted_dir.rglob("*.mtx.gz")]) if extracted_dir.exists() else []
    )
    audits = [inspect_h5ad(path) for path in h5ad_files]
    audits.extend(inspect_mtx_bundle(path) for path in matrix_files)
    if not audits:
        raise ValueError("No supported H5AD or MTX input was found after download.")

    alignment_rows: list[dict[str, Any]] = []
    feasibility_rows: list[dict[str, Any]] = []
    for audit in audits:
        coordinates = audit.pop("coordinate_values")
        strata = positive_quadrants(coordinates)
        audit["positive_audit_quadrants"] = strata
        expression_unit_count = int(audit["unit_count"])
        coordinate_unit_count = int(coordinates.shape[0]) if coordinates is not None else 0
        alignment_rows.append(
            {
                **audit.copy(),
                "expression_unit_count": expression_unit_count,
                "coordinate_unit_count": coordinate_unit_count,
                "metadata_unit_count": expression_unit_count if audit["format"] == "h5ad" else 0,
                "expression_coordinate_overlap": expression_unit_count if audit["ids_coordinates_aligned"] else 0,
                "expression_metadata_overlap": expression_unit_count if audit["format"] == "h5ad" else 0,
                "duplicate_expression_ids": not audit["unit_ids_unique"],
                "duplicate_coordinate_ids": False if coordinates is not None else "UNKNOWN",
                "duplicate_metadata_ids": False if audit["format"] == "h5ad" and audit["unit_ids_unique"] else "UNKNOWN",
                "missing_coordinates": not audit["coordinates_readable"],
                "missing_expression": False,
                "missing_labels": not bool(audit["label_fields"]),
                "alignment_status": "PASS" if audit["ids_coordinates_aligned"] else "FAIL",
            }
        )
        for record in sampling_feasibility(int(audit["unit_count"]), strata):
            infeasible_reason = "" if record["input_structurally_feasible"] else (
                "target_n_below_100" if not record["minimum_target_n_met"] else "fewer_than_four_positive_audit_quadrants"
            )
            feasibility_rows.append(
                {
                    "input_file": audit["file"],
                    "sample_id": audit["sample_id"],
                    **record,
                    "target_n_at_least_100": record["minimum_target_n_met"],
                    "expected_selection_strata": strata,
                    "strata_at_least_4": record["minimum_spatial_strata_met"],
                    "quota_feasible": record["input_structurally_feasible"],
                    "structurally_infeasible_reason": infeasible_reason,
                }
            )

    all_input_ok = all(
        row["coordinates_readable"] and row["unit_ids_unique"] and row["ids_coordinates_aligned"] for row in alignment_rows
    )
    feasible_count = sum(record["input_structurally_feasible"] for record in feasibility_rows)
    has_three_fractions = feasible_count >= 3
    license_value = candidate.get("license", "UNKNOWN")
    is_stress_only = candidate.get("candidate_identity_class") == "STRESS_TEST_ONLY"
    if candidate.get("candidate_identity_class") == "DEVELOPMENT_ONLY":
        final_status = "EXCLUDED"
        reasons = ["Development-only data cannot be promoted to external evidence."]
    elif not all_input_ok:
        final_status = "HOLD"
        reasons = ["Input structure, identifiers, or coordinates failed a required audit."]
    elif is_stress_only:
        final_status = "STRESS_TEST_ONLY"
        reasons = ["Frozen candidate role is stress-only and cannot be promoted to primary endpoint evidence."]
    elif license_value in {"UNKNOWN", "NOT_REPORTED"}:
        final_status = "REMAINS_CONDITIONALLY_QUALIFIED"
        reasons = ["Input checks passed, but research and result-display license remains unconfirmed."]
    elif not has_three_fractions:
        final_status = "HOLD"
        reasons = ["Fewer than three frozen fractions meet input-level target and space-partition requirements."]
    elif candidate.get("limited_endpoints", False):
        final_status = "FULLY_QUALIFIED_LIMITED_ENDPOINTS"
        reasons = ["Published input supports only the frozen limited endpoint scope recorded in the manifest."]
    else:
        final_status = "FULLY_QUALIFIED"
        reasons = ["All frozen input-level qualification requirements passed."]

    slice_sizes = [size for audit in audits for size in audit["slice_unit_counts"].values()]
    dataset_summary = {
        "candidate_id": candidate["candidate_id"],
        "dataset_id": candidate["candidate_id"],
        "version": candidate.get("source_version", "UNKNOWN"),
        "accession": candidate.get("accession", "UNKNOWN"),
        "tissue": candidate.get("tissue", "UNKNOWN"),
        "species": candidate.get("species", "UNKNOWN"),
        "platform": candidate.get("platform", "UNKNOWN"),
        "measurement_unit": candidate.get("measurement_unit", "UNKNOWN"),
        "candidate_identity_class": candidate["candidate_identity_class"],
        "input_files_found": len(audits),
        "patient_count": candidate.get("patient_count", "UNKNOWN"),
        "sample_count": len(audits),
        "slice_count": sum(int(audit["slice_count"]) for audit in audits),
        "total_unit_count": sum(int(audit["unit_count"]) for audit in audits),
        "minimum_units_per_slice": min(slice_sizes),
        "median_units_per_slice": float(np.median(slice_sizes)),
        "maximum_units_per_slice": max(slice_sizes),
        "gene_count": max(int(audit["shape_rows"] if audit["format"] == "mtx_bundle" else audit["shape_columns"]) for audit in audits),
        "raw_counts_available": all(audit["raw_counts_available"] is True for audit in audits),
        "normalized_expression_available": "UNKNOWN",
        "all_expression_matrices_readable": True,
        "all_coordinates_readable": all(row["coordinates_readable"] for row in alignment_rows),
        "all_ids_align": all(row["ids_coordinates_aligned"] for row in alignment_rows),
        "coordinates_available": all(row["coordinates_readable"] for row in alignment_rows),
        "labels_available": any(bool(row["label_fields"]) for row in alignment_rows),
        "domain_labels_available": any("spatialdomain" in row["label_fields"].lower() for row in alignment_rows),
        "total_download_size": sum(path.stat().st_size for path in raw_dir.rglob("*") if path.is_file()),
        "resource_class": candidate.get("resource_class", "UNKNOWN"),
        "recoverable_sample_or_slice_fields": ";".join(
            sorted({str(row["sample_field"] or row["slice_field"] or "") for row in alignment_rows if row["sample_field"] or row["slice_field"]})
        ),
        "at_least_three_frozen_fractions_feasible": has_three_fractions,
        "at_least_four_positive_audit_quadrants": all(row["positive_audit_quadrants"] >= MINIMUM_POSITIVE_STRATA for row in alignment_rows),
        "final_status": final_status,
    }
    _write_csv(target_dir / "dataset_summary.csv", [dataset_summary])
    _write_csv(target_dir / "file_alignment_audit.csv", alignment_rows)
    _write_csv(target_dir / "sampling_feasibility.csv", feasibility_rows)
    _write_csv(target_dir / "file_inventory.csv", _inventory(target_dir))
    status = {
        "candidate_id": candidate["candidate_id"],
        "final_status": final_status,
        "reasons": reasons,
        "input_level_only": True,
        "sampler_run": False,
        "benchmark_run": False,
        "qualification_checks": dataset_summary,
    }
    _write_json(target_dir / "qualification_status.json", status)
    return status
