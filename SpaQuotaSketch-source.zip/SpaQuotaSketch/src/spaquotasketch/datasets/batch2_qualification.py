"""Input-only helpers for the frozen second external qualification batch.

This module handles immutable transfer records, narrow archive extraction, and
file-structure checks. It deliberately does not import samplers, metrics,
embedding, clustering, or benchmark code.
"""

from __future__ import annotations

import csv
import gzip
import hashlib
import json
import math
import os
import shutil
import struct
import tarfile
import urllib.request
import zlib
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import h5py
import numpy as np
import pandas as pd
import yaml

from .input_qualification import (
    FROZEN_FRACTIONS,
    MINIMUM_POSITIVE_STRATA,
    MINIMUM_TARGET_N,
    append_jsonl,
    copy_with_sha256_verification,
    create_non_overwriting_directory,
    make_read_only,
    positive_quadrants,
    sampling_feasibility,
    sha256_file,
)


REQUIRED_AUDIT_FILES = {
    "source_manifest.yaml",
    "download_log.jsonl",
    "checksums_source.json",
    "checksums_local.json",
    "file_inventory.csv",
    "dataset_summary.csv",
    "file_alignment_audit.csv",
    "sampling_feasibility.csv",
    "qualification_status.json",
}
FINAL_STATUSES = {
    "FULLY_QUALIFIED",
    "FULLY_QUALIFIED_LIMITED_ENDPOINTS",
    "REMAINS_CONDITIONALLY_QUALIFIED",
    "STRESS_TEST_ONLY",
    "EXCLUDED",
    "HOLD",
}


def utc_now() -> str:
    """Return an auditable UTC timestamp."""
    return datetime.now(UTC).isoformat()


def write_json_new(path: Path, payload: Any) -> None:
    """Write one JSON file only when its path has never been used."""
    if path.exists():
        raise FileExistsError(f"Refusing to overwrite {path}")
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")


def write_yaml_new(path: Path, payload: Any) -> None:
    """Write one YAML file only when its path has never been used."""
    if path.exists():
        raise FileExistsError(f"Refusing to overwrite {path}")
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        yaml.safe_dump(payload, handle, sort_keys=False, allow_unicode=False)


def write_csv_new(path: Path, rows: list[dict[str, Any]]) -> None:
    """Write a rectangular CSV without replacing a prior audit artifact."""
    if path.exists():
        raise FileExistsError(f"Refusing to overwrite {path}")
    fields = sorted({key for row in rows for key in row}) if rows else ["empty"]
    with path.open("x", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def head_http(url: str) -> dict[str, Any]:
    """Read source identity headers without transferring the source body."""
    request = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "SpaQuotaSketch-input-qualification/2.0"})
    with urllib.request.urlopen(request, timeout=120) as response:
        return {
            "url": url,
            "resolved_url": response.geturl(),
            "content_length": int(response.headers["Content-Length"]) if response.headers.get("Content-Length") else None,
            "etag": response.headers.get("ETag"),
            "last_modified": response.headers.get("Last-Modified"),
            "content_type": response.headers.get("Content-Type"),
        }


def download_http_to_staging(url: str, destination: Path, expected_bytes: int | None) -> dict[str, Any]:
    """Receive one direct public file into NTFS staging and validate its size."""
    if destination.exists():
        raise FileExistsError(f"Refusing to reuse staging file {destination}")
    request = urllib.request.Request(url, headers={"User-Agent": "SpaQuotaSketch-input-qualification/2.0"})
    with urllib.request.urlopen(request, timeout=120) as response, destination.open("xb") as handle:
        while block := response.read(1024 * 1024):
            handle.write(block)
        content_length = response.headers.get("Content-Length")
        resolved_url = response.geturl()
    actual_bytes = destination.stat().st_size
    if expected_bytes is not None and actual_bytes != expected_bytes:
        raise ValueError(f"Expected {expected_bytes} bytes but received {actual_bytes} bytes from {url}")
    if content_length is not None and actual_bytes != int(content_length):
        raise ValueError(f"Content-Length mismatch for {url}")
    return {
        "url": url,
        "resolved_url": resolved_url,
        "content_length": int(content_length) if content_length else None,
        "bytes": actual_bytes,
        "sha256": sha256_file(destination),
    }


def _fetch_range(url: str, start: int, end: int) -> bytes:
    """Fetch an exact HTTP byte range, rejecting a server that ignores Range."""
    request = urllib.request.Request(
        url,
        headers={"Range": f"bytes={start}-{end}", "User-Agent": "SpaQuotaSketch-input-qualification/2.0"},
    )
    with urllib.request.urlopen(request, timeout=120) as response:
        if response.status != 206:
            raise ValueError(f"Expected HTTP 206 for range request, received {response.status}")
        content_range = response.headers.get("Content-Range", "")
        expected_prefix = f"bytes {start}-{end}/"
        if not content_range.startswith(expected_prefix):
            raise ValueError(f"Unexpected Content-Range: {content_range}")
        data = response.read()
    if len(data) != end - start + 1:
        raise ValueError(f"Range body length mismatch for {url}")
    return data


def _zip64_values(extra: bytes, values: list[int]) -> list[int]:
    """Resolve ZIP64 values stored among arbitrary extra-field blocks."""
    position = 0
    while position + 4 <= len(extra):
        field_id, field_size = struct.unpack_from("<HH", extra, position)
        payload = extra[position + 4 : position + 4 + field_size]
        if field_id == 0x0001:
            payload_position = 0
            resolved: list[int] = []
            for value in values:
                if value == 0xFFFFFFFF:
                    if payload_position + 8 > len(payload):
                        raise ValueError("Malformed ZIP64 extra field")
                    resolved.append(struct.unpack_from("<Q", payload, payload_position)[0])
                    payload_position += 8
                else:
                    resolved.append(value)
            return resolved
        position += 4 + field_size
    if any(value == 0xFFFFFFFF for value in values):
        raise ValueError("ZIP64 value is missing from central-directory extra field")
    return values


@dataclass(frozen=True)
class RemoteZipEntry:
    """One entry in a remotely range-read ZIP archive."""

    name: str
    compression_method: int
    flags: int
    crc32: int
    compressed_size: int
    uncompressed_size: int
    local_header_offset: int


def list_remote_zip_entries(url: str, content_length: int) -> dict[str, RemoteZipEntry]:
    """Read a ZIP central directory with tiny HTTP ranges, including ZIP64."""
    tail_size = min(131_072, content_length)
    tail_start = content_length - tail_size
    tail = _fetch_range(url, tail_start, content_length - 1)
    eocd = tail.rfind(b"PK\x05\x06")
    if eocd < 0:
        raise ValueError("ZIP end-of-central-directory record was not found")
    _, _, _, _, entries, directory_size, directory_offset, _ = struct.unpack_from("<4s4H2LH", tail, eocd)
    if entries == 0xFFFF or directory_offset == 0xFFFFFFFF:
        locator = tail.rfind(b"PK\x06\x07", 0, eocd)
        if locator < 0:
            raise ValueError("ZIP64 locator was not found")
        _, _, zip64_offset, _ = struct.unpack_from("<4sLQL", tail, locator)
        zip64 = _fetch_range(url, zip64_offset, zip64_offset + 55)
        values = struct.unpack_from("<4sQ2H2L4Q", zip64)
        if values[0] != b"PK\x06\x06":
            raise ValueError("Invalid ZIP64 end-of-central-directory signature")
        entries = int(values[7])
        directory_size = int(values[8])
        directory_offset = int(values[9])
    directory = _fetch_range(url, int(directory_offset), int(directory_offset + directory_size - 1))
    entries_by_name: dict[str, RemoteZipEntry] = {}
    position = 0
    for _ in range(int(entries)):
        if directory[position : position + 4] != b"PK\x01\x02":
            raise ValueError("Malformed ZIP central directory")
        fields = struct.unpack_from("<4s6H3L5H2L", directory, position)
        flags, compression_method, crc32 = int(fields[3]), int(fields[4]), int(fields[7])
        compressed_size, uncompressed_size, local_offset = _zip64_values(
            directory[position + 46 + fields[10] : position + 46 + fields[10] + fields[11]],
            [int(fields[8]), int(fields[9]), int(fields[16])],
        )
        name_start = position + 46
        name_end = name_start + int(fields[10])
        name = directory[name_start:name_end].decode("utf-8", "replace")
        entries_by_name[name] = RemoteZipEntry(
            name=name,
            compression_method=compression_method,
            flags=flags,
            crc32=crc32,
            compressed_size=compressed_size,
            uncompressed_size=uncompressed_size,
            local_header_offset=local_offset,
        )
        position = name_end + int(fields[11]) + int(fields[12])
    return entries_by_name


def extract_remote_zip_entry(url: str, entry: RemoteZipEntry, destination: Path) -> dict[str, Any]:
    """Download one named original ZIP member, not the whole source archive."""
    if destination.exists():
        raise FileExistsError(f"Refusing to overwrite staging member {destination}")
    header = _fetch_range(url, entry.local_header_offset, entry.local_header_offset + 4095)
    if header[:4] != b"PK\x03\x04":
        raise ValueError(f"Invalid local ZIP header for {entry.name}")
    fields = struct.unpack_from("<4s5H3L2H", header)
    name_size, extra_size = int(fields[9]), int(fields[10])
    data_offset = entry.local_header_offset + 30 + name_size + extra_size
    compressed = _fetch_range(url, data_offset, data_offset + entry.compressed_size - 1)
    if entry.compression_method == 0:
        raw = compressed
    elif entry.compression_method == 8:
        raw = zlib.decompress(compressed, -zlib.MAX_WBITS)
    else:
        raise ValueError(f"Unsupported ZIP compression method {entry.compression_method} for {entry.name}")
    if len(raw) != entry.uncompressed_size:
        raise ValueError(f"Uncompressed byte count mismatch for {entry.name}")
    if zlib.crc32(raw) & 0xFFFFFFFF != entry.crc32:
        raise ValueError(f"ZIP CRC32 mismatch for {entry.name}")
    with destination.open("xb") as handle:
        handle.write(raw)
    return {
        "source_member": entry.name,
        "zip_crc32": f"{entry.crc32:08x}",
        "compressed_bytes": entry.compressed_size,
        "bytes": entry.uncompressed_size,
        "sha256": sha256_file(destination),
    }


def extract_tar_members(archive: Path, destination: Path, suffixes: tuple[str, ...]) -> list[str]:
    """Extract only explicit non-image input members from an official TAR."""
    destination.mkdir(exist_ok=False)
    extracted: list[str] = []
    with tarfile.open(archive, "r:*") as handle:
        for member in handle.getmembers():
            relative = Path(member.name)
            if not member.isfile() or relative.is_absolute() or ".." in relative.parts:
                continue
            if not member.name.lower().endswith(suffixes):
                continue
            source = handle.extractfile(member)
            if source is None:
                continue
            target = destination / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists():
                raise FileExistsError(f"Archive would overwrite {target}")
            with source, target.open("xb") as output:
                shutil.copyfileobj(source, output)
            extracted.append(target.relative_to(destination).as_posix())
    return extracted


def _decode_strings(dataset: h5py.Dataset) -> list[str]:
    values = dataset[()]
    return [value.decode("utf-8") if isinstance(value, bytes) else str(value) for value in np.ravel(values)]


def inspect_10x_h5(path: Path) -> dict[str, Any]:
    """Read matrix dimensions and identifiers from a 10x H5 without loading X."""
    with h5py.File(path, "r") as handle:
        if "matrix" not in handle:
            raise ValueError(f"10x H5 lacks matrix group: {path.name}")
        matrix = handle["matrix"]
        shape = tuple(int(value) for value in np.asarray(matrix["shape"][()]))
        if len(shape) != 2:
            raise ValueError(f"10x H5 matrix shape is invalid: {path.name}")
        unit_ids = _decode_strings(matrix["barcodes"])
        if len(unit_ids) != shape[1]:
            raise ValueError(f"10x H5 barcode count does not match matrix columns: {path.name}")
        indptr = np.asarray(matrix["indptr"][()])
        zero_units = int(np.count_nonzero(np.diff(indptr) == 0))
        feature_ids = _decode_strings(matrix["features"]["id"]) if "features" in matrix and "id" in matrix["features"] else []
        return {
            "file": str(path),
            "sample_id": path.name.split("_filtered", 1)[0].split("_feature", 1)[0],
            "format": "10x_h5",
            "shape_rows": shape[0],
            "shape_columns": shape[1],
            "nnz": int(matrix["data"].shape[0]),
            "storage": "sparse",
            "unit_count": shape[1],
            "unit_ids": unit_ids,
            "unit_ids_unique": len(unit_ids) == len(set(unit_ids)),
            "gene_count": shape[0],
            "gene_id_type": "10x_feature_id" if feature_ids else "UNKNOWN",
            "zero_expression_units": zero_units,
            "raw_counts_available": True,
            "normalized_expression_available": False,
        }


def inspect_visium_hd_feature_slice_h5(path: Path, mask_name: str = "square_016um") -> dict[str, Any]:
    """Inspect published Visium HD feature-slice input without materializing X.

    The official feature-slice format stores each gene separately and encodes
    spatial bins as sparse row/column vectors.  The filtered mask is the
    published unit population; it supplies coordinates and stable synthetic
    ``row:column`` unit IDs for input qualification only.
    """
    with h5py.File(path, "r") as handle:
        mask_path = f"masks/{mask_name}"
        if mask_path not in handle or "features" not in handle or "feature_slices" not in handle:
            raise ValueError(f"Visium HD feature-slice schema is incomplete: {path.name}")
        mask = handle[mask_path]
        row = np.asarray(mask["row"][()])
        column = np.asarray(mask["col"][()])
        if row.shape != column.shape:
            raise ValueError(f"Visium HD coordinate vectors do not match: {path.name}")
        unit_ids = [f"{int(y)}:{int(x)}" for y, x in zip(row, column, strict=True)]
        feature_ids = _decode_strings(handle["features"]["id"])
        return {
            "file": str(path),
            "sample_id": path.name.split("_feature", 1)[0],
            "format": "visium_hd_feature_slice_h5",
            "shape_rows": len(feature_ids),
            "shape_columns": len(unit_ids),
            "nnz": None,
            "storage": "sparse_feature_slices",
            "unit_count": len(unit_ids),
            "unit_ids": unit_ids,
            "unit_ids_unique": len(unit_ids) == len(set(unit_ids)),
            "gene_count": len(feature_ids),
            "gene_id_type": "10x_feature_id",
            "zero_expression_units": "NOT_EVALUATED_FROM_FEATURE_SLICES",
            "raw_counts_available": "umis/total" in handle,
            "normalized_expression_available": False,
            "embedded_coordinate_ids": unit_ids,
            "embedded_coordinates": np.column_stack((column, row)).astype(float, copy=False),
            "coordinate_unit": "published_square_016um_bin_index",
        }


def _read_coordinate_csv(path: Path) -> dict[str, Any]:
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8", newline="") as handle:
        rows = list(csv.reader(handle))
    if not rows:
        return {"ids": [], "coordinates": None, "id_column": None, "coordinate_columns": None}
    header = [value.lower() for value in rows[0]]
    has_header = any("barcode" in value or "spot" in value or value in {"x", "y", "id"} for value in header)
    if has_header:
        body = rows[1:]
        id_index = next((index for index, value in enumerate(header) if "barcode" in value or "spot" in value or value == "id"), 0)
        coordinate_indices = [
            index
            for index, value in enumerate(header)
            if value in {"x", "y", "pxl_col_in_fullres", "pxl_row_in_fullres", "array_col", "array_row"}
        ]
        id_column = rows[0][id_index]
        coordinate_columns = ";".join(rows[0][index] for index in coordinate_indices[-2:])
    else:
        body = rows
        id_index = 0
        coordinate_indices = [4, 5] if len(rows[0]) >= 6 else [1, 2]
        id_column = "column_0"
        coordinate_columns = ";".join(f"column_{index}" for index in coordinate_indices[-2:])
    ids: list[str] = []
    coordinates: list[tuple[float, float]] = []
    for row in body:
        if len(row) <= max([id_index, *coordinate_indices]):
            continue
        try:
            coordinates.append((float(row[coordinate_indices[-2]]), float(row[coordinate_indices[-1]])))
            ids.append(row[id_index])
        except (TypeError, ValueError, IndexError):
            continue
    return {
        "ids": ids,
        "coordinates": np.asarray(coordinates, dtype=float) if coordinates else None,
        "id_column": id_column,
        "coordinate_columns": coordinate_columns,
    }


def _read_coordinate_parquet(path: Path) -> dict[str, Any]:
    table = pd.read_parquet(path)
    columns = {str(column).lower(): str(column) for column in table.columns}
    id_column = next((columns[name] for name in ("cell_id", "cellid", "barcode", "cell", "id") if name in columns), None)
    x_column = next((columns[name] for name in ("x_centroid", "x_centroid_in_pixels", "x", "x_location") if name in columns), None)
    y_column = next((columns[name] for name in ("y_centroid", "y_centroid_in_pixels", "y", "y_location") if name in columns), None)
    if id_column is None or x_column is None or y_column is None:
        raise ValueError(f"Could not identify ID and x/y columns in {path.name}: {sorted(table.columns)}")
    return {
        "ids": table[id_column].astype(str).tolist(),
        "coordinates": table[[x_column, y_column]].to_numpy(dtype=float),
        "id_column": id_column,
        "coordinate_columns": f"{x_column};{y_column}",
    }


def _coordinate_source(target_dir: Path, kind: str) -> tuple[Path | None, dict[str, Any] | None]:
    if kind == "parquet_cells":
        candidate = next(iter(sorted(target_dir.rglob("cells.parquet"))), None)
        return (candidate, _read_coordinate_parquet(candidate)) if candidate else (None, None)
    if kind == "spatial_csv":
        candidate = next(
            (
                path
                for path in sorted(target_dir.rglob("*.csv"))
                if "tissue_position" in path.name.lower() or "spatial" in path.name.lower()
            ),
            None,
        )
        return (candidate, _read_coordinate_csv(candidate)) if candidate else (None, None)
    return None, None


def _inventory(root: Path) -> list[dict[str, Any]]:
    return [
        {
            "relative_path": path.relative_to(root).as_posix(),
            "bytes": path.stat().st_size,
            "sha256": sha256_file(path),
        }
        for path in sorted(root.rglob("*"))
        if path.is_file() and path.name != "file_inventory.csv"
    ]


def audit_batch2_input(target_dir: Path, candidate: dict[str, Any]) -> dict[str, Any]:
    """Write full input-only records and a success marker for one candidate."""
    h5_files = sorted([*target_dir.rglob("*.h5"), *target_dir.rglob("*.h5ad")])
    if not h5_files:
        raise ValueError("No H5 expression file is available for input qualification")
    if candidate.get("input_format") == "visium_hd_feature_slice_h5":
        expression = inspect_visium_hd_feature_slice_h5(h5_files[0], candidate.get("qualification_mask", "square_016um"))
    else:
        expression = inspect_10x_h5(h5_files[0])
    if candidate["coordinate_source_kind"] == "embedded_visium_hd_feature_slice":
        coordinate_path = h5_files[0]
        coordinate = {
            "ids": expression.pop("embedded_coordinate_ids"),
            "coordinates": expression.pop("embedded_coordinates"),
            "id_column": "published_row:column",
            "coordinate_columns": "published_col;published_row",
        }
    else:
        coordinate_path, coordinate = _coordinate_source(target_dir, candidate["coordinate_source_kind"])
    unit_ids = expression.pop("unit_ids")
    coordinate_ids = coordinate["ids"] if coordinate else []
    coordinates = coordinate["coordinates"] if coordinate else None
    finite_coordinates = bool(coordinates is not None and np.isfinite(coordinates).all())
    coordinate_ids_unique = len(coordinate_ids) == len(set(coordinate_ids)) if coordinate else False
    coordinate_pairs_unique = bool(
        coordinates is not None and len({(float(x), float(y)) for x, y in coordinates}) == len(coordinates)
    )
    unit_id_set = set(unit_ids)
    overlap = len(unit_id_set.intersection(coordinate_ids)) if coordinate else 0
    ids_aligned = bool(
        coordinate
        and expression["unit_ids_unique"]
        and coordinate_ids_unique
        and overlap == len(unit_ids)
        and finite_coordinates
    )
    # Coordinate tables may include out-of-tissue locations.  Coverage checks
    # apply only to the published expression population used by this audit.
    if coordinate and coordinates is not None:
        expression_coordinates = np.asarray(
            [value for identifier, value in zip(coordinate_ids, coordinates, strict=True) if identifier in unit_id_set],
            dtype=float,
        )
    else:
        expression_coordinates = None
    strata = positive_quadrants(expression_coordinates) if finite_coordinates else 0
    alignment = {
        **expression,
        "coordinate_file": str(coordinate_path) if coordinate_path else None,
        "coordinate_unit_count": len(coordinate_ids),
        "metadata_unit_count": len(unit_ids),
        "expression_unit_count": len(unit_ids),
        "expression_coordinate_overlap": overlap,
        "expression_metadata_overlap": len(unit_ids),
        "coordinate_dimensions": int(coordinates.shape[1]) if coordinates is not None else 0,
        "coordinate_id_column": coordinate["id_column"] if coordinate else None,
        "coordinate_columns": coordinate["coordinate_columns"] if coordinate else None,
        "coordinates_finite": finite_coordinates,
        "duplicate_expression_ids": not expression["unit_ids_unique"],
        "duplicate_coordinate_ids": not coordinate_ids_unique if coordinate else "UNKNOWN",
        "duplicate_coordinates": not coordinate_pairs_unique if coordinate else "UNKNOWN",
        "missing_coordinates": len(unit_ids) - overlap,
        "missing_expression": len(coordinate_ids) - overlap,
        "alignment_status": "PASS" if ids_aligned else "FAIL",
        "positive_audit_quadrants": strata,
        "sample_hierarchy": candidate["sample_hierarchy"],
        "labels_available": candidate.get("labels_available", "UNKNOWN"),
    }
    feasibility = []
    for row in sampling_feasibility(expression["unit_count"], strata):
        reason = "" if row["input_structurally_feasible"] else (
            "target_n_below_100" if not row["minimum_target_n_met"] else "fewer_than_four_positive_audit_quadrants"
        )
        feasibility.append(
            {
                "sample_id": candidate["qualified_spatial_unit"],
                "total_units": expression["unit_count"],
                **row,
                "target_n_at_least_100": row["minimum_target_n_met"],
                "expected_positive_strata": strata,
                "positive_strata_at_least_4": row["minimum_spatial_strata_met"],
                "quota_feasible": row["input_structurally_feasible"],
                "structurally_infeasible_reason": reason,
            }
        )
    has_three_fractions = sum(row["quota_feasible"] for row in feasibility) >= 3
    input_ok = ids_aligned and expression["unit_ids_unique"] and has_three_fractions and strata >= MINIMUM_POSITIVE_STRATA
    if not input_ok:
        final_status = "HOLD"
        reasons = ["Expression and coordinate structure does not meet all frozen input requirements."]
    elif candidate["license"] in {"UNKNOWN", "NOT_REPORTED"}:
        final_status = "REMAINS_CONDITIONALLY_QUALIFIED"
        reasons = ["Input structure passed but the required license evidence is not confirmed."]
    elif not candidate["representation_eligible"] and not candidate["inference_eligible"]:
        final_status = "HOLD"
        reasons = ["Neither frozen Representation nor Inference endpoint is definable."]
    elif candidate.get("limited_endpoints", False):
        final_status = "FULLY_QUALIFIED_LIMITED_ENDPOINTS"
        reasons = ["Input passes qualification with recorded platform or endpoint limits."]
    else:
        final_status = "FULLY_QUALIFIED"
        reasons = ["All frozen file-level input qualification requirements passed."]

    summary = {
        "dataset_id": candidate["candidate_id"],
        "accession": candidate["accession"],
        "official_title": candidate["official_title"],
        "source_version": candidate["source_version"],
        "publication_date": candidate["publication_date"],
        "tissue": candidate["tissue"],
        "species": candidate["species"],
        "platform": candidate["platform"],
        "measurement_unit": candidate["measurement_unit"],
        "patient_count": candidate["patient_count"],
        "sample_count": candidate["sample_count"],
        "slice_count": candidate["slice_count"],
        "total_unit_count": expression["unit_count"],
        "gene_count": expression["gene_count"],
        "raw_counts_available": expression["raw_counts_available"],
        "normalized_expression_available": expression["normalized_expression_available"],
        "expression_format": expression["format"],
        "coordinates_available": bool(finite_coordinates),
        "coordinate_dimensions": int(coordinates.shape[1]) if coordinates is not None else 0,
        "labels_available": candidate.get("labels_available", "UNKNOWN"),
        "targeted_panel": candidate.get("targeted_panel", False),
        "panel_gene_count": candidate.get("panel_gene_count", "NOT_APPLICABLE"),
        "representation_eligible": candidate["representation_eligible"],
        "inference_eligible": candidate["inference_eligible"],
        "at_least_three_frozen_fractions_feasible": has_three_fractions,
        "at_least_four_positive_audit_quadrants": strata >= MINIMUM_POSITIVE_STRATA,
        "final_status": final_status,
    }
    write_csv_new(target_dir / "dataset_summary.csv", [summary])
    write_csv_new(target_dir / "file_alignment_audit.csv", [alignment])
    write_csv_new(target_dir / "sampling_feasibility.csv", feasibility)
    write_csv_new(target_dir / "file_inventory.csv", _inventory(target_dir))
    status = {
        "candidate_id": candidate["candidate_id"],
        "final_status": final_status,
        "reasons": reasons,
        "input_level_only": True,
        "development_trace_detected": bool(candidate.get("development_trace_detected", False)),
        "sampler_run": False,
        "benchmark_run": False,
        "pca_run": False,
        "clustering_run": False,
        "qualification_checks": summary,
    }
    write_json_new(target_dir / "qualification_status.json", status)
    return status


def write_success_marker(target_dir: Path, checksum_verified: bool, filesystem_readonly_preserved: bool) -> None:
    """Write the batch-2 completion marker only after all audit files exist."""
    missing = REQUIRED_AUDIT_FILES.difference({path.name for path in target_dir.iterdir()})
    if missing:
        raise ValueError(f"Cannot mark qualification complete; missing {sorted(missing)}")
    write_json_new(
        target_dir / "_SUCCESS.json",
        {
            "published_at": utc_now(),
            "immutable_by_policy": True,
            "filesystem_readonly_preserved": filesystem_readonly_preserved,
            "overwrite_prohibited": True,
            "checksum_verified": checksum_verified,
            "qualification_files_complete": True,
        },
    )


def record_batch2_hold(
    target_dir: Path,
    candidate: dict[str, Any],
    reason: str,
    source_checksums: list[dict[str, Any]],
    local_checksums: list[dict[str, Any]],
) -> dict[str, Any]:
    """Publish a complete, explicit HOLD record without substituting input."""
    if not (target_dir / "checksums_source.json").exists():
        write_json_new(target_dir / "checksums_source.json", source_checksums)
    if not (target_dir / "checksums_local.json").exists():
        write_json_new(target_dir / "checksums_local.json", local_checksums)
    if not (target_dir / "dataset_summary.csv").exists():
        write_csv_new(
            target_dir / "dataset_summary.csv",
            [
                {
                    "dataset_id": candidate["candidate_id"],
                    "accession": candidate["accession"],
                    "official_title": candidate["official_title"],
                    "source_version": candidate["source_version"],
                    "total_unit_count": 0,
                    "gene_count": 0,
                    "coordinates_available": False,
                    "at_least_three_frozen_fractions_feasible": False,
                    "at_least_four_positive_audit_quadrants": False,
                    "final_status": "HOLD",
                }
            ],
        )
    if not (target_dir / "file_alignment_audit.csv").exists():
        write_csv_new(
            target_dir / "file_alignment_audit.csv",
            [
                {
                    "sample_id": "NOT_AVAILABLE",
                    "expression_unit_count": 0,
                    "coordinate_unit_count": 0,
                    "alignment_status": "NOT_AVAILABLE",
                    "failure_reason": reason,
                }
            ],
        )
    if not (target_dir / "sampling_feasibility.csv").exists():
        write_csv_new(
            target_dir / "sampling_feasibility.csv",
            [
                {
                    "fraction": fraction,
                    "target_n": None,
                    "quota_feasible": False,
                    "structurally_infeasible_reason": reason,
                }
                for fraction in FROZEN_FRACTIONS
            ],
        )
    if not (target_dir / "file_inventory.csv").exists():
        write_csv_new(target_dir / "file_inventory.csv", _inventory(target_dir))
    status = {
        "candidate_id": candidate["candidate_id"],
        "final_status": "HOLD",
        "reasons": [reason],
        "input_level_only": True,
        "sampler_run": False,
        "benchmark_run": False,
        "pca_run": False,
        "clustering_run": False,
    }
    if not (target_dir / "qualification_status.json").exists():
        write_json_new(target_dir / "qualification_status.json", status)
    return status
