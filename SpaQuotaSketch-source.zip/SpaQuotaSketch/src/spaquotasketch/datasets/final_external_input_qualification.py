"""Read-only qualification for the frozen final external input batch.

This module deliberately stops at file integrity, expression/coordinate
structure, identifier alignment, and sample-size feasibility.  It never
normalizes data, calls a sampler, or evaluates benchmark performance.
"""

from __future__ import annotations

import csv
import gzip
import hashlib
import io
import json
import math
import tarfile
from collections import Counter
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Iterable, Mapping

import h5py
import numpy as np
import pandas as pd
import yaml

from .input_qualification import positive_quadrants, sampling_feasibility, sha256_file
from .slideseqv2_gse190094 import SlideSeqV2InputError, load_slideseqv2_pair


SAMPLE_SUCCESS = frozenset(
    {
        "SAMPLE_INPUT_FULLY_QUALIFIED",
        "SAMPLE_INPUT_FULLY_QUALIFIED_LIMITED_ENDPOINTS",
    }
)
DATASET_SUCCESS = frozenset({"FULLY_QUALIFIED", "FULLY_QUALIFIED_LIMITED_ENDPOINTS"})
UNFINISHED_SUFFIXES = (".part", ".partial", ".tmp", ".aria2", ".download")


class FinalExternalInputQualificationError(ValueError):
    """Raised when a frozen external input cannot be read safely."""


@dataclass(frozen=True)
class CoordinateTable:
    """Identifiers and planar coordinates read without positional matching."""

    identifiers: tuple[str, ...]
    coordinates: np.ndarray
    id_column: str
    x_column: str
    y_column: str


def utc_now() -> str:
    """Return an explicit audit timestamp for append-only runtime events."""
    return datetime.now(UTC).isoformat()


def load_yaml_mapping(path: str | Path) -> dict[str, Any]:
    """Load one YAML mapping and reject accidental list/scalar configurations."""
    payload = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise FinalExternalInputQualificationError(f"Expected a YAML mapping: {path}")
    return payload


def validate_frozen_batch_config(config: Mapping[str, Any]) -> None:
    """Reject a batch configuration that silently changes the frozen pool."""
    datasets = config.get("datasets")
    if not isinstance(datasets, list) or len(datasets) != 10:
        raise FinalExternalInputQualificationError("Final batch must contain exactly ten frozen candidates.")
    primary = [item for item in datasets if item.get("pool_role") == "primary"]
    backup = [item for item in datasets if item.get("pool_role") == "backup"]
    if len(primary) != 8 or len(backup) != 2:
        raise FinalExternalInputQualificationError("Final batch must retain eight primary and two backup candidates.")
    identifiers = [str(item.get("candidate_id", "")) for item in datasets]
    if len(identifiers) != len(set(identifiers)) or any(not value for value in identifiers):
        raise FinalExternalInputQualificationError("Candidate identifiers must be present and unique.")
    directories = [str(item.get("input_directory", "")) for item in datasets]
    if len(directories) != len(set(directories)) or any(not value for value in directories):
        raise FinalExternalInputQualificationError("Input directories must be present and unique.")
    forbidden = set(config.get("forbidden_actions", []))
    required_forbidden = {"sampling", "benchmark", "pca", "umap", "clustering", "batch_correction"}
    if not required_forbidden.issubset(forbidden):
        raise FinalExternalInputQualificationError("Input-only batch configuration is missing a forbidden-action guard.")


def _iter_sample_specs(dataset: Mapping[str, Any]) -> Iterable[tuple[Mapping[str, Any], Mapping[str, Any]]]:
    for sample in dataset.get("samples", []):
        if not isinstance(sample, Mapping) or not sample.get("sample_id"):
            raise FinalExternalInputQualificationError(f"Invalid sample specification for {dataset.get('candidate_id')}")
        files = sample.get("files")
        if not isinstance(files, list) or not files:
            raise FinalExternalInputQualificationError(f"Sample {sample['sample_id']} has no frozen files.")
        for file_spec in files:
            if not isinstance(file_spec, Mapping) or not file_spec.get("filename"):
                raise FinalExternalInputQualificationError(f"Sample {sample['sample_id']} has an invalid file specification.")
            yield sample, file_spec


def _expected_file_lookup(config: Mapping[str, Any]) -> tuple[dict[tuple[str, str], list[dict[str, Any]]], dict[str, str]]:
    expected: dict[tuple[str, str], list[dict[str, Any]]] = {}
    directories: dict[str, str] = {}
    for dataset in config["datasets"]:
        candidate_id = str(dataset["candidate_id"])
        directory = str(dataset["input_directory"])
        directories[directory] = candidate_id
        for sample, file_spec in _iter_sample_specs(dataset):
            key = (candidate_id, str(file_spec["filename"]))
            expected.setdefault(key, []).append({"sample_id": sample["sample_id"], **dict(file_spec)})
    return expected, directories


def classify_file_role(filename: str) -> str:
    """Classify a downloaded input file without interpreting biological values."""
    name = filename.lower()
    if "feature_slice" in name and name.endswith(".h5"):
        return "EXPRESSION_MATRIX_AND_SPATIAL_COORDINATES_AND_UNIT_IDS"
    if name.endswith("cell_feature_matrix.h5") or name.endswith("filtered_feature_bc_matrix.h5"):
        return "EXPRESSION_MATRIX_AND_UNIT_IDS"
    if name.endswith("cells.parquet"):
        return "SPATIAL_COORDINATES_AND_UNIT_IDS"
    if "beadlocationsforr" in name:
        return "SPATIAL_COORDINATES_AND_UNIT_IDS"
    if "mappeddgeforr" in name:
        return "EXPRESSION_MATRIX_AND_UNIT_IDS"
    if name.endswith("gene_panel.json"):
        return "PANEL_DEFINITION"
    if name.endswith(".tar.gz") or name.endswith(".tgz"):
        return "SPATIAL_COORDINATES_CONTAINER"
    if name.endswith((".sha256", ".md5", "checksums.txt")):
        return "CHECKSUM"
    if name.endswith((".yaml", ".yml", ".json", ".md", ".txt")):
        return "README_OR_MANIFEST"
    return "OTHER"


def scan_actual_inventory(data_root: str | Path, config: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Recursively inventory real files while keeping paths relative to data_root."""
    root = Path(data_root)
    if not root.is_dir():
        raise FileNotFoundError(f"External input root does not exist: {root}")
    expected, directories = _expected_file_lookup(config)
    records: list[dict[str, Any]] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(root).as_posix()
        parts = relative.split("/")
        input_directory = parts[0] if parts else ""
        candidate_id = directories.get(input_directory)
        matched_specs = expected.get((candidate_id, path.name), []) if candidate_id else []
        records.append(
            {
                "dataset_id": candidate_id or "UNKNOWN_DIRECTORY",
                "sample_id": matched_specs[0]["sample_id"] if len(matched_specs) == 1 else "UNKNOWN",
                "relative_path": relative,
                "filename": path.name,
                "bytes": int(path.stat().st_size),
                "extension": "".join(path.suffixes).lower(),
                "modified_utc": datetime.fromtimestamp(path.stat().st_mtime, UTC).isoformat(),
                "compressed": bool(path.suffix.lower() in {".gz", ".zip"} or path.name.lower().endswith(".tar.gz")),
                "role": matched_specs[0].get("role", classify_file_role(path.name)) if len(matched_specs) == 1 else classify_file_role(path.name),
                "listed_in_frozen_manifest": bool(matched_specs),
                "duplicate_filename_within_dataset": False,
                "unknown_file": not bool(matched_specs),
                "zero_bytes": path.stat().st_size == 0,
                "unfinished_marker": path.name.lower().endswith(UNFINISHED_SUFFIXES),
            }
        )
    counts = Counter((record["dataset_id"], record["filename"]) for record in records)
    for record in records:
        record["duplicate_filename_within_dataset"] = counts[(record["dataset_id"], record["filename"])] > 1
    return records


def reconcile_frozen_manifest(data_root: str | Path, config: Mapping[str, Any], inventory: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Compare every frozen required file with the real read-only inventory."""
    root = Path(data_root)
    inventory_by_relative = {record["relative_path"]: record for record in inventory}
    records: list[dict[str, Any]] = []
    for dataset in config["datasets"]:
        directory = str(dataset["input_directory"])
        candidate_id = str(dataset["candidate_id"])
        for sample, file_spec in _iter_sample_specs(dataset):
            relative = f"{directory}/{file_spec['filename']}"
            present = inventory_by_relative.get(relative)
            if present is None:
                status = "MISSING"
            elif present["duplicate_filename_within_dataset"]:
                status = "DUPLICATED"
            elif file_spec.get("expected_bytes") is not None and int(file_spec["expected_bytes"]) != int(present["bytes"]):
                status = "PRESENT_SIZE_MISMATCH"
            elif sample.get("previous_qualification"):
                status = "PREVIOUSLY_VERIFIED"
            else:
                status = "PRESENT_AND_MATCHED"
            records.append(
                {
                    "dataset_id": candidate_id,
                    "sample_id": str(sample["sample_id"]),
                    "relative_path": relative,
                    "filename": str(file_spec["filename"]),
                    "required": bool(file_spec.get("required", False)),
                    "expected_bytes": file_spec.get("expected_bytes"),
                    "observed_bytes": present["bytes"] if present else None,
                    "role": file_spec.get("role", classify_file_role(str(file_spec["filename"]))),
                    "status": status,
                }
            )
    expected_paths = {record["relative_path"] for record in records}
    for record in inventory:
        if record["relative_path"] not in expected_paths:
            records.append(
                {
                    "dataset_id": record["dataset_id"],
                    "sample_id": record["sample_id"],
                    "relative_path": record["relative_path"],
                    "filename": record["filename"],
                    "required": False,
                    "expected_bytes": None,
                    "observed_bytes": record["bytes"],
                    "role": record["role"],
                    "status": "UNEXPECTED_FILE",
                }
            )
    return sorted(records, key=lambda item: (str(item["dataset_id"]), str(item["sample_id"]), str(item["relative_path"])))


def _hash_file(path: Path, algorithm: str) -> str:
    digest = hashlib.new(algorithm)
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _gzip_integrity(path: Path) -> dict[str, Any]:
    uncompressed_bytes = 0
    with gzip.open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            uncompressed_bytes += len(block)
    return {"gzip_stream_complete": True, "uncompressed_bytes": uncompressed_bytes}


def _tar_integrity(path: Path) -> dict[str, Any]:
    with tarfile.open(path, "r:gz") as archive:
        members = [member for member in archive.getmembers() if member.isfile()]
    names = [member.name for member in members]
    return {
        "tar_stream_complete": True,
        "regular_member_count": len(names),
        "contains_tissue_positions": any("tissue_positions" in name.lower() for name in names),
        "members": names,
    }


def inspect_file_integrity(path: str | Path) -> dict[str, Any]:
    """Run a minimum format check without creating an extracted copy."""
    file_path = Path(path)
    name = file_path.name.lower()
    result: dict[str, Any] = {"readable": True, "format": "opaque"}
    try:
        if name.endswith(".tar.gz") or name.endswith(".tgz"):
            result = {"readable": True, "format": "tar_gzip", **_tar_integrity(file_path)}
        elif name.endswith(".csv.gz"):
            result = {"readable": True, "format": "gzip_csv", **_gzip_integrity(file_path)}
        elif name.endswith(".h5"):
            with h5py.File(file_path, "r") as handle:
                result = {"readable": True, "format": "hdf5", "top_level_groups": sorted(handle.keys())}
        elif name.endswith(".parquet"):
            pd.read_parquet(file_path, columns=[])
            result = {"readable": True, "format": "parquet"}
        elif name.endswith(".json"):
            json.loads(file_path.read_text(encoding="utf-8"))
            result = {"readable": True, "format": "json"}
    except Exception as error:  # One file must not abort the remaining samples.
        result = {"readable": False, "format": "unreadable", "error": str(error)}
    return result


def calculate_checksums_and_integrity(
    data_root: str | Path,
    config: Mapping[str, Any],
    inventory: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Hash all scanned inputs and compare only checksums declared by the frozen config."""
    root = Path(data_root)
    _, directories = _expected_file_lookup(config)
    declared: dict[tuple[str, str], Mapping[str, Any]] = {}
    for dataset in config["datasets"]:
        for _sample, file_spec in _iter_sample_specs(dataset):
            declared[(str(dataset["candidate_id"]), str(file_spec["filename"]))] = file_spec
    records: list[dict[str, Any]] = []
    for item in inventory:
        path = root / item["relative_path"]
        candidate_id = item["dataset_id"]
        spec = declared.get((candidate_id, path.name))
        expected_sha = spec.get("expected_sha256") if spec else None
        official = spec.get("official_checksum") if spec else None
        observed_sha = sha256_file(path)
        official_observed = None
        official_match: bool | None = None
        if isinstance(official, Mapping):
            algorithm = str(official.get("algorithm", "")).lower()
            official_observed = _hash_file(path, algorithm)
            official_match = official_observed.lower() == str(official.get("value", "")).lower()
        integrity = inspect_file_integrity(path)
        records.append(
            {
                "dataset_id": candidate_id,
                "sample_id": item["sample_id"],
                "relative_path": item["relative_path"],
                "filename": path.name,
                "bytes": int(path.stat().st_size),
                "sha256": observed_sha,
                "expected_sha256": expected_sha,
                "sha256_match": observed_sha.lower() == str(expected_sha).lower() if expected_sha else None,
                "official_checksum_algorithm": official.get("algorithm") if isinstance(official, Mapping) else None,
                "official_checksum_expected": official.get("value") if isinstance(official, Mapping) else None,
                "official_checksum_observed": official_observed,
                "official_checksum_match": official_match,
                "integrity": integrity,
            }
        )
    return sorted(records, key=lambda item: item["relative_path"])


def _decode_strings(values: np.ndarray) -> tuple[str, ...]:
    return tuple(value.decode("utf-8") if isinstance(value, bytes) else str(value) for value in np.ravel(values))


def inspect_sparse_10x_h5(path: str | Path) -> dict[str, Any]:
    """Inspect a 10x sparse HDF5 matrix while preserving its raw orientation."""
    file_path = Path(path)
    with h5py.File(file_path, "r") as handle:
        if "matrix" not in handle:
            raise FinalExternalInputQualificationError(f"10x matrix group is missing: {file_path.name}")
        matrix = handle["matrix"]
        required = {"shape", "barcodes", "data", "indices", "indptr"}
        missing = sorted(name for name in required if name not in matrix)
        if missing:
            raise FinalExternalInputQualificationError(f"10x matrix schema is missing {missing}: {file_path.name}")
        shape = tuple(int(value) for value in matrix["shape"][()])
        if len(shape) != 2 or min(shape) < 1:
            raise FinalExternalInputQualificationError(f"10x matrix shape is invalid: {file_path.name}")
        gene_count, unit_count = shape
        unit_ids = _decode_strings(np.asarray(matrix["barcodes"][()]))
        if len(unit_ids) != unit_count:
            raise FinalExternalInputQualificationError(f"10x barcode count does not match matrix columns: {file_path.name}")
        if "features" not in matrix or "id" not in matrix["features"]:
            raise FinalExternalInputQualificationError(f"10x feature identifiers are missing: {file_path.name}")
        gene_ids = _decode_strings(np.asarray(matrix["features"]["id"][()]))
        if len(gene_ids) != gene_count:
            raise FinalExternalInputQualificationError(f"10x feature count does not match matrix rows: {file_path.name}")
        indptr = np.asarray(matrix["indptr"][()])
        if len(indptr) != unit_count + 1 or int(indptr[-1]) != int(matrix["data"].shape[0]):
            raise FinalExternalInputQualificationError(f"10x sparse index pointers are invalid: {file_path.name}")
        all_zero_units = int(np.count_nonzero(np.diff(indptr) == 0))
        all_zero_genes = np.ones(gene_count, dtype=bool)
        has_negative = False
        has_nonfinite = False
        data_dataset = matrix["data"]
        index_dataset = matrix["indices"]
        for start in range(0, int(data_dataset.shape[0]), 1_000_000):
            stop = min(start + 1_000_000, int(data_dataset.shape[0]))
            values = np.asarray(data_dataset[start:stop])
            indices = np.asarray(index_dataset[start:stop])
            if np.issubdtype(values.dtype, np.floating):
                has_nonfinite = has_nonfinite or not bool(np.isfinite(values).all())
            has_negative = has_negative or bool((values < 0).any())
            if indices.size:
                if int(indices.min()) < 0 or int(indices.max()) >= gene_count:
                    raise FinalExternalInputQualificationError(f"10x feature indices are out of range: {file_path.name}")
                all_zero_genes[indices] = False
        return {
            "expression_format": "10x_h5_sparse_csc",
            "raw_expression_orientation": "features_by_units",
            "unit_count": unit_count,
            "gene_count": gene_count,
            "nnz": int(data_dataset.shape[0]),
            "sparsity": float(1.0 - int(data_dataset.shape[0]) / (gene_count * unit_count)),
            "data_type": str(data_dataset.dtype),
            "negative_values": has_negative,
            "nonfinite_values": has_nonfinite,
            "duplicate_unit_ids": len(unit_ids) != len(set(unit_ids)),
            "duplicate_gene_ids": len(gene_ids) != len(set(gene_ids)),
            "all_zero_units": all_zero_units,
            "all_zero_genes": int(all_zero_genes.sum()),
            "unit_ids": unit_ids,
            "gene_ids": gene_ids,
        }


def _coordinates_from_parquet(path: str | Path) -> CoordinateTable:
    table = pd.read_parquet(path)
    columns = {str(column).lower(): str(column) for column in table.columns}
    id_column = next((columns[key] for key in ("cell_id", "cellid", "barcode", "cell", "id") if key in columns), None)
    x_column = next((columns[key] for key in ("x_centroid", "x_centroid_in_pixels", "x", "x_location") if key in columns), None)
    y_column = next((columns[key] for key in ("y_centroid", "y_centroid_in_pixels", "y", "y_location") if key in columns), None)
    if id_column is None or x_column is None or y_column is None:
        raise FinalExternalInputQualificationError(f"Could not find identifier/x/y columns in {Path(path).name}")
    values = table[[x_column, y_column]].to_numpy(dtype=float)
    return CoordinateTable(tuple(table[id_column].astype(str).tolist()), values, id_column, x_column, y_column)


def _coordinates_from_visium_tar(path: str | Path) -> CoordinateTable:
    with tarfile.open(path, "r:gz") as archive:
        members = [member for member in archive.getmembers() if member.isfile() and "tissue_positions" in member.name.lower()]
        if len(members) != 1:
            raise FinalExternalInputQualificationError(f"Expected exactly one tissue-position table in {Path(path).name}")
        raw = archive.extractfile(members[0])
        if raw is None:
            raise FinalExternalInputQualificationError(f"Could not read tissue-position table in {Path(path).name}")
        text = io.TextIOWrapper(raw, encoding="utf-8", newline="")
        rows = list(csv.reader(text))
    if not rows:
        raise FinalExternalInputQualificationError(f"Tissue-position table is empty in {Path(path).name}")
    header = [value.lower() for value in rows[0]]
    has_header = "barcode" in header or "pxl_row_in_fullres" in header
    if has_header:
        body = rows[1:]
        id_index = header.index("barcode") if "barcode" in header else 0
        x_index = header.index("pxl_col_in_fullres") if "pxl_col_in_fullres" in header else header.index("array_col")
        y_index = header.index("pxl_row_in_fullres") if "pxl_row_in_fullres" in header else header.index("array_row")
        id_column, x_column, y_column = rows[0][id_index], rows[0][x_index], rows[0][y_index]
    else:
        body = rows
        if len(rows[0]) < 6:
            raise FinalExternalInputQualificationError(f"Headerless tissue-position table is too narrow: {Path(path).name}")
        id_index, y_index, x_index = 0, 4, 5
        id_column, x_column, y_column = "column_0", "column_5", "column_4"
    identifiers: list[str] = []
    coordinates: list[tuple[float, float]] = []
    for row_number, row in enumerate(body, start=2 if has_header else 1):
        if len(row) <= max(id_index, x_index, y_index):
            raise FinalExternalInputQualificationError(f"Malformed tissue-position row {row_number}: {Path(path).name}")
        identifier = row[id_index]
        if not identifier:
            raise FinalExternalInputQualificationError(f"Missing tissue-position identifier at row {row_number}: {Path(path).name}")
        try:
            x, y = float(row[x_index]), float(row[y_index])
        except ValueError as error:
            raise FinalExternalInputQualificationError(f"Unreadable tissue-position coordinate at row {row_number}: {Path(path).name}") from error
        identifiers.append(identifier)
        coordinates.append((x, y))
    return CoordinateTable(tuple(identifiers), np.asarray(coordinates, dtype=float), id_column, x_column, y_column)


def _alignment_summary(unit_ids: tuple[str, ...], coordinate: CoordinateTable) -> dict[str, Any]:
    expression_set = set(unit_ids)
    coordinate_set = set(coordinate.identifiers)
    expression_unique = len(unit_ids) == len(expression_set)
    coordinate_unique = len(coordinate.identifiers) == len(coordinate_set)
    finite = bool(np.isfinite(coordinate.coordinates).all())
    coordinate_lookup = dict(zip(coordinate.identifiers, coordinate.coordinates, strict=True)) if coordinate_unique else {}
    expression_only = sorted(expression_set.difference(coordinate_set))
    coordinate_only = sorted(coordinate_set.difference(expression_set))
    matched = np.asarray([coordinate_lookup[item] for item in unit_ids if item in coordinate_lookup], dtype=float)
    duplicate_coordinates = bool(len({(float(x), float(y)) for x, y in coordinate.coordinates}) != len(coordinate.coordinates))
    return {
        "expression_id_count": len(unit_ids),
        "coordinate_id_count": len(coordinate.identifiers),
        "intersection_count": len(expression_set.intersection(coordinate_set)),
        "expression_only_count": len(expression_only),
        "coordinate_only_count": len(coordinate_only),
        "expression_ids_unique": expression_unique,
        "coordinate_ids_unique": coordinate_unique,
        "coordinates_finite": finite,
        "duplicate_coordinates": duplicate_coordinates,
        "id_normalization_rule": "identity",
        "id_alignment_status": "PASS" if expression_unique and coordinate_unique and finite and not expression_only else "FAIL",
        "matched_coordinates": matched,
        "coordinate_id_column": coordinate.id_column,
        "x_coordinate_column": coordinate.x_column,
        "y_coordinate_column": coordinate.y_column,
        "x_range": [float(coordinate.coordinates[:, 0].min()), float(coordinate.coordinates[:, 0].max())],
        "y_range": [float(coordinate.coordinates[:, 1].min()), float(coordinate.coordinates[:, 1].max())],
    }


def _summarize_visium_hd(path: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    from .batch2_qualification import inspect_visium_hd_feature_slice_h5

    summary = inspect_visium_hd_feature_slice_h5(path)
    coordinate = CoordinateTable(
        tuple(summary.pop("embedded_coordinate_ids")),
        np.asarray(summary.pop("embedded_coordinates"), dtype=float),
        "published_row:column",
        "published_col",
        "published_row",
    )
    unit_ids = tuple(summary.pop("unit_ids"))
    expression = {
        "expression_format": summary["format"],
        "raw_expression_orientation": "feature_slices_by_embedded_bins",
        "unit_count": summary["unit_count"],
        "gene_count": summary["gene_count"],
        "nnz": "NOT_EVALUATED_FROM_FEATURE_SLICES",
        "sparsity": "NOT_EVALUATED_FROM_FEATURE_SLICES",
        "data_type": "sparse_feature_slices",
        "negative_values": "NOT_EVALUATED_FROM_FEATURE_SLICES",
        "nonfinite_values": "NOT_EVALUATED_FROM_FEATURE_SLICES",
        "duplicate_unit_ids": not summary["unit_ids_unique"],
        "duplicate_gene_ids": "NOT_EVALUATED_FROM_FEATURE_SLICES",
        "all_zero_units": summary["zero_expression_units"],
        "all_zero_genes": "NOT_EVALUATED_FROM_FEATURE_SLICES",
    }
    return expression, _alignment_summary(unit_ids, coordinate)


def _adapter_summary(dataset: Mapping[str, Any], sample: Mapping[str, Any], directory: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    adapter = str(dataset["adapter"])
    files = {str(item["filename"]): directory / str(item["filename"]) for item in sample["files"]}
    if adapter == "xenium_h5_parquet":
        expression_path = next(path for name, path in files.items() if name.endswith(".h5"))
        coordinate_path = next(path for name, path in files.items() if name.endswith("cells.parquet"))
        expression = inspect_sparse_10x_h5(expression_path)
        unit_ids = expression.pop("unit_ids")
        expression.pop("gene_ids")
        return expression, _alignment_summary(unit_ids, _coordinates_from_parquet(coordinate_path))
    if adapter == "visium_h5_spatial_tar":
        expression_path = next(path for name, path in files.items() if name.endswith(".h5"))
        coordinate_path = next(path for name, path in files.items() if name.endswith(".tar.gz"))
        expression = inspect_sparse_10x_h5(expression_path)
        unit_ids = expression.pop("unit_ids")
        expression.pop("gene_ids")
        return expression, _alignment_summary(unit_ids, _coordinates_from_visium_tar(coordinate_path))
    if adapter == "visium_hd_feature_slice":
        expression_path = next(path for name, path in files.items() if name.endswith(".h5"))
        return _summarize_visium_hd(expression_path)
    if adapter == "slideseqv2_gzip_csv":
        coordinate_name = next(name for name in files if "BeadLocationsForR" in name)
        expression_name = next(name for name in files if "MappedDGEForR" in name)
        expected = {str(item["filename"]): str(item["expected_sha256"]) for item in sample["files"] if item.get("expected_sha256")}
        puck_id = coordinate_name.split("_BeadLocationsForR", 1)[0].split("_", 1)[-1]
        loaded = load_slideseqv2_pair(
            directory,
            coordinate_filename=coordinate_name,
            expression_filename=expression_name,
            sample_accession=str(sample["sample_id"]),
            puck_id=puck_id,
            expected_sha256=expected or None,
            verify_checksums=True,
        )
        raw = loaded.structural_summary
        expression = {
            "expression_format": "gzip_csv_sparse_in_memory",
            "raw_expression_orientation": loaded.raw_expression_orientation,
            "unit_count": int(loaded.counts.shape[0]),
            "gene_count": int(loaded.counts.shape[1]),
            "nnz": int(loaded.counts.nnz),
            "sparsity": raw["expression"]["sparsity"],
            "data_type": str(loaded.counts.dtype),
            "negative_values": False,
            "nonfinite_values": False,
            "duplicate_unit_ids": len(loaded.unit_ids) != len(set(loaded.unit_ids)),
            "duplicate_gene_ids": len(loaded.gene_ids) != len(set(loaded.gene_ids)),
            "all_zero_units": raw["expression"]["all_zero_bead_count"],
            "all_zero_genes": raw["expression"]["all_zero_gene_count"],
            "gzip": raw["gzip"],
        }
        coordinate = CoordinateTable(loaded.unit_ids, loaded.coordinates, "barcodes", "xcoord", "ycoord")
        return expression, _alignment_summary(loaded.unit_ids, coordinate)
    raise FinalExternalInputQualificationError(f"Unsupported frozen adapter: {adapter}")


def _sample_file_records(
    dataset: Mapping[str, Any],
    sample: Mapping[str, Any],
    data_root: Path,
    checksums: Mapping[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    directory = str(dataset["input_directory"])
    records: list[dict[str, Any]] = []
    for spec in sample["files"]:
        relative = f"{directory}/{spec['filename']}"
        record = checksums.get(relative)
        if record is None:
            records.append({"filename": spec["filename"], "relative_path": relative, "missing": True})
        else:
            records.append(dict(record))
    return records


def _sample_status(
    dataset: Mapping[str, Any],
    sample: Mapping[str, Any],
    file_records: list[dict[str, Any]],
    expression: dict[str, Any] | None,
    alignment: dict[str, Any] | None,
    feasibility: list[dict[str, Any]] | None,
    adapter_error: Exception | None,
) -> tuple[str, list[str]]:
    if any(item.get("missing") for item in file_records):
        return "HOLD_INPUT_MISSING", ["A frozen required input file is missing."]
    if any(item.get("sha256_match") is False or item.get("official_checksum_match") is False for item in file_records):
        return "HOLD_CHECKSUM", ["A declared checksum did not match the downloaded file."]
    if any(not item.get("integrity", {}).get("readable", False) for item in file_records):
        compressed = any(item.get("filename", "").endswith((".gz", ".tgz")) for item in file_records)
        return ("HOLD_ARCHIVE_INTEGRITY" if compressed else "HOLD_INPUT_FORMAT"), ["A required input file is not readable."]
    if adapter_error is not None:
        message = str(adapter_error).lower()
        identifier_failure = any(
            phrase in message
            for phrase in ("identifier", "one-to-one intersection", "bead identifiers")
        )
        if identifier_failure:
            return "HOLD_ID_ALIGNMENT", [str(adapter_error)]
        return "HOLD_INPUT_FORMAT", [str(adapter_error)]
    if expression is None or alignment is None or feasibility is None:
        return "HOLD_INPUT_FORMAT", ["The input adapter returned no structural summary."]
    if expression.get("negative_values") is True or expression.get("nonfinite_values") is True:
        return "HOLD_INPUT_FORMAT", ["The expression matrix has negative or non-finite values."]
    if expression.get("duplicate_unit_ids") is True or expression.get("duplicate_gene_ids") is True:
        return "HOLD_INPUT_FORMAT", ["Expression identifiers are not unique."]
    if alignment.get("id_alignment_status") != "PASS":
        return "HOLD_ID_ALIGNMENT", ["Expression and spatial identifiers do not have an exact identity-based join."]
    if sum(bool(row["input_structurally_feasible"]) for row in feasibility) < 3:
        return "HOLD_STRUCTURAL_FEASIBILITY", ["Fewer than three frozen sample fractions are structurally feasible."]
    if str(dataset.get("license_status", "")).upper() in {"UNKNOWN", "NOT_REPORTED"}:
        return "HOLD_LICENSE", ["Frozen license evidence is not sufficient."]
    if bool(dataset.get("limited_endpoints", False)):
        return "SAMPLE_INPUT_FULLY_QUALIFIED_LIMITED_ENDPOINTS", ["Input is valid with frozen endpoint limitations."]
    return "SAMPLE_INPUT_FULLY_QUALIFIED", ["Frozen input checks passed."]


def qualify_sample(
    dataset: Mapping[str, Any],
    sample: Mapping[str, Any],
    data_root: str | Path,
    checksums: Mapping[str, dict[str, Any]],
) -> dict[str, Any]:
    """Qualify one sample independently; no failure is allowed to abort its peers."""
    root = Path(data_root)
    file_records = _sample_file_records(dataset, sample, root, checksums)
    expression: dict[str, Any] | None = None
    alignment: dict[str, Any] | None = None
    feasibility: list[dict[str, Any]] | None = None
    adapter_error: Exception | None = None
    if not any(item.get("missing") for item in file_records):
        try:
            expression, alignment = _adapter_summary(dataset, sample, root / str(dataset["input_directory"]))
            matched = np.asarray(alignment.pop("matched_coordinates"), dtype=float)
            strata = positive_quadrants(matched)
            feasibility = sampling_feasibility(int(expression["unit_count"]), strata)
        except Exception as error:  # Keep all other samples auditable after one failure.
            adapter_error = error
            strata = 0
    else:
        strata = 0
    status, reasons = _sample_status(dataset, sample, file_records, expression, alignment, feasibility, adapter_error)
    capability = {
        "representation_expression_state_coverage": expression is not None,
        "representation_spatial_coverage": alignment is not None and alignment.get("id_alignment_status") == "PASS",
        "representation_label_endpoints": bool(dataset.get("labels_available", False)),
        "inference_gene_total_and_mean": expression is not None,
        "inference_label_proportions": bool(dataset.get("labels_available", False)),
        "targeted_panel_limited_endpoints": bool(dataset.get("targeted_panel", False)),
    }
    return {
        "dataset_id": dataset["candidate_id"],
        "sample_id": sample["sample_id"],
        "animal_id": sample.get("animal_id"),
        "pool_role": dataset["pool_role"],
        "platform": dataset["platform"],
        "platform_paradigm": dataset["platform_paradigm"],
        "measurement_unit": dataset["measurement_unit"],
        "sample_hierarchy": sample["sample_hierarchy"],
        "status": status,
        "reasons": reasons,
        "file_records": file_records,
        "expression": expression,
        "alignment": alignment,
        "positive_spatial_strata": strata,
        "structural_feasibility": feasibility,
        "capability": capability,
        "sampler_run": False,
        "benchmark_run": False,
        "normalization_run": False,
        "pca_run": False,
        "umap_run": False,
        "clustering_run": False,
        "batch_correction_run": False,
    }


class AppendOnlyQualificationStore:
    """Small SSHFS-safe event and sample-record publisher for input qualification."""

    def __init__(self, result_root: str | Path) -> None:
        self.root = Path(result_root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.samples = self.root / "samples"
        self.samples.mkdir(exist_ok=True)
        self.events = self.root / "events.jsonl"

    def append_event(self, event: Mapping[str, Any]) -> None:
        payload = {"at": utc_now(), **dict(event)}
        with self.events.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(payload, sort_keys=True))
            handle.write("\n")

    @staticmethod
    def _sample_filename(dataset_id: str, sample_id: str) -> str:
        return f"{dataset_id}__{sample_id}.json".replace("/", "_").replace("\\", "_")

    def load_or_publish_sample(self, record: Mapping[str, Any]) -> tuple[dict[str, Any], bool]:
        path = self.samples / self._sample_filename(str(record["dataset_id"]), str(record["sample_id"]))
        if path.exists():
            payload = json.loads(path.read_text(encoding="utf-8"))
            self.append_event({"event": "resume_detected", "sample_record": path.name})
            return payload, True
        payload = dict(record)
        payload["published_at"] = utc_now()
        with path.open("x", encoding="utf-8", newline="\n") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
            handle.write("\n")
        self.append_event({"event": "sample_published", "sample_record": path.name, "status": record["status"]})
        return payload, False

    def publish_completion(self, summary: Mapping[str, Any]) -> Path:
        stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
        path = self.root / f"_SUCCESS_{stamp}.json"
        payload = {"published_at": utc_now(), "overwrite_prohibited": True, "summary": dict(summary)}
        with path.open("x", encoding="utf-8", newline="\n") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
            handle.write("\n")
        self.append_event({"event": "batch_complete", "completion_marker": path.name})
        return path


def aggregate_dataset_status(dataset: Mapping[str, Any], sample_records: list[Mapping[str, Any]]) -> dict[str, Any]:
    """Aggregate fixed samples without substituting one sample for an entire dataset."""
    statuses = [str(item["status"]) for item in sample_records]
    held_statuses = sorted({status for status in statuses if status not in SAMPLE_SUCCESS})
    if not sample_records:
        final_status = "HOLD_INPUT_MISSING"
    elif all(status in SAMPLE_SUCCESS for status in statuses):
        final_status = "FULLY_QUALIFIED_LIMITED_ENDPOINTS" if bool(dataset.get("limited_endpoints", False)) else "FULLY_QUALIFIED"
    elif any(status == "HOLD_ID_ALIGNMENT" for status in statuses):
        final_status = "HOLD_ID_ALIGNMENT"
    elif any(status == "HOLD_INPUT_MISSING" for status in statuses):
        final_status = "HOLD_INPUT_MISSING"
    else:
        # The dataset-level vocabulary has no separate format or size hold.
        # Keep the exact sample-level hold and avoid falsely attributing it to metadata or licensing.
        final_status = "REMAINS_CONDITIONALLY_QUALIFIED"
    success = sum(status in SAMPLE_SUCCESS for status in statuses)
    if held_statuses:
        primary_limitation = "sample_status:" + ",".join(held_statuses)
    elif dataset.get("targeted_panel"):
        primary_limitation = "targeted_panel"
    else:
        primary_limitation = "label_endpoints_not_supplied"
    return {
        "dataset_id": dataset["candidate_id"],
        "pool_role": dataset["pool_role"],
        "final_status": final_status,
        "frozen_sample_count": len(dataset["samples"]),
        "successful_sample_count": success,
        "failed_sample_count": len(dataset["samples"]) - success,
        "independent_donor_or_animal_count": dataset["independent_donor_or_animal_count"],
        "usable_fraction": float(success / len(dataset["samples"])) if dataset["samples"] else 0.0,
        "platform": dataset["platform"],
        "platform_paradigm": dataset["platform_paradigm"],
        "species": dataset["species"],
        "tissue_or_disease": dataset["tissue_or_disease"],
        "measurement_unit": dataset["measurement_unit"],
        "targeted_panel": bool(dataset["targeted_panel"]),
        "representation_capability": all(item["capability"]["representation_spatial_coverage"] for item in sample_records),
        "inference_capability": all(item["capability"]["inference_gene_total_and_mean"] for item in sample_records),
        "primary_limitation": primary_limitation,
        "sample_hold_statuses": held_statuses,
    }


def diversity_summary(dataset_records: list[Mapping[str, Any]], non_enrolled: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
    """Count only qualified formal candidates in the benchmark-readiness gate."""
    formal = [record for record in dataset_records if record["final_status"] in DATASET_SUCCESS]
    platform_counts = Counter(str(record["platform"]) for record in formal)
    paradigms = {str(record["platform_paradigm"]) for record in formal}
    tissues = {str(record["tissue_or_disease"]) for record in formal}
    counts = Counter(str(record["species"]) for record in formal)
    measurement = Counter(str(record["measurement_unit"]) for record in formal)
    stress = sum(str(item.get("final_status")) == "STRESS_TEST_ONLY" for item in non_enrolled)
    hold = sum(str(item.get("final_status", "")).startswith("HOLD") for item in non_enrolled)
    development = sum(str(item.get("final_status")) == "DEVELOPMENT_ONLY" for item in non_enrolled)
    largest_platform = max(platform_counts.values(), default=0)
    return {
        "fully_qualified_count": sum(record["final_status"] == "FULLY_QUALIFIED" for record in dataset_records),
        "fully_qualified_limited_endpoints_count": sum(record["final_status"] == "FULLY_QUALIFIED_LIMITED_ENDPOINTS" for record in dataset_records),
        "conditionally_qualified_count": sum(
            record["final_status"] == "REMAINS_CONDITIONALLY_QUALIFIED" for record in dataset_records
        ),
        "formal_external_dataset_count": len(formal),
        "stress_test_only_count": stress,
        "hold_count": hold + sum(str(record["final_status"]).startswith("HOLD") for record in dataset_records),
        "development_only_count": development,
        "platform_paradigm_count": len(paradigms),
        "tissue_or_disease_background_count": len(tissues),
        "human_dataset_count": counts["human"],
        "mouse_dataset_count": counts["mouse"],
        "single_cell_resolution_dataset_count": sum(record["measurement_unit"] == "cell" for record in formal),
        "spot_based_dataset_count": sum(record["platform_paradigm"] == "spot_based" for record in formal),
        "high_density_bead_or_bin_dataset_count": sum(
            record["platform_paradigm"] in {"high_density_bin_based", "bead_based_high_resolution"} for record in formal
        ),
        "targeted_panel_dataset_count": sum(bool(record["targeted_panel"]) for record in formal),
        "whole_transcriptome_dataset_count": sum(not bool(record["targeted_panel"]) for record in formal),
        "largest_platform_dataset_count": largest_platform,
        "single_platform_not_more_than_half": largest_platform * 2 <= len(formal) if formal else False,
    }


def readiness_decision(diversity: Mapping[str, Any]) -> str:
    """Apply the frozen benchmark-input gate without evaluating any method."""
    checks = (
        diversity["formal_external_dataset_count"] >= 6,
        diversity["platform_paradigm_count"] >= 3,
        diversity["tissue_or_disease_background_count"] >= 4,
        diversity["single_cell_resolution_dataset_count"] >= 2,
        diversity["spot_based_dataset_count"] >= 1,
        diversity["high_density_bead_or_bin_dataset_count"] >= 1,
        diversity["human_dataset_count"] >= 1,
        diversity["single_platform_not_more_than_half"],
    )
    return "READY_TO_FREEZE_FORMAL_BENCHMARK_INPUTS" if all(checks) else "NEED_TARGETED_INPUT_REPAIR"


def summarize_batch_records(
    config: Mapping[str, Any],
    *,
    inventory: list[Mapping[str, Any]],
    reconciliation: list[Mapping[str, Any]],
    checksums: list[Mapping[str, Any]],
    samples: list[Mapping[str, Any]],
) -> dict[str, Any]:
    """Summarize existing sample records without rereading external inputs."""
    validate_frozen_batch_config(config)
    dataset_records = [
        aggregate_dataset_status(dataset, [record for record in samples if record["dataset_id"] == dataset["candidate_id"]])
        for dataset in config["datasets"]
    ]
    diversity = diversity_summary(dataset_records, config.get("non_enrolled_records", []))
    return {
        "batch_id": config["batch_id"],
        "inventory": list(inventory),
        "reconciliation": list(reconciliation),
        "checksums": list(checksums),
        "samples": [dict(record) for record in samples],
        "datasets": dataset_records,
        "diversity": diversity,
        "final_decision": readiness_decision(diversity),
        "sampler_run": False,
        "benchmark_run": False,
        "normalization_run": False,
        "pca_run": False,
        "umap_run": False,
        "clustering_run": False,
        "batch_correction_run": False,
    }


def run_batch_qualification(
    config: Mapping[str, Any],
    *,
    data_root: str | Path,
    result_root: str | Path,
) -> dict[str, Any]:
    """Run the complete read-only batch and publish independent append-only records."""
    validate_frozen_batch_config(config)
    inventory = scan_actual_inventory(data_root, config)
    reconciliation = reconcile_frozen_manifest(data_root, config, inventory)
    checksums = calculate_checksums_and_integrity(data_root, config, inventory)
    checksum_by_path = {record["relative_path"]: record for record in checksums}
    store = AppendOnlyQualificationStore(result_root)
    store.append_event({"event": "batch_started", "batch_id": config["batch_id"], "sampler_run": False, "benchmark_run": False})
    samples: list[dict[str, Any]] = []
    for dataset in config["datasets"]:
        for sample in dataset["samples"]:
            record = qualify_sample(dataset, sample, data_root, checksum_by_path)
            published, resumed = store.load_or_publish_sample(record)
            if resumed:
                published["resumed_without_overwrite"] = True
            samples.append(published)
    summary = summarize_batch_records(
        config,
        inventory=inventory,
        reconciliation=reconciliation,
        checksums=checksums,
        samples=samples,
    )
    marker = store.publish_completion(
        {"batch_id": config["batch_id"], "final_decision": summary["final_decision"], "sample_count": len(samples)}
    )
    summary["completion_marker"] = marker.name
    return summary


def _canonical_yaml(payload: Mapping[str, Any]) -> str:
    return yaml.safe_dump(dict(payload), allow_unicode=False, sort_keys=False)


def write_yaml_new_or_equal(path: str | Path, payload: Mapping[str, Any], *, allow_explicit_local_refresh: bool = False) -> None:
    """Create a small artifact, allowing replacement only for an explicit local summary refresh."""
    target = Path(path)
    content = _canonical_yaml(payload)
    if target.exists():
        if target.read_text(encoding="utf-8") != content:
            if not allow_explicit_local_refresh:
                raise FileExistsError(f"Refusing to replace non-identical frozen artifact: {target}")
            with target.open("w", encoding="utf-8", newline="\n") as handle:
                handle.write(content)
        return
    with target.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(content)


def write_text_new_or_equal(path: str | Path, content: str, *, allow_explicit_local_refresh: bool = False) -> None:
    """Create a text artifact, allowing replacement only for an explicit local summary refresh."""
    target = Path(path)
    normalized = content.replace("\r\n", "\n").replace("\r", "\n")
    if target.exists():
        if target.read_text(encoding="utf-8") != normalized:
            if not allow_explicit_local_refresh:
                raise FileExistsError(f"Refusing to replace non-identical frozen artifact: {target}")
            with target.open("w", encoding="utf-8", newline="\n") as handle:
                handle.write(normalized)
        return
    with target.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(normalized)


def config_artifacts(summary: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
    """Build compact, path-relative artifacts suitable for version control."""
    inventory = summary["inventory"]
    reconciliation = summary["reconciliation"]
    checksums = summary["checksums"]
    datasets = summary["datasets"]
    samples = []
    for sample in summary["samples"]:
        stable = dict(sample)
        stable.pop("published_at", None)
        stable.pop("resumed_without_overwrite", None)
        samples.append(stable)
    return {
        "inventory": {
            "schema_version": 1,
            "batch_id": summary["batch_id"],
            "actual_file_count": len(inventory),
            "actual_total_bytes": sum(int(item["bytes"]) for item in inventory),
            "files": inventory,
            "manifest_reconciliation": reconciliation,
        },
        "checksums": {
            "schema_version": 1,
            "batch_id": summary["batch_id"],
            "algorithm": "sha256",
            "files": checksums,
        },
        "status": {
            "schema_version": 1,
            "batch_id": summary["batch_id"],
            "samples": samples,
            "datasets": datasets,
            "diversity": summary["diversity"],
            "final_decision": summary["final_decision"],
            "analysis_actions": {
                "sampler_run": False,
                "benchmark_run": False,
                "normalization_run": False,
                "pca_run": False,
                "umap_run": False,
                "clustering_run": False,
                "batch_correction_run": False,
            },
        },
    }
