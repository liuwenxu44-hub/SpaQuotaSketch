"""Lossless readers and integrity checks for externally qualified inputs.

This package deliberately does not import samplers, metrics, or benchmark
code.  It is limited to download integrity and input-structure auditing.
"""

from .input_qualification import (
    FROZEN_FRACTIONS,
    audit_dataset_directory,
    copy_with_sha256_verification,
    create_non_overwriting_directory,
    record_download_failure,
    sha256_file,
)

__all__ = [
    "FROZEN_FRACTIONS",
    "audit_dataset_directory",
    "copy_with_sha256_verification",
    "create_non_overwriting_directory",
    "record_download_failure",
    "sha256_file",
]
