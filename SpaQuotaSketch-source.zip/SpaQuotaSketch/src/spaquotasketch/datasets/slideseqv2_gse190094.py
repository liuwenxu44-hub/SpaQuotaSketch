"""Lossless reader for the qualified Slide-seqV2 GSM5713337 input pair.

This module is deliberately an input adapter, not an analysis entry point.  It
checks the two published gzip CSV files, joins them by their explicit bead IDs,
and returns raw integer counts with coordinates.  It does not call a sampler or
perform expression transformation, dimension reduction, clustering, or any
downstream analysis.
"""

from __future__ import annotations

import csv
import gzip
import hashlib
import math
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import numpy as np
from scipy import sparse


DATASET_ID = "GSE190094"
SAMPLE_ACCESSION = "GSM5713337"
PUCK_ID = "Puck_191109_14"
SAMPLING_UNIT = "bead"
COORDINATE_FILENAME = "GSM5713337_Puck_191109_14_BeadLocationsForR.csv.gz"
EXPRESSION_FILENAME = "GSM5713337_Puck_191109_14_MappedDGEForR.csv.gz"
EXPECTED_SHA256 = {
    COORDINATE_FILENAME: "5bb331deda87df7374fedca920c616dc2376c7b3ff03aaee0c08cc1c3fe6486a",
    EXPRESSION_FILENAME: "5fd9deacc5c7b22a9afdd4b12a7c0adb8cfc4a6239d9861438e2db3d274a6b72",
}
IDENTIFIER_NORMALIZATION_RULE = "identity"


class SlideSeqV2InputError(ValueError):
    """Raised when the published pair cannot support an exact raw-data join."""


@dataclass(frozen=True)
class SlideSeqV2Input:
    """Raw, aligned Slide-seqV2 input with units in expression-header order."""

    unit_ids: tuple[str, ...]
    coordinates: np.ndarray
    gene_ids: tuple[str, ...]
    counts: sparse.csr_matrix
    raw_expression_orientation: str
    transpose_performed: bool
    identifier_normalization_rule: str
    structural_summary: dict[str, Any]


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    """Hash one file incrementally without materialising it in memory."""
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(chunk_size), b""):
            digest.update(block)
    return digest.hexdigest()


def normalize_unit_ids(values: Iterable[str], *, rule: str = IDENTIFIER_NORMALIZATION_RULE) -> tuple[str, ...]:
    """Apply the frozen identity rule and reject ambiguous identifiers.

    No trimming, case folding, prefix removal, or positional matching is
    permitted for this qualified input.  An exact identity join is therefore
    auditable and cannot create collisions silently.
    """
    if rule != IDENTIFIER_NORMALIZATION_RULE:
        raise SlideSeqV2InputError(f"Unsupported identifier normalization rule: {rule}")
    normalized = tuple(str(value) for value in values)
    if any(not value for value in normalized):
        raise SlideSeqV2InputError("Unit identifiers must be non-empty.")
    if len(normalized) != len(set(normalized)):
        raise SlideSeqV2InputError("Unit identifiers are not unique under the identity rule.")
    return normalized


def verify_slideseqv2_pair(
    data_directory: Path,
    *,
    coordinate_filename: str,
    expression_filename: str,
    expected_sha256: dict[str, str] | None = None,
    verify_checksums: bool = True,
) -> dict[str, Any]:
    """Check one published coordinate/expression pair without modifying it."""
    directory = Path(data_directory)
    if not directory.is_dir():
        raise FileNotFoundError(f"Slide-seqV2 input directory does not exist: {directory}")
    expected_names = {coordinate_filename, expression_filename}
    expected_checksums = expected_sha256 or {}
    regular_files = sorted(path for path in directory.iterdir() if path.is_file())
    present_names = {path.name for path in regular_files}
    missing = sorted(expected_names - present_names)
    if missing:
        raise FileNotFoundError(f"Missing required Slide-seqV2 input file(s): {missing}")

    temporary_suffixes = (".part", ".partial", ".tmp", ".download")
    temporary_files = sorted(path.name for path in regular_files if path.name.lower().endswith(temporary_suffixes))
    unexpected = sorted(path.name for path in regular_files if path.name not in expected_names and path.name not in temporary_files)
    duplicate_names = sorted(name for name, count in Counter(path.name for path in regular_files).items() if count > 1)
    records: list[dict[str, Any]] = []
    for name in sorted(expected_names):
        path = directory / name
        observed = sha256_file(path)
        expected = expected_checksums.get(name)
        record = {
            "filename": name,
            "bytes": path.stat().st_size,
            "sha256": observed,
            "expected_sha256": expected,
            "checksum_match": observed == expected if expected is not None else True,
            "regular_file": path.is_file(),
        }
        if verify_checksums and not record["checksum_match"]:
            raise SlideSeqV2InputError(f"CHECKSUM_MISMATCH for {name}")
        records.append(record)
    return {
        "required_files": records,
        "unexpected_regular_files": unexpected,
        "temporary_or_partial_files": temporary_files,
        "duplicate_filenames": duplicate_names,
    }


def verify_required_files(data_directory: Path, *, verify_checksums: bool = True) -> dict[str, Any]:
    """Check the frozen GSM5713337 two-file contract without modifying it."""
    return verify_slideseqv2_pair(
        data_directory,
        coordinate_filename=COORDINATE_FILENAME,
        expression_filename=EXPRESSION_FILENAME,
        expected_sha256=EXPECTED_SHA256,
        verify_checksums=verify_checksums,
    )


def verify_gzip_integrity(path: Path, chunk_size: int = 1024 * 1024) -> dict[str, Any]:
    """Read an entire gzip stream to validate its header, CRC, trailer, and UTF-8."""
    path = Path(path)
    header = path.read_bytes()[:10]
    if len(header) < 10 or header[:2] != b"\x1f\x8b" or header[2] != 8:
        raise SlideSeqV2InputError(f"Invalid gzip header: {path.name}")

    endings = Counter()
    pending_carriage_return = False
    uncompressed_bytes = 0
    with gzip.open(path, "rb") as handle:
        while block := handle.read(chunk_size):
            uncompressed_bytes += len(block)
            for byte in block:
                if pending_carriage_return:
                    if byte == 10:
                        endings["crlf"] += 1
                        pending_carriage_return = False
                        continue
                    endings["cr"] += 1
                    pending_carriage_return = False
                if byte == 13:
                    pending_carriage_return = True
                elif byte == 10:
                    endings["lf"] += 1
    if pending_carriage_return:
        endings["cr"] += 1

    text_lines = 0
    with gzip.open(path, "rt", encoding="utf-8", errors="strict", newline="") as handle:
        for _ in handle:
            text_lines += 1
    return {
        "gzip_magic": header[:2].hex(),
        "compression_method": int(header[2]),
        "header_flags": int(header[3]),
        "uncompressed_bytes": uncompressed_bytes,
        "text_encoding": "utf-8",
        "text_lines": text_lines,
        "line_endings": dict(sorted(endings.items())),
        "full_stream_crc_and_trailer_verified": True,
    }


def _read_coordinates(path: Path) -> tuple[tuple[str, ...], np.ndarray, dict[str, Any]]:
    with gzip.open(path, "rt", encoding="utf-8", errors="strict", newline="") as handle:
        reader = csv.DictReader(handle)
        required_columns = {"barcodes", "xcoord", "ycoord"}
        observed_columns = set(reader.fieldnames or [])
        if not required_columns.issubset(observed_columns):
            raise SlideSeqV2InputError(
                f"Coordinate columns must include {sorted(required_columns)}; observed {sorted(observed_columns)}."
            )
        raw_ids: list[str] = []
        coordinate_rows: list[tuple[float, float]] = []
        for row_number, row in enumerate(reader, start=2):
            raw_id = row["barcodes"]
            if raw_id is None or raw_id == "":
                raise SlideSeqV2InputError(f"Missing coordinate unit ID at CSV row {row_number}.")
            try:
                x = float(row["xcoord"])
                y = float(row["ycoord"])
            except (TypeError, ValueError) as error:
                raise SlideSeqV2InputError(f"Unreadable coordinate at CSV row {row_number}.") from error
            if not math.isfinite(x) or not math.isfinite(y):
                raise SlideSeqV2InputError(f"Non-finite coordinate at CSV row {row_number}.")
            raw_ids.append(raw_id)
            coordinate_rows.append((x, y))

    unit_ids = normalize_unit_ids(raw_ids)
    coordinates = np.asarray(coordinate_rows, dtype=np.float64)
    coordinate_pair_counts = Counter((float(x), float(y)) for x, y in coordinates)
    duplicate_pair_count = sum(count > 1 for count in coordinate_pair_counts.values())
    duplicate_pair_rows = sum(count - 1 for count in coordinate_pair_counts.values() if count > 1)
    summary = {
        "rows": len(unit_ids),
        "columns": ["barcodes", "xcoord", "ycoord"],
        "unit_id_column": "barcodes",
        "x_coordinate_column": "xcoord",
        "y_coordinate_column": "ycoord",
        "unique_unit_ids": len(unit_ids),
        "duplicate_coordinate_pairs": duplicate_pair_count,
        "duplicate_coordinate_rows": duplicate_pair_rows,
        "x_range": [float(coordinates[:, 0].min()), float(coordinates[:, 0].max())],
        "y_range": [float(coordinates[:, 1].min()), float(coordinates[:, 1].max())],
        "integer_like_coordinate_pairs_at_1e-8": int(
            np.isclose(coordinates, np.round(coordinates), atol=1e-8, rtol=0).all(axis=1).sum()
        ),
    }
    return unit_ids, coordinates, summary


def _expression_header(path: Path) -> tuple[str, tuple[str, ...]]:
    with gzip.open(path, "rt", encoding="utf-8", errors="strict", newline="") as handle:
        try:
            header = next(csv.reader([handle.readline().rstrip("\r\n")]))
        except StopIteration as error:
            raise SlideSeqV2InputError("Expression file is empty.") from error
    if len(header) < 2:
        raise SlideSeqV2InputError("Expression header must contain a row ID plus bead identifiers.")
    return header[0], normalize_unit_ids(header[1:])


def _read_gene_by_bead_counts(path: Path, bead_ids: tuple[str, ...]) -> tuple[tuple[str, ...], sparse.csr_matrix, dict[str, Any]]:
    expected_value_count = len(bead_ids)
    gene_ids: list[str] = []
    seen_gene_ids: set[str] = set()
    row_parts: list[np.ndarray] = []
    column_parts: list[np.ndarray] = []
    value_parts: list[np.ndarray] = []
    all_zero_genes = 0
    maximum_value = 0.0
    total_counts = 0.0

    with gzip.open(path, "rt", encoding="utf-8", errors="strict", newline="") as handle:
        header = handle.readline()
        if not header:
            raise SlideSeqV2InputError("Expression file is empty.")
        for row_index, line in enumerate(handle):
            raw_line = line.rstrip("\r\n")
            if "," not in raw_line:
                raise SlideSeqV2InputError(f"Malformed expression row {row_index + 2}: missing comma.")
            gene_id, values_text = raw_line.split(",", 1)
            if not gene_id:
                raise SlideSeqV2InputError(f"Missing gene ID at expression row {row_index + 2}.")
            if gene_id in seen_gene_ids:
                raise SlideSeqV2InputError(f"Duplicate gene ID: {gene_id}")
            seen_gene_ids.add(gene_id)
            if values_text.count(",") + 1 != expected_value_count:
                raise SlideSeqV2InputError(
                    f"Expression row {row_index + 2} has a value count different from its header."
                )
            values = np.fromstring(values_text, dtype=np.float64, sep=",")
            if values.size != expected_value_count:
                raise SlideSeqV2InputError(f"Expression row {row_index + 2} contains missing or non-numeric values.")
            if not np.isfinite(values).all():
                raise SlideSeqV2InputError(f"Expression row {row_index + 2} contains non-finite values.")
            if (values < 0).any():
                raise SlideSeqV2InputError(f"Expression row {row_index + 2} contains negative counts.")
            if (values != np.floor(values)).any():
                raise SlideSeqV2InputError(f"Expression row {row_index + 2} contains non-integer counts.")
            nonzero_columns = np.flatnonzero(values)
            if nonzero_columns.size == 0:
                all_zero_genes += 1
            else:
                row_parts.append(np.full(nonzero_columns.size, row_index, dtype=np.int32))
                column_parts.append(nonzero_columns.astype(np.int32, copy=False))
                value_parts.append(values[nonzero_columns].astype(np.int64, copy=False))
                maximum_value = max(maximum_value, float(values[nonzero_columns].max()))
                total_counts += float(values[nonzero_columns].sum())
            gene_ids.append(gene_id)

    if not gene_ids:
        raise SlideSeqV2InputError("Expression matrix has no gene rows.")
    if value_parts:
        matrix = sparse.coo_matrix(
            (np.concatenate(value_parts), (np.concatenate(row_parts), np.concatenate(column_parts))),
            shape=(len(gene_ids), expected_value_count),
            dtype=np.int64,
        ).tocsr()
    else:
        matrix = sparse.csr_matrix((len(gene_ids), expected_value_count), dtype=np.int64)
    nonzero_per_bead = np.diff(matrix.tocsc().indptr)
    summary = {
        "rows_genes": len(gene_ids),
        "columns_beads_plus_index": expected_value_count + 1,
        "orientation": "genes_by_beads",
        "nnz": int(matrix.nnz),
        "sparsity": float(1.0 - matrix.nnz / (matrix.shape[0] * matrix.shape[1])),
        "all_zero_gene_count": all_zero_genes,
        "all_zero_bead_count": int((nonzero_per_bead == 0).sum()),
        "maximum_value": maximum_value,
        "total_counts": total_counts,
    }
    return tuple(gene_ids), matrix, summary


def load_slideseqv2_pair(
    data_directory: Path,
    *,
    coordinate_filename: str,
    expression_filename: str,
    dataset_id: str = DATASET_ID,
    sample_accession: str = SAMPLE_ACCESSION,
    puck_id: str = PUCK_ID,
    expected_sha256: dict[str, str] | None = None,
    verify_checksums: bool = True,
) -> SlideSeqV2Input:
    """Load one published Slide-seqV2 pair as raw bead-by-gene sparse counts.

    The documented expression layout is genes by beads.  It is transposed once
    in memory after validation so the returned matrix has rows aligned to the
    returned bead IDs and coordinate rows.  No on-disk matrix is written.
    """
    data_directory = Path(data_directory)
    file_inventory = verify_slideseqv2_pair(
        data_directory,
        coordinate_filename=coordinate_filename,
        expression_filename=expression_filename,
        expected_sha256=expected_sha256,
        verify_checksums=verify_checksums,
    )
    coordinate_path = data_directory / coordinate_filename
    expression_path = data_directory / expression_filename
    gzip_summary = {
        "coordinates": verify_gzip_integrity(coordinate_path),
        "expression": verify_gzip_integrity(expression_path),
    }
    coordinate_ids, coordinates, coordinate_summary = _read_coordinates(coordinate_path)
    expression_index_column, expression_bead_ids = _expression_header(expression_path)
    coordinate_set = set(coordinate_ids)
    expression_set = set(expression_bead_ids)
    if expression_set != coordinate_set:
        raise SlideSeqV2InputError(
            "Expression and coordinate bead identifiers do not have an exact one-to-one intersection."
        )
    coordinate_lookup = dict(zip(coordinate_ids, coordinates, strict=True))
    aligned_coordinates = np.asarray([coordinate_lookup[unit_id] for unit_id in expression_bead_ids], dtype=np.float64)
    gene_ids, gene_by_bead, expression_summary = _read_gene_by_bead_counts(expression_path, expression_bead_ids)
    counts = gene_by_bead.transpose().tocsr()
    expression_summary.update(
        {
            "index_column": expression_index_column,
            "gene_id_type": "string",
            "bead_id_type": "string",
            "unique_gene_ids": len(gene_ids),
            "unique_bead_ids": len(expression_bead_ids),
            "first_five_gene_ids": list(gene_ids[:5]),
            "first_five_bead_ids": list(expression_bead_ids[:5]),
        }
    )
    structural_summary = {
        "dataset_id": dataset_id,
        "sample_accession": sample_accession,
        "puck_id": puck_id,
        "sampling_unit": SAMPLING_UNIT,
        "file_inventory": file_inventory,
        "gzip": gzip_summary,
        "coordinates": coordinate_summary,
        "expression": expression_summary,
        "id_alignment": {
            "coordinate_unique_ids": len(coordinate_ids),
            "expression_unique_ids": len(expression_bead_ids),
            "intersection": len(expression_set),
            "expression_only": 0,
            "coordinate_only": 0,
            "normalization_rule": IDENTIFIER_NORMALIZATION_RULE,
            "coordinate_reordered_to_expression_header": coordinate_ids != expression_bead_ids,
        },
        "returned_matrix_shape": [int(counts.shape[0]), int(counts.shape[1])],
    }
    return SlideSeqV2Input(
        unit_ids=expression_bead_ids,
        coordinates=aligned_coordinates,
        gene_ids=gene_ids,
        counts=counts,
        raw_expression_orientation="genes_by_beads",
        transpose_performed=True,
        identifier_normalization_rule=IDENTIFIER_NORMALIZATION_RULE,
        structural_summary=structural_summary,
    )


def load_slideseqv2_gse190094(data_directory: Path, *, verify_checksums: bool = True) -> SlideSeqV2Input:
    """Load the frozen GSM5713337 pair with its original checksum contract."""
    return load_slideseqv2_pair(
        data_directory,
        coordinate_filename=COORDINATE_FILENAME,
        expression_filename=EXPRESSION_FILENAME,
        dataset_id=DATASET_ID,
        sample_accession=SAMPLE_ACCESSION,
        puck_id=PUCK_ID,
        expected_sha256=EXPECTED_SHA256,
        verify_checksums=verify_checksums,
    )
