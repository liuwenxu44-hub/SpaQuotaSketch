"""Resolve optional machine-specific project paths from YAML configuration."""

from __future__ import annotations

from pathlib import Path

from .utils import read_yaml


def resolve_results_root(project_root: str | Path) -> Path:
    """Return the local results directory or the configured external results root.

    A repository-local results directory takes precedence. When it is absent,
    developers can provide ``configs/paths.windows.local.yaml`` or
    ``configs/paths.local.yaml`` with a ``results_root`` entry. This keeps
    machine-specific paths out of the sampling algorithms.
    """
    root = Path(project_root)
    repository_results = root / "results"
    if repository_results.exists():
        return repository_results

    for config_name in ("paths.windows.local.yaml", "paths.local.yaml"):
        config_path = root / "configs" / config_name
        if not config_path.exists():
            continue
        configured_root = read_yaml(config_path).get("results_root")
        if configured_root:
            return Path(str(configured_root))
    return repository_results


def frozen_simulation_design_path(project_root: str | Path) -> Path:
    """Return the frozen Version 2 simulation design path."""
    return resolve_results_root(project_root) / "v2_simulation_stress_test" / "simulation_design.json"
