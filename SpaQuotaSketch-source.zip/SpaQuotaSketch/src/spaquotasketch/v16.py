"""V16 four-margin allocation for spatial transcriptomics sketching."""

from __future__ import annotations

from collections import Counter, defaultdict
from typing import Hashable, Sequence

import numpy as np

from .constrained_exchange import finite_population_inclusion_probability
from .soft_balance import proportional_quotas
from .v15 import (
    _fine_spatial_quotas,
    _hierarchical_state_quotas,
    _l1_error,
    _minimum_cost_joint_allocation,
    candidate_metrics,
)


def _reserve_detectable_expression_quotas(
    labels: Sequence[Hashable],
    target_n: int,
    confidence_level: float,
) -> tuple[dict[Hashable, int], dict[str, int]]:
    """Allocate local expression quotas while protecting detectable states."""
    target_n = min(max(int(target_n), 0), len(labels))
    quotas = proportional_quotas(list(labels), target_n)
    counts = Counter(labels)
    if target_n == 0 or not counts:
        return quotas, {
            "n_detectable_expression_states": 0,
            "n_protected_expression_states": 0,
            "n_unmet_detectable_expression_states": 0,
        }
    detectable = [
        label
        for label, count in counts.items()
        if finite_population_inclusion_probability(len(labels), count, target_n)
        >= confidence_level
    ]
    ranked_detectable = sorted(
        detectable,
        key=lambda label: (
            -finite_population_inclusion_probability(len(labels), counts[label], target_n),
            -counts[label],
            str(label),
        ),
    )
    protected = set(ranked_detectable[:target_n])
    unmet = 0
    for label in protected:
        if quotas[label] > 0:
            continue
        donors = [candidate for candidate in counts if quotas[candidate] > 1]
        if not donors:
            donors = [
                candidate
                for candidate in counts
                if candidate not in protected and quotas[candidate] > 0
            ]
        if not donors:
            unmet += 1
            continue
        donor = max(
            donors,
            key=lambda candidate: (quotas[candidate], counts[candidate], str(candidate)),
        )
        quotas[donor] -= 1
        quotas[label] += 1
    return quotas, {
        "n_detectable_expression_states": int(len(detectable)),
        "n_protected_expression_states": int(len(protected)),
        "n_unmet_detectable_expression_states": int(unmet),
    }


def primary_expression_quotas(
    primary_spatial_bin_ids: Sequence[Hashable],
    expression_bin_ids: Sequence[Hashable],
    primary_quotas: dict[Hashable, int],
    confidence_level: float = 0.95,
) -> tuple[dict[tuple[Hashable, Hashable], int], dict[str, int]]:
    """Allocate the original primary-spatial by expression-grid margins."""
    if len(primary_spatial_bin_ids) != len(expression_bin_ids):
        raise ValueError("primary_spatial_bin_ids and expression_bin_ids must have the same length.")
    if not (0 < confidence_level < 1):
        raise ValueError("confidence_level must be in (0, 1).")
    by_primary: dict[Hashable, list[int]] = defaultdict(list)
    for index, primary in enumerate(primary_spatial_bin_ids):
        by_primary[primary].append(index)
    result: dict[tuple[Hashable, Hashable], int] = {}
    summary = {
        "n_detectable_primary_expression_states": 0,
        "n_protected_primary_expression_states": 0,
        "n_unmet_detectable_primary_expression_states": 0,
    }
    for primary, indices in by_primary.items():
        local_expression = [expression_bin_ids[index] for index in indices]
        local_quotas, local_summary = _reserve_detectable_expression_quotas(
            local_expression,
            int(primary_quotas.get(primary, 0)),
            confidence_level,
        )
        for expression, quota in local_quotas.items():
            result[(primary, expression)] = int(quota)
        summary["n_detectable_primary_expression_states"] += local_summary[
            "n_detectable_expression_states"
        ]
        summary["n_protected_primary_expression_states"] += local_summary[
            "n_protected_expression_states"
        ]
        summary["n_unmet_detectable_primary_expression_states"] += local_summary[
            "n_unmet_detectable_expression_states"
        ]
    if sum(result.values()) != sum(primary_quotas.values()):
        raise RuntimeError("Primary-expression quotas did not reach the requested target.")
    return result, summary


def _fill_row_shortfall(
    row_quotas: dict[Hashable, int],
    state_quotas: dict[Hashable, int],
    pair_indices: dict[tuple[Hashable, Hashable], list[int]],
    planned_counts: dict[tuple[Hashable, Hashable], int],
) -> tuple[dict[tuple[Hashable, Hashable], int], int]:
    """Fill any infeasible flow remainder while keeping every row quota exact."""
    planned = Counter(planned_counts)
    by_row = Counter()
    by_state = Counter()
    for (row, state), count in planned.items():
        by_row[row] += int(count)
        by_state[state] += int(count)
    relaxed = 0
    for row, quota in row_quotas.items():
        remaining = int(quota) - int(by_row[row])
        while remaining > 0:
            candidates = [
                state
                for (candidate_row, state), indices in pair_indices.items()
                if candidate_row == row
                and len(indices) > int(planned[(candidate_row, state)])
            ]
            if not candidates:
                raise RuntimeError("Could not fill a row quota after flow relaxation.")
            state = max(
                candidates,
                key=lambda candidate: (
                    int(state_quotas.get(candidate, 0)) - int(by_state[candidate]),
                    len(pair_indices[(row, candidate)]) - int(planned[(row, candidate)]),
                    str(candidate),
                ),
            )
            planned[(row, state)] += 1
            by_row[row] += 1
            by_state[state] += 1
            remaining -= 1
            relaxed += 1
    return dict(planned), int(relaxed)


def _select_from_plan(
    triple_indices: dict[tuple[Hashable, Hashable, Hashable], list[int]],
    planned_counts: dict[tuple[Hashable, Hashable, Hashable], int],
    seed: int,
) -> list[int]:
    rng = np.random.default_rng(seed)
    selected: list[int] = []
    for triple, count in planned_counts.items():
        if count <= 0:
            continue
        available = np.asarray(triple_indices[triple], dtype=int)
        chosen = available if count >= available.size else rng.choice(available, size=count, replace=False)
        selected.extend(chosen.astype(int).tolist())
    return sorted(selected)


def sample_four_margin_plan(
    triple_indices: dict[tuple[Hashable, Hashable, Hashable], list[int]],
    planned_counts: dict[tuple[Hashable, Hashable, Hashable], int],
    seed: int,
) -> list[int]:
    """Choose concrete cells from a fixed four-margin allocation plan."""
    return _select_from_plan(triple_indices, planned_counts, seed)


def build_four_margin_plan(
    primary_spatial_bin_ids: Sequence[Hashable],
    fine_spatial_bin_ids: Sequence[Hashable],
    expression_bin_ids: Sequence[Hashable],
    coarse_state_ids: Sequence[Hashable],
    fine_state_ids: Sequence[Hashable],
    target_n: int,
    fine_min_population: int = 20,
    confidence_level: float = 0.95,
) -> tuple[
    dict[tuple[Hashable, Hashable, Hashable], list[int]],
    dict[tuple[Hashable, Hashable, Hashable], int],
    dict[str, object],
]:
    """Build a four-margin allocation plan without choosing individual cells.

    The final counts m_(b,e,s) satisfy fine-space quotas, the original
    primary-space by expression-grid quotas, and global hierarchical-state
    quotas whenever the data make the three margins jointly feasible.
    """
    n_obs = len(primary_spatial_bin_ids)
    if not (
        len(fine_spatial_bin_ids)
        == len(expression_bin_ids)
        == len(coarse_state_ids)
        == len(fine_state_ids)
        == n_obs
    ):
        raise ValueError("All label sequences must have the same length.")
    target_n = min(max(int(target_n), 0), n_obs)
    if target_n == 0:
        return {}, {}, {"n_selected": 0}
    primary_quotas = proportional_quotas(list(primary_spatial_bin_ids), target_n)
    by_primary: dict[Hashable, list[int]] = defaultdict(list)
    fine_by_primary: dict[Hashable, set[Hashable]] = defaultdict(set)
    for index, (primary, fine) in enumerate(zip(primary_spatial_bin_ids, fine_spatial_bin_ids)):
        by_primary[primary].append(index)
        fine_by_primary[primary].add(fine)

    fine_quotas: dict[Hashable, int] = {}
    fine_summary = {
        "n_occupied_fine_bins": 0,
        "n_reachable_fine_bins": 0,
        "n_reachable_fine_bins_protected": 0,
    }
    for primary, indices in by_primary.items():
        local_fine = [fine_spatial_bin_ids[index] for index in indices]
        local_quotas, local_summary = _fine_spatial_quotas(
            local_fine,
            int(primary_quotas[primary]),
            min_population=fine_min_population,
        )
        fine_quotas.update(local_quotas)
        for key in fine_summary:
            fine_summary[key] += local_summary[key]
    if sum(fine_quotas.values()) != target_n:
        raise RuntimeError("Fine spatial quotas did not reach the requested target.")

    primary_expression, expression_summary = primary_expression_quotas(
        primary_spatial_bin_ids,
        expression_bin_ids,
        primary_quotas,
        confidence_level=confidence_level,
    )

    fine_expression_quotas: dict[tuple[Hashable, Hashable], int] = {}
    primary_expression_flow_units = 0
    primary_expression_relaxation = 0
    primary_expression_cost = 0
    for primary, indices in by_primary.items():
        local_rows = {fine: int(fine_quotas[fine]) for fine in fine_by_primary[primary]}
        local_states = {
            expression: int(quota)
            for (candidate_primary, expression), quota in primary_expression.items()
            if candidate_primary == primary and quota > 0
        }
        pair_indices: dict[tuple[Hashable, Hashable], list[int]] = defaultdict(list)
        for index in indices:
            pair_indices[(fine_spatial_bin_ids[index], expression_bin_ids[index])].append(index)
        pair_counts = {pair: len(values) for pair, values in pair_indices.items()}
        local_plan, flow_units, flow_cost = _minimum_cost_joint_allocation(
            local_rows,
            local_states,
            pair_counts,
        )
        if flow_units < int(primary_quotas[primary]):
            local_plan, relaxed = _fill_row_shortfall(
                local_rows,
                local_states,
                pair_indices,
                local_plan,
            )
            primary_expression_relaxation += relaxed
        primary_expression_flow_units += flow_units
        if flow_cost is not None:
            primary_expression_cost += int(flow_cost)
        fine_expression_quotas.update({pair: int(count) for pair, count in local_plan.items() if count > 0})
    if sum(fine_expression_quotas.values()) != target_n:
        raise RuntimeError("Fine-expression quotas did not reach the requested target.")

    _, fine_state_quotas = _hierarchical_state_quotas(
        coarse_state_ids,
        fine_state_ids,
        target_n,
    )
    triple_indices: dict[tuple[Hashable, Hashable, Hashable], list[int]] = defaultdict(list)
    for index, (fine, expression, state) in enumerate(
        zip(fine_spatial_bin_ids, expression_bin_ids, fine_state_ids)
    ):
        triple_indices[(fine, expression, state)].append(index)
    state_pair_indices: dict[
        tuple[tuple[Hashable, Hashable], Hashable], list[int]
    ] = defaultdict(list)
    for (fine, expression, state), indices in triple_indices.items():
        state_pair_indices[((fine, expression), state)].extend(indices)
    state_pair_counts = {pair: len(indices) for pair, indices in state_pair_indices.items()}
    state_plan, state_flow_units, state_flow_cost = _minimum_cost_joint_allocation(
        fine_expression_quotas,
        fine_state_quotas,
        state_pair_counts,
    )
    state_relaxation = 0
    if state_flow_units < target_n:
        state_plan, state_relaxation = _fill_row_shortfall(
            fine_expression_quotas,
            fine_state_quotas,
            state_pair_indices,
            state_plan,
        )
    triple_plan = {
        (fine, expression, state): int(count)
        for ((fine, expression), state), count in state_plan.items()
        if count > 0
    }
    if sum(triple_plan.values()) != target_n:
        raise RuntimeError("Four-margin allocation plan did not reach the requested target.")
    report = {
        "n_selected": target_n,
        "primary_expression_flow_units": int(primary_expression_flow_units),
        "primary_expression_flow_feasible": bool(primary_expression_flow_units == target_n),
        "primary_expression_quota_relaxation_cells": int(primary_expression_relaxation),
        "primary_expression_joint_allocation_cost": int(primary_expression_cost),
        "fine_state_flow_units": int(state_flow_units),
        "fine_state_flow_feasible": bool(state_flow_units == target_n),
        "fine_state_quota_relaxation_cells": int(state_relaxation),
        "fine_state_joint_allocation_cost": state_flow_cost,
        "candidate_construction": "primary_expression_quota_then_fine_spatial_and_global_hierarchical_state_minimum_cost_flows",
        **fine_summary,
        **expression_summary,
    }
    return dict(triple_indices), triple_plan, report


def four_margin_candidate_metrics(
    primary_spatial_bin_ids: Sequence[Hashable],
    fine_spatial_bin_ids: Sequence[Hashable],
    expression_bin_ids: Sequence[Hashable],
    coarse_state_ids: Sequence[Hashable],
    fine_state_ids: Sequence[Hashable],
    selected_indices: Sequence[int],
    expression_features,
    gene_view_a_mean_error: float = 0.0,
    gene_view_b_mean_error: float = 0.0,
) -> dict[str, float]:
    """Unlabeled V16 candidate metrics, including the original joint stratum."""
    selected = np.asarray(selected_indices, dtype=int)
    metrics = candidate_metrics(
        primary_spatial_bin_ids,
        fine_spatial_bin_ids,
        coarse_state_ids,
        fine_state_ids,
        selected,
        expression_features,
        gene_view_a_mean_error=gene_view_a_mean_error,
        gene_view_b_mean_error=gene_view_b_mean_error,
    )
    full_primary_expression = list(zip(primary_spatial_bin_ids, expression_bin_ids))
    selected_primary_expression = [
        (primary_spatial_bin_ids[index], expression_bin_ids[index]) for index in selected
    ]
    metrics["primary_expression_l1"] = _l1_error(
        full_primary_expression,
        selected_primary_expression,
    )
    metrics["primary_expression_coverage_penalty"] = 1.0 - len(
        set(full_primary_expression).intersection(selected_primary_expression)
    ) / max(1, len(set(full_primary_expression)))
    metrics["expression_bin_l1"] = _l1_error(
        expression_bin_ids,
        [expression_bin_ids[index] for index in selected],
    )
    return metrics


__all__ = [
    "build_four_margin_plan",
    "four_margin_candidate_metrics",
    "primary_expression_quotas",
    "sample_four_margin_plan",
]
