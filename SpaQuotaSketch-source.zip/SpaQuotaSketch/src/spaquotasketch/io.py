"""Input and output helpers."""

from __future__ import annotations

from pathlib import Path
from typing import Any


def read_h5ad(path: str | Path) -> Any:
    """Read an AnnData file from disk."""
    import anndata as ad

    return ad.read_h5ad(Path(path))


def write_h5ad(adata: Any, path: str | Path, overwrite: bool = False) -> None:
    """Write an AnnData file, refusing to overwrite unless requested."""
    from .utils import ensure_parent_dir, refuse_overwrite

    output_path = Path(path)
    ensure_parent_dir(output_path)
    if not overwrite:
        refuse_overwrite(output_path)
    adata.write_h5ad(output_path)


def write_csv(records: list[dict[str, Any]], path: str | Path, overwrite: bool = False) -> None:
    """Write a list of records as CSV."""
    import pandas as pd

    from .utils import ensure_parent_dir, refuse_overwrite

    output_path = Path(path)
    ensure_parent_dir(output_path)
    if not overwrite:
        refuse_overwrite(output_path)
    pd.DataFrame.from_records(records).to_csv(output_path, index=False)
