"""Explicit local and SSHFS-safe persistence for immutable benchmark results.

The SSHFS backend deliberately uses only new-file creation, byte-for-byte
verification, immutable event records, and immutable snapshots.  It never
renames a directory, replaces a file, or overwrites a prior result.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
import csv
import hashlib
import io
import json
import os
from pathlib import Path
from typing import Any, Callable, Iterable, Mapping
from uuid import uuid4

import yaml


STATUS_EVENTS = frozenset(
    {
        "PLANNED",
        "RUNNING",
        "COMPUTE_SUCCESS",
        "COMPUTE_FAIL",
        "PUBLISHING",
        "SUCCESS",
        "FAIL",
        "INFEASIBLE",
        "PUBLISH_FAILED",
        "INTERRUPTED",
        "RESUME_DETECTED",
    }
)
SNAPSHOT_EVENT = "SNAPSHOT_CREATED"
STATUS_TRANSITIONS: dict[str | None, frozenset[str]] = {
    None: frozenset({"PLANNED"}),
    "PLANNED": frozenset({"RUNNING", "RESUME_DETECTED", "INTERRUPTED"}),
    "RUNNING": frozenset(
        {
            "COMPUTE_SUCCESS",
            "COMPUTE_FAIL",
            "FAIL",
            "INFEASIBLE",
            "PUBLISH_FAILED",
            "SUCCESS",
            "INTERRUPTED",
        }
    ),
    "COMPUTE_SUCCESS": frozenset({"PUBLISHING", "PUBLISH_FAILED", "INTERRUPTED"}),
    "PUBLISHING": frozenset({"PLANNED", "SUCCESS", "PUBLISH_FAILED", "INTERRUPTED"}),
    "COMPUTE_FAIL": frozenset({"PLANNED", "RESUME_DETECTED"}),
    "PUBLISH_FAILED": frozenset({"PLANNED", "RESUME_DETECTED"}),
    "UNCONFIRMED_SUCCESS_MARKER": frozenset({"PLANNED", "RESUME_DETECTED"}),
    "INFEASIBLE": frozenset({"PLANNED", "RESUME_DETECTED"}),
    "INTERRUPTED": frozenset({"PLANNED", "RESUME_DETECTED"}),
    "RESUME_DETECTED": frozenset({"RUNNING", "COMPUTE_SUCCESS", "PUBLISHING", "INTERRUPTED"}),
    "SUCCESS": frozenset(),
}


class StorageConfigurationError(ValueError):
    """Raised when a persistence backend configuration is internally inconsistent."""


class ImmutableWriteError(RuntimeError):
    """Raised when an immutable file or attempt would be overwritten."""


class ChecksumMismatchError(RuntimeError):
    """Raised when an existing or copied file does not match its expected bytes."""


class PublishError(RuntimeError):
    """Raised when an SSHFS publish operation cannot complete."""


class EventWriteError(PublishError):
    """Raised when a remote event cannot be appended safely."""


@dataclass(frozen=True)
class StorageConfig:
    """Configuration for one explicit persistence backend."""

    backend: str
    local_staging_root: Path
    remote_results_root: Path
    overwrite: bool = False
    verify_sha256: bool = True
    retain_local_staging_after_success: bool = True
    manifest_mode: str = "append_only_events"
    allow_atomic_replace: bool = False
    allow_directory_rename: bool = False
    allow_existing_file_overwrite: bool = False

    @classmethod
    def from_mapping(
        cls,
        value: Mapping[str, Any],
        *,
        local_staging_root: str | Path | None = None,
        remote_results_root: str | Path | None = None,
    ) -> "StorageConfig":
        mapping = value.get("storage", value)
        if not isinstance(mapping, Mapping):
            raise StorageConfigurationError("storage configuration must be a mapping")
        local_root = local_staging_root if local_staging_root is not None else mapping.get("local_staging_root")
        remote_root = remote_results_root if remote_results_root is not None else mapping.get("remote_results_root")
        if not local_root or not remote_root:
            raise StorageConfigurationError(
                "local_staging_root and remote_results_root must be supplied by configuration or command line"
            )
        config = cls(
            backend=str(mapping.get("backend", "")),
            local_staging_root=Path(local_root),
            remote_results_root=Path(remote_root),
            overwrite=bool(mapping.get("overwrite", False)),
            verify_sha256=bool(mapping.get("verify_sha256", True)),
            retain_local_staging_after_success=bool(
                mapping.get("retain_local_staging_after_success", True)
            ),
            manifest_mode=str(mapping.get("manifest_mode", "append_only_events")),
            allow_atomic_replace=bool(mapping.get("allow_atomic_replace", False)),
            allow_directory_rename=bool(mapping.get("allow_directory_rename", False)),
            allow_existing_file_overwrite=bool(
                mapping.get("allow_existing_file_overwrite", False)
            ),
        )
        config.validate()
        return config

    def validate(self) -> None:
        if self.backend not in {"local_atomic", "sshfs_append_only"}:
            raise StorageConfigurationError(
                "backend must be local_atomic or sshfs_append_only"
            )
        if self.overwrite or self.allow_existing_file_overwrite:
            raise StorageConfigurationError("result persistence must never overwrite an existing file")
        if self.backend == "sshfs_append_only":
            if not self.verify_sha256:
                raise StorageConfigurationError("sshfs_append_only requires verify_sha256=true")
            if self.manifest_mode != "append_only_events":
                raise StorageConfigurationError(
                    "sshfs_append_only requires manifest_mode=append_only_events"
                )
            if self.allow_atomic_replace or self.allow_directory_rename:
                raise StorageConfigurationError(
                    "sshfs_append_only forbids atomic replacement and directory rename"
                )


def load_storage_config(
    path: str | Path,
    *,
    local_staging_root: str | Path | None = None,
    remote_results_root: str | Path | None = None,
) -> StorageConfig:
    """Load an explicit backend configuration, with optional CLI path injection."""

    value = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, Mapping):
        raise StorageConfigurationError(f"Expected a YAML mapping: {path}")
    return StorageConfig.from_mapping(
        value,
        local_staging_root=local_staging_root,
        remote_results_root=remote_results_root,
    )


def sha256_file(path: str | Path, chunk_size: int = 1024 * 1024) -> str:
    """Return a SHA-256 digest without loading an artifact into memory."""

    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _canonical_json(value: Mapping[str, Any]) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _safe_component(value: str, field_name: str) -> str:
    if not value or value in {".", ".."} or any(character in value for character in "\\/\x00"):
        raise ValueError(f"{field_name} must be a non-empty path-safe identifier")
    return value


def _safe_relative_path(value: str | Path) -> Path:
    relative = Path(value)
    if relative.is_absolute() or not relative.parts or any(part in {"", ".", ".."} for part in relative.parts):
        raise ValueError(f"Artifact path must be a safe relative path: {value}")
    return relative


@dataclass
class OperationAudit:
    """Counts storage operations for an explicit validation audit."""

    os_replace_calls: int = 0
    directory_rename_calls: int = 0
    target_file_overwrite_calls: int = 0
    overwrite_refusals: int = 0
    cross_filesystem_move_calls: int = 0
    immutable_file_creations: int = 0
    copied_files: int = 0
    verified_file_copies: int = 0
    already_present_verified: int = 0
    local_staged_files: int = 0
    event_files_written: int = 0
    snapshot_files_written: int = 0

    def as_dict(self) -> dict[str, int]:
        return dict(self.__dict__)


@dataclass(frozen=True)
class StagedAttempt:
    """One immutable local staging attempt and its future remote destination."""

    run_id: str
    attempt_id: int
    method_id: str
    config_hash: str
    code_commit: str
    local_directory: Path
    remote_directory: Path

    @property
    def attempt_name(self) -> str:
        return f"attempt_{self.attempt_id:04d}"


@dataclass(frozen=True)
class PublishResult:
    """Verified outcome of one append-only publication."""

    attempt: StagedAttempt
    artifact_checksums: Mapping[str, Mapping[str, Any]]
    success_marker_path: Path
    success_marker_sha256: str
    status: str


FaultInjector = Callable[[str], None]
BeforeCopyHook = Callable[[Path, Path], None]


class LocalAtomicBackend:
    """A local NTFS-only backend that permits same-filesystem atomic replacement."""

    backend_name = "local_atomic"

    def __init__(self, config: StorageConfig, audit: OperationAudit | None = None) -> None:
        config.validate()
        if config.backend != self.backend_name:
            raise StorageConfigurationError("LocalAtomicBackend requires backend=local_atomic")
        self.config = config
        self.audit = audit or OperationAudit()

    def write_atomic_bytes(self, destination: str | Path, payload: bytes) -> Path:
        """Write locally, then atomically replace the destination on NTFS only."""

        path = Path(destination)
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(f".{path.name}.{uuid4().hex}.tmp")
        with temporary.open("xb") as handle:
            handle.write(payload)
        os.replace(temporary, path)
        self.audit.os_replace_calls += 1
        return path


class SSHFSAppendOnlyBackend:
    """A local-staging, remote-append-only backend for the SSHFS Z drive."""

    backend_name = "sshfs_append_only"

    def __init__(
        self,
        config: StorageConfig,
        *,
        audit: OperationAudit | None = None,
        fault_injector: FaultInjector | None = None,
        before_copy: BeforeCopyHook | None = None,
    ) -> None:
        config.validate()
        if config.backend != self.backend_name:
            raise StorageConfigurationError(
                "SSHFSAppendOnlyBackend requires backend=sshfs_append_only"
            )
        self.config = config
        self.audit = audit or OperationAudit()
        self._fault_injector = fault_injector
        self._before_copy = before_copy

    @property
    def _local_runs_root(self) -> Path:
        return self.config.local_staging_root / "runs"

    @property
    def _remote_runs_root(self) -> Path:
        return self.config.remote_results_root / "runs"

    @property
    def _events_root(self) -> Path:
        return self.config.remote_results_root / "events"

    @property
    def _snapshots_root(self) -> Path:
        return self.config.remote_results_root / "snapshots"

    @property
    def _pending_events_root(self) -> Path:
        return self.config.local_staging_root / "pending_events"

    def _inject(self, operation: str) -> None:
        if self._fault_injector is not None:
            self._fault_injector(operation)

    def _write_exclusive_bytes(self, destination: Path, payload: bytes) -> str:
        if destination.exists():
            self.audit.overwrite_refusals += 1
            raise ImmutableWriteError(f"Refusing to overwrite existing file: {destination}")
        destination.parent.mkdir(parents=True, exist_ok=True)
        try:
            with destination.open("xb") as handle:
                handle.write(payload)
                handle.flush()
        except FileExistsError as error:
            self.audit.overwrite_refusals += 1
            raise ImmutableWriteError(f"Refusing to overwrite existing file: {destination}") from error
        self.audit.immutable_file_creations += 1
        observed = sha256_file(destination)
        expected = hashlib.sha256(payload).hexdigest()
        if observed != expected:
            raise ChecksumMismatchError(f"Newly written file failed verification: {destination}")
        return observed

    def _next_attempt_id(self, run_id: str) -> int:
        values: list[int] = []
        for root in (self._local_runs_root / run_id, self._remote_runs_root / run_id):
            if not root.is_dir():
                continue
            for path in root.iterdir():
                if path.is_dir() and path.name.startswith("attempt_"):
                    suffix = path.name.removeprefix("attempt_")
                    if suffix.isdigit():
                        values.append(int(suffix))
        return max(values, default=0) + 1

    def begin_attempt(
        self,
        *,
        run_id: str,
        method_id: str,
        config_hash: str,
        code_commit: str,
        previous_status: str | None = None,
    ) -> StagedAttempt:
        """Create a new local attempt.  No remote result file is created yet."""

        clean_run_id = _safe_component(run_id, "run_id")
        clean_method_id = _safe_component(method_id, "method_id")
        attempt_id = self._next_attempt_id(clean_run_id)
        attempt_name = f"attempt_{attempt_id:04d}"
        local_directory = self._local_runs_root / clean_run_id / attempt_name
        remote_directory = self._remote_runs_root / clean_run_id / attempt_name
        if local_directory.exists() or remote_directory.exists():
            raise ImmutableWriteError(f"Attempt directory already exists: {attempt_name}")
        local_directory.mkdir(parents=True, exist_ok=False)
        attempt = StagedAttempt(
            run_id=clean_run_id,
            attempt_id=attempt_id,
            method_id=clean_method_id,
            config_hash=str(config_hash),
            code_commit=str(code_commit),
            local_directory=local_directory,
            remote_directory=remote_directory,
        )
        self.record_event(attempt, new_status="PLANNED", previous_status=previous_status)
        return attempt

    def stage_bytes(self, attempt: StagedAttempt, relative_path: str | Path, payload: bytes) -> Path:
        """Write one immutable artifact to local NTFS staging."""

        destination = attempt.local_directory / _safe_relative_path(relative_path)
        if not destination.is_relative_to(attempt.local_directory):
            raise ValueError("Artifact destination escapes local staging")
        digest = self._write_exclusive_bytes(destination, payload)
        if digest != hashlib.sha256(payload).hexdigest():
            raise ChecksumMismatchError(f"Local staging verification failed: {destination}")
        self.audit.local_staged_files += 1
        return destination

    def stage_text(self, attempt: StagedAttempt, relative_path: str | Path, text: str) -> Path:
        return self.stage_bytes(attempt, relative_path, text.encode("utf-8"))

    def stage_json(self, attempt: StagedAttempt, relative_path: str | Path, value: Mapping[str, Any]) -> Path:
        return self.stage_bytes(attempt, relative_path, _canonical_json(value))

    def stage_copy(self, attempt: StagedAttempt, relative_path: str | Path, source: str | Path) -> Path:
        """Copy an input file into local staging without a move or overwrite."""

        source_path = Path(source)
        destination = attempt.local_directory / _safe_relative_path(relative_path)
        if destination.exists():
            self.audit.overwrite_refusals += 1
            raise ImmutableWriteError(f"Refusing to overwrite staged file: {destination}")
        destination.parent.mkdir(parents=True, exist_ok=True)
        with source_path.open("rb") as reader, destination.open("xb") as writer:
            while True:
                chunk = reader.read(1024 * 1024)
                if not chunk:
                    break
                writer.write(chunk)
        if sha256_file(source_path) != sha256_file(destination):
            raise ChecksumMismatchError(f"Local staging copy verification failed: {source_path}")
        self.audit.local_staged_files += 1
        return destination

    def staged_artifact_checksums(self, attempt: StagedAttempt) -> dict[str, dict[str, Any]]:
        """Return verified file metadata for every staged artifact."""

        files = sorted(path for path in attempt.local_directory.rglob("*") if path.is_file())
        if not files:
            raise PublishError(f"No artifacts were staged for {attempt.run_id}")
        checksums: dict[str, dict[str, Any]] = {}
        for path in files:
            relative = path.relative_to(attempt.local_directory).as_posix()
            checksums[relative] = {
                "bytes": int(path.stat().st_size),
                "sha256": sha256_file(path),
            }
        return checksums

    def publish_immutable_provenance(
        self,
        *,
        provenance_id: str,
        artifacts: Mapping[str, bytes],
        metadata: Mapping[str, Any],
    ) -> dict[str, Any]:
        """Publish one immutable non-run provenance bundle with verified copies.

        Provenance is intentionally separate from the 200 planned run IDs, so
        replayed execution state remains a statement about planned units only.
        """

        identifier = _safe_component(provenance_id, "provenance_id")
        local_directory = self.config.local_staging_root / "provenance" / identifier
        remote_directory = self.config.remote_results_root / "provenance" / identifier
        if local_directory.exists() or remote_directory.exists():
            raise ImmutableWriteError(f"Provenance bundle already exists: {identifier}")
        local_directory.mkdir(parents=True, exist_ok=False)
        checksums: dict[str, dict[str, Any]] = {}
        for relative_path, payload in sorted(artifacts.items()):
            local_path = local_directory / _safe_relative_path(relative_path)
            self._write_exclusive_bytes(local_path, bytes(payload))
            checksums[local_path.relative_to(local_directory).as_posix()] = {
                "bytes": int(local_path.stat().st_size),
                "sha256": sha256_file(local_path),
            }
        remote_directory.mkdir(parents=True, exist_ok=False)
        for relative_path in checksums:
            self.copy_verified_file(
                local_directory / Path(relative_path),
                remote_directory / Path(relative_path),
            )
        marker_payload = {
            "provenance_id": identifier,
            "metadata": dict(metadata),
            "file_checksums": checksums,
            "storage_backend": self.backend_name,
            "source_local_staging_path": str(local_directory),
            "destination_path": str(remote_directory),
            "published_at": _utc_now(),
        }
        marker_path = remote_directory / "_SUCCESS.json"
        marker_sha256 = self._write_exclusive_bytes(marker_path, _canonical_json(marker_payload))
        for relative_path, expected in checksums.items():
            destination = remote_directory / Path(relative_path)
            if int(destination.stat().st_size) != int(expected["bytes"]) or sha256_file(destination) != expected["sha256"]:
                raise ChecksumMismatchError(f"Published provenance failed verification: {destination}")
        return {
            "provenance_id": identifier,
            "remote_directory": str(remote_directory),
            "local_directory": str(local_directory),
            "file_checksums": checksums,
            "success_marker_path": str(marker_path),
            "success_marker_sha256": marker_sha256,
        }

    def copy_verified_file(self, source: str | Path, destination: str | Path) -> str:
        """Copy one file to a new remote path and verify size and SHA-256."""

        source_path = Path(source)
        destination_path = Path(destination)
        expected_size = int(source_path.stat().st_size)
        expected_sha256 = sha256_file(source_path)
        if self._before_copy is not None:
            self._before_copy(source_path, destination_path)
        if destination_path.exists():
            observed_size = int(destination_path.stat().st_size)
            observed_sha256 = sha256_file(destination_path)
            if observed_size == expected_size and observed_sha256 == expected_sha256:
                self.audit.already_present_verified += 1
                return "already_present_verified"
            self.audit.overwrite_refusals += 1
            raise ChecksumMismatchError(
                f"Existing target differs and cannot be overwritten: {destination_path}"
            )
        destination_path.parent.mkdir(parents=True, exist_ok=True)
        self._inject("copy")
        try:
            with source_path.open("rb") as reader, destination_path.open("xb") as writer:
                while True:
                    chunk = reader.read(1024 * 1024)
                    if not chunk:
                        break
                    writer.write(chunk)
                writer.flush()
        except FileExistsError as error:
            self.audit.overwrite_refusals += 1
            raise ImmutableWriteError(f"Refusing to overwrite target: {destination_path}") from error
        self.audit.copied_files += 1
        observed_size = int(destination_path.stat().st_size)
        observed_sha256 = sha256_file(destination_path)
        if observed_size != expected_size or observed_sha256 != expected_sha256:
            raise ChecksumMismatchError(f"Published file failed verification: {destination_path}")
        self.audit.verified_file_copies += 1
        return "copied_verified"

    def _event_payload(
        self,
        attempt: StagedAttempt,
        *,
        sequence_id: int,
        previous_status: str | None,
        new_status: str,
        error: Mapping[str, Any] | None,
        file_checksums: Mapping[str, Mapping[str, Any]] | None,
        extra: Mapping[str, Any] | None,
    ) -> dict[str, Any]:
        return {
            "event_id": uuid4().hex,
            "event_kind": "status",
            "sequence_id": sequence_id,
            "run_id": attempt.run_id,
            "attempt_id": attempt.attempt_id,
            "method_id": attempt.method_id,
            "previous_status": previous_status,
            "new_status": new_status,
            "timestamp": _utc_now(),
            "config_hash": attempt.config_hash,
            "code_commit": attempt.code_commit,
            "storage_backend": self.backend_name,
            "error": dict(error or {}),
            "run_directory": str(attempt.remote_directory),
            "source_local_staging_path": str(attempt.local_directory),
            "file_checksums": dict(file_checksums or {}),
            "extra": dict(extra or {}),
        }

    def _next_event_sequence(self) -> int:
        sequences: list[int] = []
        if self._events_root.is_dir():
            for path in self._events_root.glob("*.json"):
                prefix = path.name.split("_", 1)[0]
                if prefix.isdigit():
                    sequences.append(int(prefix))
        return max(sequences, default=0) + 1

    def record_event(
        self,
        attempt: StagedAttempt,
        *,
        new_status: str,
        previous_status: str | None,
        error: Mapping[str, Any] | None = None,
        file_checksums: Mapping[str, Mapping[str, Any]] | None = None,
        extra: Mapping[str, Any] | None = None,
    ) -> Path:
        """Append one immutable state event, preserving a local copy if it fails."""

        if new_status not in STATUS_EVENTS:
            raise ValueError(f"Unsupported state event: {new_status}")
        if new_status not in STATUS_TRANSITIONS.get(previous_status, frozenset()):
            raise ValueError(f"Illegal status transition: {previous_status} -> {new_status}")
        sequence_id = self._next_event_sequence()
        payload = self._event_payload(
            attempt,
            sequence_id=sequence_id,
            previous_status=previous_status,
            new_status=new_status,
            error=error,
            file_checksums=file_checksums,
            extra=extra,
        )
        content = _canonical_json(payload)
        filename = f"{sequence_id:06d}_{attempt.run_id}_{new_status}_{payload['event_id']}.json"
        destination = self._events_root / filename
        try:
            self._inject(f"event:{new_status}")
            digest = self._write_exclusive_bytes(destination, content)
        except Exception as error_value:
            pending = self._pending_events_root / filename
            pending_payload = {
                "intended_event": payload,
                "intended_event_sha256": hashlib.sha256(content).hexdigest(),
                "remote_destination": str(destination),
                "write_error_type": type(error_value).__name__,
                "write_error": str(error_value),
            }
            self._write_exclusive_bytes(pending, _canonical_json(pending_payload))
            raise EventWriteError(f"Unable to append event {new_status}: {error_value}") from error_value
        if digest != hashlib.sha256(content).hexdigest():
            raise ChecksumMismatchError(f"Event verification failed: {destination}")
        self.audit.event_files_written += 1
        return destination

    def mark_running(self, attempt: StagedAttempt, previous_status: str = "PLANNED") -> Path:
        return self.record_event(
            attempt,
            new_status="RUNNING",
            previous_status=previous_status,
        )

    def publish(self, attempt: StagedAttempt, *, previous_status: str = "RUNNING") -> PublishResult:
        """Publish verified staged files, then append a success marker and event."""

        checksums = self.staged_artifact_checksums(attempt)
        if attempt.remote_directory.exists():
            raise ImmutableWriteError(
                f"Remote attempt directory already exists: {attempt.remote_directory}"
            )
        attempt.remote_directory.mkdir(parents=True, exist_ok=False)
        try:
            for relative in checksums:
                self.copy_verified_file(
                    attempt.local_directory / Path(relative),
                    attempt.remote_directory / Path(relative),
                )
            marker_payload = {
                "run_id": attempt.run_id,
                "attempt_id": attempt.attempt_id,
                "method_id": attempt.method_id,
                "config_hash": attempt.config_hash,
                "file_checksums": checksums,
                "published_at": _utc_now(),
                "storage_backend": self.backend_name,
                "source_local_staging_path": str(attempt.local_directory),
                "destination_path": str(attempt.remote_directory),
            }
            marker_path = attempt.remote_directory / "_SUCCESS.json"
            marker_sha256 = self._write_exclusive_bytes(marker_path, _canonical_json(marker_payload))
            self.record_event(
                attempt,
                new_status="SUCCESS",
                previous_status=previous_status,
                file_checksums=checksums,
                extra={"success_marker_sha256": marker_sha256},
            )
            return PublishResult(
                attempt=attempt,
                artifact_checksums=checksums,
                success_marker_path=marker_path,
                success_marker_sha256=marker_sha256,
                status="SUCCESS",
            )
        except EventWriteError:
            # A marker without a verified SUCCESS event is intentionally not a
            # formal success.  The pending local event enables later recovery.
            raise
        except Exception as error:
            try:
                self.record_event(
                    attempt,
                    new_status="PUBLISH_FAILED",
                    previous_status=previous_status,
                    error={"error_type": type(error).__name__, "message": str(error)},
                    file_checksums=checksums,
                )
            except EventWriteError:
                pass
            raise PublishError(f"Publish failed for {attempt.run_id}: {error}") from error

    def publish_failure(
        self,
        attempt: StagedAttempt,
        *,
        previous_status: str = "RUNNING",
        incomplete: bool = False,
        error: Mapping[str, Any] | None = None,
    ) -> PublishResult:
        """Publish immutable engineering failure evidence without a success marker.

        A failed attempt is still useful operational evidence.  It receives a
        checked copy of its local log plus exactly one ``_FAILURE.json`` marker;
        neither the marker nor the attempt directory can be overwritten.
        """

        checksums = self.staged_artifact_checksums(attempt)
        if attempt.remote_directory.exists():
            raise ImmutableWriteError(
                f"Remote attempt directory already exists: {attempt.remote_directory}"
            )
        attempt.remote_directory.mkdir(parents=True, exist_ok=False)
        status = "INTERRUPTED" if incomplete else "FAIL"
        try:
            for relative in checksums:
                self.copy_verified_file(
                    attempt.local_directory / Path(relative),
                    attempt.remote_directory / Path(relative),
                )
            marker_payload = {
                "run_id": attempt.run_id,
                "attempt_id": attempt.attempt_id,
                "method_id": attempt.method_id,
                "config_hash": attempt.config_hash,
                "file_checksums": checksums,
                "published_at": _utc_now(),
                "storage_backend": self.backend_name,
                "source_local_staging_path": str(attempt.local_directory),
                "destination_path": str(attempt.remote_directory),
                "status": status,
                "error": dict(error or {}),
            }
            marker_path = attempt.remote_directory / "_FAILURE.json"
            marker_sha256 = self._write_exclusive_bytes(marker_path, _canonical_json(marker_payload))
            self.record_event(
                attempt,
                new_status=status,
                previous_status=previous_status,
                error=dict(error or {}),
                file_checksums=checksums,
                extra={"failure_marker_sha256": marker_sha256},
            )
            return PublishResult(
                attempt=attempt,
                artifact_checksums=checksums,
                success_marker_path=marker_path,
                success_marker_sha256=marker_sha256,
                status=status,
            )
        except EventWriteError:
            raise
        except Exception as error_value:
            try:
                self.record_event(
                    attempt,
                    new_status="PUBLISH_FAILED",
                    previous_status=previous_status,
                    error={"error_type": type(error_value).__name__, "message": str(error_value)},
                    file_checksums=checksums,
                )
            except EventWriteError:
                pass
            raise PublishError(f"Failure publication failed for {attempt.run_id}: {error_value}") from error_value

    def valid_success_marker(self, attempt_directory: str | Path) -> tuple[bool, dict[str, Any] | None]:
        """Verify every artifact recorded by a success marker."""

        directory = Path(attempt_directory)
        marker = directory / "_SUCCESS.json"
        if not marker.is_file():
            return False, None
        try:
            payload = json.loads(marker.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return False, None
        checksums = payload.get("file_checksums")
        if not isinstance(checksums, Mapping):
            return False, None
        for relative, expected in checksums.items():
            if not isinstance(expected, Mapping):
                return False, None
            artifact = directory / _safe_relative_path(str(relative))
            if not artifact.is_file():
                return False, None
            if int(artifact.stat().st_size) != int(expected.get("bytes", -1)):
                return False, None
            if sha256_file(artifact) != str(expected.get("sha256", "")):
                return False, None
        return True, payload

    def replay_events(self) -> dict[str, dict[str, Any]]:
        """Replay immutable events and classify interrupted/incomplete attempts."""

        state: dict[str, dict[str, Any]] = {}
        attempt_state: dict[tuple[str, int], dict[str, Any]] = {}
        events: list[dict[str, Any]] = []
        if self._events_root.is_dir():
            for path in sorted(self._events_root.glob("*.json")):
                try:
                    event = json.loads(path.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError) as error:
                    raise PublishError(f"Unreadable event file: {path}") from error
                if event.get("event_kind") == "status":
                    events.append(event)
        for event in sorted(events, key=lambda item: (int(item["sequence_id"]), str(item["event_id"]))):
            run_id = str(event["run_id"])
            record = {
                "run_id": run_id,
                "attempt_id": int(event["attempt_id"]),
                "method_id": str(event.get("method_id", "")),
                "status": str(event["new_status"]),
                "event_id": str(event["event_id"]),
                "sequence_id": int(event["sequence_id"]),
                "run_directory": str(event["run_directory"]),
                "source_local_staging_path": str(event.get("source_local_staging_path", "")),
                "config_hash": str(event["config_hash"]),
                "code_commit": str(event["code_commit"]),
                "storage_backend": str(event["storage_backend"]),
            }
            state[run_id] = record
            attempt_state[(run_id, int(event["attempt_id"]))] = record

        if self._remote_runs_root.is_dir():
            for run_root in sorted(path for path in self._remote_runs_root.iterdir() if path.is_dir()):
                run_id = run_root.name
                attempts = sorted(
                    (path for path in run_root.iterdir() if path.is_dir()),
                    key=lambda path: path.name,
                )
                if not attempts:
                    continue
                latest = attempts[-1]
                verified_successes: list[tuple[int, dict[str, Any], Path]] = []
                marker_without_success_event: tuple[Path, dict[str, Any]] | None = None
                for attempt_directory in attempts:
                    attempt_id = int(str(attempt_directory.name).removeprefix("attempt_") or 0)
                    valid_marker, marker_payload = self.valid_success_marker(attempt_directory)
                    event_record = attempt_state.get((run_id, attempt_id))
                    if valid_marker and event_record and event_record["status"] == "SUCCESS":
                        verified_successes.append((attempt_id, event_record, attempt_directory))
                    elif valid_marker and marker_payload is not None:
                        marker_without_success_event = (attempt_directory, marker_payload)
                if verified_successes:
                    _, event_record, attempt_directory = max(verified_successes, key=lambda item: item[0])
                    state[run_id] = dict(event_record)
                    state[run_id]["success_marker_valid"] = True
                    state[run_id]["success_marker_path"] = str(attempt_directory / "_SUCCESS.json")
                    continue
                current = state.get(run_id)
                if marker_without_success_event is not None:
                    attempt_directory, marker_payload = marker_without_success_event
                    prior = state.get(run_id, {})
                    state[run_id] = {
                        "run_id": run_id,
                        "attempt_id": int(str(attempt_directory.name).removeprefix("attempt_") or 0),
                        "method_id": str(marker_payload.get("method_id", prior.get("method_id", ""))),
                        "status": "UNCONFIRMED_SUCCESS_MARKER",
                        "run_directory": str(attempt_directory),
                        "source_local_staging_path": str(
                            marker_payload.get(
                                "source_local_staging_path",
                                prior.get("source_local_staging_path", ""),
                            )
                        ),
                        "config_hash": str(marker_payload.get("config_hash", prior.get("config_hash", ""))),
                        "code_commit": str(prior.get("code_commit", "")),
                        "success_marker_valid": True,
                        "marker_payload": marker_payload,
                    }
                elif current and current["status"] in {"RUNNING", "PUBLISHING"}:
                    current["status"] = "INTERRUPTED"
                    current["run_directory"] = str(latest)
                elif current and current["status"] == "SUCCESS":
                    current["status"] = "INVALID_SUCCESS_MARKER"
                    current["run_directory"] = str(latest)
                elif latest.exists():
                    state.setdefault(
                        run_id,
                        {
                            "run_id": run_id,
                            "attempt_id": int(str(latest.name).removeprefix("attempt_") or 0),
                            "status": "INCOMPLETE_PUBLISH",
                            "run_directory": str(latest),
                        },
                    )
        # Replay is a recovery operation after a process stop.  A RUNNING
        # event without a verified marker is therefore an interrupted attempt.
        for record in state.values():
            if record.get("status") in {"RUNNING", "PUBLISHING"}:
                record["status"] = "INTERRUPTED"
        return state

    def has_verified_success(self, run_id: str) -> bool:
        record = self.replay_events().get(run_id)
        return bool(record and record.get("status") == "SUCCESS" and record.get("success_marker_valid"))

    def retry_from_staging(
        self,
        prior_attempt: StagedAttempt,
        *,
        previous_status: str = "PUBLISH_FAILED",
    ) -> StagedAttempt:
        """Copy retained local staging files into a new immutable attempt."""

        replacement = self.begin_attempt(
            run_id=prior_attempt.run_id,
            method_id=prior_attempt.method_id,
            config_hash=prior_attempt.config_hash,
            code_commit=prior_attempt.code_commit,
            previous_status=previous_status,
        )
        for source in sorted(path for path in prior_attempt.local_directory.rglob("*") if path.is_file()):
            self.stage_copy(replacement, source.relative_to(prior_attempt.local_directory), source)
        return replacement

    def rebuild_snapshot(self) -> tuple[Path, Path, dict[str, dict[str, Any]]]:
        """Write a new immutable CSV snapshot reconstructed from state events."""

        state = self.replay_events()
        values: list[int] = []
        if self._snapshots_root.is_dir():
            for path in self._snapshots_root.glob("execution_manifest_*.csv"):
                suffix = path.stem.removeprefix("execution_manifest_")
                if suffix.isdigit():
                    values.append(int(suffix))
        sequence = max(values, default=0) + 1
        snapshot = self._snapshots_root / f"execution_manifest_{sequence:06d}.csv"
        columns = [
            "run_id",
            "attempt_id",
            "status",
            "sequence_id",
            "event_id",
            "run_directory",
            "success_marker_valid",
        ]
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(stream, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for row in sorted(state.values(), key=lambda item: str(item["run_id"])):
            writer.writerow(row)
        content = stream.getvalue().encode("utf-8")
        snapshot_sha = self._write_exclusive_bytes(snapshot, content)
        checksum_path = snapshot.with_suffix(".csv.sha256")
        self._write_exclusive_bytes(checksum_path, f"{snapshot_sha}  {snapshot.name}\n".encode("utf-8"))
        self.audit.snapshot_files_written += 2
        pointer_attempt = StagedAttempt(
            run_id="manifest_snapshot",
            attempt_id=sequence,
            method_id="manifest_snapshot",
            config_hash="snapshot_replay",
            code_commit="snapshot_replay",
            local_directory=self.config.local_staging_root,
            remote_directory=self._snapshots_root,
        )
        self._record_snapshot_pointer(pointer_attempt, snapshot, snapshot_sha)
        return snapshot, checksum_path, state

    def _record_snapshot_pointer(self, attempt: StagedAttempt, snapshot: Path, snapshot_sha: str) -> Path:
        sequence_id = self._next_event_sequence()
        payload = {
            "event_id": uuid4().hex,
            "event_kind": SNAPSHOT_EVENT,
            "sequence_id": sequence_id,
            "run_id": attempt.run_id,
            "attempt_id": attempt.attempt_id,
            "previous_status": None,
            "new_status": SNAPSHOT_EVENT,
            "timestamp": _utc_now(),
            "config_hash": attempt.config_hash,
            "code_commit": attempt.code_commit,
            "storage_backend": self.backend_name,
            "snapshot_path": str(snapshot),
            "snapshot_sha256": snapshot_sha,
        }
        content = _canonical_json(payload)
        destination = self._events_root / f"{sequence_id:06d}_manifest_snapshot_{payload['event_id']}.json"
        self._inject("event:SNAPSHOT_CREATED")
        self._write_exclusive_bytes(destination, content)
        self.audit.event_files_written += 1
        return destination


def create_storage_backend(
    config: StorageConfig,
    *,
    audit: OperationAudit | None = None,
    fault_injector: FaultInjector | None = None,
) -> LocalAtomicBackend | SSHFSAppendOnlyBackend:
    """Create the backend explicitly selected by configuration."""

    if config.backend == "local_atomic":
        return LocalAtomicBackend(config, audit=audit)
    return SSHFSAppendOnlyBackend(config, audit=audit, fault_injector=fault_injector)


__all__ = [
    "ChecksumMismatchError",
    "EventWriteError",
    "ImmutableWriteError",
    "LocalAtomicBackend",
    "OperationAudit",
    "PublishError",
    "PublishResult",
    "SSHFSAppendOnlyBackend",
    "STATUS_EVENTS",
    "StagedAttempt",
    "StorageConfig",
    "StorageConfigurationError",
    "create_storage_backend",
    "load_storage_config",
    "sha256_file",
]
