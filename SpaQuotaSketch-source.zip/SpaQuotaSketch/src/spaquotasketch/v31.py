"""Exact sampled-graph candidate proposals for SpaQuotaSketch V31."""

from __future__ import annotations

from collections import Counter, defaultdict
from typing import Hashable, Sequence

import numpy as np

from .v30 import standardized_state_flow_error


def propose_exact_flow_exchange_pairs(
    selected_indices: Sequence[int],
    spatial_bin_ids: Sequence[Hashable],
    state_ids,
    full_neighbor_histograms: np.ndarray,
    current_sample_flow: np.ndarray,
    target_flow: np.ndarray,
    flow_scale: np.ndarray,
    moment_features,
    moment_loss_limit: float,
    state_l1_limit: float,
    candidate_pool_size: int = 3,
    max_candidates: int = 96,
) -> list[tuple[int, int, float]]:
    """Propose feasible within-space exchanges for exact sampled-graph evaluation.

    Full-graph neighbor information is used only to reduce a large exchange set
    to a deterministic shortlist. The caller must rebuild the sampled graph and
    decide whether an exchange is genuinely beneficial.
    """
    n_obs = len(spatial_bin_ids)
    states = np.asarray(state_ids, dtype=int)
    histograms = np.asarray(full_neighbor_histograms, dtype=float)
    flow = np.asarray(current_sample_flow, dtype=float)
    target = np.asarray(target_flow, dtype=float)
    scale = np.asarray(flow_scale, dtype=float)
    features = np.asarray(moment_features, dtype=float)
    if (
        states.shape != (n_obs,)
        or states.min(initial=0) < 0
        or histograms.shape[0] != n_obs
        or flow.shape != target.shape
        or scale.shape != target.shape
        or histograms.shape[1] != flow.shape[0]
        or features.ndim != 2
        or features.shape[0] != n_obs
        or candidate_pool_size < 1
        or max_candidates < 1
    ):
        raise ValueError("V31 proposal inputs have incompatible dimensions.")
    n_states = flow.shape[0]
    selected = np.asarray(selected_indices, dtype=int)
    if (
        selected.ndim != 1
        or selected.size == 0
        or selected.size != np.unique(selected).size
        or selected.min(initial=0) < 0
        or selected.max(initial=-1) >= n_obs
    ):
        raise ValueError("selected_indices must be unique valid indices.")
    selected_mask = np.zeros(n_obs, dtype=bool)
    selected_mask[selected] = True
    n_selected = selected.size
    state_counts = np.bincount(states[selected], minlength=n_states).astype(int)
    full_state_fraction = np.bincount(states, minlength=n_states) / n_obs
    full_mean = features.mean(axis=0)
    full_variance = features.var(axis=0)
    selected_sum = features[selected].sum(axis=0)
    selected_squares = np.square(features[selected]).sum(axis=0)
    current_error = standardized_state_flow_error(flow, target, scale)
    residual_weight = (flow - target) / np.square(scale)
    source_quotas = Counter(spatial_bin_ids[index] for index in selected)
    by_spatial: dict[Hashable, list[int]] = defaultdict(list)
    for index, spatial_bin in enumerate(spatial_bin_ids):
        by_spatial[spatial_bin].append(index)

    def moment_loss(sum_values, square_values) -> float:
        observed_mean = sum_values / n_selected
        observed_variance = np.maximum(square_values / n_selected - observed_mean**2, 0.0)
        mean_scale = np.sqrt(np.maximum(full_variance, 1e-12))
        variance_scale = np.maximum(full_variance, 1e-12)
        return float(
            np.mean(np.square((observed_mean - full_mean) / mean_scale))
            + np.mean(np.square((observed_variance - full_variance) / variance_scale))
        )

    proposals: list[tuple[float, int, int]] = []
    for spatial_bin in sorted(source_quotas, key=str):
        local = np.asarray(by_spatial[spatial_bin], dtype=int)
        incoming_all = local[~selected_mask[local]]
        outgoing_all = local[selected_mask[local]]
        removable = outgoing_all[state_counts[states[outgoing_all]] > 1]
        if incoming_all.size == 0 or removable.size == 0:
            continue
        incoming_linear = np.einsum(
            "ij,ij->i", histograms[incoming_all], residual_weight[states[incoming_all]]
        )
        outgoing_linear = np.einsum(
            "ij,ij->i", histograms[removable], residual_weight[states[removable]]
        )
        incoming_pool = incoming_all[np.argsort(incoming_linear, kind="stable")[:candidate_pool_size]]
        outgoing_pool = removable[np.argsort(-outgoing_linear, kind="stable")[:candidate_pool_size]]
        for incoming in incoming_pool.tolist():
            for outgoing in outgoing_pool.tolist():
                trial_sum = selected_sum - features[outgoing] + features[incoming]
                trial_squares = selected_squares - np.square(features[outgoing]) + np.square(features[incoming])
                if moment_loss(trial_sum, trial_squares) > moment_loss_limit + 1e-12:
                    continue
                trial_counts = state_counts.copy()
                trial_counts[states[outgoing]] -= 1
                trial_counts[states[incoming]] += 1
                state_l1 = float(np.abs(trial_counts / n_selected - full_state_fraction).sum())
                if state_l1 > state_l1_limit + 1e-12:
                    continue
                proxy_flow = flow.copy()
                proxy_flow[states[outgoing]] -= histograms[outgoing] / n_selected
                proxy_flow[states[incoming]] += histograms[incoming] / n_selected
                proxy_gain = current_error - standardized_state_flow_error(proxy_flow, target, scale)
                proposals.append((float(proxy_gain), int(incoming), int(outgoing)))
    proposals.sort(key=lambda item: (-item[0], item[1], item[2]))
    return [(incoming, outgoing, score) for score, incoming, outgoing in proposals[:max_candidates]]


__all__ = ["propose_exact_flow_exchange_pairs"]
