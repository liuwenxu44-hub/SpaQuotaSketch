"""V20 cross-fitted candidate guards for spatial transcriptomics sketches."""

from __future__ import annotations

from typing import Sequence

import numpy as np

from .metrics import composition_error


DEFAULT_RANK_METRICS = [
    "holdout_mean_relative_mae",
    "holdout_detection_relative_mae",
    "holdout_variance_relative_mae",
    "holdout_state_composition_l1",
    "holdout_graph_degree_l1",
    "negative_holdout_graph_coverage",
]


def build_holdout_structure(
    expression_features,
    n_states: int = 32,
    n_neighbors: int = 15,
    seed: int = 0,
) -> dict[str, np.ndarray]:
    """Build independent state and neighbor summaries from held-out genes."""
    from sklearn.cluster import MiniBatchKMeans
    from sklearn.neighbors import NearestNeighbors

    values = np.asarray(expression_features, dtype=float)
    if values.ndim != 2 or values.shape[0] < 2 or not np.isfinite(values).all():
        raise ValueError("expression_features must be a finite two-dimensional array.")
    n_obs = values.shape[0]
    n_states = min(max(1, int(n_states)), n_obs)
    n_neighbors = min(max(1, int(n_neighbors)), n_obs - 1)
    scale = values.std(axis=0)
    scale[scale <= np.finfo(float).eps] = 1.0
    standardized = (values - values.mean(axis=0)) / scale
    state_ids = MiniBatchKMeans(
        n_clusters=n_states,
        batch_size=min(4096, n_obs),
        n_init=3,
        max_iter=100,
        random_state=seed,
    ).fit_predict(standardized).astype(int)
    neighbors = NearestNeighbors(n_neighbors=n_neighbors + 1, algorithm="auto").fit(
        standardized
    ).kneighbors(standardized, return_distance=False)[:, 1:]
    degree = np.bincount(neighbors.reshape(-1), minlength=n_obs).astype(float)
    quantiles = np.quantile(degree, np.linspace(0.0, 1.0, 11))
    degree_bins = np.digitize(degree, quantiles[1:-1], right=True).astype(int)
    return {
        "state_ids": state_ids,
        "neighbor_indices": neighbors.astype(int),
        "degree_bins": degree_bins,
    }


def holdout_structure_metrics(
    selected_indices: Sequence[int],
    holdout_structure: dict[str, np.ndarray],
) -> dict[str, float]:
    """Measure whether a candidate preserves held-out states and graph degree mix."""
    selected = np.asarray(selected_indices, dtype=int)
    state_ids = np.asarray(holdout_structure["state_ids"], dtype=int)
    degree_bins = np.asarray(holdout_structure["degree_bins"], dtype=int)
    neighbors = np.asarray(holdout_structure["neighbor_indices"], dtype=int)
    n_obs = state_ids.size
    if (
        selected.ndim != 1
        or selected.size == 0
        or selected.size != np.unique(selected).size
        or selected.min(initial=0) < 0
        or selected.max(initial=-1) >= n_obs
        or degree_bins.shape != (n_obs,)
        or neighbors.ndim != 2
        or neighbors.shape[0] != n_obs
    ):
        raise ValueError("selected_indices and holdout_structure must describe the same observations.")
    selected_mask = np.zeros(n_obs, dtype=bool)
    selected_mask[selected] = True
    represented = selected_mask | selected_mask[neighbors].any(axis=1)
    return {
        "holdout_state_composition_l1": float(
            composition_error(state_ids.tolist(), state_ids[selected].tolist())
        ),
        "holdout_graph_degree_l1": float(
            composition_error(degree_bins.tolist(), degree_bins[selected].tolist())
        ),
        "holdout_graph_coverage": float(represented.mean()),
    }


def choose_crossfit_guarded_candidate(
    candidate_rows: list[dict[str, object]],
    baseline_name: str,
    metric_names: Sequence[str] | None = None,
) -> tuple[int, list[dict[str, object]], str]:
    """Choose a candidate that passes independent expression and structure guards.

    Gene moments must not worsen compared with the seed-zero candidate. State and
    neighbor-distribution metrics may vary only by their sampling-resolution bound.
    The final choice is based on ranks, avoiding hand-set metric weights.
    """
    if not candidate_rows:
        raise ValueError("candidate_rows must not be empty.")
    baseline_positions = [
        index for index, row in enumerate(candidate_rows) if row.get("candidate_name") == baseline_name
    ]
    if len(baseline_positions) != 1:
        raise ValueError("baseline_name must identify exactly one candidate.")
    required = set(DEFAULT_RANK_METRICS) | {"candidate_name", "n_selected"}
    if any(required.difference(row) for row in candidate_rows):
        raise ValueError("Every candidate must provide the V20 guard metrics.")
    if metric_names is None:
        metric_names = DEFAULT_RANK_METRICS
    if not metric_names or any(
        metric not in row for metric in metric_names for row in candidate_rows
    ):
        raise ValueError("metric_names must be non-empty and present in every candidate row.")

    baseline_index = baseline_positions[0]
    baseline = candidate_rows[baseline_index]
    n_selected = max(1, int(baseline["n_selected"]))
    resolution = 1.0 / np.sqrt(n_selected)
    eligible: list[int] = []
    for index, row in enumerate(candidate_rows):
        moments_preserved = all(
            float(row[metric]) <= float(baseline[metric]) + 1e-12
            for metric in (
                "holdout_mean_relative_mae",
                "holdout_detection_relative_mae",
                "holdout_variance_relative_mae",
            )
        )
        structure_preserved = (
            float(row["holdout_state_composition_l1"])
            <= float(baseline["holdout_state_composition_l1"]) + resolution + 1e-12
            and float(row["holdout_graph_degree_l1"])
            <= float(baseline["holdout_graph_degree_l1"]) + resolution + 1e-12
            and float(row["holdout_graph_coverage"])
            >= float(baseline["holdout_graph_coverage"]) - resolution - 1e-12
        )
        if moments_preserved and structure_preserved:
            eligible.append(index)
    if not eligible:
        return baseline_index, [dict(row) for row in candidate_rows], "baseline_guard_fallback"

    ranked = [dict(row) for row in candidate_rows]
    for index, row in enumerate(ranked):
        row["crossfit_guard_passed"] = index in eligible
        row["structural_resolution"] = float(resolution)
    for metric in metric_names:
        ordered = sorted(
            eligible,
            key=lambda index: (float(ranked[index][metric]), str(ranked[index]["candidate_name"])),
        )
        for rank, index in enumerate(ordered, start=1):
            ranked[index][f"rank_{metric}"] = int(rank)
    for index in eligible:
        ranked[index]["mean_rank"] = float(
            np.mean([ranked[index][f"rank_{metric}"] for metric in metric_names])
        )
    for index, row in enumerate(ranked):
        if index not in eligible:
            row["mean_rank"] = float("inf")
    winner = min(
        eligible,
        key=lambda index: (ranked[index]["mean_rank"], str(ranked[index]["candidate_name"])),
    )
    return winner, ranked, "crossfit_guarded_rank"


__all__ = [
    "DEFAULT_RANK_METRICS",
    "build_holdout_structure",
    "choose_crossfit_guarded_candidate",
    "holdout_structure_metrics",
]
