"""Strict reader for the only official pancreas R2 evidence bundle."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping


OFFICIAL_R2_SUMMARY_NAME = "formal_r2_summary_v3"


class OfficialEvidenceError(ValueError):
    """Raised when a caller tries to treat an audit-only bundle as official evidence."""


def read_official_pancreas_r2_evidence(summary_directory: str | Path) -> Mapping[str, Any]:
    """Read only the immutable v3 success marker, never v1 or v2 summaries."""
    directory = Path(summary_directory)
    if directory.name != OFFICIAL_R2_SUMMARY_NAME:
        raise OfficialEvidenceError(
            "Official pancreas R2 evidence must be read from formal_r2_summary_v3; "
            "v1 and v2 summary bundles are audit-only and cannot support public claims."
        )
    marker = directory / "_SUCCESS.json"
    if not marker.is_file():
        raise OfficialEvidenceError("Official R2 evidence requires the immutable _SUCCESS.json marker.")
    try:
        payload = json.loads(marker.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise OfficialEvidenceError("Official R2 _SUCCESS.json could not be read.") from error
    if payload.get("provenance_id") != OFFICIAL_R2_SUMMARY_NAME:
        raise OfficialEvidenceError("R2 marker provenance_id does not identify formal_r2_summary_v3.")
    metadata = payload.get("metadata")
    if not isinstance(metadata, Mapping) or metadata.get("artifact_type") != "formal_r2_summary":
        raise OfficialEvidenceError("R2 marker does not describe an official formal summary artifact.")
    return payload


__all__ = ["OFFICIAL_R2_SUMMARY_NAME", "OfficialEvidenceError", "read_official_pancreas_r2_evidence"]
