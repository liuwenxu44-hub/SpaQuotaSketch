"""V18 stratum-constrained representative selection for a fixed V17 plan."""

from __future__ import annotations

from collections import Counter, defaultdict
from typing import Hashable, Sequence

import numpy as np


def _rank_positions(values: np.ndarray) -> np.ndarray:
    """Return zero-based stable ranks where smaller values receive lower ranks."""
    order = np.argsort(values, kind="stable")
    ranks = np.empty(values.size, dtype=int)
    ranks[order] = np.arange(values.size, dtype=int)
    return ranks


def _facility_selection(
    spatial_values: np.ndarray,
    expression_values: np.ndarray,
    target_n: int,
    strategy: str,
) -> np.ndarray:
    """Select local representatives by spatial, expression, or rank-balanced coverage."""
    from scipy.spatial.distance import cdist

    n_obs = spatial_values.shape[0]
    target_n = min(max(int(target_n), 0), n_obs)
    if target_n == 0:
        return np.empty(0, dtype=int)
    if target_n >= n_obs:
        return np.arange(n_obs, dtype=int)
    if strategy not in {"spatial", "expression", "rank"}:
        raise ValueError("strategy must be spatial, expression, or rank.")
    spatial_distances = cdist(spatial_values, spatial_values, metric="euclidean")
    expression_distances = cdist(expression_values, expression_values, metric="euclidean")
    chosen: list[int] = []
    nearest_spatial = np.full(n_obs, np.inf, dtype=float)
    nearest_expression = np.full(n_obs, np.inf, dtype=float)
    for _ in range(target_n):
        available = np.asarray([index for index in range(n_obs) if index not in chosen], dtype=int)
        spatial_loss = np.minimum(nearest_spatial[:, None], spatial_distances[:, available]).mean(axis=0)
        expression_loss = np.minimum(
            nearest_expression[:, None], expression_distances[:, available]
        ).mean(axis=0)
        if strategy == "spatial":
            local_position = int(np.argmin(spatial_loss))
        elif strategy == "expression":
            local_position = int(np.argmin(expression_loss))
        else:
            combined_rank = _rank_positions(spatial_loss) + _rank_positions(expression_loss)
            local_position = int(np.argmin(combined_rank))
        candidate = int(available[local_position])
        chosen.append(candidate)
        nearest_spatial = np.minimum(nearest_spatial, spatial_distances[:, candidate])
        nearest_expression = np.minimum(nearest_expression, expression_distances[:, candidate])
    return np.asarray(chosen, dtype=int)


def stratum_constrained_selection(
    triple_indices: dict[tuple[Hashable, Hashable, Hashable], list[int]],
    triple_plan: dict[tuple[Hashable, Hashable, Hashable], int],
    spatial_coordinates,
    expression_features,
    strategy: str,
    seed: int = 0,
) -> list[int]:
    """Choose cells without changing any V17 fine-space/state/expression quota."""
    coordinates = np.asarray(spatial_coordinates, dtype=float)
    features = np.asarray(expression_features, dtype=float)
    if coordinates.ndim != 2 or coordinates.shape[1] < 2:
        raise ValueError("spatial_coordinates must have at least two columns.")
    if features.ndim != 2 or features.shape[0] != coordinates.shape[0]:
        raise ValueError("expression_features must have one row per spatial coordinate.")
    rng = np.random.default_rng(seed)
    selected: list[int] = []
    for triple, quota in triple_plan.items():
        available = np.asarray(triple_indices[triple], dtype=int)
        target_n = int(quota)
        if target_n <= 0:
            continue
        if target_n > available.size:
            raise ValueError("A triple quota cannot exceed its available cells.")
        if strategy == "random":
            chosen = available if target_n == available.size else rng.choice(
                available, size=target_n, replace=False
            )
        else:
            local = _facility_selection(
                coordinates[available, :2],
                features[available],
                target_n,
                strategy,
            )
            chosen = available[local]
        selected.extend(np.asarray(chosen, dtype=int).tolist())
    if len(selected) != sum(triple_plan.values()) or len(set(selected)) != len(selected):
        raise RuntimeError("Stratum-constrained selection did not preserve the requested sample size.")
    return sorted(selected)


def validate_triple_quotas(
    selected_indices: Sequence[int],
    fine_spatial_bin_ids: Sequence[Hashable],
    fine_state_ids: Sequence[Hashable],
    expression_bin_ids: Sequence[Hashable],
    triple_plan: dict[tuple[Hashable, Hashable, Hashable], int],
) -> bool:
    """Check that a selected set has exactly the V17 triple counts."""
    observed = Counter(
        (
            fine_spatial_bin_ids[index],
            fine_state_ids[index],
            expression_bin_ids[index],
        )
        for index in selected_indices
    )
    expected = Counter({triple: int(count) for triple, count in triple_plan.items() if count > 0})
    return observed == expected


def local_nearest_mean(
    values,
    primary_spatial_bin_ids: Sequence[Hashable],
    selected_indices: Sequence[int],
) -> float:
    """Mean local distance to the nearest selected cell within each primary bin."""
    from sklearn.neighbors import NearestNeighbors

    array = np.asarray(values, dtype=float)
    if array.ndim != 2 or array.shape[0] != len(primary_spatial_bin_ids):
        raise ValueError("values must be two-dimensional with one row per primary bin id.")
    scale = array.std(axis=0)
    scale[scale <= np.finfo(float).eps] = 1.0
    standardized = (array - array.mean(axis=0)) / scale
    selected_mask = np.zeros(array.shape[0], dtype=bool)
    selected_mask[np.asarray(selected_indices, dtype=int)] = True
    by_primary: dict[Hashable, list[int]] = defaultdict(list)
    for index, primary in enumerate(primary_spatial_bin_ids):
        by_primary[primary].append(index)
    distances: list[np.ndarray] = []
    for indices in by_primary.values():
        positions = np.asarray(indices, dtype=int)
        chosen = positions[selected_mask[positions]]
        if chosen.size == 0:
            continue
        model = NearestNeighbors(n_neighbors=1, algorithm="auto")
        model.fit(standardized[chosen])
        distances.append(model.kneighbors(standardized[positions], return_distance=True)[0][:, 0])
    if not distances:
        return float("inf")
    return float(np.concatenate(distances).mean())


def choose_holdout_guarded_candidate(
    candidate_rows: list[dict[str, object]],
    baseline_name: str,
    metric_names: Sequence[str] | None = None,
) -> tuple[int, list[dict[str, object]], str]:
    """Choose by average rank after an independent gene-statistics guard."""
    if not candidate_rows:
        raise ValueError("candidate_rows must not be empty.")
    baseline_positions = [
        index for index, row in enumerate(candidate_rows) if row["candidate_name"] == baseline_name
    ]
    if len(baseline_positions) != 1:
        raise ValueError("baseline_name must identify exactly one candidate.")
    baseline = candidate_rows[baseline_positions[0]]
    mean_limit = float(baseline["holdout_mean_relative_mae"])
    variance_limit = float(baseline["holdout_variance_relative_mae"])
    eligible = [
        index
        for index, row in enumerate(candidate_rows)
        if float(row["holdout_mean_relative_mae"]) <= mean_limit + 1e-12
        and float(row["holdout_variance_relative_mae"]) <= variance_limit + 1e-12
    ]
    if not eligible:
        return baseline_positions[0], [dict(row) for row in candidate_rows], "baseline_guard_fallback"
    if metric_names is None:
        metric_names = [
            "local_spatial_distance",
            "local_expression_distance",
            "holdout_mean_relative_mae",
            "holdout_variance_relative_mae",
        ]
    if not metric_names or any(
        metric not in row for metric in metric_names for row in candidate_rows
    ):
        raise ValueError("metric_names must be non-empty and present in every candidate row.")
    ranked = [dict(row) for row in candidate_rows]
    for row in ranked:
        row["holdout_guard_passed"] = False
    for index in eligible:
        ranked[index]["holdout_guard_passed"] = True
    for metric in metric_names:
        ordered = sorted(
            eligible,
            key=lambda index: (float(ranked[index][metric]), str(ranked[index]["candidate_name"])),
        )
        for rank, index in enumerate(ordered, start=1):
            ranked[index][f"rank_{metric}"] = rank
    for index in eligible:
        ranked[index]["mean_rank"] = float(
            np.mean([ranked[index][f"rank_{metric}"] for metric in metric_names])
        )
    for index, row in enumerate(ranked):
        if index not in eligible:
            row["mean_rank"] = float("inf")
    winner = min(
        eligible,
        key=lambda index: (ranked[index]["mean_rank"], str(ranked[index]["candidate_name"])),
    )
    return winner, ranked, "holdout_guarded_rank"


__all__ = [
    "choose_holdout_guarded_candidate",
    "local_nearest_mean",
    "stratum_constrained_selection",
    "validate_triple_quotas",
]
