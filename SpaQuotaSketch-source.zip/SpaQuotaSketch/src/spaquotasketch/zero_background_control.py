"""Controlled zero-background simulations for fixed-quota sampling designs."""

from __future__ import annotations

from dataclasses import dataclass
from types import SimpleNamespace
from typing import Any

import numpy as np

from .fixed_quota_probability import (
    DIRECT_SPATIAL_QUOTA_SRS,
    LEVERAGE_WEIGHTED_FIXED_QUOTA,
    fixed_quota_probability_selections,
    hajek_normalized_expression_fidelity,
)
from .preprocess import compute_normalized_log1p_svd_representation


@dataclass(frozen=True)
class ZeroBackgroundPopulation:
    """One simulated spatial population with observable zero-count background."""

    counts: np.ndarray
    coordinates: np.ndarray
    spatial_strata: np.ndarray
    zero_background: np.ndarray


@dataclass(frozen=True)
class PreparedZeroBackgroundPopulation:
    """One population plus the common expression representation used for all draws."""

    population: ZeroBackgroundPopulation
    expression_embedding: np.ndarray
    expression_basis: np.ndarray
    normalized_log1p_matrix: Any


def generate_zero_background_population(
    *,
    grid_side: int,
    cells_per_stratum: int,
    n_genes: int,
    zero_background_fraction: float,
    seed: int,
) -> ZeroBackgroundPopulation:
    """Generate a spatial population with exact within-stratum zero fractions.

    Background status is observable through an all-zero count row but is never
    passed directly to the sampler. The sampler receives only the expression
    representation derived from the count matrix.
    """
    grid_side = int(grid_side)
    cells_per_stratum = int(cells_per_stratum)
    n_genes = int(n_genes)
    zero_background_fraction = float(zero_background_fraction)
    if grid_side < 1 or cells_per_stratum < 2 or n_genes < 3:
        raise ValueError("grid_side, cells_per_stratum, and n_genes are too small.")
    if not 0 <= zero_background_fraction < 1:
        raise ValueError("zero_background_fraction must be in [0, 1).")
    rng = np.random.default_rng(int(seed))
    labels: list[str] = []
    locations: list[np.ndarray] = []
    rows: list[np.ndarray] = []
    background: list[np.ndarray] = []
    n_zero = int(round(cells_per_stratum * zero_background_fraction))
    n_positive = cells_per_stratum - n_zero
    if n_positive < 1:
        raise ValueError("Every spatial stratum must retain at least one positive-count cell.")
    gene_baseline = rng.gamma(shape=1.5, scale=1.2, size=n_genes)
    for x_index in range(grid_side):
        for y_index in range(grid_side):
            label = f"x{x_index:02d}_y{y_index:02d}"
            local = np.column_stack(
                (
                    x_index + rng.uniform(0.05, 0.95, size=cells_per_stratum),
                    y_index + rng.uniform(0.05, 0.95, size=cells_per_stratum),
                )
            )
            positive_library = rng.lognormal(mean=2.8, sigma=0.45, size=n_positive)
            local_state = rng.integers(0, 3, size=n_positive)
            state_effect = np.ones((n_positive, n_genes), dtype=float)
            for state in range(3):
                start = (state * 7) % n_genes
                state_effect[local_state == state, start : start + 7] = 4.0
            positive_counts = rng.poisson(
                positive_library[:, None] * gene_baseline[None, :] * state_effect / 25.0
            ).astype(float)
            local_rows = np.vstack((positive_counts, np.zeros((n_zero, n_genes), dtype=float)))
            local_background = np.concatenate(
                (np.zeros(n_positive, dtype=bool), np.ones(n_zero, dtype=bool))
            )
            permutation = rng.permutation(cells_per_stratum)
            rows.append(local_rows[permutation])
            background.append(local_background[permutation])
            locations.append(local[permutation])
            labels.extend([label] * cells_per_stratum)
    return ZeroBackgroundPopulation(
        counts=np.vstack(rows),
        coordinates=np.vstack(locations),
        spatial_strata=np.asarray(labels, dtype=object),
        zero_background=np.concatenate(background),
    )


def prepare_zero_background_population(
    population: ZeroBackgroundPopulation,
    *,
    n_components: int,
) -> PreparedZeroBackgroundPopulation:
    """Compute the common representation once before technical sampling repeats."""
    adata = SimpleNamespace(
        X=population.counts,
        obsm={"spatial": population.coordinates},
    )
    embedding, basis, normalized = compute_normalized_log1p_svd_representation(
        adata,
        n_components=int(n_components),
        random_state=0,
    )
    return PreparedZeroBackgroundPopulation(
        population=population,
        expression_embedding=embedding,
        expression_basis=basis,
        normalized_log1p_matrix=normalized,
    )


def evaluate_zero_background_population(
    population: ZeroBackgroundPopulation,
    *,
    quota_per_stratum: int,
    n_components: int,
    seed: int,
    max_weight_inflation: float = 4.0,
    prepared: PreparedZeroBackgroundPopulation | None = None,
) -> dict[str, Any]:
    """Evaluate direct and leverage-weighted designs under identical quotas."""
    quota_per_stratum = int(quota_per_stratum)
    prepared = prepared or prepare_zero_background_population(
        population,
        n_components=int(n_components),
    )
    if prepared.population is not population:
        raise ValueError("prepared representation must belong to the supplied population")
    embedding = prepared.expression_embedding
    basis = prepared.expression_basis
    normalized = prepared.normalized_log1p_matrix
    strata = population.spatial_strata
    quotas = {
        stratum: quota_per_stratum
        for stratum in sorted(set(strata.tolist()))
    }
    selections = fixed_quota_probability_selections(
        expression_embedding=embedding,
        expression_basis=basis,
        spatial_strata=strata,
        quotas=quotas,
        seed=int(seed),
        max_weight_inflation=float(max_weight_inflation),
    )
    output: dict[str, Any] = {
        "n_obs": int(strata.size),
        "zero_background_fraction_population": float(population.zero_background.mean()),
        "quota_per_stratum": quota_per_stratum,
        "all_spatial_quotas_exact": all(
            bool(selection.diagnostics["all_spatial_quotas_exact"])
            for selection in selections.values()
        ),
    }
    for method in (DIRECT_SPATIAL_QUOTA_SRS, LEVERAGE_WEIGHTED_FIXED_QUOTA):
        selection = selections[method]
        metrics = hajek_normalized_expression_fidelity(
            normalized,
            selection.selected_indices,
            selection.sampling_weight,
        )
        output[f"selected_zero_background_fraction__{method}"] = float(
            population.zero_background[selection.selected_indices].mean()
        )
        output.update({f"{key}__{method}": value for key, value in metrics.items()})
    for metric in ("gene_mean_l1_error_hajek", "gene_detection_l1_error_hajek"):
        output[f"direct_minus_weighted__{metric}"] = (
            output[f"{metric}__{DIRECT_SPATIAL_QUOTA_SRS}"]
            - output[f"{metric}__{LEVERAGE_WEIGHTED_FIXED_QUOTA}"]
        )
    return output


__all__ = [
    "PreparedZeroBackgroundPopulation",
    "ZeroBackgroundPopulation",
    "evaluate_zero_background_population",
    "generate_zero_background_population",
    "prepare_zero_background_population",
]
