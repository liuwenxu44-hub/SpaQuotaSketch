"""Small shared utilities."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def ensure_parent_dir(path: str | Path) -> None:
    """Create the parent directory for a file path if needed."""
    Path(path).parent.mkdir(parents=True, exist_ok=True)


def refuse_overwrite(path: str | Path) -> None:
    """Raise an error when a target path already exists."""
    target = Path(path)
    if target.exists():
        raise FileExistsError(f"Refusing to overwrite existing file: {target}")


def write_json(data: dict[str, Any], path: str | Path, overwrite: bool = False) -> None:
    """Write JSON with overwrite protection."""
    output_path = Path(path)
    ensure_parent_dir(output_path)
    if not overwrite:
        refuse_overwrite(output_path)
    output_path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def read_yaml(path: str | Path) -> dict[str, Any]:
    """Read a YAML configuration file."""
    import yaml

    with Path(path).open("r", encoding="utf-8") as handle:
        loaded = yaml.safe_load(handle)
    return loaded or {}
