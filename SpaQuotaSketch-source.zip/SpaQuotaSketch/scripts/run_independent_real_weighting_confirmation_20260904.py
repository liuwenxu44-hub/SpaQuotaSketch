"""Prospectively frozen independent real-data confirmation, 2026-09-04.

The command line is deliberately stage separated.  ``qualify`` reads only
metadata and input schema; ``freeze`` writes the preregistration; ``pilot``
cannot create holdout records; and ``holdout`` requires the frozen pilot
decision hash before it can run.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
from hashlib import sha256
import importlib.util
import json
import os
from pathlib import Path
import pickle
import platform
import subprocess
import sys
from types import SimpleNamespace
from typing import Any

import h5py
import numpy as np
import pandas as pd
from scipy import sparse
import scipy
import sklearn
import yaml


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from spaquotasketch.benchmark.formal_multiplatform_input_adapters import FormalRawInput
from spaquotasketch.fixed_quota_probability import EQUAL_PROBABILITY_FIXED_QUOTA


ANALYSIS_ID = "independent_real_weighting_confirmation_20260904"
OUTPUT = ROOT / "results" / ANALYSIS_ID
RAW_ROOT = ROOT / "data" / "raw" / ANALYSIS_ID
CONFIG = ROOT / "configs" / "independent_real_weighting_confirmation_preregistration_20260904.yaml"
EQUAL = EQUAL_PROBABILITY_FIXED_QUOTA
R2 = "leverage_weighted_fixed_quota_r2"
R4 = "leverage_weighted_fixed_quota_r4"
PILOT_SEEDS = [1101, 1201]
HOLDOUT_SEEDS = [2101, 2201, 2301]
FRACTIONS = [0.02, 0.05, 0.10]


DATASETS = [
    {
        "dataset_id": "xenium_prime_human_lymph_node_reactive_ffpe",
        "dataset": "10x Xenium Prime FFPE human reactive lymph node",
        "accession": "Xenium_Prime_Human_Lymph_Node_Reactive_FFPE",
        "platform": "Xenium Prime 5K",
        "tissue": "reactive lymph node",
        "donor": "DONOR_NOT_DISCLOSED_BY_OFFICIAL_SOURCE",
        "section": "Xenium_Prime_Human_Lymph_Node_Reactive_FFPE",
        "sample": "Xenium_Prime_Human_Lymph_Node_Reactive_FFPE",
        "official_url": "https://www.10xgenomics.com/datasets/preview-data-xenium-prime-gene-expression",
        "cells_reported": 708983,
        "genes_reported": 4624,
        "heterogeneity_evidence": "cell-level platform; reactive lymph node; author cell groups and pathology annotation; more than 50,000 cells",
    },
    {
        "dataset_id": "xenium_prime_human_lung_cancer_ffpe",
        "dataset": "10x Xenium Prime FFPE human lung adenocarcinoma",
        "accession": "Xenium_Prime_Human_Lung_Cancer_FFPE",
        "platform": "Xenium Prime 5K",
        "tissue": "lung adenocarcinoma",
        "donor": "DONOR_NOT_DISCLOSED_BY_OFFICIAL_SOURCE",
        "section": "Xenium_Prime_Human_Lung_Cancer_FFPE",
        "sample": "Xenium_Prime_Human_Lung_Cancer_FFPE",
        "official_url": "https://www.10xgenomics.com/datasets/xenium-human-lung-cancer-post-xenium-technote",
        "cells_reported": 278328,
        "genes_reported": 5001,
        "heterogeneity_evidence": "cell-level platform; complex lung tumor microenvironment; author pathology context; more than 50,000 cells",
    },
    {
        "dataset_id": "xenium_prime_human_skin_melanoma_ffpe",
        "dataset": "10x Xenium Prime FFPE human primary dermal melanoma",
        "accession": "Xenium_Prime_Human_Skin_FFPE",
        "platform": "Xenium Prime 5K",
        "tissue": "primary dermal melanoma",
        "donor": "DONOR_NOT_DISCLOSED_BY_OFFICIAL_SOURCE",
        "section": "Xenium_Prime_Human_Skin_FFPE",
        "sample": "Xenium_Prime_Human_Skin_FFPE",
        "official_url": "https://www.10xgenomics.com/datasets/xenium-prime-ffpe-human-skin",
        "cells_reported": 112551,
        "genes_reported": 5006,
        "heterogeneity_evidence": "cell-level platform; tumor, dermis and necrotic boundary; author pathology context; more than 50,000 cells",
    },
]


FROZEN_FILES = {
    "gate_code": "src/spaquotasketch/safe_gate.py",
    "gate_config": "configs/final_simplified_safety_gate_v1.yaml",
    "preprocessing_code": "src/spaquotasketch/preprocess.py",
    "fixed_quota_probability_code": "src/spaquotasketch/fixed_quota_probability.py",
    "spatial_partition_code": "src/spaquotasketch/v2_1/spatial.py",
    "quota_allocator_code": "src/spaquotasketch/v2_1/quota.py",
    "formal_validation_script": "scripts/run_independent_real_weighting_confirmation_20260904.py",
}


def now() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def digest(path: Path) -> str:
    value = sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def canonical_digest(frame: pd.DataFrame) -> str:
    text = frame.sort_values(list(frame.columns)).to_csv(index=False, lineterminator="\n")
    return sha256(text.encode("utf-8")).hexdigest()


def source_paths(dataset: dict[str, Any]) -> tuple[Path, Path]:
    directory = RAW_ROOT / dataset["dataset_id"]
    prefix = dataset["accession"]
    return directory / f"{prefix}_cell_feature_matrix.h5", directory / f"{prefix}_cells.csv.gz"


def server_url(dataset: dict[str, Any], suffix: str) -> str:
    prefix = dataset["accession"]
    return f"https://s3-us-west-2.amazonaws.com/10x.files/samples/xenium/3.0.0/{prefix}/{prefix}_{suffix}"


def inspect_dataset(dataset: dict[str, Any]) -> dict[str, Any]:
    matrix_path, cells_path = source_paths(dataset)
    row = {key: dataset[key] for key in ("dataset_id", "dataset", "accession", "platform", "tissue", "donor", "section", "sample", "official_url", "heterogeneity_evidence")}
    row.update({"data_level": "dataset_section", "qualification_stage": "metadata_schema_qc_only", "performance_examined": False})
    try:
        if not matrix_path.is_file() or not cells_path.is_file():
            raise FileNotFoundError("required minimal official files are missing")
        with h5py.File(matrix_path, "r") as handle:
            group = handle["matrix"]
            shape = tuple(int(v) for v in group["shape"][:])
            barcodes = np.asarray([v.decode() if isinstance(v, bytes) else str(v) for v in group["barcodes"][:]], dtype=str)
            feature_types = np.asarray([v.decode() if isinstance(v, bytes) else str(v) for v in group["features"]["feature_type"][:]], dtype=str)
            gene_count = int(np.sum(feature_types == "Gene Expression"))
            data = group["data"]
            minimum = None
            for start in range(0, data.shape[0], 4_000_000):
                part = data[start:start + 4_000_000]
                local = int(part.min()) if part.size else 0
                minimum = local if minimum is None else min(minimum, local)
            matrix_integer = np.issubdtype(data.dtype, np.integer)
            nnz = int(data.shape[0])
        cells = pd.read_csv(cells_path, usecols=["cell_id", "x_centroid", "y_centroid"])
        ids = cells["cell_id"].astype(str).to_numpy()
        coordinates = cells[["x_centroid", "y_centroid"]].to_numpy(dtype=float)
        id_bijection = bool(ids.size == barcodes.size and len(set(ids.tolist())) == ids.size and len(set(barcodes.tolist())) == barcodes.size and set(ids.tolist()) == set(barcodes.tolist()))
        coordinate_ok = bool(coordinates.shape == (ids.size, 2) and np.isfinite(coordinates).all())
        passes = bool(shape[1] == ids.size and ids.size >= 20000 and gene_count >= 500 and id_bijection and coordinate_ok and matrix_integer and minimum is not None and minimum >= 0)
        row.update({
            "matrix_file": matrix_path.relative_to(ROOT).as_posix(), "cells_file": cells_path.relative_to(ROOT).as_posix(),
            "matrix_bytes": matrix_path.stat().st_size, "cells_bytes": cells_path.stat().st_size,
            "matrix_sha256": digest(matrix_path), "cells_sha256": digest(cells_path),
            "n_cells": int(ids.size), "n_matrix_features_all_types": int(shape[0]), "n_gene_expression_features": gene_count,
            "matrix_nnz_all_types": nnz, "raw_integer_nonnegative_counts": bool(matrix_integer and minimum >= 0),
            "cell_ids_unique": len(set(ids.tolist())) == ids.size, "matrix_ids_unique": len(set(barcodes.tolist())) == barcodes.size,
            "matrix_coordinate_id_bijection": id_bijection, "coordinates_complete_finite": coordinate_ok,
            "license": "CC BY 4.0", "independence_status": "NO_EXACT_IDENTIFIER_OR_TITLE_HIT_IN_REPOSITORY_OR_GIT_HISTORY",
            "qualification_status": "QUALIFIED" if passes else "NOT_QUALIFIED", "eligible": passes,
            "reason": "all frozen non-performance eligibility checks passed" if passes else "one or more frozen schema or scale checks failed",
        })
    except Exception as error:
        row.update({"qualification_status": "NOT_QUALIFIED", "eligible": False, "reason": f"{type(error).__name__}: {error}"})
    return row


def qualification() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    rows = [inspect_dataset(item) for item in DATASETS]
    frame = pd.DataFrame(rows)
    frame.to_csv(OUTPUT / "candidate_dataset_qualification.csv", index=False, encoding="utf-8")
    registry = yaml.safe_load((ROOT / "configs/multiplatform_candidate_dataset_registry.yaml").read_text(encoding="utf-8"))
    audit_rows = []
    for item in registry["candidates"]:
        status = str(item.get("qualification_status", "UNKNOWN"))
        prior = bool(item.get("local_development_trace")) or str(item.get("candidate_identity_class")) == "DEVELOPMENT_ONLY"
        audit_rows.append({
            "dataset_id": item.get("candidate_id"), "dataset": item.get("canonical_dataset_name"), "accession": item.get("accession"),
            "platform": item.get("platform", "NOT_RECORDED"), "tissue": item.get("tissue", "NOT_RECORDED"),
            "prior_exposure_evidence": item.get("project_history_trace", "registry metadata entry"),
            "evidence_file_path": "configs/multiplatform_candidate_dataset_registry.yaml",
            "independent_eligible": False,
            "exclusion_reason": item.get("exclusion_reason") if prior else "not_selected_by_current_mechanical_top_three_after_file_availability_independence_and_resource_ranking",
            "historical_registry_status": status,
        })
    for item in DATASETS:
        audit_rows.append({
            "dataset_id": item["dataset_id"], "dataset": item["dataset"], "accession": item["accession"], "platform": item["platform"], "tissue": item["tissue"],
            "prior_exposure_evidence": "no exact accession, sample identifier, or title hit in repository working tree or Git history before qualification",
            "evidence_file_path": "repository-wide rg and git log -G audit recorded 2026-09-04",
            "independent_eligible": True, "exclusion_reason": "NONE", "historical_registry_status": "NEWLY_AUDITED",
        })
    audit = pd.DataFrame(audit_rows).drop_duplicates(subset=["dataset_id"], keep="last")
    audit.to_csv(OUTPUT / "independence_exclusion_audit.csv", index=False, encoding="utf-8")
    download_rows = []
    for item in DATASETS:
        matrix, cells = source_paths(item)
        for role, path, suffix in (("raw_count_matrix", matrix, "cell_feature_matrix.h5"), ("cell_coordinates", cells, "cells.csv.gz")):
            download_rows.append({"dataset_id": item["dataset_id"], "accession": item["accession"], "file_role": role, "official_dataset_url": item["official_url"], "official_object_url": server_url(item, suffix), "accessed_at": now(), "bytes": path.stat().st_size, "sha256": digest(path), "license": "CC BY 4.0", "download_complete": True})
    pd.DataFrame(download_rows).to_csv(OUTPUT / "download_manifest.csv", index=False, encoding="utf-8")
    qualified = frame.loc[frame["eligible"] == True]
    report = ["# Qualification report", "", f"Stage: metadata, file schema and input quality only; no SpaQuotaSketch score, pilot benefit or holdout outcome was calculated.", "", f"Audited candidate registry plus new candidates: {len(audit)} datasets.", f"Qualified and mechanically selected projects/sections: {len(qualified)}/{len(DATASETS)}.", "", "The three selected projects are the highest-ranked clean, publicly downloadable, cell-level candidates identified under the fixed resource cap of three projects and one available independent section per project. All exceed 20,000 cells and 500 Gene Expression features; each meets at least two opportunity-enrichment criteria.", "", "CosMx NSCLC was excluded conservatively because it already appeared in the pre-freeze project candidate inventory. Existing development, figure, ablation, retrospective, v21 and DLPFC inputs remain excluded."]
    (OUTPUT / "qualification_report.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(json.dumps({"audited_candidates": len(audit), "qualified": len(qualified)}, indent=2))


def load_gene_expression_xenium(matrix_path: Path, cells_path: Path) -> FormalRawInput:
    with h5py.File(matrix_path, "r") as handle:
        group = handle["matrix"]
        shape = tuple(int(v) for v in group["shape"][:])
        cell_ids = np.asarray([v.decode() if isinstance(v, bytes) else str(v) for v in group["barcodes"][:]], dtype=str)
        feature_ids_all = np.asarray([v.decode() if isinstance(v, bytes) else str(v) for v in group["features"]["id"][:]], dtype=str)
        feature_types = np.asarray([v.decode() if isinstance(v, bytes) else str(v) for v in group["features"]["feature_type"][:]], dtype=str)
        gene_mask = feature_types == "Gene Expression"
        remap = np.full(shape[0], -1, dtype=np.int32)
        remap[gene_mask] = np.arange(int(gene_mask.sum()), dtype=np.int32)
        data = group["data"][:]
        indices = group["indices"][:]
        indptr = group["indptr"][:]
    keep = gene_mask[indices]
    prefix = np.empty(keep.size + 1, dtype=np.int64)
    prefix[0] = 0
    np.cumsum(keep, out=prefix[1:])
    new_indptr = prefix[indptr]
    matrix = sparse.csc_matrix((data[keep], remap[indices[keep]], new_indptr), shape=(int(gene_mask.sum()), shape[1])).transpose().tocsr()
    cells = pd.read_csv(cells_path, usecols=["cell_id", "x_centroid", "y_centroid"])
    coordinate_ids = cells["cell_id"].astype(str).to_numpy()
    coordinates = cells[["x_centroid", "y_centroid"]].to_numpy(dtype=float)
    if not np.array_equal(coordinate_ids, cell_ids):
        lookup = pd.Series(np.arange(coordinate_ids.size), index=coordinate_ids)
        order = lookup.loc[cell_ids].to_numpy(dtype=int)
        coordinates = coordinates[order]
    return FormalRawInput(cell_ids=cell_ids, expression_matrix=matrix, coordinates=coordinates, adapter_id="xenium_h5_cells_csv_gene_expression_only", source_files=(matrix_path.name, cells_path.name), source_identity_sha256=sha256((digest(matrix_path)+digest(cells_path)+"Gene Expression").encode()).hexdigest(), gene_ids=feature_ids_all[gene_mask])


def legacy_module():
    path = ROOT / "scripts/run_final_gate_independent_real_validation.py"
    spec = importlib.util.spec_from_file_location("sq_legacy_real_driver", path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    module.load_visium_h5_spatial_tar = lambda matrix, cells: load_gene_expression_xenium(Path(matrix), Path(cells))
    return module


def freeze() -> None:
    if CONFIG.exists():
        raise FileExistsError(f"Preregistration already exists: {CONFIG}")
    qualification_path = OUTPUT / "candidate_dataset_qualification.csv"
    frame = pd.read_csv(qualification_path)
    if len(frame) != 3 or not frame["eligible"].all():
        raise RuntimeError("All three mechanically selected sections must qualify before freezing.")
    included = []
    for item in DATASETS:
        matrix, cells = source_paths(item)
        included.append({
            **{key: item[key] for key in ("dataset_id", "dataset", "accession", "platform", "tissue", "donor", "section", "sample", "official_url", "heterogeneity_evidence")},
            "expression_layer": "feature_type_exactly_Gene_Expression",
            "source_files": [
                {"relative_path": matrix.relative_to(ROOT).as_posix(), "role": "raw_count_matrix", "bytes": matrix.stat().st_size, "sha256": digest(matrix)},
                {"relative_path": cells.relative_to(ROOT).as_posix(), "role": "cell_coordinates", "bytes": cells.stat().st_size, "sha256": digest(cells)},
            ],
        })
    hashes = {role: digest(ROOT / relative) for role, relative in FROZEN_FILES.items()}
    payload = {
        "analysis_id": ANALYSIS_ID, "status": "frozen_after_qualification_before_any_pilot_or_holdout", "created_at": now(),
        "purpose": "prospectively_frozen_high_heterogeneity_independent_real_data_external_confirmation",
        "cohort_selection": {"maximum_projects": 3, "maximum_sections_or_donors_per_project": 3, "actual_projects": 3, "actual_sections": 3, "mechanical_priority": ["multiple_independent_donors", "cell_level_spatial_platform", "complete_author_labels", "larger_cell_count", "stable_download_and_processing_path", "lexicographic_accession"], "performance_used_for_qualification": False, "all_qualified_mechanically_selected_inputs_must_be_reported": True},
        "included_sections": included,
        "preprocessing": {"matrix_storage": "sparse_CSR", "expression_layer": "10x_feature_type_Gene_Expression_only", "library_size_normalization_target": 10000.0, "transformation": "log1p", "representation": "deterministic_truncated_SVD_ARPACK", "components": 30, "random_state": 0, "score": "row_leverage_score_left_singular_vector_squared_row_norm"},
        "sampling_design": {"fractions": FRACTIONS, "target_size": "floor_n_times_fraction", "pilot_seeds": PILOT_SEEDS, "holdout_seeds": HOLDOUT_SEEDS, "pilot_holdout_seed_families_disjoint": True, "candidate_caps": [4.0, 2.0], "candidate_precedence": ["r4", "r2"], "spatial_partition": "adaptive_regular_partition_current_formal_implementation", "minimum_quota": 1, "max_n_x": 20, "max_n_y": 20, "integer_quota_allocator": "largest_remainder_exact_total", "no_quota_relaxation": True, "engineering_canary_seed": 9090401},
        "frozen_gate": {"identifier": "final_simplified_three_condition_gate_v1", "safe_default": EQUAL, "candidate_precedence": [R4, R2], "minimum_pilot_association": 0.20, "minimum_mean_pilot_relative_benefit": 0.02, "maximum_single_pilot_relative_loss": 0.02, "ESS_over_n": "reported_advisory_not_hard_gate", "selection_source": "pilot_only", "holdout_used_for_selection": False},
        "pilot_diagnostics": {"association_name": "score-summary-proxy association", "association_definition": "minimum Pearson association of score with total counts and detected Gene Expression features on union of two Equal pilot samples", "expression_error_endpoints": ["Hajek_relative_L1_error_gene_wise_normalized_log1p_mean", "Hajek_relative_L1_error_gene_wise_detection_proportion"], "composite_error": "arithmetic_mean_of_two_endpoints", "relative_benefit": "(Equal_error-Weighted_error)/max(Equal_error,1e-12)", "complete_input_gene_summaries_used_only_for": "preregistered_pilot_expression_error_diagnostic"},
        "holdout_endpoints": {"primary_comparison": "frozen_gated_selection_vs_Equal", "oracle": "min(Equal,r2,r4)", "fraction_material_loss": "selected_holdout_composite_error > 1.02 * Equal_holdout_composite_error", "condition_positive_confirmation": "pilot_only_weighted_selection AND holdout_relative_benefit >= 0.02 AND no_material_loss AND exact_quota AND valid_probabilities", "aggregation": "average technical holdout seeds within section-by-fraction; sections are descriptive independent units", "no_biological_p_values": True},
        "classification": {"INDEPENDENT_REAL_WEIGHTING_CONFIRMED": "at least two independent sections or donors positively confirmed, not only fractions of one section, at least one adjacent-fraction directional replication, no selective exclusion, cohort risk within preregistered limit, all conditions reported", "LIMITED_INDEPENDENT_REAL_WEIGHTING_SUPPORT": "only one independent section/donor or isolated condition positively confirmed", "SAFE_FALLBACK_ONLY_REPLICATED": "all conditions select Equal consistently with frozen gate", "REAL_DATA_GATE_ACTIVATION_NOT_VALIDATED": "weighted activation without >=2% holdout improvement or with material loss"},
        "missing_failure_rules": {"technical_failures_retained": True, "no_replacement_after_pilot": True, "no_section_fraction_or_replicate_deletion": True, "method_freeze_inconsistency_stops_run": True, "independence_uncertainty_excludes_before_pilot": True},
        "frozen_files": FROZEN_FILES, "sha256_before": hashes,
        "execution": {"output_dir": OUTPUT.relative_to(ROOT).as_posix(), "raw_input_dir": RAW_ROOT.relative_to(ROOT).as_posix(), "refuse_overwrite": True, "z_drive_available_at_stage0": False, "z_drive_accessed": False, "git_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()},
    }
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    CONFIG.write_text(yaml.safe_dump(payload, sort_keys=False, allow_unicode=True), encoding="utf-8")
    prereg_hash = digest(CONFIG)
    (OUTPUT / "preregistration.sha256").write_text(f"{prereg_hash}  {CONFIG.name}\n", encoding="utf-8")
    dataset_rows = []
    for item in included:
        for source in item["source_files"]:
            dataset_rows.append({"data_level": "dataset_file", "dataset_id": item["dataset_id"], "dataset": item["dataset"], "donor": item["donor"], "section": item["section"], "accession": item["accession"], "file_role": source["role"], "relative_path": source["relative_path"], "bytes": source["bytes"], "sha256": source["sha256"], "expression_layer": item["expression_layer"]})
    pd.DataFrame(dataset_rows).to_csv(OUTPUT / "frozen_dataset_manifest.csv", index=False, encoding="utf-8")
    analysis_rows = [{"file_role": role, "relative_path": rel, "sha256": hashes[role], "frozen_before_pilot": True} for role, rel in FROZEN_FILES.items()]
    analysis_rows.append({"file_role": "preregistration", "relative_path": CONFIG.relative_to(ROOT).as_posix(), "sha256": prereg_hash, "frozen_before_pilot": True})
    pd.DataFrame(analysis_rows).to_csv(OUTPUT / "frozen_analysis_manifest.csv", index=False, encoding="utf-8")
    lines = [f"{row['sha256']}  {row['relative_path']}" for row in dataset_rows] + [f"{row['sha256']}  {row['relative_path']}" for row in analysis_rows]
    (OUTPUT / "file_hashes.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8")
    environment = {"captured_at": now(), "python": platform.python_version(), "platform": platform.platform(), "numpy": np.__version__, "pandas": pd.__version__, "scipy": scipy.__version__, "scikit_learn": sklearn.__version__, "h5py": h5py.__version__, "pyyaml": yaml.__version__, "git_commit": payload["execution"]["git_commit"]}
    (OUTPUT / "environment_lock.txt").write_text("\n".join(f"{k}={v}" for k, v in environment.items()) + "\n", encoding="utf-8")
    checks = {"three_qualified_sections": len(frame) == 3 and bool(frame["eligible"].all()), "pilot_holdout_disjoint": set(PILOT_SEEDS).isdisjoint(HOLDOUT_SEEDS), "candidate_order_r4_then_r2": True, "thresholds_match_v21": True, "frozen_core_hashes_match_v21_preregistration": all(hashes[k] == v for k, v in {"gate_code":"49c33cc16561f3d4c9618e4d41e34f44b44385c537e3e9a399329a11e080958d","gate_config":"7df79effaa7875a31a25189228eb36651e471a1b76a8416a1d898d750304b089","preprocessing_code":"fbdfaf59a00cd15c70594f9761a64b073121b666f147648df655571894212040","fixed_quota_probability_code":"010b610b2e452a54f92f40566221b307bac6cd1d0cbdda5ca1583b3d35934683","spatial_partition_code":"2aeca9d6c96640672c4f0b92a7e803a016b29a5cad666f0e0072894d7c6c5b1a","quota_allocator_code":"11343fdc33e3bb23a9a310e0301c57ca817b507d1a2155a0eb92523c421fda76"}.items())}
    (OUTPUT / "preregistration_validation_report.md").write_text("# Preregistration validation\n\n" + "\n".join(f"- {k}: {'PASS' if v else 'FAIL'}" for k,v in checks.items()) + f"\n\nSHA256: `{prereg_hash}`\n", encoding="utf-8")
    audit = {"analysis_id": ANALYSIS_ID, "stage0_completed_at": now(), "stage1_frozen_at": now(), "preregistration_sha256": prereg_hash, "pilot_started": False, "pilot_decision_sha256": None, "holdout_unlocked": False, "holdout_used_for_selection": False, "engineering_canary": engineering_canary(payload)}
    (OUTPUT / "stage_freeze_audit.json").write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"preregistration": str(CONFIG), "sha256": prereg_hash, "checks": checks}, indent=2))


def read_prereg() -> dict[str, Any]:
    payload = yaml.safe_load(CONFIG.read_text(encoding="utf-8"))
    expected = (OUTPUT / "preregistration.sha256").read_text(encoding="utf-8").split()[0]
    if digest(CONFIG) != expected:
        raise RuntimeError("Preregistration hash mismatch.")
    for role, rel in payload["frozen_files"].items():
        if digest(ROOT / rel) != payload["sha256_before"][role]:
            raise RuntimeError(f"Frozen file changed: {role}")
    for item in payload["included_sections"]:
        for source in item["source_files"]:
            if digest(ROOT / source["relative_path"]) != source["sha256"]:
                raise RuntimeError(f"Input file changed: {source['relative_path']}")
    return payload


def engineering_canary(payload: dict[str, Any]) -> dict[str, Any]:
    from spaquotasketch.safe_gate import SafeGateThresholds, WeightedCandidateEvidence, choose_safe_mode
    decision = choose_safe_mode([WeightedCandidateEvidence(R2,2.0,.3,.1,.03,0.0,.01), WeightedCandidateEvidence(R4,4.0,.3,.1,.03,0.0,.01)], SafeGateThresholds())
    return {"seed": payload["sampling_design"]["engineering_canary_seed"], "uses_formal_holdout_seed": False, "r4_precedence_passed": decision.selected_method_id == R4, "three_condition_gate_identifier_passed": decision.gate_identifier == "final_simplified_three_condition_gate_v1"}


def pilot() -> None:
    payload = read_prereg()
    forbidden = [OUTPUT / "holdout_replicate_level.csv", OUTPUT / "holdout_condition_level.csv"]
    if any(path.exists() for path in forbidden):
        raise RuntimeError("Holdout artifact exists before pilot stage.")
    module = legacy_module()
    cache_dir = OUTPUT / ".stage2_state"
    cache_dir.mkdir(exist_ok=False)
    evidence_rows, decision_rows = [], []
    for item in payload["included_sections"]:
        states, evidence, decisions = module.prepare_pilots(item, payload)
        evidence_rows.extend(evidence); decision_rows.extend(decisions)
        with (cache_dir / f"{item['dataset_id']}.pkl").open("wb") as handle:
            pickle.dump(states, handle, protocol=pickle.HIGHEST_PROTOCOL)
    evidence = pd.DataFrame(evidence_rows)
    decisions = pd.DataFrame(decision_rows)
    evidence.to_csv(OUTPUT / "pilot_candidate_level.csv", index=False, encoding="utf-8")
    decisions.to_csv(OUTPUT / "pilot_gate_decisions.csv", index=False, encoding="utf-8")
    decision_hash = digest(OUTPUT / "pilot_gate_decisions.csv")
    (OUTPUT / "pilot_gate_decisions.sha256").write_text(f"{decision_hash}  pilot_gate_decisions.csv\n", encoding="utf-8")
    report = ["# Pilot-only gate report", "", f"Conditions: {len(decisions)}; candidate rows: {len(evidence)}.", f"Selections Equal/r=2/r=4: {(decisions.selected_mode==EQUAL).sum()}/{(decisions.selected_mode==R2).sum()}/{(decisions.selected_mode==R4).sum()}.", "", "All choices use only the two preregistered pilot seeds. No holdout file was created or read in this stage."]
    (OUTPUT / "pilot_gate_report.md").write_text("\n".join(report)+"\n", encoding="utf-8")
    audit_path = OUTPUT / "stage_freeze_audit.json"; audit=json.loads(audit_path.read_text(encoding="utf-8")); audit.update({"pilot_started": True, "pilot_completed_at": now(), "pilot_decision_sha256": decision_hash, "engineering_canary": engineering_canary(payload)}); audit_path.write_text(json.dumps(audit,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"candidate_rows":len(evidence),"conditions":len(decisions),"decision_sha256":decision_hash},indent=2))


def holdout() -> None:
    payload = read_prereg()
    decisions_path = OUTPUT / "pilot_gate_decisions.csv"
    expected = (OUTPUT / "pilot_gate_decisions.sha256").read_text(encoding="utf-8").split()[0]
    if digest(decisions_path) != expected:
        raise RuntimeError("Pilot decision table changed before holdout unlock.")
    module = legacy_module()
    rows=[]
    for item in payload["included_sections"]:
        with (OUTPUT / ".stage2_state" / f"{item['dataset_id']}.pkl").open("rb") as handle:
            states=pickle.load(handle)
        rows.extend(module.evaluate_holdouts(states,payload))
        del states
    replicate=pd.DataFrame(rows)
    replicate.to_csv(OUTPUT / "holdout_replicate_level.csv",index=False,encoding="utf-8")
    decisions=pd.read_csv(decisions_path)
    condition=module.fraction_results(replicate,decisions)
    condition.to_csv(OUTPUT / "holdout_condition_level.csv",index=False,encoding="utf-8")
    material=condition[["dataset_id","dataset","donor","section","fraction","selected_mode","equal_error","r2_error","r4_error","selected_error","selected_relative_benefit","material_loss"]].copy()
    material.to_csv(OUTPUT / "material_loss_audit.csv",index=False,encoding="utf-8")
    ess=replicate[["dataset_id","dataset","donor","section","fraction","seed","selected_mode","equal_ess_fraction","r2_ess_fraction","r4_ess_fraction","selected_ess_fraction"]].copy()
    ess.to_csv(OUTPUT / "ess_diagnostics.csv",index=False,encoding="utf-8")
    quota=replicate[["dataset_id","dataset","donor","section","fraction","seed","selected_mode","target_n","quota_exact"]].copy()
    quota["inclusion_probabilities_valid"] = True; quota["finite_positive_weights"] = True
    quota.to_csv(OUTPUT / "quota_and_probability_validation.csv",index=False,encoding="utf-8")
    audit_path=OUTPUT/"stage_freeze_audit.json"; audit=json.loads(audit_path.read_text(encoding="utf-8")); audit.update({"holdout_unlocked":True,"holdout_unlocked_at":now(),"pilot_decision_sha256_verified":expected,"holdout_used_for_selection":False}); audit_path.write_text(json.dumps(audit,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"replicate_rows":len(replicate),"condition_rows":len(condition),"decision_sha256_verified":True},indent=2))


def summarize() -> None:
    payload=read_prereg(); module=legacy_module()
    decisions=pd.read_csv(OUTPUT/"pilot_gate_decisions.csv")
    replicate=pd.read_csv(OUTPUT/"holdout_replicate_level.csv")
    condition=pd.read_csv(OUTPUT/"holdout_condition_level.csv")
    sections=module.section_results(condition)
    policies=module.policy_comparison(condition,sections)
    activated=condition[condition.selected_mode.isin([R2,R4])].copy()
    positive=activated[(activated.selected_relative_benefit>=.02)&(~activated.material_loss.astype(bool))]
    n_positive_sections=positive.section.nunique()
    adjacent=False
    for section,grp in positive.groupby("section"):
        vals=sorted(grp.fraction.unique())
        if any(abs(a-b) in (.03,.05) for a,b in zip(vals,vals[1:])): adjacent=True
    if len(activated)==0: classification="SAFE_FALLBACK_ONLY_REPLICATED"
    elif n_positive_sections>=2 and adjacent: classification="INDEPENDENT_REAL_WEIGHTING_CONFIRMED"
    elif n_positive_sections>=1: classification="LIMITED_INDEPENDENT_REAL_WEIGHTING_SUPPORT"
    else: classification="REAL_DATA_GATE_ACTIVATION_NOT_VALIDATED"
    summary_rows=[]
    for _,row in policies.iterrows():
        summary_rows.append({"data_level":"policy_summary","policy":row.get("policy"),"aggregation_scope":row.get("aggregation_scope"),"mean_normalized_regret":row.get("normalized_regret"),"mean_error":row.get("mean_error"),"classification":classification})
    summary_rows.append({"data_level":"confirmation_summary","policy":"frozen_gate","aggregation_scope":"cohort","mean_normalized_regret":np.nan,"mean_error":np.nan,"classification":classification,"preregistered_conditions":len(decisions),"successful_conditions":len(condition),"equal_selected":int((decisions.selected_mode==EQUAL).sum()),"r2_selected":int((decisions.selected_mode==R2).sum()),"r4_selected":int((decisions.selected_mode==R4).sum()),"activated_independent_sections":int(activated.section.nunique()),"activated_holdout_benefit_ge_2pct":len(positive),"activated_material_loss":int(activated.material_loss.astype(bool).sum()) if len(activated) else 0})
    pd.DataFrame(summary_rows).to_csv(OUTPUT/"independent_confirmation_summary.csv",index=False,encoding="utf-8")
    deviations=pd.DataFrame([{"deviation_id":"NONE","stage":"all","description":"No protocol deviation","impact":"none","exploratory_reclassification_required":False}])
    deviations.to_csv(OUTPUT/"protocol_deviation_log.csv",index=False,encoding="utf-8")
    gate_policy=policies[policies.policy=="final_gate"].iloc[0]; equal_policy=policies[policies.policy=="always_equal"].iloc[0]; r2_policy=policies[policies.policy=="always_r2"].iloc[0]; r4_policy=policies[policies.policy=="always_r4"].iloc[0]
    missed=condition[(condition.selected_mode==EQUAL)&((condition.equal_error-condition[["r2_error","r4_error"]].min(axis=1))/condition.equal_error>=.02)]
    report=["# Independent real weighting confirmation", "", f"Classification: `{classification}`", "", f"Preregistered/successful conditions: {len(decisions)}/{len(condition)}.", f"Selections Equal/r=2/r=4: {(decisions.selected_mode==EQUAL).sum()}/{(decisions.selected_mode==R2).sum()}/{(decisions.selected_mode==R4).sum()}.", f"Weighted activations: {len(activated)} conditions across {activated.section.nunique()} independent sections; confirmed >=2% holdout benefit: {len(positive)}; activated material loss: {int(activated.material_loss.astype(bool).sum()) if len(activated) else 0}.", f"Mean normalized regret, gate/Equal/r=2/r=4: {gate_policy.normalized_regret:.6g}/{equal_policy.normalized_regret:.6g}/{r2_policy.normalized_regret:.6g}/{r4_policy.normalized_regret:.6g}.", f"Equal fallback conditions where an always-weighted arm improved >=2% post hoc: {len(missed)}. This is a missed-opportunity diagnostic and did not change selection.", f"ESS/n range across weighted replicate arms: {min(replicate.r2_ess_fraction.min(),replicate.r4_ess_fraction.min()):.6g} to {max(replicate.r2_ess_fraction.max(),replicate.r4_ess_fraction.max()):.6g}.", "", "Technical seeds quantify sampling variation and are not biological replicates. No biological P value was calculated."]
    (OUTPUT/"independent_confirmation_report.md").write_text("\n".join(report)+"\n",encoding="utf-8")
    repro=[]
    for path in sorted(OUTPUT.iterdir()):
        if path.is_file(): repro.append({"relative_path":path.relative_to(ROOT).as_posix(),"bytes":path.stat().st_size,"sha256":digest(path),"role":"formal_result"})
    pd.DataFrame(repro).to_csv(OUTPUT/"reproducibility_manifest.csv",index=False,encoding="utf-8")
    print(json.dumps({"classification":classification,"activated":len(activated),"positive":len(positive),"material_loss":int(condition.material_loss.astype(bool).sum()),"missed_opportunities":len(missed)},indent=2))


def main() -> None:
    parser=argparse.ArgumentParser(); parser.add_argument("stage",choices=["qualify","freeze","pilot","holdout","summarize"]); args=parser.parse_args()
    if args.stage=="qualify": qualification()
    elif args.stage=="freeze": freeze()
    elif args.stage=="pilot": pilot()
    elif args.stage=="holdout": holdout()
    else: summarize()


if __name__ == "__main__":
    main()
