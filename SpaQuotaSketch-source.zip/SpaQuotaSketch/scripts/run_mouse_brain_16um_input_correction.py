"""Targeted correction run for the Visium HD mouse-brain 16-um input.

This wrapper reuses the frozen 9 September 2026 controlled-reproduction
driver, but limits execution to the affected mouse-brain input and writes to a
new result directory.  Fractions, seeds, methods, endpoints, preprocessing and
quota rules remain unchanged.
"""

from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
import sys

import pandas as pd
import yaml


ROOT = Path(__file__).resolve().parents[1]
BASE_DRIVER = ROOT / "scripts/run_controlled_reproduction_public_path_template.py"
OUT = ROOT / "results/mouse_brain_16um_input_correction_20260917"
DATASET = "visium_hd_mouse_brain_fresh_frozen_2024"


def load_driver():
    spec = importlib.util.spec_from_file_location("frozen_reproduction_driver", BASE_DRIVER)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load frozen driver: {BASE_DRIVER}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    module.OUT = OUT
    module.DATASETS = (DATASET,)
    module.PROTOCOL = OUT / "correction_protocol.yaml"
    module.INPUT_MANIFEST = OUT / "input_verification_manifest.csv"
    module.EXECUTION_MANIFEST = OUT / "execution_manifest.csv"
    module.STATUS_DIR = OUT / "unit_status"
    module.CACHE_DIR = OUT / "cache"
    module.DETAIL_DIR = OUT / "unit_details"
    historical_results = module.historical_results
    module.historical_results = lambda: historical_results().loc[
        lambda frame: frame["dataset_id"] == DATASET
    ].reset_index(drop=True)
    return module


def rewrite_protocol(module) -> None:
    path = module.PROTOCOL
    protocol = yaml.safe_load(path.read_text(encoding="utf-8"))
    protocol["protocol_name"] = "mouse_brain_16um_input_correction_20260917"
    protocol["status"] = "targeted_input_correction_after_coordinate_scale_error_confirmation"
    protocol["purpose"] = (
        "Re-execute only the affected Visium HD mouse-brain Equal-versus-matched-"
        "within-stratum-SRS conditions after correcting native 2-um feature-slice "
        "aggregation to the frozen 16-um mask."
    )
    protocol["scope_boundary"] = (
        "No other dataset, fraction, seed, method, endpoint, threshold or quota rule is changed."
    )
    protocol["input_correction"] = {
        "mask": "square_016um",
        "native_feature_slice_pitch_um": 2,
        "binning_scale_per_axis": 8,
        "operation": "integer-divide native row and column by 8, then sum gene counts within each retained mask bin",
    }
    protocol["history_statement"] = (
        "This is a targeted correction after discovery of an upstream input-coordinate error; "
        "historical outputs remain unchanged and are used only for an explicit old-versus-corrected comparison."
    )
    path.write_text(yaml.safe_dump(protocol, sort_keys=False, allow_unicode=True), encoding="utf-8")


def write_targeted_summary(module) -> None:
    methods = pd.read_csv(OUT / "method_endpoint_results.csv")
    pairs = pd.read_csv(OUT / "paired_endpoint_results.csv")
    summary = {
        "dataset_id": DATASET,
        "method_endpoint_rows": int(len(methods)),
        "paired_endpoint_rows": int(len(pairs)),
        "expected_method_endpoint_rows": 60,
        "expected_paired_endpoint_rows": 30,
        "all_spatial_quotas_exact": bool(methods["all_spatial_quotas_exact"].all()),
        "corrected_target_sums": {
            str(endpoint): float(group["target_sum"].iloc[0])
            for endpoint, group in methods.groupby("endpoint")
        },
        "corrected_absolute_error_range": {
            str(endpoint): {"minimum": float(group["error"].min()), "maximum": float(group["error"].max())}
            for endpoint, group in methods.groupby("endpoint")
        },
        "corrected_equal_wins": int((pairs["new_relative_benefit_equal_vs_srs"] > 0).sum()),
        "corrected_srs_wins": int((pairs["new_relative_benefit_equal_vs_srs"] < 0).sum()),
        "corrected_ties": int((pairs["new_relative_benefit_equal_vs_srs"] == 0).sum()),
        "corrected_mean_relative_benefit": float(pairs["new_relative_benefit_equal_vs_srs"].mean()),
        "corrected_median_relative_benefit": float(pairs["new_relative_benefit_equal_vs_srs"].median()),
        "historical_mean_relative_benefit": float(pairs["old_relative_benefit_equal_vs_srs"].mean()),
        "historical_median_relative_benefit": float(pairs["old_relative_benefit_equal_vs_srs"].median()),
    }
    (OUT / "targeted_correction_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    lines = [
        "# Targeted Visium HD mouse-brain input correction",
        "",
        f"Completed {summary['method_endpoint_rows']}/60 method-endpoint rows and "
        f"{summary['paired_endpoint_rows']}/30 paired endpoint rows.",
        f"All spatial quotas exact: {summary['all_spatial_quotas_exact']}.",
        "",
        "The corrected run used the same official feature-slice file, fractions, seeds, methods, "
        "endpoints and quota rules as the frozen reproduction. The only scientific correction was "
        "aggregation of native 2-um feature coordinates into the square_016um mask by an 8-by-8 sum.",
        "",
        "Historical results were not overwritten.",
    ]
    (OUT / "targeted_correction_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("prepare", "complete"), required=True)
    args = parser.parse_args()
    module = load_driver()
    if args.mode == "prepare":
        module.prepare()
        rewrite_protocol(module)
    else:
        module.run("complete")
        write_targeted_summary(module)


if __name__ == "__main__":
    main()
