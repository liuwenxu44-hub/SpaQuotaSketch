"""Controlled rerun of the four-input Equal-versus-matched-SRS comparison.

This is a known-results reproduction protocol, not an independent preregistration.
It freezes the current v4 candidate implementation and runs only the historically
reported four inputs, three fractions, five seeds, two methods and two endpoints.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import platform
import shutil
import sys
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Iterable

import h5py
import numpy as np
import pandas as pd
import scipy
import sklearn
import yaml
from scipy import sparse


ROOT = Path(os.environ.get("SPAQUOTASKETCH_ROOT", Path(__file__).resolve().parents[1])).resolve()
OUT = ROOT / "results" / "core_direct_comparison_reproduction_20260909"
DATA_ROOT = Path(os.environ.get("EXTERNAL_INPUT_PATH", ROOT / "external_inputs")).resolve()
FREEZE = ROOT / "configs" / "formal_multiplatform_dataset_freeze.yaml"
V4_CODE = ROOT
PROTOCOL = OUT / "reproduction_protocol.yaml"
INPUT_MANIFEST = OUT / "input_verification_manifest.csv"
EXECUTION_MANIFEST = OUT / "execution_manifest.csv"
STATUS_DIR = OUT / "unit_status"
CACHE_DIR = OUT / "cache"
DETAIL_DIR = OUT / "unit_details"

sys.path.insert(0, str(ROOT / "src"))
from spaquotasketch.benchmark.formal_multiplatform_input_adapters import load_formal_raw_input
from spaquotasketch.fixed_quota_probability import (
    DIRECT_SPATIAL_QUOTA_SRS,
    EQUAL_PROBABILITY_FIXED_QUOTA,
    fixed_quota_probability_plans,
    fixed_quota_probability_selections,
)
from spaquotasketch.preprocess import compute_normalized_log1p_svd_representation
from spaquotasketch.v2_1.quota import allocate_largest_remainder_quotas
from spaquotasketch.v2_1.spatial import choose_adaptive_regular_partition


DATASETS = (
    "visium_cytassist_human_breast_cancer_2023",
    "xenium_human_brain_alzheimers_2023",
    "visium_hd_mouse_brain_fresh_frozen_2024",
    "xenium_human_renal_cell_carcinoma_2025",
)
FRACTIONS = (0.02, 0.05, 0.10)
SEEDS = (101, 202, 303, 404, 505)
METHODS = (DIRECT_SPATIAL_QUOTA_SRS, EQUAL_PROBABILITY_FIXED_QUOTA)
ENDPOINTS = ("normalized_log_expression_gene_mean", "raw_count_detection_proportion")
ATOL = 1e-10
RTOL = 1e-7


def atomic_text(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, dir=path.parent, suffix=".tmp") as handle:
        handle.write(content)
        temp = Path(handle.name)
    temp.replace(path)


def atomic_csv(path: Path, rows: list[dict[str, Any]], columns: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if columns is None:
        columns = list(dict.fromkeys(key for row in rows for key in row)) if rows else []
    with tempfile.NamedTemporaryFile("w", encoding="utf-8-sig", newline="", delete=False, dir=path.parent, suffix=".tmp") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)
        temp = Path(handle.name)
    temp.replace(path)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_array(values: np.ndarray) -> str:
    array = np.ascontiguousarray(values)
    return hashlib.sha256(array.view(np.uint8)).hexdigest()


def json_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_yaml(path: Path) -> dict[str, Any]:
    value = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise TypeError(f"Expected YAML mapping: {path}")
    return value


def fraction_label(value: float) -> str:
    return f"{int(round(value * 100)):02d}pct"


def unit_key(dataset_id: str, fraction: float, seed: int, method: str) -> str:
    return f"{dataset_id}__{fraction_label(fraction)}__seed{seed}__{method}"


def target_n(n_obs: int, fraction: float) -> int:
    return max(4, min(int(n_obs), int(np.floor(int(n_obs) * float(fraction)))))


def frozen_records() -> dict[str, dict[str, Any]]:
    freeze = read_yaml(FREEZE)
    records = {str(row["dataset_id"]): row for row in freeze["datasets"]}
    missing = set(DATASETS).difference(records)
    if missing:
        raise RuntimeError(f"Missing frozen records: {sorted(missing)}")
    return records


SNAPSHOT_FILES = (
    "src/spaquotasketch/fixed_quota_probability.py",
    "src/spaquotasketch/preprocess.py",
    "src/spaquotasketch/v2_1/sampling.py",
    "src/spaquotasketch/v2_1/quota.py",
    "src/spaquotasketch/v2_1/spatial.py",
    "src/spaquotasketch/v2/inference.py",
    "src/spaquotasketch/v2/errors.py",
    "src/spaquotasketch/benchmark/formal_multiplatform_input_adapters.py",
    "src/spaquotasketch/datasets/final_external_input_qualification.py",
    "configs/formal_multiplatform_dataset_freeze.yaml",
    "configs/real_fixed_quota_probability_fraction_sensitivity_v1.yaml",
    "configs/real_fixed_quota_probability_confirmation_v2.yaml",
    "configs/real_fixed_quota_probability_renal_confirmation_v1.yaml",
)


def prepare() -> None:
    if PROTOCOL.exists():
        raise FileExistsError(f"Protocol already exists; refusing to change freeze: {PROTOCOL}")
    if not DATA_ROOT.is_dir():
        raise FileNotFoundError(f"Recorded local input cache is unavailable: {DATA_ROOT}")
    OUT.mkdir(parents=True, exist_ok=True)
    STATUS_DIR.mkdir(exist_ok=True)
    CACHE_DIR.mkdir(exist_ok=True)
    DETAIL_DIR.mkdir(exist_ok=True)
    records = frozen_records()
    input_rows: list[dict[str, Any]] = []
    for dataset_id in DATASETS:
        record = records[dataset_id]
        paths = [DATA_ROOT / str(item) for item in record["input_file_relative_paths"]]
        for index, path in enumerate(paths):
            exists = path.is_file()
            current = sha256_file(path) if exists else ""
            expected = str(record["input_sha256"][index])
            input_rows.append({
                "dataset_id": dataset_id,
                "adapter_id": record["adapter_id"],
                "relative_path": str(record["input_file_relative_paths"][index]),
                "runtime_cache_path": str(path),
                "expected_bytes": int(record["input_file_sizes"][index]),
                "observed_bytes": path.stat().st_size if exists else "",
                "expected_sha256": expected,
                "observed_sha256_streamed_this_run": current,
                "historical_identity_status": "MATCHED_TRUSTED_HISTORICAL_HASH" if current == expected else "MISMATCH_OR_MISSING",
                "verification_basis": "streamed SHA256 on the recorded D-drive runtime cache before sampling",
            })
    atomic_csv(INPUT_MANIFEST, input_rows)
    if not all(row["historical_identity_status"] == "MATCHED_TRUSTED_HISTORICAL_HASH" for row in input_rows):
        raise RuntimeError("At least one input does not match its trusted historical SHA256; sampling is blocked.")

    snapshot_rows: list[dict[str, Any]] = []
    snapshot_root = OUT / "code_snapshot"
    for relative in SNAPSHOT_FILES:
        source = ROOT / relative
        destination = snapshot_root / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        snapshot_rows.append({"relative_path": relative, "sha256": sha256_file(source), "bytes": source.stat().st_size})
    candidate_parity = []
    for relative in (
        "src/spaquotasketch/fixed_quota_probability.py",
        "src/spaquotasketch/preprocess.py",
        "src/spaquotasketch/v2_1/sampling.py",
        "src/spaquotasketch/v2_1/quota.py",
        "src/spaquotasketch/v2_1/spatial.py",
    ):
        current = ROOT / relative
        candidate = V4_CODE / relative
        candidate_parity.append({
            "relative_path": relative,
            "current_sha256": sha256_file(current),
            "v4_candidate_sha256": sha256_file(candidate),
            "match": sha256_file(current) == sha256_file(candidate),
        })
    atomic_csv(OUT / "code_snapshot_manifest.csv", snapshot_rows)
    atomic_csv(OUT / "v4_candidate_code_parity.csv", candidate_parity)
    if not all(bool(row["match"]) for row in candidate_parity):
        raise RuntimeError("Current core code differs from the v4 candidate extract; protocol requires explicit review before sampling.")
    dependencies = {
        "python_executable": sys.executable,
        "python_version": sys.version,
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "scikit_learn": sklearn.__version__,
        "pandas": pd.__version__,
        "h5py": h5py.__version__,
        "pyyaml": yaml.__version__,
        "platform": platform.platform(),
    }
    atomic_text(OUT / "dependencies.json", json.dumps(dependencies, indent=2) + "\n")
    protocol = {
        "protocol_name": "core_direct_comparison_controlled_reproduction_20260909",
        "status": "known_historical_results_reproduction_not_independent_preregistration",
        "purpose": "re-execute the four-input Equal-versus-matched-within-stratum-SRS comparison using a frozen current v4 candidate snapshot",
        "input_cache": {"path": str(DATA_ROOT), "mapping_evidence": "the three historical direct-comparison configurations and prior run manifests use this exact local runtime-cache path; no unverified Z-drive/server mapping is asserted"},
        "datasets": list(DATASETS),
        "methods": list(METHODS),
        "fractions": list(FRACTIONS),
        "repeat_seeds": list(SEEDS),
        "run_order": "dataset order, then fraction 2%, 5%, 10%, then seeds 101,202,303,404,505, then direct SRS followed by Equal",
        "preprocessing": {"matrix": "sparse CSR", "normalization": "library-size target 10000", "log1p": True, "svd_components": 30, "svd_algorithm": "ARPACK", "random_state": 0, "basis": "left singular vectors from normalized log1p SVD"},
        "spatial_allocation": {"adaptive_regular_partition": True, "minimum_quota": 1, "max_n_x": 20, "max_n_y": 20, "quota": "largest remainder exact integer quota"},
        "endpoints": {"normalized_log_expression_gene_mean": "Hajek relative L1", "raw_count_detection_proportion": "Hajek relative L1 using raw count > 0"},
        "seed_split": {"direct_srs": "SeedSequence([seed,0])", "Equal": "SeedSequence([seed,0]) after direct plan; same integer seed does not imply the same random stream or selected sample"},
        "comparison_rules": {"identifiers_quotas_probabilities": "exact comparison when a historical field exists", "float64": {"atol": ATOL, "rtol": RTOL}, "rounded_historical_fields": "compare only to retained precision and label high-precision comparison unavailable", "no_tolerance_relaxation_after_results": True},
        "cache_rule": "only fresh cache files generated in this output directory are reused; cache metadata binds input hashes, identifier order, feature order, preprocessing parameters and snapshot hashes",
        "execution": {"concurrency": 1, "thread_environment": {"OMP_NUM_THREADS": os.environ.get("OMP_NUM_THREADS", "1"), "OPENBLAS_NUM_THREADS": os.environ.get("OPENBLAS_NUM_THREADS", "1"), "MKL_NUM_THREADS": os.environ.get("MKL_NUM_THREADS", "1")}, "atomic_unit_success_markers": True, "resume": "only unit markers with status SUCCESS and matching protocol hash are skipped"},
        "snapshot_manifest_sha256": hashlib.sha256(json.dumps(snapshot_rows, sort_keys=True).encode()).hexdigest(),
        "input_manifest_sha256": sha256_file(INPUT_MANIFEST),
        "created_at_unix": time.time(),
        "history_statement": "This freezes a new reproduction snapshot after the historical results were known. It is not asserted to be the historical formal code commit.",
    }
    atomic_text(PROTOCOL, yaml.safe_dump(protocol, sort_keys=False, allow_unicode=True))
    print(json.dumps({"status": "PREPARED", "protocol": str(PROTOCOL), "input_files": len(input_rows)}, indent=2))


def cache_metadata_path(dataset_id: str) -> Path:
    return CACHE_DIR / dataset_id / "cache_metadata.json"


@dataclass
class CachedDataset:
    raw_matrix: sparse.csr_matrix
    normalized: sparse.csr_matrix
    embedding: np.ndarray
    basis: np.ndarray
    coordinates: np.ndarray
    cell_ids: np.ndarray
    gene_ids: np.ndarray
    source_identity_sha256: str


def expected_cache_metadata(dataset_id: str, raw: Any) -> dict[str, Any]:
    return {
        "dataset_id": dataset_id,
        "source_identity_sha256": raw.source_identity_sha256,
        "n_obs": int(raw.n_obs),
        "n_vars": int(raw.n_vars),
        "cell_ids_sha256": sha256_array(np.asarray(raw.cell_ids, dtype="U")),
        "gene_ids_sha256": sha256_array(np.asarray(raw.gene_ids, dtype="U")),
        "preprocess_sha256": sha256_file(ROOT / "src/spaquotasketch/preprocess.py"),
        "components": 30,
        "random_state": 0,
        "normalization_target": 10000,
    }


def save_cache(dataset_id: str, cached: CachedDataset, metadata: dict[str, Any]) -> None:
    target = CACHE_DIR / dataset_id
    target.mkdir(parents=True, exist_ok=True)
    sparse.save_npz(target / "raw_counts_csr.npz", cached.raw_matrix)
    sparse.save_npz(target / "normalized_log1p_csr.npz", cached.normalized)
    np.save(target / "embedding.npy", cached.embedding)
    np.save(target / "basis.npy", cached.basis)
    np.save(target / "coordinates.npy", cached.coordinates)
    np.save(target / "cell_ids.npy", cached.cell_ids)
    np.save(target / "gene_ids.npy", cached.gene_ids)
    files = {path.name: sha256_file(path) for path in target.iterdir() if path.is_file()}
    metadata = dict(metadata)
    metadata["cache_file_sha256"] = files
    atomic_text(cache_metadata_path(dataset_id), json.dumps(metadata, indent=2) + "\n")


def load_or_build_cache(dataset_id: str) -> CachedDataset:
    records = frozen_records()
    record = records[dataset_id]
    paths = [DATA_ROOT / str(item) for item in record["input_file_relative_paths"]]
    raw = load_formal_raw_input(adapter_id=str(record["adapter_id"]), source_files=paths)
    expected = expected_cache_metadata(dataset_id, raw)
    metadata_path = cache_metadata_path(dataset_id)
    target = CACHE_DIR / dataset_id
    if metadata_path.is_file():
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        if all(metadata.get(key) == value for key, value in expected.items()):
            hashes = metadata.get("cache_file_sha256", {})
            if hashes and all((target / name).is_file() and sha256_file(target / name) == digest for name, digest in hashes.items()):
                return CachedDataset(
                    raw_matrix=sparse.load_npz(target / "raw_counts_csr.npz").tocsr(),
                    normalized=sparse.load_npz(target / "normalized_log1p_csr.npz").tocsr(),
                    embedding=np.load(target / "embedding.npy"),
                    basis=np.load(target / "basis.npy"),
                    coordinates=np.load(target / "coordinates.npy"),
                    cell_ids=np.load(target / "cell_ids.npy"),
                    gene_ids=np.load(target / "gene_ids.npy"),
                    source_identity_sha256=raw.source_identity_sha256,
                )
        raise RuntimeError(f"Existing cache does not meet the frozen validation rule: {target}")
    adata = SimpleNamespace(X=raw.expression_matrix, obsm={"spatial": raw.coordinates})
    embedding, basis, normalized = compute_normalized_log1p_svd_representation(
        adata, n_components=30, random_state=0
    )
    cached = CachedDataset(
        raw_matrix=raw.expression_matrix.tocsr(copy=False),
        normalized=normalized.tocsr(copy=False),
        embedding=np.asarray(embedding, dtype=np.float64),
        basis=np.asarray(basis, dtype=np.float64),
        coordinates=np.asarray(raw.coordinates, dtype=np.float64),
        cell_ids=np.asarray(raw.cell_ids, dtype=str),
        gene_ids=np.asarray(raw.gene_ids, dtype=str),
        source_identity_sha256=raw.source_identity_sha256,
    )
    save_cache(dataset_id, cached, expected)
    return cached


def endpoint_targets(cached: CachedDataset) -> dict[str, np.ndarray]:
    return {
        "normalized_log_expression_gene_mean": np.asarray(cached.normalized.mean(axis=0)).reshape(-1),
        "raw_count_detection_proportion": cached.raw_matrix.getnnz(axis=0).astype(np.float64) / cached.raw_matrix.shape[0],
    }


def endpoint_estimate(matrix: sparse.csr_matrix, selected: np.ndarray, weights: np.ndarray, *, detection: bool) -> np.ndarray:
    selected_matrix = matrix[selected].tocsr(copy=True)
    if detection:
        selected_matrix.data = np.ones_like(selected_matrix.data, dtype=np.float64)
    return np.asarray(selected_matrix.T @ weights).reshape(-1) / weights.sum()


def condition_paths(dataset_id: str, fraction: float) -> tuple[Path, Path]:
    folder = DETAIL_DIR / dataset_id / fraction_label(fraction)
    return folder / "design.npz", folder / "quota_audit.csv"


def condition_design(dataset_id: str, fraction: float, cached: CachedDataset) -> tuple[np.ndarray, dict[str, int], dict[str, Any], dict[str, Any]]:
    design_path, quota_path = condition_paths(dataset_id, fraction)
    target = target_n(cached.raw_matrix.shape[0], fraction)
    partition = choose_adaptive_regular_partition(cached.coordinates, target, minimum_quota=1, max_n_x=20, max_n_y=20)
    allocation = allocate_largest_remainder_quotas(partition.stratum_audit, target, minimum_quota=1)
    plans = fixed_quota_probability_plans(
        expression_embedding=cached.embedding,
        expression_basis=cached.basis,
        spatial_strata=partition.stratum_ids,
        quotas=allocation.quotas,
        max_weight_inflation=4.0,
    )
    folder = design_path.parent
    folder.mkdir(parents=True, exist_ok=True)
    equal_plan = plans[EQUAL_PROBABILITY_FIXED_QUOTA]
    direct_pi = np.zeros(cached.raw_matrix.shape[0], dtype=np.float64)
    strata = np.asarray([str(value) for value in partition.stratum_ids], dtype=str)
    for stratum, quota in allocation.quotas.items():
        positions = np.flatnonzero(strata == str(stratum))
        direct_pi[positions] = int(quota) / positions.size
    np.savez_compressed(
        design_path,
        spatial_strata=strata,
        direct_inclusion_probability=direct_pi,
        equal_inclusion_probability=np.asarray(equal_plan.inclusion_probability, dtype=np.float64),
        cell_ids=cached.cell_ids,
    )
    audit = allocation.audit.copy()
    audit.insert(0, "dataset_id", dataset_id)
    audit.insert(1, "fraction", fraction)
    audit["grid_n_x"] = int(partition.n_x)
    audit["grid_n_y"] = int(partition.n_y)
    audit.to_csv(quota_path, index=False)
    design_info = {
        "target_n": target,
        "grid_n_x": int(partition.n_x),
        "grid_n_y": int(partition.n_y),
        "design_path": str(design_path.relative_to(OUT)),
        "quota_audit_path": str(quota_path.relative_to(OUT)),
        "strata_sha256": sha256_array(strata.astype("U")),
        "direct_pi_sha256": sha256_array(direct_pi),
        "equal_pi_sha256": sha256_array(np.asarray(equal_plan.inclusion_probability, dtype=np.float64)),
    }
    return strata, {str(k): int(v) for k, v in allocation.quotas.items()}, plans, design_info


def write_status(key: str, content: dict[str, Any]) -> None:
    atomic_text(STATUS_DIR / f"{key}.json", json.dumps(content, indent=2) + "\n")


def status_success(key: str) -> dict[str, Any] | None:
    path = STATUS_DIR / f"{key}.json"
    if not path.is_file():
        return None
    value = json.loads(path.read_text(encoding="utf-8"))
    if value.get("status") != "SUCCESS" or value.get("protocol_sha256") != json_hash(PROTOCOL):
        return None
    detail = OUT / value["detail_path"]
    if not detail.is_file() or sha256_file(detail) != value.get("detail_sha256"):
        return None
    return value


def run_condition(dataset_id: str, fraction: float, seed: int, cached: CachedDataset, design_state: tuple[np.ndarray, dict[str, int], dict[str, Any], dict[str, Any]]) -> None:
    if all(status_success(unit_key(dataset_id, fraction, seed, method)) for method in METHODS):
        return
    strata, quotas, plans, design_info = design_state
    selections = fixed_quota_probability_selections(
        expression_embedding=cached.embedding,
        expression_basis=cached.basis,
        spatial_strata=strata,
        quotas=quotas,
        seed=seed,
        max_weight_inflation=4.0,
        precomputed_pivotal_plans=plans,
    )
    targets = endpoint_targets(cached)
    target_path = DETAIL_DIR / dataset_id / "population_targets.npz"
    if not target_path.exists():
        target_path.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(target_path, **targets, gene_ids=cached.gene_ids)
    for method in METHODS:
        key = unit_key(dataset_id, fraction, seed, method)
        if status_success(key):
            continue
        selection = selections[method]
        selected = np.asarray(selection.selected_indices, dtype=np.int64)
        weights = np.asarray(selection.sampling_weight, dtype=np.float64)[selected]
        selected_strata = strata[selected]
        quota_ok = all(int(np.sum(selected_strata == s)) == int(q) for s, q in quotas.items())
        if selected.size != int(sum(quotas.values())) or not quota_ok:
            raise RuntimeError(f"Design constraint failed for {key}")
        endpoint_rows = []
        arrays: dict[str, Any] = {
            "selected_indices": selected,
            "selected_ids": cached.cell_ids[selected],
            "selected_strata": selected_strata,
            "selected_sampling_weight": weights,
            "selected_inclusion_probability": np.asarray(selection.inclusion_probability, dtype=np.float64)[selected],
        }
        for endpoint in ENDPOINTS:
            detection = endpoint == "raw_count_detection_proportion"
            target = targets[endpoint]
            estimate = endpoint_estimate(cached.raw_matrix if detection else cached.normalized, selected, weights, detection=detection)
            numerator = float(np.abs(target - estimate).sum())
            denominator = max(float(target.sum()), 1e-12)
            error = numerator / denominator
            arrays[f"estimate__{endpoint}"] = estimate
            arrays[f"target__{endpoint}"] = target
            endpoint_rows.append({
                "dataset_id": dataset_id,
                "fraction": fraction,
                "seed": seed,
                "method": method,
                "endpoint": endpoint,
                "error": error,
                "error_numerator": numerator,
                "error_denominator": denominator,
                "target_sum": float(target.sum()),
                "estimate_sum": float(estimate.sum()),
                "hajek_weight_denominator": float(weights.sum()),
                "target_n": int(selected.size),
                "all_spatial_quotas_exact": bool(quota_ok),
                "selected_ids_sha256": sha256_array(cached.cell_ids[selected].astype("U")),
                "selected_indices_sha256": sha256_array(selected),
                "selected_weights_sha256": sha256_array(weights),
                "source_identity_sha256": cached.source_identity_sha256,
                **selection.diagnostics,
                **design_info,
                "target_vector_path": str(target_path.relative_to(OUT)),
            })
        detail_path = DETAIL_DIR / dataset_id / fraction_label(fraction) / f"seed{seed}__{method}.npz"
        np.savez_compressed(detail_path, **arrays)
        status = {
            "status": "SUCCESS",
            "protocol_sha256": json_hash(PROTOCOL),
            "unit_key": key,
            "dataset_id": dataset_id,
            "fraction": fraction,
            "seed": seed,
            "method": method,
            "detail_path": str(detail_path.relative_to(OUT)),
            "detail_sha256": sha256_file(detail_path),
            "endpoint_rows": endpoint_rows,
            "completed_at_unix": time.time(),
            "retry_count": 0,
        }
        write_status(key, status)


def collect_new_results() -> pd.DataFrame:
    rows = []
    for path in sorted(STATUS_DIR.glob("*.json")):
        value = json.loads(path.read_text(encoding="utf-8"))
        if value.get("status") == "SUCCESS" and value.get("protocol_sha256") == json_hash(PROTOCOL):
            rows.extend(value.get("endpoint_rows", []))
    if not rows:
        return pd.DataFrame()
    frame = pd.DataFrame(rows)
    return frame.sort_values(["dataset_id", "fraction", "seed", "method", "endpoint"]).reset_index(drop=True)


def historical_results() -> pd.DataFrame:
    locations = (
        ROOT / "results" / "real_fixed_quota_probability_fraction_sensitivity_20260820" / "selection_metrics.tsv",
        ROOT / "results" / "real_fixed_quota_probability_confirmation_v2_20260820" / "selection_metrics.tsv",
        ROOT / "results" / "real_fixed_quota_probability_renal_confirmation_20260820" / "selection_metrics.tsv",
    )
    frames = []
    for path in locations:
        frame = pd.read_csv(path, sep="\t")
        frames.append(frame)
    source = pd.concat(frames, ignore_index=True)
    source = source[source["method"].isin(METHODS)].copy()
    records = []
    for row in source.to_dict(orient="records"):
        for endpoint, column in (
            ("normalized_log_expression_gene_mean", "gene_mean_l1_error_hajek"),
            ("raw_count_detection_proportion", "gene_detection_l1_error_hajek"),
        ):
            records.append({
                "dataset_id": row["dataset_id"], "fraction": float(row["sampling_fraction"]), "seed": int(row["seed"]),
                "method": row["method"], "endpoint": endpoint, "historical_error": float(row[column]),
                "historical_source_identity_sha256": row.get("source_identity_sha256", ""),
                "historical_target_n": int(row["target_n"]),
            })
    frame = pd.DataFrame(records)
    return frame.sort_values(["dataset_id", "fraction", "seed", "method", "endpoint"]).reset_index(drop=True)


def make_outputs() -> None:
    new = collect_new_results()
    if new.empty:
        return
    atomic_csv(OUT / "method_endpoint_results.csv", new.to_dict(orient="records"))
    old = historical_results()
    merged = new.merge(old, on=["dataset_id", "fraction", "seed", "method", "endpoint"], how="outer", indicator=True)
    merged["absolute_difference"] = merged["error"] - merged["historical_error"]
    merged["relative_difference"] = merged["absolute_difference"] / np.maximum(np.abs(merged["historical_error"]), 1e-12)
    merged["numeric_within_tolerance"] = np.isclose(merged["error"], merged["historical_error"], atol=ATOL, rtol=RTOL)
    merged["historical_sample_ids_status"] = "NOT_AVAILABLE_FOR_COMPARISON"
    merged["historical_quota_status"] = "NOT_AVAILABLE_FOR_COMPARISON"
    merged["historical_inclusion_probability_status"] = "NOT_AVAILABLE_FOR_COMPARISON"
    atomic_csv(OUT / "old_vs_new_comparison.csv", merged.to_dict(orient="records"))

    new_wide = new.pivot(index=["dataset_id", "fraction", "seed", "endpoint"], columns="method", values="error").reset_index()
    old_wide = old.pivot(index=["dataset_id", "fraction", "seed", "endpoint"], columns="method", values="historical_error").reset_index()
    pairs = new_wide.merge(old_wide, on=["dataset_id", "fraction", "seed", "endpoint"], suffixes=("", "__old"))
    pairs["new_relative_benefit_equal_vs_srs"] = (
        (pairs[DIRECT_SPATIAL_QUOTA_SRS] - pairs[EQUAL_PROBABILITY_FIXED_QUOTA])
        / np.maximum(pairs[DIRECT_SPATIAL_QUOTA_SRS], 1e-12)
    )
    pairs["old_relative_benefit_equal_vs_srs"] = (
        (pairs[f"{DIRECT_SPATIAL_QUOTA_SRS}__old"] - pairs[f"{EQUAL_PROBABILITY_FIXED_QUOTA}__old"])
        / np.maximum(pairs[f"{DIRECT_SPATIAL_QUOTA_SRS}__old"], 1e-12)
    )
    pairs["new_winner"] = np.where(pairs["new_relative_benefit_equal_vs_srs"] > 0, "Equal", np.where(pairs["new_relative_benefit_equal_vs_srs"] < 0, "SRS", "tie"))
    pairs["old_winner"] = np.where(pairs["old_relative_benefit_equal_vs_srs"] > 0, "Equal", np.where(pairs["old_relative_benefit_equal_vs_srs"] < 0, "SRS", "tie"))
    pairs["winner_direction_changed"] = pairs["new_winner"] != pairs["old_winner"]
    def band(values: pd.Series) -> pd.Series:
        return np.where(values > 0.02, "Equal_by_more_than_2pct", np.where(values < -0.02, "SRS_by_more_than_2pct", "within_2pct"))
    pairs["new_descriptive_2pct_class"] = band(pairs["new_relative_benefit_equal_vs_srs"])
    pairs["old_descriptive_2pct_class"] = band(pairs["old_relative_benefit_equal_vs_srs"])
    pairs["descriptive_2pct_class_changed"] = pairs["new_descriptive_2pct_class"] != pairs["old_descriptive_2pct_class"]
    atomic_csv(OUT / "paired_endpoint_results.csv", pairs.to_dict(orient="records"))

    summary_rows = []
    for label, frame in (("new", pairs), ("historical", pairs.assign(new_relative_benefit_equal_vs_srs=pairs["old_relative_benefit_equal_vs_srs"]))):
        values = frame["new_relative_benefit_equal_vs_srs"].astype(float)
        summary_rows.append({"summary_level": "overall_endpoint_records", "dataset_id": "ALL", "version": label, "n_pairs": len(values), "equal_wins": int((values > 0).sum()), "srs_wins": int((values < 0).sum()), "ties": int((values == 0).sum()), "median_relative_benefit": float(values.median()), "q1_relative_benefit": float(values.quantile(.25)), "q3_relative_benefit": float(values.quantile(.75)), "mean_relative_benefit": float(values.mean())})
        for dataset_id, group in frame.groupby("dataset_id"):
            val = group["new_relative_benefit_equal_vs_srs"].astype(float)
            summary_rows.append({"summary_level": "dataset_endpoint_records", "dataset_id": dataset_id, "version": label, "n_pairs": len(val), "equal_wins": int((val > 0).sum()), "srs_wins": int((val < 0).sum()), "ties": int((val == 0).sum()), "median_relative_benefit": float(val.median()), "q1_relative_benefit": float(val.quantile(.25)), "q3_relative_benefit": float(val.quantile(.75)), "mean_relative_benefit": float(val.mean())})
        for (fraction, endpoint), group in frame.groupby(["fraction", "endpoint"]):
            val = group["new_relative_benefit_equal_vs_srs"].astype(float)
            summary_rows.append({"summary_level": "fraction_endpoint_records", "dataset_id": "ALL", "fraction": fraction, "endpoint": endpoint, "version": label, "n_pairs": len(val), "equal_wins": int((val > 0).sum()), "srs_wins": int((val < 0).sum()), "ties": int((val == 0).sum()), "median_relative_benefit": float(val.median()), "q1_relative_benefit": float(val.quantile(.25)), "q3_relative_benefit": float(val.quantile(.75)), "mean_relative_benefit": float(val.mean())})
    errors = new.groupby(["dataset_id", "endpoint"])["error"].agg(["min", "max"]).reset_index()
    for row in errors.to_dict(orient="records"):
        summary_rows.append({"summary_level": "absolute_error_range", "dataset_id": row["dataset_id"], "endpoint": row["endpoint"], "version": "new", "minimum_error": row["min"], "maximum_error": row["max"]})
    atomic_csv(OUT / "reproduction_summary.csv", summary_rows)

    complete = len(new) == 240 and len(pairs) == 120 and len(merged) == 240
    numeric = bool(merged["numeric_within_tolerance"].all()) if complete else False
    if complete and numeric:
        classification = "A. CORE_NUMERICAL_REPRODUCTION_CONFIRMED"
    elif complete:
        classification = "B. COMPLETE_RERUN_WITH_NUMERICAL_DIFFERENCES"
    else:
        classification = "D. REPRODUCTION_INCOMPLETE"
    disagreement = merged.loc[~merged["numeric_within_tolerance"].fillna(False)]
    report = ["# Controlled reproduction discrepancy report", "", f"Classification: `{classification}`", "", f"Completed endpoint rows: {len(new)}/240; paired endpoint records: {len(pairs)}/120.", f"Float64 rule: atol={ATOL:g}, rtol={RTOL:g}.", "", "## New-versus-history numerical comparison", ""]
    if len(disagreement) == 0:
        report.append("All 240 method-endpoint errors matched the retained full-precision historical values under the prerecorded numerical rule.")
    else:
        report.append(f"{len(disagreement)} method-endpoint records did not meet the prerecorded numerical rule. No tolerance was changed and no sampling parameter was adjusted.")
        report.append("")
        report.append("Potential sources requiring evidence-directed review: input/order, preprocessing/target, spatial strata/quota, neighbourhood/ties, seed split, dependency numerics, sampling logic, or endpoint evaluation. This run does not search alternative seeds or implementations.")
    report.extend(["", "## Historical fields unavailable for direct comparison", "", "Historical selected identifiers, quota vectors and inclusion-probability vectors were not retained in the three direct-comparison result folders. Their status is therefore NOT_AVAILABLE_FOR_COMPARISON; the new values are fully retained in each unit detail file.", "", "## Mouse-brain high absolute error audit", "", "The new endpoint rows retain target and estimate vectors, numerator, denominator and weight denominator. Detection uses raw count > 0. Relative L1 is sum(abs(estimate-target))/sum(target). No high-error point was removed."])
    atomic_text(OUT / "discrepancy_report.md", "\n".join(report) + "\n")
    decision = ["# Reproduction decision", "", f"`{classification}`", "", "This is a newly frozen controlled rerun after historical results were known. It does not establish that the historical unrecorded code commit was identical.", "", "The rerun does not alter the v4 manuscript or replace historical result tables automatically."]
    atomic_text(OUT / "reproduction_decision.md", "\n".join(decision) + "\n")


def selected_units(mode: str) -> Iterable[tuple[str, float, int]]:
    if mode == "preflight":
        return ((DATASETS[0], 0.02, SEEDS[0]),)
    return ((dataset, fraction, seed) for dataset in DATASETS for fraction in FRACTIONS for seed in SEEDS)


def run(mode: str) -> None:
    if not PROTOCOL.is_file():
        raise FileNotFoundError("Run --mode prepare before sampling.")
    if not INPUT_MANIFEST.is_file():
        raise FileNotFoundError("Input verification manifest is missing.")
    manifest = pd.read_csv(INPUT_MANIFEST)
    if not (manifest["historical_identity_status"] == "MATCHED_TRUSTED_HISTORICAL_HASH").all():
        raise RuntimeError("Input verification does not permit sampling.")
    by_dataset: dict[str, list[tuple[float, int]]] = {}
    for dataset, fraction, seed in selected_units(mode):
        by_dataset.setdefault(dataset, []).append((fraction, seed))
    for dataset_id in DATASETS:
        if dataset_id not in by_dataset:
            continue
        cached = load_or_build_cache(dataset_id)
        designs = {fraction: condition_design(dataset_id, fraction, cached) for fraction in FRACTIONS if any(item[0] == fraction for item in by_dataset[dataset_id])}
        for fraction, seed in by_dataset[dataset_id]:
            run_condition(dataset_id, fraction, seed, cached, designs[fraction])
            make_outputs()
    make_outputs()
    execution_rows = []
    for path in sorted(STATUS_DIR.glob("*.json")):
        value = json.loads(path.read_text(encoding="utf-8"))
        execution_rows.append({"unit_key": value.get("unit_key"), "status": value.get("status"), "dataset_id": value.get("dataset_id"), "fraction": value.get("fraction"), "seed": value.get("seed"), "method": value.get("method"), "retry_count": value.get("retry_count"), "detail_path": value.get("detail_path"), "detail_sha256": value.get("detail_sha256"), "completed_at_unix": value.get("completed_at_unix")})
    atomic_csv(EXECUTION_MANIFEST, execution_rows)
    print(json.dumps({"status": "RUN_COMPLETE", "mode": mode, "completed_method_runs": len(execution_rows)}, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("prepare", "preflight", "complete"), required=True)
    args = parser.parse_args()
    if args.mode == "prepare":
        prepare()
    else:
        run(args.mode)


if __name__ == "__main__":
    main()
