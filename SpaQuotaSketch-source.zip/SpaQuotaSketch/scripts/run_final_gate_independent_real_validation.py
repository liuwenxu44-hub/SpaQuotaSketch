"""Run the preregistered independent real-tissue confirmation of the final gate.

This driver deliberately has two non-overlapping stages.  It first generates
only pilot evidence and writes a frozen decision table.  It then evaluates the
three disjoint holdout seeds with those already-written decisions.  It never
alters a quota, fraction, candidate order, threshold, endpoint, oracle, or
material-loss definition in response to an observed result.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import UTC, datetime
from hashlib import sha256
import json
from pathlib import Path
import platform
import sys
from types import SimpleNamespace
from typing import Any

import numpy as np
import pandas as pd
import scipy
import sklearn
import yaml


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from spaquotasketch.benchmark.formal_multiplatform_input_adapters import load_visium_h5_spatial_tar  # noqa: E402
from spaquotasketch.fixed_quota_probability import (  # noqa: E402
    EQUAL_PROBABILITY_FIXED_QUOTA,
    LEVERAGE_WEIGHTED_FIXED_QUOTA,
    fixed_quota_probability_plans,
    fixed_quota_probability_selections,
    hajek_normalized_expression_fidelity,
    leverage_score_values,
)
from spaquotasketch.preprocess import compute_normalized_log1p_svd_representation  # noqa: E402
from spaquotasketch.safe_gate import SafeGateThresholds, WeightedCandidateEvidence, choose_safe_mode  # noqa: E402
from spaquotasketch.v2_1.quota import allocate_largest_remainder_quotas  # noqa: E402
from spaquotasketch.v2_1.spatial import choose_adaptive_regular_partition  # noqa: E402


EQUAL = EQUAL_PROBABILITY_FIXED_QUOTA
R2 = "leverage_weighted_fixed_quota_r2"
R4 = "leverage_weighted_fixed_quota_r4"
METHOD_BY_CAP = {2.0: R2, 4.0: R4}
ENDPOINTS = ("gene_mean_l1_error_hajek", "gene_detection_l1_error_hajek")
COMMON_COLUMNS = (
    "data_level", "dataset", "dataset_id", "donor", "section", "sample", "fraction", "seed",
    "selected_mode", "equal_error", "r2_error", "r4_error", "oracle_mode", "oracle_error",
    "selected_error", "normalized_regret", "material_loss", "equal_ess_fraction",
    "r2_ess_fraction", "r4_ess_fraction", "selected_ess_fraction",
)


@dataclass
class FractionState:
    dataset: dict[str, Any]
    fraction: float
    target_n: int
    embedding: np.ndarray
    basis: np.ndarray
    normalized: Any
    strata: np.ndarray
    quotas: dict[str, int]
    plans: dict[float, dict[str, Any]]
    pilot_association: float
    pilot_total_association: float
    pilot_detected_association: float
    decision: Any
    decision_row: dict[str, Any]


def file_sha256(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_yaml(path: Path) -> dict[str, Any]:
    value = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"Expected a YAML mapping: {path}")
    return value


def mode_for_cap(cap: float) -> str:
    try:
        return METHOD_BY_CAP[float(cap)]
    except KeyError as error:
        raise ValueError(f"Unsupported frozen cap: {cap}") from error


def correlation(first: np.ndarray, second: np.ndarray) -> float:
    first = np.asarray(first, dtype=float)
    second = np.asarray(second, dtype=float)
    if first.shape != second.shape or first.size < 3:
        raise ValueError("Association inputs must be aligned and contain at least three observations.")
    if float(np.std(first)) == 0.0 or float(np.std(second)) == 0.0:
        return 0.0
    value = float(np.corrcoef(first, second)[0, 1])
    return value if np.isfinite(value) else 0.0


def target_size(n_obs: int, fraction: float) -> int:
    value = int(np.floor(int(n_obs) * float(fraction)))
    if not 1 <= value <= int(n_obs):
        raise ValueError(f"Frozen fraction {fraction} is not feasible for {n_obs} observations.")
    return value


def common_row(level: str, dataset: dict[str, Any], fraction: float | None, seed: Any, **values: Any) -> dict[str, Any]:
    row: dict[str, Any] = {
        "data_level": level,
        "dataset": dataset.get("dataset", ""),
        "dataset_id": dataset.get("dataset_id", ""),
        "donor": dataset.get("donor", ""),
        "section": dataset.get("section", ""),
        "sample": dataset.get("sample", ""),
        "fraction": float(fraction) if fraction is not None else np.nan,
        "seed": seed,
        "selected_mode": "NOT_APPLICABLE",
        "equal_error": np.nan,
        "r2_error": np.nan,
        "r4_error": np.nan,
        "oracle_mode": "NOT_APPLICABLE",
        "oracle_error": np.nan,
        "selected_error": np.nan,
        "normalized_regret": np.nan,
        "material_loss": np.nan,
        "equal_ess_fraction": np.nan,
        "r2_ess_fraction": np.nan,
        "r4_ess_fraction": np.nan,
        "selected_ess_fraction": np.nan,
    }
    row.update(values)
    return row


def write_tsv(frame: pd.DataFrame, path: Path) -> None:
    for column in COMMON_COLUMNS:
        if column not in frame.columns:
            frame[column] = np.nan
    ordered = list(COMMON_COLUMNS) + [column for column in frame.columns if column not in COMMON_COLUMNS]
    frame.loc[:, ordered].to_csv(path, sep="\t", index=False)


def require_frozen_hashes(preregistration: dict[str, Any], preregistration_path: Path) -> dict[str, str]:
    observed: dict[str, str] = {}
    for label, relative in preregistration["frozen_files"].items():
        path = ROOT / relative
        observed[label] = file_sha256(path)
        if observed[label] != preregistration["sha256_before"][label]:
            raise RuntimeError(f"Frozen hash mismatch before execution: {label}")
    observed["preregistration"] = file_sha256(preregistration_path)
    for item in preregistration["included_sections"]:
        for source in item["source_files"]:
            path = ROOT / source["relative_path"]
            if file_sha256(path) != source["sha256"]:
                raise RuntimeError(f"Input file checksum mismatch before execution: {source['relative_path']}")
    return observed


def make_evidence(
    *,
    method: str,
    cap: float,
    pilot_association: float,
    pilot_records: dict[int, dict[str, dict[str, float]]],
) -> tuple[WeightedCandidateEvidence, dict[str, float]]:
    benefits: list[float] = []
    for seed, result in sorted(pilot_records.items()):
        equal_error = result[EQUAL]["composite"]
        weighted_error = result[method]["composite"]
        benefits.append((equal_error - weighted_error) / max(equal_error, 1e-12))
    diagnostics = {
        "mean_pilot_relative_benefit": float(np.mean(benefits)),
        "worst_single_pilot_relative_benefit": float(np.min(benefits)),
        "minimum_pilot_ess_fraction": float(min(result[method]["ess"] for result in pilot_records.values())),
    }
    # The final three-condition rule never reads this legacy compatibility field.
    evidence = WeightedCandidateEvidence(
        method_id=method,
        max_weight_inflation=float(cap),
        pilot_alignment=float(pilot_association),
        minimum_pilot_ess_fraction=diagnostics["minimum_pilot_ess_fraction"],
        mean_pilot_relative_benefit=diagnostics["mean_pilot_relative_benefit"],
        minimum_endpoint_mean_relative_benefit=0.0,
        worst_single_pilot_relative_benefit=diagnostics["worst_single_pilot_relative_benefit"],
    )
    return evidence, diagnostics


def prepare_pilots(dataset: dict[str, Any], preregistration: dict[str, Any]) -> tuple[list[FractionState], list[dict[str, Any]], list[dict[str, Any]]]:
    raw_files = [ROOT / item["relative_path"] for item in dataset["source_files"]]
    raw = load_visium_h5_spatial_tar(raw_files[0], raw_files[1])
    local = SimpleNamespace(X=raw.expression_matrix, obsm={"spatial": raw.coordinates})
    prep = preregistration["preprocessing"]
    embedding, basis, normalized = compute_normalized_log1p_svd_representation(
        local,
        n_components=int(prep["components"]),
        random_state=int(prep["random_state"]),
        target_sum=float(prep["library_size_normalization_target"]),
    )
    score = leverage_score_values(basis)
    total_counts = np.asarray(raw.expression_matrix.sum(axis=1)).reshape(-1)
    detected_features = raw.expression_matrix.getnnz(axis=1).astype(float)
    design = preregistration["sampling_design"]
    pilot_seeds = [int(value) for value in design["pilot_seeds"]]
    caps = [float(value) for value in design["candidate_caps"]]
    thresholds = SafeGateThresholds(
        minimum_alignment=float(preregistration["frozen_gate"]["minimum_pilot_association"]),
        minimum_mean_relative_benefit=float(preregistration["frozen_gate"]["minimum_mean_pilot_relative_benefit"]),
        maximum_single_pilot_relative_loss=float(preregistration["frozen_gate"]["maximum_single_pilot_relative_loss"]),
    )
    states: list[FractionState] = []
    evidence_rows: list[dict[str, Any]] = []
    decision_rows: list[dict[str, Any]] = []
    for fraction in (float(value) for value in design["fractions"]):
        n_target = target_size(raw.n_obs, fraction)
        try:
            partition = choose_adaptive_regular_partition(
                raw.coordinates,
                n_target,
                minimum_quota=int(design["minimum_quota"]),
                max_n_x=int(design["max_n_x"]),
                max_n_y=int(design["max_n_y"]),
            )
            allocation = allocate_largest_remainder_quotas(
                partition.stratum_audit,
                n_target,
                minimum_quota=int(design["minimum_quota"]),
            )
        except Exception as error:
            decision_rows.append(common_row(
                "frozen_gate_decision", dataset, fraction, "pilot:1101,1201",
                selected_mode="NOT_FEASIBLE", decision_source="pilot_only", feasibility="NOT_FEASIBLE",
                gate_reason=str(error), target_n=n_target,
            ))
            continue
        plans = {
            cap: fixed_quota_probability_plans(
                expression_embedding=embedding, expression_basis=basis,
                spatial_strata=partition.stratum_ids, quotas=allocation.quotas,
                max_weight_inflation=cap,
            )
            for cap in caps
        }
        pilot_records: dict[int, dict[str, dict[str, float]]] = {}
        equal_indices: list[np.ndarray] = []
        for seed in pilot_seeds:
            records: dict[str, dict[str, float]] = {}
            expected_equal: np.ndarray | None = None
            for cap in caps:
                selections = fixed_quota_probability_selections(
                    expression_embedding=embedding, expression_basis=basis,
                    spatial_strata=partition.stratum_ids, quotas=allocation.quotas, seed=seed,
                    max_weight_inflation=cap, precomputed_pivotal_plans=plans[cap],
                )
                equal = selections[EQUAL]
                if expected_equal is None:
                    expected_equal = equal.selected_indices
                    equal_metric = hajek_normalized_expression_fidelity(normalized, equal.selected_indices, equal.sampling_weight)
                    records[EQUAL] = {"composite": float(np.mean([equal_metric[key] for key in ENDPOINTS])), "ess": float(equal.diagnostics["mean_selected_ess_fraction"])}
                    equal_indices.append(equal.selected_indices.copy())
                elif not np.array_equal(expected_equal, equal.selected_indices):
                    raise RuntimeError("Equal pivotal sample changed across r=2 and r=4 matched plans.")
                weighted = selections[LEVERAGE_WEIGHTED_FIXED_QUOTA]
                metric = hajek_normalized_expression_fidelity(normalized, weighted.selected_indices, weighted.sampling_weight)
                records[mode_for_cap(cap)] = {"composite": float(np.mean([metric[key] for key in ENDPOINTS])), "ess": float(weighted.diagnostics["mean_selected_ess_fraction"])}
            pilot_records[seed] = records
        pilot_union = np.unique(np.concatenate(equal_indices))
        total_association = correlation(score[pilot_union], total_counts[pilot_union])
        detected_association = correlation(score[pilot_union], detected_features[pilot_union])
        association = min(total_association, detected_association)
        evidences: list[WeightedCandidateEvidence] = []
        candidate_values: dict[str, dict[str, float]] = {}
        for cap in caps:
            method = mode_for_cap(cap)
            evidence, values = make_evidence(method=method, cap=cap, pilot_association=association, pilot_records=pilot_records)
            evidences.append(evidence)
            candidate_values[method] = values
        decision = choose_safe_mode(evidences, thresholds)
        by_method = {item.method_id: item for item in evidences}
        for method in (R4, R2):
            evidence = by_method[method]
            values = candidate_values[method]
            evidence_rows.append(common_row(
                "pilot_evidence", dataset, fraction, "pilot:1101,1201",
                selected_mode=decision.selected_method_id,
                decision_source="pilot_only", candidate_mode=method,
                candidate_cap=evidence.max_weight_inflation,
                score_summary_proxy_association=association,
                pilot_score_total_counts_association=total_association,
                pilot_score_detected_feature_count_association=detected_association,
                pilot_equal_observation_union_n=int(pilot_union.size),
                mean_pilot_relative_benefit=values["mean_pilot_relative_benefit"],
                worst_single_pilot_relative_benefit=values["worst_single_pilot_relative_benefit"],
                minimum_pilot_ess_fraction=values["minimum_pilot_ess_fraction"],
                endpoint_compatibility_field_not_used_by_gate=0.0,
                gate_passed=decision.selected_method_id == method,
                **{
                    "equal_error": float(np.mean([record[EQUAL]["composite"] for record in pilot_records.values()])),
                    "r2_error": float(np.mean([record[R2]["composite"] for record in pilot_records.values()])),
                    "r4_error": float(np.mean([record[R4]["composite"] for record in pilot_records.values()])),
                    "equal_ess_fraction": float(np.mean([record[EQUAL]["ess"] for record in pilot_records.values()])),
                    "r2_ess_fraction": float(np.mean([record[R2]["ess"] for record in pilot_records.values()])),
                    "r4_ess_fraction": float(np.mean([record[R4]["ess"] for record in pilot_records.values()])),
                },
            ))
        selected_ess = (float(np.mean([record[decision.selected_method_id]["ess"] for record in pilot_records.values()])) if decision.selected_method_id != EQUAL else float(np.mean([record[EQUAL]["ess"] for record in pilot_records.values()])))
        decision_row = common_row(
            "frozen_gate_decision", dataset, fraction, "pilot:1101,1201",
            selected_mode=decision.selected_method_id, selected_ess_fraction=selected_ess,
            decision_source="pilot_only", weighted_enabled=decision.weighted_enabled,
            gate_reason=decision.reason, gate_identifier=decision.gate_identifier,
            candidate_precedence="r=4_then_r=2", ess_role="advisory_not_hard_gate",
            target_n=n_target, spatial_grid_n_x=partition.n_x, spatial_grid_n_y=partition.n_y,
            occupied_strata=len(allocation.quotas), quota_sum=sum(allocation.quotas.values()),
            quota_exact=True, feasibility="FEASIBLE",
            score_summary_proxy_association=association,
            pilot_score_total_counts_association=total_association,
            pilot_score_detected_feature_count_association=detected_association,
            pilot_equal_observation_union_n=int(pilot_union.size),
            **{
                "equal_error": float(np.mean([record[EQUAL]["composite"] for record in pilot_records.values()])),
                "r2_error": float(np.mean([record[R2]["composite"] for record in pilot_records.values()])),
                "r4_error": float(np.mean([record[R4]["composite"] for record in pilot_records.values()])),
                "equal_ess_fraction": float(np.mean([record[EQUAL]["ess"] for record in pilot_records.values()])),
                "r2_ess_fraction": float(np.mean([record[R2]["ess"] for record in pilot_records.values()])),
                "r4_ess_fraction": float(np.mean([record[R4]["ess"] for record in pilot_records.values()])),
            },
        )
        decision_rows.append(decision_row)
        states.append(FractionState(dataset, fraction, n_target, embedding, basis, normalized, partition.stratum_ids, allocation.quotas, plans, association, total_association, detected_association, decision, decision_row))
    return states, evidence_rows, decision_rows


def evaluate_holdouts(states: list[FractionState], preregistration: dict[str, Any]) -> list[dict[str, Any]]:
    holdout_rows: list[dict[str, Any]] = []
    holdout_seeds = [int(value) for value in preregistration["sampling_design"]["holdout_seeds"]]
    for state in states:
        if state.decision.selected_method_id == "NOT_FEASIBLE":
            continue
        for seed in holdout_seeds:
            records: dict[str, dict[str, float]] = {}
            expected_equal: np.ndarray | None = None
            for cap in (4.0, 2.0):
                selections = fixed_quota_probability_selections(
                    expression_embedding=state.embedding, expression_basis=state.basis,
                    spatial_strata=state.strata, quotas=state.quotas, seed=seed,
                    max_weight_inflation=cap, precomputed_pivotal_plans=state.plans[cap],
                )
                equal = selections[EQUAL]
                if expected_equal is None:
                    expected_equal = equal.selected_indices
                    equal_metrics = hajek_normalized_expression_fidelity(state.normalized, equal.selected_indices, equal.sampling_weight)
                    records[EQUAL] = {
                        "composite": float(np.mean([equal_metrics[key] for key in ENDPOINTS])),
                        "mean": float(equal_metrics[ENDPOINTS[0]]), "detection": float(equal_metrics[ENDPOINTS[1]]),
                        "ess": float(equal.diagnostics["mean_selected_ess_fraction"]),
                    }
                elif not np.array_equal(expected_equal, equal.selected_indices):
                    raise RuntimeError("Equal pivotal holdout sample changed across r=2 and r=4 matched plans.")
                weighted = selections[LEVERAGE_WEIGHTED_FIXED_QUOTA]
                metric = hajek_normalized_expression_fidelity(state.normalized, weighted.selected_indices, weighted.sampling_weight)
                records[mode_for_cap(cap)] = {
                    "composite": float(np.mean([metric[key] for key in ENDPOINTS])),
                    "mean": float(metric[ENDPOINTS[0]]), "detection": float(metric[ENDPOINTS[1]]),
                    "ess": float(weighted.diagnostics["mean_selected_ess_fraction"]),
                }
            oracle_mode = min((EQUAL, R2, R4), key=lambda mode: records[mode]["composite"])
            selected_mode = state.decision.selected_method_id
            equal_error = records[EQUAL]["composite"]
            selected_error = records[selected_mode]["composite"]
            holdout_rows.append(common_row(
                "holdout_seed", state.dataset, state.fraction, seed,
                selected_mode=selected_mode, oracle_mode=oracle_mode,
                equal_error=equal_error, r2_error=records[R2]["composite"], r4_error=records[R4]["composite"],
                oracle_error=records[oracle_mode]["composite"], selected_error=selected_error,
                normalized_regret=(selected_error - records[oracle_mode]["composite"]) / max(equal_error, 1e-12),
                material_loss=selected_error > 1.02 * equal_error,
                material_loss_seed=selected_error > 1.02 * equal_error,
                selected_relative_benefit=(equal_error - selected_error) / max(equal_error, 1e-12),
                always_equal_regret=(equal_error - records[oracle_mode]["composite"]) / max(equal_error, 1e-12),
                always_r4_regret=(records[R4]["composite"] - records[oracle_mode]["composite"]) / max(equal_error, 1e-12),
                equal_ess_fraction=records[EQUAL]["ess"], r2_ess_fraction=records[R2]["ess"], r4_ess_fraction=records[R4]["ess"],
                selected_ess_fraction=records[selected_mode]["ess"],
                equal_gene_mean_error=records[EQUAL]["mean"], r2_gene_mean_error=records[R2]["mean"], r4_gene_mean_error=records[R4]["mean"],
                equal_detection_error=records[EQUAL]["detection"], r2_detection_error=records[R2]["detection"], r4_detection_error=records[R4]["detection"],
                decision_source="pilot_only_frozen_before_holdout", quota_exact=True, target_n=state.target_n,
            ))
    return holdout_rows


def fraction_results(holdout: pd.DataFrame, decisions: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    feasible_decisions = decisions.loc[decisions["selected_mode"] != "NOT_FEASIBLE"].copy()
    for decision in feasible_decisions.itertuples(index=False):
        key = (decision.dataset_id, float(decision.fraction))
        unit = holdout.loc[(holdout["dataset_id"] == key[0]) & (holdout["fraction"] == key[1])]
        if unit["seed"].nunique() != 3:
            raise RuntimeError(f"Holdout seeds incomplete for {key}")
        equal_error = float(unit["equal_error"].mean())
        r2_error = float(unit["r2_error"].mean())
        r4_error = float(unit["r4_error"].mean())
        error_by_mode = {EQUAL: equal_error, R2: r2_error, R4: r4_error}
        oracle_mode = min(error_by_mode, key=error_by_mode.get)
        selected_mode = str(decision.selected_mode)
        selected_error = error_by_mode[selected_mode]
        dataset = {"dataset": decision.dataset, "dataset_id": decision.dataset_id, "donor": decision.donor, "section": decision.section, "sample": decision.sample}
        rows.append(common_row(
            "fraction", dataset, float(decision.fraction), "holdout:2101,2201,2301",
            selected_mode=selected_mode, oracle_mode=oracle_mode, equal_error=equal_error, r2_error=r2_error, r4_error=r4_error,
            oracle_error=error_by_mode[oracle_mode], selected_error=selected_error,
            normalized_regret=(selected_error - error_by_mode[oracle_mode]) / max(equal_error, 1e-12),
            material_loss=selected_error > 1.02 * equal_error,
            selected_relative_benefit=(equal_error - selected_error) / max(equal_error, 1e-12),
            always_equal_regret=(equal_error - error_by_mode[oracle_mode]) / max(equal_error, 1e-12),
            always_r4_regret=(r4_error - error_by_mode[oracle_mode]) / max(equal_error, 1e-12),
            equal_ess_fraction=float(unit["equal_ess_fraction"].mean()), r2_ess_fraction=float(unit["r2_ess_fraction"].mean()), r4_ess_fraction=float(unit["r4_ess_fraction"].mean()), selected_ess_fraction=float(unit["selected_ess_fraction"].mean()),
            holdout_seed_count=3, decision_source="pilot_only", target_n=int(decision.target_n), quota_exact=bool(unit["quota_exact"].all()),
            score_summary_proxy_association=float(decision.score_summary_proxy_association), gate_reason=decision.gate_reason,
        ))
    return pd.DataFrame(rows)


def section_results(fractions: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for section, group in fractions.groupby("section", sort=True):
        group = group.sort_values("fraction")
        dataset = group.iloc[0].to_dict()
        loss_count = int(group["material_loss"].sum())
        modes = ";".join(f"{value:.2f}:{mode}" for value, mode in zip(group["fraction"], group["selected_mode"], strict=True))
        rows.append(common_row(
            "section", dataset, None, "aggregated_holdout_seeds_then_fractions",
            selected_mode=f"MIXED[{modes}]", oracle_mode="fraction_specific_oracle",
            equal_error=float(group["equal_error"].mean()), r2_error=float(group["r2_error"].mean()), r4_error=float(group["r4_error"].mean()),
            oracle_error=float(group["oracle_error"].mean()), selected_error=float(group["selected_error"].mean()),
            normalized_regret=float(group["normalized_regret"].mean()), material_loss=loss_count > len(group) / 2,
            section_material_loss=loss_count > len(group) / 2, fraction_material_loss_count=loss_count,
            evaluable_fraction_count=int(len(group)), equal_ess_fraction=float(group["equal_ess_fraction"].mean()),
            r2_ess_fraction=float(group["r2_ess_fraction"].mean()), r4_ess_fraction=float(group["r4_ess_fraction"].mean()), selected_ess_fraction=float(group["selected_ess_fraction"].mean()),
            unit_definition="section; descriptive only; no patient-level biological inference",
        ))
    return pd.DataFrame(rows)


def donor_blocked_results(sections: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for section_row in sections.itertuples(index=False):
        record = section_row._asdict()
        dataset = {key: record[key] for key in ("dataset", "dataset_id", "donor", "section", "sample")}
        rows.append(common_row(
            "donor_blocked_not_applicable", dataset, None, "not_applicable",
            selected_mode=record["selected_mode"], oracle_mode=record["oracle_mode"],
            equal_error=record["equal_error"], r2_error=record["r2_error"], r4_error=record["r4_error"], oracle_error=record["oracle_error"], selected_error=record["selected_error"], normalized_regret=record["normalized_regret"], material_loss=record["material_loss"],
            equal_ess_fraction=record["equal_ess_fraction"], r2_ess_fraction=record["r2_ess_fraction"], r4_ess_fraction=record["r4_ess_fraction"], selected_ess_fraction=record["selected_ess_fraction"],
            donor_block_status="NOT_APPLICABLE_DONOR_METADATA_NOT_DISCLOSED", unit_definition="section retained as descriptive block; no donor-level or patient-level inference",
        ))
    return pd.DataFrame(rows)


def policy_comparison(fractions: pd.DataFrame, sections: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    policy_map = {"final_gate": "selected_error", "always_equal": "equal_error", "always_r4": "r4_error"}
    for scope, frame in (("fraction_level", fractions), ("section_level", sections)):
        for policy, column in policy_map.items():
            error = frame[column].astype(float)
            regret = (error - frame["oracle_error"].astype(float)) / frame["equal_error"].astype(float).clip(lower=1e-12)
            loss = error > 1.02 * frame["equal_error"].astype(float)
            selection = frame["selected_mode"] if policy == "final_gate" and scope == "fraction_level" else pd.Series({"always_equal": EQUAL, "always_r4": R4}.get(policy, "MIXED"), index=frame.index)
            representative = {"dataset": "ALL_QUALIFIED_REAL_SECTIONS", "dataset_id": "all", "donor": "DONOR_METADATA_NOT_DISCLOSED", "section": "all", "sample": "all"}
            rows.append(common_row(
                f"policy_{scope}", representative, None, "aggregated",
                selected_mode=policy, oracle_mode="pivotal_family_min_equal_r2_r4", equal_error=float(frame["equal_error"].mean()), r2_error=float(frame["r2_error"].mean()), r4_error=float(frame["r4_error"].mean()), oracle_error=float(frame["oracle_error"].mean()), selected_error=float(error.mean()), normalized_regret=float(regret.mean()), material_loss=bool(loss.any()),
                equal_ess_fraction=float(frame["equal_ess_fraction"].mean()), r2_ess_fraction=float(frame["r2_ess_fraction"].mean()), r4_ess_fraction=float(frame["r4_ess_fraction"].mean()), selected_ess_fraction=float(frame["selected_ess_fraction"].mean()) if policy == "final_gate" else (float(frame["equal_ess_fraction"].mean()) if policy == "always_equal" else float(frame["r4_ess_fraction"].mean())),
                policy=policy, aggregation_scope=scope, independent_input_instances=int(frame["section"].nunique()) if scope == "fraction_level" else int(len(frame)), evaluable_units=int(len(frame)),
                equal_selection_count=int((selection == EQUAL).sum()) if scope == "fraction_level" else np.nan,
                r2_selection_count=int((selection == R2).sum()) if scope == "fraction_level" else np.nan,
                r4_selection_count=int((selection == R4).sum()) if scope == "fraction_level" else np.nan,
                material_loss_count=int(loss.sum()), technical_seeds_not_biological_replicates=True,
            ))
    return pd.DataFrame(rows)


def classify(preregistration: dict[str, Any], fractions: pd.DataFrame, sections: pd.DataFrame, policies: pd.DataFrame, hashes_unchanged: bool, simulation_supported: bool) -> tuple[str, dict[str, bool]]:
    fraction_policy = policies.loc[policies["aggregation_scope"] == "fraction_level"].set_index("policy")
    final = fraction_policy.loc["final_gate"]
    equal = fraction_policy.loc["always_equal"]
    r4 = fraction_policy.loc["always_r4"]
    activated = fractions.loc[fractions["selected_mode"].isin([R2, R4])]
    checks = {
        "at_least_three_qualified_new_real_instances": int(fractions["section"].nunique()) >= 3,
        "all_decisions_pilot_only": bool((fractions["decision_source"] == "pilot_only").all()),
        "frozen_hashes_unchanged": bool(hashes_unchanged),
        "section_level_material_loss_zero": bool((~sections["section_material_loss"].astype(bool)).all()),
        "final_mean_regret_not_higher_than_always_equal": float(final["normalized_regret"]) <= float(equal["normalized_regret"]) + 1e-12,
        "final_mean_regret_not_higher_than_always_r4": float(final["normalized_regret"]) <= float(r4["normalized_regret"]) + 1e-12,
        "at_least_one_weighted_activation": len(activated) >= 1,
        "activated_weighted_conditions_no_material_loss": bool((~activated["material_loss"].astype(bool)).all()) if len(activated) else True,
        "independent_simulation_confirmation_remains_supported": bool(simulation_supported),
    }
    base_safety = checks["at_least_three_qualified_new_real_instances"] and checks["all_decisions_pilot_only"] and checks["frozen_hashes_unchanged"] and checks["section_level_material_loss_zero"] and checks["independent_simulation_confirmation_remains_supported"]
    full = base_safety and checks["final_mean_regret_not_higher_than_always_equal"] and checks["final_mean_regret_not_higher_than_always_r4"] and checks["at_least_one_weighted_activation"] and checks["activated_weighted_conditions_no_material_loss"]
    nearly_all_equal = len(activated) <= max(1, int(np.floor(0.10 * len(fractions))))
    if full:
        return "FULL_INDEPENDENT_REAL_CONFIRMATION_SUPPORTED", checks
    if base_safety and nearly_all_equal:
        return "INDEPENDENT_REAL_FALLBACK_SAFETY_SUPPORTED", checks
    return "INDEPENDENT_REAL_CONFIRMATION_NOT_SUPPORTED", checks


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--preregistration", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    preregistration_path = args.preregistration.resolve()
    output_dir = args.output_dir.resolve()
    if "Z:" in str(output_dir).upper() or "Z:" in str(preregistration_path).upper():
        raise ValueError("Z drive is prohibited.")
    preregistration = read_yaml(preregistration_path)
    allowed_before = {"download_manifest.tsv", "real_confirmatory_candidate_qualification.tsv", "real_confirmatory_candidate_qualification_20260831.tsv", "input_manifest.tsv", "preregistration.yaml", "preregistration.sha256", "frozen_hashes_before.tsv"}
    present = {path.name for path in output_dir.iterdir()}
    unexpected = present.difference(allowed_before)
    if unexpected:
        raise FileExistsError(f"Refusing to overwrite existing outcomes: {sorted(unexpected)}")
    hashes_before = require_frozen_hashes(preregistration, preregistration_path)
    qualified = preregistration["included_sections"]
    if len(qualified) < 3:
        raise RuntimeError("No formal real-data calculation is permitted with fewer than three qualified new inputs.")

    # Stage 1: all decisions are created exclusively from pilots.
    states: list[FractionState] = []
    pilot_evidence: list[dict[str, Any]] = []
    decisions: list[dict[str, Any]] = []
    for dataset in qualified:
        ds_states, ds_evidence, ds_decisions = prepare_pilots(dataset, preregistration)
        states.extend(ds_states)
        pilot_evidence.extend(ds_evidence)
        decisions.extend(ds_decisions)
    evidence_frame = pd.DataFrame(pilot_evidence)
    decisions_frame = pd.DataFrame(decisions)
    write_tsv(evidence_frame, output_dir / "pilot_evidence.tsv")
    write_tsv(decisions_frame, output_dir / "frozen_gate_decisions.tsv")
    decision_sha = file_sha256(output_dir / "frozen_gate_decisions.tsv")

    # Stage 2: only the already-frozen pilot decision is used for holdouts.
    holdout_frame = pd.DataFrame(evaluate_holdouts(states, preregistration))
    fractions_frame = fraction_results(holdout_frame, decisions_frame)
    sections_frame = section_results(fractions_frame)
    donors_frame = donor_blocked_results(sections_frame)
    policies_frame = policy_comparison(fractions_frame, sections_frame)
    material_rows: list[dict[str, Any]] = []
    for row in fractions_frame.itertuples(index=False):
        record = row._asdict()
        material_rows.append(common_row("material_loss_audit_fraction", record, float(record["fraction"]), "holdout:2101,2201,2301", **{key: record[key] for key in COMMON_COLUMNS if key in record and key not in {"data_level", "dataset", "dataset_id", "donor", "section", "sample", "fraction", "seed"}}, activated_weighted=record["selected_mode"] in {R2, R4}, pass_material_loss_rule=not bool(record["material_loss"])))
    for row in sections_frame.itertuples(index=False):
        record = row._asdict()
        material_rows.append(common_row("material_loss_audit_section", record, None, "aggregated", **{key: record[key] for key in COMMON_COLUMNS if key in record and key not in {"data_level", "dataset", "dataset_id", "donor", "section", "sample", "fraction", "seed"}}, pass_material_loss_rule=not bool(record["section_material_loss"])))
    material_frame = pd.DataFrame(material_rows)

    write_tsv(holdout_frame, output_dir / "holdout_seed_level.tsv")
    write_tsv(fractions_frame, output_dir / "fraction_level_results.tsv")
    write_tsv(sections_frame, output_dir / "section_level_results.tsv")
    write_tsv(donors_frame, output_dir / "donor_blocked_results.tsv")
    write_tsv(policies_frame, output_dir / "policy_comparison.tsv")
    write_tsv(material_frame, output_dir / "material_loss_audit.tsv")

    simulation_manifest = json.loads((ROOT / "results" / "final_gate_independent_validation_20260829" / "confirmatory_simulation_manifest.json").read_text(encoding="utf-8"))
    simulation_supported = simulation_manifest.get("classification") == "INDEPENDENT_SIMULATION_VALIDATION_SUPPORTED"
    hashes_after = require_frozen_hashes(preregistration, preregistration_path)
    hashes_after["preregistration"] = file_sha256(preregistration_path)
    hashes_unchanged = hashes_before == hashes_after
    hashes_frame = pd.DataFrame([
        {"data_level": "frozen_hash", "dataset": "", "dataset_id": "", "donor": "", "section": "", "sample": "", "fraction": np.nan, "seed": "", "selected_mode": "NOT_APPLICABLE", "equal_error": np.nan, "r2_error": np.nan, "r4_error": np.nan, "oracle_mode": "NOT_APPLICABLE", "oracle_error": np.nan, "selected_error": np.nan, "normalized_regret": np.nan, "material_loss": np.nan, "equal_ess_fraction": np.nan, "r2_ess_fraction": np.nan, "r4_ess_fraction": np.nan, "selected_ess_fraction": np.nan, "file_role": key, "sha256_before": hashes_before[key], "sha256_after": hashes_after[key], "unchanged": hashes_before[key] == hashes_after[key]}
        for key in hashes_before
    ])
    write_tsv(hashes_frame, output_dir / "frozen_hashes_after.tsv")
    classification, criteria = classify(preregistration, fractions_frame, sections_frame, policies_frame, hashes_unchanged, simulation_supported)
    output_summary = policies_frame.loc[policies_frame["aggregation_scope"] == "fraction_level"].set_index("policy")
    final = output_summary.loc["final_gate"]
    equal = output_summary.loc["always_equal"]
    r4 = output_summary.loc["always_r4"]
    activated = fractions_frame.loc[fractions_frame["selected_mode"].isin([R2, R4])]
    report = [
        "# Independent real-tissue confirmation classification", "",
        f"Classification: `{classification}`.", "",
        "## Frozen analysis facts", "",
        f"Qualified new real input instances: {int(fractions_frame['section'].nunique())}.",
        f"Fraction-level selections (Equal/r=2/r=4): {int((fractions_frame['selected_mode'] == EQUAL).sum())}/{int((fractions_frame['selected_mode'] == R2).sum())}/{int((fractions_frame['selected_mode'] == R4).sum())}.",
        f"Section-level material loss: {int(sections_frame['section_material_loss'].sum())}/{len(sections_frame)}. Fraction-level material loss: {int(fractions_frame['material_loss'].sum())}/{len(fractions_frame)}.",
        f"Mean normalized regret (final gate / always Equal / always r=4): {float(final['normalized_regret']) * 100:.4f}% / {float(equal['normalized_regret']) * 100:.4f}% / {float(r4['normalized_regret']) * 100:.4f}%.",
        f"Beneficial weighted activations (>0 benefit on holdout): {int(((activated['selected_relative_benefit'] > 0) if len(activated) else pd.Series(dtype=bool)).sum())}/{len(activated)}.",
        f"All decisions pilot-only: {criteria['all_decisions_pilot_only']}. Frozen hashes unchanged: {hashes_unchanged}.",
        "", "## Prespecified classification checks", "",
    ]
    report.extend(f"- {key}: {'PASS' if value else 'FAIL'}" for key, value in criteria.items())
    report.extend([
        "", "## Interpretation boundary", "",
        "The score-summary-proxy association uses only the union of the two Equal pilot samples and is the smaller Pearson association with total counts and detected-feature count. It is an expression-summary proxy, not a score-target alignment or downstream biological target. Complete-input gene summaries were used only for the preregistered pilot expression-error diagnostic. Cell labels, downstream-task outcomes, and holdout outcomes were not used for selection. Technical seeds are not biological replicates and no biological P value or pseudo-confidence interval was calculated.",
    ])
    (output_dir / "final_real_confirmatory_classification.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    provenance = {
        "analysis_id": preregistration["analysis_id"], "classification": classification,
        "started_and_completed_utc": datetime.now(UTC).isoformat(), "decision_table_sha256_before_holdout": decision_sha,
        "decision_source": "pilot_only", "holdout_used_for_selection": False, "thresholds_tuned_after_outcomes": False,
        "z_drive_accessed": False, "technical_seeds_are_not_biological_replicates": True,
        "simulation_confirmation_classification": simulation_manifest.get("classification"), "frozen_hashes_unchanged": hashes_unchanged,
        "versions": {"python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__, "scipy": scipy.__version__, "scikit_learn": sklearn.__version__, "pyyaml": yaml.__version__},
    }
    (output_dir / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"classification": classification, "fraction_rows": len(fractions_frame), "decision_sha256": decision_sha}, indent=2))


if __name__ == "__main__":
    main()
