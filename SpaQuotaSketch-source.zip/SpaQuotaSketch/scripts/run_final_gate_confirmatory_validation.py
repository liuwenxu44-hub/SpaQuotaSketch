"""Run the preregistered independent simulation confirmation of the frozen gate.

This script does not tune thresholds or use holdout outcomes for selection.
Each decision is constructed from two pilot batches before three disjoint
holdout batches are evaluated.
"""

from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict, dataclass
from hashlib import sha256
import json
from pathlib import Path
import platform
import sys
from typing import Any

import numpy as np
import pandas as pd
import scipy
import sklearn
import yaml


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from spaquotasketch.fixed_quota_boundary import (  # noqa: E402
    FixedQuotaBoundaryPopulation,
    generate_fixed_quota_boundary_population,
)
from spaquotasketch.safe_gate import (  # noqa: E402
    EQUAL_SAFE_DEFAULT,
    SafeGateThresholds,
    WeightedCandidateEvidence,
    choose_safe_mode,
)
from spaquotasketch.v2_1.sampling import (  # noqa: E402
    SamplingPlan,
    build_sampling_plan,
    draw_fixed_size_sample,
)


EQUAL = "equal"
R2 = "weighted_r2"
R4 = "weighted_r4"
POLICIES = ("always_equal", "always_r4", "final_gate")
CONDITIONS = (
    (1, "unrelated", "independent", "clustered"),
    (2, "unrelated", "independent", "scattered"),
    (3, "proxy", "proxy", "clustered"),
    (4, "proxy", "proxy", "scattered"),
    (5, "oracle_positive_control", "oracle_positive_control", "clustered"),
    (6, "oracle_positive_control", "oracle_positive_control", "scattered"),
)


def sha256_file(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def read_yaml(path: Path) -> dict[str, Any]:
    parsed = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(parsed, dict):
        raise ValueError(f"Expected a mapping in {path}")
    return parsed


def weighted_method(cap: float) -> str:
    return f"score_weighted_fixed_quota_r{int(cap)}"


def method_mode(method_id: str) -> str:
    if method_id == EQUAL_SAFE_DEFAULT:
        return EQUAL
    if method_id.endswith("r2"):
        return R2
    if method_id.endswith("r4"):
        return R4
    raise ValueError(f"Unrecognized method id: {method_id}")


def correlation(first: np.ndarray, second: np.ndarray) -> float:
    first = np.asarray(first, dtype=float)
    second = np.asarray(second, dtype=float)
    if first.shape != second.shape or first.size < 3:
        raise ValueError("Correlation inputs must be aligned and contain at least three values.")
    if float(np.std(first)) == 0.0 or float(np.std(second)) == 0.0:
        return 0.0
    value = float(np.corrcoef(first, second)[0, 1])
    return value if np.isfinite(value) else 0.0


def build_plans(
    population: FixedQuotaBoundaryPopulation,
    quota_per_stratum: int,
    caps: tuple[float, ...],
) -> tuple[SamplingPlan, dict[float, SamplingPlan]]:
    labels = sorted(set(population.spatial_strata.tolist()))
    quotas = {label: int(quota_per_stratum) for label in labels}
    equal = build_sampling_plan(
        population.spatial_strata,
        quotas,
        population.coordinates,
        np.ones(population.rare_target.size, dtype=float),
        method="v2_1_coordinate_only",
        max_weight_inflation=max(caps),
    )
    weighted = {
        cap: build_sampling_plan(
            population.spatial_strata,
            quotas,
            population.coordinates,
            population.score,
            method="v2_1_inference",
            max_weight_inflation=cap,
        )
        for cap in caps
    }
    return equal, weighted


def estimate_total(target: np.ndarray, selected: np.ndarray, plan: SamplingPlan) -> float:
    return float(np.sum(target[selected] / plan.inclusion_probability[selected]))


def ess_fraction(selected: np.ndarray, plan: SamplingPlan) -> float:
    weights = plan.sampling_weight[selected]
    effective_n = float(np.square(weights.sum()) / np.square(weights).sum())
    return effective_n / float(selected.size)


def exact_quotas(
    selected: np.ndarray,
    population: FixedQuotaBoundaryPopulation,
    plan: SamplingPlan,
) -> bool:
    counts = pd.Series(population.spatial_strata[selected]).value_counts()
    return bool(
        len(counts) == len(plan.quotas)
        and all(int(counts.get(label, 0)) == int(quota) for label, quota in plan.quotas.items())
    )


@dataclass(frozen=True)
class BatchSummary:
    relative_rmse: dict[str, float]
    mean_ess_fraction: dict[str, float]
    first_equal_indices: np.ndarray


def evaluate_batch(
    population: FixedQuotaBoundaryPopulation,
    equal_plan: SamplingPlan,
    weighted_plans: dict[float, SamplingPlan],
    *,
    n_draws: int,
    seed_base: int,
) -> BatchSummary:
    target_total = float(population.rare_target.sum())
    estimates: dict[str, list[float]] = {EQUAL: []}
    ess: dict[str, list[float]] = {EQUAL: []}
    for cap in weighted_plans:
        estimates[method_mode(weighted_method(cap))] = []
        ess[method_mode(weighted_method(cap))] = []
    first_equal: np.ndarray | None = None
    for draw_index in range(int(n_draws)):
        draw_seed = int(seed_base) + draw_index
        selected_equal = draw_fixed_size_sample(equal_plan, random_seed=draw_seed)
        if first_equal is None:
            first_equal = selected_equal.copy()
        if not exact_quotas(selected_equal, population, equal_plan):
            raise RuntimeError("Equal draw violated an exact spatial quota.")
        estimates[EQUAL].append(estimate_total(population.rare_target, selected_equal, equal_plan))
        ess[EQUAL].append(ess_fraction(selected_equal, equal_plan))
        for cap, plan in weighted_plans.items():
            selected = draw_fixed_size_sample(plan, random_seed=draw_seed)
            if not exact_quotas(selected, population, plan):
                raise RuntimeError("Weighted draw violated an exact spatial quota.")
            mode = method_mode(weighted_method(cap))
            estimates[mode].append(estimate_total(population.rare_target, selected, plan))
            ess[mode].append(ess_fraction(selected, plan))
    if first_equal is None:
        raise RuntimeError("At least one draw is required.")
    relative_rmse = {}
    for mode, values in estimates.items():
        error = np.asarray(values, dtype=float) - target_total
        relative_rmse[mode] = float(np.sqrt(np.mean(np.square(error))) / target_total)
    return BatchSummary(
        relative_rmse=relative_rmse,
        mean_ess_fraction={mode: float(np.mean(values)) for mode, values in ess.items()},
        first_equal_indices=first_equal,
    )


@dataclass(frozen=True)
class PilotDecision:
    selected_mode: str
    gate_reason: str
    weighted_enabled: bool
    evidence_rows: tuple[dict[str, Any], ...]


def make_pilot_decision(
    population: FixedQuotaBoundaryPopulation,
    equal_plan: SamplingPlan,
    weighted_plans: dict[float, SamplingPlan],
    *,
    pilot_labels: tuple[int, ...],
    draws_per_batch: int,
    population_offset: int,
    seed_multiplier: int,
    thresholds: SafeGateThresholds,
) -> PilotDecision:
    pilot_batches = [
        evaluate_batch(
            population,
            equal_plan,
            weighted_plans,
            n_draws=draws_per_batch,
            seed_base=population_offset + label * seed_multiplier,
        )
        for label in pilot_labels
    ]
    pilot_indices = np.unique(
        np.concatenate([batch.first_equal_indices for batch in pilot_batches])
    )
    pilot_association = correlation(
        population.score[pilot_indices], population.rare_target[pilot_indices]
    )
    evidences: list[WeightedCandidateEvidence] = []
    evidence_rows: list[dict[str, Any]] = []
    for cap in sorted(weighted_plans, reverse=True):
        mode = method_mode(weighted_method(cap))
        benefits = [
            (batch.relative_rmse[EQUAL] - batch.relative_rmse[mode])
            / max(batch.relative_rmse[EQUAL], 1e-12)
            for batch in pilot_batches
        ]
        evidence = WeightedCandidateEvidence(
            method_id=weighted_method(cap),
            max_weight_inflation=cap,
            pilot_alignment=pilot_association,
            minimum_pilot_ess_fraction=float(
                min(batch.mean_ess_fraction[mode] for batch in pilot_batches)
            ),
            mean_pilot_relative_benefit=float(np.mean(benefits)),
            minimum_endpoint_mean_relative_benefit=float(np.mean(benefits)),
            worst_single_pilot_relative_benefit=float(min(benefits)),
        )
        evidences.append(evidence)
        evidence_rows.append(
            {
                "candidate_mode": mode,
                "candidate_max_weight_inflation": cap,
                "pilot_association_diagnostic": pilot_association,
                "pilot_unique_observations": int(pilot_indices.size),
                "mean_pilot_relative_benefit": evidence.mean_pilot_relative_benefit,
                "worst_single_pilot_relative_benefit": evidence.worst_single_pilot_relative_benefit,
                "minimum_pilot_ess_fraction": evidence.minimum_pilot_ess_fraction,
            }
        )
    decision = choose_safe_mode(evidences, thresholds)
    return PilotDecision(
        selected_mode=method_mode(decision.selected_method_id),
        gate_reason=decision.reason,
        weighted_enabled=decision.weighted_enabled,
        evidence_rows=tuple(evidence_rows),
    )


def evaluate_one_condition(task: dict[str, Any]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    condition_index = int(task["condition_index"])
    replicate_index = int(task["replicate_index"])
    population_seed = int(task["population_seed"])
    score_condition = str(task["score_condition"])
    generator_alignment = str(task["generator_alignment"])
    target_pattern = str(task["target_pattern"])
    population = generate_fixed_quota_boundary_population(
        grid_side=int(task["grid_side"]),
        cells_per_stratum=int(task["cells_per_stratum"]),
        rare_frequency=float(task["rare_frequency"]),
        rare_pattern=target_pattern,
        alignment=generator_alignment,
        seed=population_seed,
    )
    caps = tuple(float(value) for value in task["candidate_caps"])
    equal_plan, weighted_plans = build_plans(population, int(task["quota_per_stratum"]), caps)
    population_offset = (population_seed % int(task["seed_multiplier"])) * 1000
    thresholds = SafeGateThresholds(
        minimum_alignment=float(task["minimum_alignment"]),
        minimum_mean_relative_benefit=float(task["minimum_mean_benefit"]),
        maximum_single_pilot_relative_loss=float(task["maximum_single_pilot_loss"]),
    )
    decision = make_pilot_decision(
        population,
        equal_plan,
        weighted_plans,
        pilot_labels=tuple(int(value) for value in task["pilot_labels"]),
        draws_per_batch=int(task["pilot_draws_per_batch"]),
        population_offset=population_offset,
        seed_multiplier=int(task["seed_multiplier"]),
        thresholds=thresholds,
    )
    evidence_rows = []
    for row in decision.evidence_rows:
        evidence_rows.append(
            {
                "condition_index": condition_index,
                "replicate_index": replicate_index,
                "population_seed": population_seed,
                "score_condition": score_condition,
                "target_pattern": target_pattern,
                "full_score_target_correlation_audit_only": float(
                    population.metadata["score_target_correlation"]
                ),
                **row,
                "selected_mode": decision.selected_mode,
                "weighted_enabled": decision.weighted_enabled,
                "gate_reason": decision.gate_reason,
                "decision_source": "pilot_only",
            }
        )
    holdout_rows = []
    for holdout_label in tuple(int(value) for value in task["holdout_labels"]):
        batch = evaluate_batch(
            population,
            equal_plan,
            weighted_plans,
            n_draws=int(task["holdout_draws_per_batch"]),
            seed_base=population_offset + holdout_label * int(task["seed_multiplier"]),
        )
        errors = batch.relative_rmse
        oracle_mode = min((EQUAL, R2, R4), key=lambda mode: errors[mode])
        selected_error = errors[decision.selected_mode]
        equal_error = errors[EQUAL]
        oracle_error = errors[oracle_mode]
        holdout_rows.append(
            {
                "condition_index": condition_index,
                "replicate_index": replicate_index,
                "population_seed": population_seed,
                "score_condition": score_condition,
                "target_pattern": target_pattern,
                "holdout_batch_label": holdout_label,
                "selected_mode": decision.selected_mode,
                "decision_source": "pilot_only",
                "equal_error": equal_error,
                "r2_error": errors[R2],
                "r4_error": errors[R4],
                "selected_error": selected_error,
                "oracle_mode": oracle_mode,
                "oracle_error": oracle_error,
                "selected_gain_vs_equal": (equal_error - selected_error) / max(equal_error, 1e-12),
                "selected_regret": (selected_error - oracle_error) / max(equal_error, 1e-12),
                "equal_regret": (equal_error - oracle_error) / max(equal_error, 1e-12),
                "r4_regret": (errors[R4] - oracle_error) / max(equal_error, 1e-12),
                "selected_relative_loss_vs_equal": (selected_error - equal_error) / max(equal_error, 1e-12),
                "selected_material_loss_batch": bool(selected_error > 1.02 * equal_error),
                "equal_ess_fraction": batch.mean_ess_fraction[EQUAL],
                "r2_ess_fraction": batch.mean_ess_fraction[R2],
                "r4_ess_fraction": batch.mean_ess_fraction[R4],
                "selected_ess_fraction": batch.mean_ess_fraction[decision.selected_mode],
            }
        )
    return evidence_rows, holdout_rows


def summarize_condition_level(evidence: pd.DataFrame, holdout: pd.DataFrame) -> pd.DataFrame:
    decision = (
        evidence.groupby(
            ["condition_index", "replicate_index", "population_seed", "score_condition", "target_pattern"],
            as_index=False,
        )
        .agg(
            selected_mode=("selected_mode", "first"),
            weighted_enabled=("weighted_enabled", "first"),
            gate_reason=("gate_reason", "first"),
            decision_source=("decision_source", "first"),
            pilot_association_diagnostic=("pilot_association_diagnostic", "first"),
            r4_mean_pilot_benefit=("mean_pilot_relative_benefit", lambda values: float(values.iloc[0])),
        )
    )
    # Replace the candidate-specific placeholder with explicit r=2/r=4 evidence.
    wide = evidence.pivot_table(
        index=["condition_index", "replicate_index", "population_seed", "score_condition", "target_pattern"],
        columns="candidate_mode",
        values=["mean_pilot_relative_benefit", "worst_single_pilot_relative_benefit", "minimum_pilot_ess_fraction"],
        aggfunc="first",
    )
    wide.columns = [f"{mode}_{metric}" for metric, mode in wide.columns]
    wide = wide.reset_index()
    decision = decision.drop(columns=["r4_mean_pilot_benefit"]).merge(
        wide,
        on=["condition_index", "replicate_index", "population_seed", "score_condition", "target_pattern"],
        how="left",
        validate="one_to_one",
    )
    technical = (
        holdout.groupby(
            ["condition_index", "replicate_index", "population_seed", "score_condition", "target_pattern"],
            as_index=False,
        )
        .agg(
            holdout_batches=("holdout_batch_label", "nunique"),
            equal_error=("equal_error", "mean"),
            r2_error=("r2_error", "mean"),
            r4_error=("r4_error", "mean"),
            selected_error=("selected_error", "mean"),
            oracle_error=("oracle_error", "mean"),
            selected_ess_fraction=("selected_ess_fraction", "mean"),
        )
    )
    result = decision.merge(
        technical,
        on=["condition_index", "replicate_index", "population_seed", "score_condition", "target_pattern"],
        how="inner",
        validate="one_to_one",
    )
    # The formal oracle is condition-wise: compare each method after averaging
    # the frozen holdout batches, then take the lowest of Equal, r=2, and r=4.
    result["oracle_error"] = result[["equal_error", "r2_error", "r4_error"]].min(axis=1)
    result["oracle_mode"] = result[["equal_error", "r2_error", "r4_error"]].idxmin(axis=1).map(
        {"equal_error": EQUAL, "r2_error": R2, "r4_error": R4}
    )
    result["selected_gain_vs_equal"] = (
        result["equal_error"] - result["selected_error"]
    ) / result["equal_error"].clip(lower=1e-12)
    result["selected_regret"] = (
        result["selected_error"] - result["oracle_error"]
    ) / result["equal_error"].clip(lower=1e-12)
    result["equal_regret"] = (
        result["equal_error"] - result["oracle_error"]
    ) / result["equal_error"].clip(lower=1e-12)
    result["r4_regret"] = (
        result["r4_error"] - result["oracle_error"]
    ) / result["equal_error"].clip(lower=1e-12)
    result["selected_relative_loss_vs_equal"] = (
        result["selected_error"] - result["equal_error"]
    ) / result["equal_error"].clip(lower=1e-12)
    result["material_loss"] = result["selected_error"] > 1.02 * result["equal_error"]
    return result.sort_values(["condition_index", "replicate_index"]).reset_index(drop=True)


def policy_summary(condition: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    scopes = [("all", condition)]
    scopes.extend(
        (
            f"{score_condition}_{target_pattern}",
            condition.loc[
                (condition["score_condition"] == score_condition)
                & (condition["target_pattern"] == target_pattern)
            ],
        )
        for _, score_condition, _, target_pattern in CONDITIONS
    )
    for scope, frame in scopes:
        for policy in POLICIES:
            if policy == "always_equal":
                selected_mode = pd.Series([EQUAL] * len(frame), index=frame.index)
                selected_error = frame["equal_error"]
            elif policy == "always_r4":
                selected_mode = pd.Series([R4] * len(frame), index=frame.index)
                selected_error = frame["r4_error"]
            else:
                selected_mode = frame["selected_mode"]
                selected_error = frame["selected_error"]
            regret = (selected_error - frame["oracle_error"]) / frame["equal_error"].clip(lower=1e-12)
            improvement = (frame["equal_error"] - selected_error) / frame["equal_error"].clip(lower=1e-12)
            material = selected_error > 1.02 * frame["equal_error"]
            rows.append(
                {
                    "scope": scope,
                    "policy": policy,
                    "independent_populations": int(len(frame)),
                    "equal_count": int((selected_mode == EQUAL).sum()),
                    "r2_count": int((selected_mode == R2).sum()),
                    "r4_count": int((selected_mode == R4).sum()),
                    "activation_count": int((selected_mode != EQUAL).sum()),
                    "activation_rate": float((selected_mode != EQUAL).mean()),
                    "mean_gain_vs_equal": float(improvement.mean()),
                    "median_gain_vs_equal": float(improvement.median()),
                    "mean_normalized_regret": float(regret.mean()),
                    "median_normalized_regret": float(regret.median()),
                    "maximum_normalized_regret": float(regret.max()),
                    "material_loss_count": int(material.sum()),
                    "material_loss_rate": float(material.mean()),
                }
            )
    return pd.DataFrame(rows)


def confirmation_criteria(condition: pd.DataFrame, summary: pd.DataFrame) -> tuple[dict[str, bool], pd.DataFrame]:
    final_all = summary.loc[(summary["scope"] == "all") & (summary["policy"] == "final_gate")].iloc[0]
    equal_all = summary.loc[(summary["scope"] == "all") & (summary["policy"] == "always_equal")].iloc[0]
    r4_all = summary.loc[(summary["scope"] == "all") & (summary["policy"] == "always_r4")].iloc[0]
    unrelated = condition.loc[condition["score_condition"] == "unrelated"]
    checks: dict[str, bool] = {
        "unrelated_false_activation_zero_of_60": bool((unrelated["selected_mode"] == EQUAL).all() and len(unrelated) == 60),
        "final_gate_material_loss_zero_of_180": bool((~condition["material_loss"]).all() and len(condition) == 180),
        "final_gate_mean_regret_below_always_equal": bool(final_all["mean_normalized_regret"] < equal_all["mean_normalized_regret"]),
        "final_gate_mean_regret_below_always_r4": bool(final_all["mean_normalized_regret"] < r4_all["mean_normalized_regret"]),
    }
    for score in ("proxy", "oracle_positive_control"):
        for pattern in ("clustered", "scattered"):
            frame = condition.loc[
                (condition["score_condition"] == score)
                & (condition["target_pattern"] == pattern)
            ]
            checks[f"{score}_{pattern}_mean_holdout_gain_positive"] = bool(
                len(frame) == 30 and float(frame["selected_gain_vs_equal"].mean()) > 0.0
            )
    checks["all_decisions_pilot_only"] = bool((condition["decision_source"] == "pilot_only").all())
    failures = []
    for criterion, passed in checks.items():
        if not passed:
            failures.append({"criterion": criterion, "status": "FAIL", "affected_units": "see condition-level table"})
    return checks, pd.DataFrame(failures, columns=["criterion", "status", "affected_units"])


def build_tasks(preregistration: dict[str, Any]) -> list[dict[str, Any]]:
    design = preregistration["simulation_design"]
    thresholds = preregistration["frozen_gate"]
    tasks = []
    for condition_index, score_condition, generator_alignment, target_pattern in CONDITIONS:
        for replicate_index in range(1, 31):
            tasks.append(
                {
                    "condition_index": condition_index,
                    "replicate_index": replicate_index,
                    "population_seed": 202608290000 + condition_index * 100 + replicate_index,
                    "score_condition": score_condition,
                    "generator_alignment": generator_alignment,
                    "target_pattern": target_pattern,
                    "grid_side": design["grid_side"],
                    "cells_per_stratum": design["cells_per_stratum"],
                    "rare_frequency": design["rare_frequency"],
                    "quota_per_stratum": design["quota_per_stratum"],
                    "candidate_caps": tuple(design["candidate_max_weight_inflation"]),
                    "pilot_labels": tuple(design["pilot_batch_seed_labels"]),
                    "holdout_labels": tuple(design["holdout_batch_seed_labels"]),
                    "pilot_draws_per_batch": design["pilot_draws_per_batch"],
                    "holdout_draws_per_batch": design["holdout_draws_per_batch"],
                    "seed_multiplier": design["sampling_seed_multiplier"],
                    "minimum_alignment": thresholds["minimum_pilot_association"],
                    "minimum_mean_benefit": thresholds["minimum_mean_pilot_relative_benefit"],
                    "maximum_single_pilot_loss": thresholds["maximum_single_pilot_relative_loss"],
                }
            )
    if len(tasks) != 180 or len({task["population_seed"] for task in tasks}) != 180:
        raise RuntimeError("The preregistered design must contain 180 unique populations.")
    return tasks


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--preregistration", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    preregistration_path = args.preregistration.resolve()
    output_dir = args.output_dir.resolve()
    preregistration = read_yaml(preregistration_path)
    expected_existing = {
        "preregistration.yaml",
        "preregistration.sha256",
        "frozen_gate_hashes_before.tsv",
        "git_status_before.txt",
    }
    if not output_dir.exists():
        raise FileNotFoundError("The preregistration output directory must exist before execution.")
    unexpected = {path.name for path in output_dir.iterdir()} - expected_existing
    if unexpected:
        raise FileExistsError(f"Refusing to run with unexpected pre-existing outputs: {sorted(unexpected)}")
    paths = preregistration["frozen_files"]
    gate_code = ROOT / paths["gate_code"]
    gate_config = ROOT / paths["gate_config"]
    validation_script = ROOT / paths["validation_script"]
    before = preregistration["sha256_before"]
    current_before = {
        "gate_code": sha256_file(gate_code),
        "gate_config": sha256_file(gate_config),
        "validation_script": sha256_file(validation_script),
        "preregistration": sha256_file(preregistration_path),
    }
    for label in ("gate_code", "gate_config", "validation_script"):
        if current_before[label] != before[label]:
            raise RuntimeError(f"Frozen {label} hash differs before execution.")
    if current_before["preregistration"] != (output_dir / "preregistration.sha256").read_text(encoding="utf-8").strip():
        raise RuntimeError("Preregistration hash differs before execution.")
    tasks = build_tasks(preregistration)
    evidence_rows: list[dict[str, Any]] = []
    holdout_rows: list[dict[str, Any]] = []
    workers = int(preregistration["execution"]["parallel_workers"])
    with ProcessPoolExecutor(max_workers=workers) as executor:
        for completed, (evidence, holdout) in enumerate(
            executor.map(evaluate_one_condition, tasks, chunksize=1), start=1
        ):
            evidence_rows.extend(evidence)
            holdout_rows.extend(holdout)
            if completed % 10 == 0 or completed == len(tasks):
                print(f"completed {completed}/{len(tasks)} confirmatory populations", flush=True)
    evidence = pd.DataFrame(evidence_rows)
    holdout = pd.DataFrame(holdout_rows)
    condition = summarize_condition_level(evidence, holdout)
    summary = policy_summary(condition)
    checks, failures = confirmation_criteria(condition, summary)
    after = {
        "gate_code": sha256_file(gate_code),
        "gate_config": sha256_file(gate_config),
        "validation_script": sha256_file(validation_script),
        "preregistration": sha256_file(preregistration_path),
    }
    hashes_unchanged = all(after[label] == current_before[label] for label in after)
    checks["frozen_hashes_unchanged"] = hashes_unchanged
    if not hashes_unchanged:
        failures = pd.concat(
            [
                failures,
                pd.DataFrame(
                    [{"criterion": "frozen_hashes_unchanged", "status": "FAIL", "affected_units": "all"}]
                ),
            ],
            ignore_index=True,
        )
    classification = (
        "INDEPENDENT_SIMULATION_VALIDATION_SUPPORTED"
        if all(checks.values())
        else "INDEPENDENT_SIMULATION_VALIDATION_NOT_SUPPORTED"
    )
    evidence.to_csv(output_dir / "confirmatory_simulation_pilot_evidence.tsv", sep="\t", index=False)
    holdout.to_csv(output_dir / "confirmatory_simulation_holdout_batches.tsv", sep="\t", index=False)
    condition.to_csv(output_dir / "confirmatory_simulation_condition_level.tsv", sep="\t", index=False)
    summary.to_csv(output_dir / "confirmatory_simulation_summary.tsv", sep="\t", index=False)
    failures.to_csv(output_dir / "confirmatory_simulation_failures.tsv", sep="\t", index=False)
    pd.DataFrame(
        [
            {"file_role": label, "sha256_before": current_before[label], "sha256_after": after[label], "unchanged": current_before[label] == after[label]}
            for label in current_before
        ]
    ).to_csv(output_dir / "frozen_gate_hashes_after.tsv", sep="\t", index=False)
    manifest = {
        "classification": classification,
        "criteria": checks,
        "independent_populations": int(len(condition)),
        "pilot_evidence_rows": int(len(evidence)),
        "holdout_batch_rows": int(len(holdout)),
        "thresholds_tuned_on_holdout": False,
        "holdout_used_for_selection": False,
        "hashes_unchanged": hashes_unchanged,
        "versions": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "scipy": scipy.__version__,
            "scikit_learn": sklearn.__version__,
            "pyyaml": yaml.__version__,
        },
    }
    (output_dir / "confirmatory_simulation_manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
