"""Rebuild the affected 5% retrospective gate example after 16-um input correction."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from scipy import sparse


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "results/mouse_brain_16um_input_correction_20260917"
OUT = ROOT / "results/mouse_brain_16um_gate_correction_20260917"
DATASET = "visium_hd_mouse_brain_fresh_frozen_2024"
SAMPLE = "Visium_HD_Mouse_Brain_Fresh_Frozen"
FRACTION = 0.05
SEEDS = (101, 202, 303)
PILOT_SEEDS = (101, 202)
HOLDOUT_SEED = 303
CAPS = (4.0, 2.0)
ENDPOINTS = ("gene_mean_l1_error_hajek", "gene_detection_l1_error_hajek")

sys.path.insert(0, str(ROOT / "src"))
from spaquotasketch.fixed_quota_probability import (  # noqa: E402
    EQUAL_PROBABILITY_FIXED_QUOTA,
    fixed_quota_probability_plans,
    fixed_quota_probability_selections,
    hajek_normalized_expression_fidelity,
    score_technical_diagnostics,
)
from spaquotasketch.v2_1.quota import allocate_largest_remainder_quotas  # noqa: E402
from spaquotasketch.v2_1.spatial import choose_adaptive_regular_partition  # noqa: E402


def relative_benefits(metrics: pd.DataFrame, cap: float) -> list[float]:
    equal = metrics.loc[
        (metrics["max_weight_inflation"] == cap)
        & (metrics["method"] == EQUAL_PROBABILITY_FIXED_QUOTA)
        & metrics["seed"].isin(PILOT_SEEDS)
    ].set_index("seed")
    weighted = metrics.loc[
        (metrics["max_weight_inflation"] == cap)
        & (metrics["method"] == "leverage_weighted_fixed_quota")
        & metrics["seed"].isin(PILOT_SEEDS)
    ].set_index("seed")
    values: list[float] = []
    for endpoint in ENDPOINTS:
        values.extend(((equal[endpoint] - weighted[endpoint]) / equal[endpoint]).tolist())
    return [float(value) for value in values]


def main() -> None:
    if OUT.exists():
        raise FileExistsError(f"Refusing to overwrite {OUT}")
    OUT.mkdir(parents=True)
    cache = SOURCE / "cache" / DATASET
    raw = sparse.load_npz(cache / "raw_counts_csr.npz").tocsr()
    normalized = sparse.load_npz(cache / "normalized_log1p_csr.npz").tocsr()
    embedding = np.load(cache / "embedding.npy")
    basis = np.load(cache / "basis.npy")
    coordinates = np.load(cache / "coordinates.npy")
    metadata = json.loads((cache / "cache_metadata.json").read_text(encoding="utf-8"))

    target_n = int(np.floor(raw.shape[0] * FRACTION))
    partition = choose_adaptive_regular_partition(
        coordinates, target_n, minimum_quota=1, shapes=[(10, 10)]
    )
    allocation = allocate_largest_remainder_quotas(
        partition.stratum_audit, target_n, minimum_quota=1
    )
    audit = allocation.audit.copy()
    audit.insert(0, "dataset_id", DATASET)
    audit.insert(1, "sampling_fraction", FRACTION)
    audit["grid_n_x"] = int(partition.n_x)
    audit["grid_n_y"] = int(partition.n_y)
    audit.to_csv(OUT / "spatial_quota_audit.tsv", sep="\t", index=False)

    rows: list[dict[str, object]] = []
    for cap in CAPS:
        plans = fixed_quota_probability_plans(
            expression_embedding=embedding,
            expression_basis=basis,
            spatial_strata=partition.stratum_ids,
            quotas=allocation.quotas,
            max_weight_inflation=cap,
        )
        for seed in SEEDS:
            selections = fixed_quota_probability_selections(
                expression_embedding=embedding,
                expression_basis=basis,
                spatial_strata=partition.stratum_ids,
                quotas=allocation.quotas,
                seed=seed,
                max_weight_inflation=cap,
                precomputed_pivotal_plans=plans,
            )
            for method, selection in selections.items():
                rows.append(
                    {
                        "dataset_id": DATASET,
                        "sample_id": SAMPLE,
                        "sampling_fraction": FRACTION,
                        "target_n": target_n,
                        "grid_n_x": int(partition.n_x),
                        "grid_n_y": int(partition.n_y),
                        "max_weight_inflation": cap,
                        "seed": seed,
                        "method": method,
                        **hajek_normalized_expression_fidelity(
                            normalized,
                            selection.selected_indices,
                            selection.sampling_weight,
                        ),
                        **selection.diagnostics,
                        "source_identity_sha256": metadata["source_identity_sha256"],
                    }
                )
    metrics = pd.DataFrame(rows)
    metrics.to_csv(OUT / "selection_metrics.tsv", sep="\t", index=False)

    diagnostics = {
        "dataset_id": DATASET,
        "sample_id": SAMPLE,
        "n_obs": int(raw.shape[0]),
        **score_technical_diagnostics(expression_basis=basis, raw_matrix=raw),
    }
    pd.DataFrame([diagnostics]).to_csv(OUT / "score_technical_diagnostics.tsv", sep="\t", index=False)
    alignment = min(
        float(diagnostics["score_total_counts_correlation"]),
        float(diagnostics["score_detected_features_correlation"]),
    )

    evidence_rows: list[dict[str, object]] = []
    for cap in CAPS:
        benefits = relative_benefits(metrics, cap)
        endpoint_means = []
        for endpoint in ENDPOINTS:
            equal = metrics.loc[
                (metrics["max_weight_inflation"] == cap)
                & (metrics["method"] == EQUAL_PROBABILITY_FIXED_QUOTA)
                & metrics["seed"].isin(PILOT_SEEDS)
            ].set_index("seed")
            weighted = metrics.loc[
                (metrics["max_weight_inflation"] == cap)
                & (metrics["method"] == "leverage_weighted_fixed_quota")
                & metrics["seed"].isin(PILOT_SEEDS)
            ].set_index("seed")
            endpoint_means.append(float(((equal[endpoint] - weighted[endpoint]) / equal[endpoint]).mean()))
        weighted_rows = metrics.loc[
            (metrics["max_weight_inflation"] == cap)
            & (metrics["method"] == "leverage_weighted_fixed_quota")
            & metrics["seed"].isin(PILOT_SEEDS)
        ]
        checks = {
            "alignment": alignment >= 0.20,
            "mean_benefit": float(np.mean(benefits)) >= 0.02,
            "endpoint_mean": float(min(endpoint_means)) >= 0.0,
            "worst_loss": float(min(benefits)) >= -0.02,
            "ess": float(weighted_rows["mean_selected_ess_fraction"].min()) >= 0.50,
        }
        evidence_rows.append(
            {
                "dataset_id": DATASET,
                "candidate_method": f"leverage_weighted_fixed_quota_r{int(cap)}",
                "candidate_max_weight_inflation": cap,
                "pilot_alignment": alignment,
                "minimum_pilot_ess_fraction": float(weighted_rows["mean_selected_ess_fraction"].min()),
                "mean_pilot_relative_benefit": float(np.mean(benefits)),
                "minimum_endpoint_mean_relative_benefit": float(min(endpoint_means)),
                "worst_single_pilot_relative_benefit": float(min(benefits)),
                **{f"pass_{name}": passed for name, passed in checks.items()},
                "legacy_full_gate_pass": all(checks.values()),
                "final_three_condition_gate_pass": all(checks[name] for name in ("alignment", "mean_benefit", "worst_loss")),
            }
        )
    evidence = pd.DataFrame(evidence_rows)
    evidence.to_csv(OUT / "gate_candidate_evidence.tsv", sep="\t", index=False)

    final_selection = "equal_probability_fixed_quota"
    for cap in CAPS:
        row = evidence.loc[evidence["candidate_max_weight_inflation"] == cap].iloc[0]
        if bool(row["final_three_condition_gate_pass"]):
            final_selection = f"leverage_weighted_fixed_quota_r{int(cap)}"
            break
    holdout: dict[str, float] = {}
    equal_row = metrics.loc[
        (metrics["seed"] == HOLDOUT_SEED)
        & (metrics["max_weight_inflation"] == 4.0)
        & (metrics["method"] == EQUAL_PROBABILITY_FIXED_QUOTA)
    ].iloc[0]
    holdout["equal"] = float(equal_row[list(ENDPOINTS)].mean())
    for cap in CAPS:
        row = metrics.loc[
            (metrics["seed"] == HOLDOUT_SEED)
            & (metrics["max_weight_inflation"] == cap)
            & (metrics["method"] == "leverage_weighted_fixed_quota")
        ].iloc[0]
        holdout[f"r{int(cap)}"] = float(row[list(ENDPOINTS)].mean())
    selected_key = "equal" if final_selection == EQUAL_PROBABILITY_FIXED_QUOTA else final_selection.rsplit("_r", 1)[1]
    if selected_key in {"2", "4"}:
        selected_key = f"r{selected_key}"
    selected_error = holdout[selected_key]
    example = {
        "dataset_id": DATASET,
        "sampling_fraction": FRACTION,
        "pilot_seeds": "101;202",
        "holdout_seed": HOLDOUT_SEED,
        "final_gate_selected_method": final_selection,
        "equal_composite_error": holdout["equal"],
        "r2_composite_error": holdout["r2"],
        "r4_composite_error": holdout["r4"],
        "selected_composite_error": selected_error,
        "relative_gain_vs_equal": (holdout["equal"] - selected_error) / holdout["equal"],
        "oracle_method": min(holdout, key=holdout.get),
        "oracle_composite_error": min(holdout.values()),
        "classification": "retrospective_worked_example_after_input_correction",
    }
    pd.DataFrame([example]).to_csv(OUT / "retrospective_mouse_brain_worked_example.csv", index=False)
    (OUT / "run_manifest.json").write_text(
        json.dumps(
            {
                "status": "completed_targeted_input_correction",
                "dataset_id": DATASET,
                "fractions": [FRACTION],
                "pilot_seeds": list(PILOT_SEEDS),
                "holdout_seeds": [HOLDOUT_SEED],
                "candidate_caps": list(CAPS),
                "grid": [10, 10],
                "thresholds_unchanged": True,
                "technical_seeds_are_not_independent_replicates": True,
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    print(evidence.to_string(index=False))
    print(pd.DataFrame([example]).to_string(index=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Rebuild the corrected retrospective 5% mouse-brain gate example."
    )
    parser.parse_args()
    main()
