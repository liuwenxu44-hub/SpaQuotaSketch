"""Synthetic format tests for the frozen formal raw-input adapters."""

from __future__ import annotations

import csv
from pathlib import Path
import tarfile

import h5py
import numpy as np
import pandas as pd
import pytest

from spaquotasketch.benchmark.formal_multiplatform_input_adapters import (
    FormalInputAdapterError,
    load_formal_raw_input,
    load_frozen_unit_raw_input,
    load_visium_hd_feature_slice,
    load_visium_h5_spatial_tar,
    load_xenium_h5_parquet,
    read_10x_h5_matrix,
    resolve_frozen_unit_sources,
)


def _write_10x_h5(path: Path, *, barcodes: list[str] | None = None) -> None:
    identifiers = barcodes or ["cell_a", "cell_b", "cell_c"]
    # Two genes by three observations in CSC form.
    with h5py.File(path, "w") as handle:
        matrix = handle.create_group("matrix")
        matrix.create_dataset("shape", data=np.asarray([2, len(identifiers)], dtype=np.int64))
        matrix.create_dataset("barcodes", data=np.asarray(identifiers, dtype="S"))
        matrix.create_dataset("data", data=np.asarray([1, 3, 2, 4], dtype=np.int64))
        matrix.create_dataset("indices", data=np.asarray([0, 1, 0, 1], dtype=np.int32))
        matrix.create_dataset("indptr", data=np.asarray([0, 2, 3, 4], dtype=np.int64))
        features = matrix.create_group("features")
        features.create_dataset("id", data=np.asarray(["gene_1", "gene_2"], dtype="S"))


def _write_cells_parquet(path: Path, *, identifiers: list[str] | None = None) -> None:
    ids = identifiers or ["cell_a", "cell_b", "cell_c"]
    pd.DataFrame(
        {"cell_id": ids, "x_centroid": [20.0, 10.0, 30.0], "y_centroid": [2.0, 1.0, 3.0]}
    ).to_parquet(path, index=False)


def _write_spatial_tar(path: Path, *, identifiers: list[str] | None = None) -> None:
    ids = identifiers or ["cell_a", "cell_b", "cell_c"]
    source = path.parent / "tissue_positions.csv"
    with source.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["barcode", "in_tissue", "array_row", "array_col", "pxl_row_in_fullres", "pxl_col_in_fullres"])
        writer.writerows([[identifier, 1, 0, index, 100 + index, 200 + index] for index, identifier in enumerate(ids)])
    with tarfile.open(path, "w:gz") as archive:
        archive.add(source, arcname="spatial/tissue_positions.csv")
    source.unlink()


def _write_hd_feature_slice(path: Path) -> None:
    with h5py.File(path, "w") as handle:
        features = handle.create_group("features")
        features.create_dataset("id", data=np.asarray(["gene_1", "gene_2"], dtype="S"))
        mask = handle.create_group("masks").create_group("square_016um")
        mask.create_dataset("row", data=np.asarray([0, 1, 0, 1], dtype=np.int32))
        mask.create_dataset("col", data=np.asarray([0, 0, 1, 1], dtype=np.int32))
        slices = handle.create_group("feature_slices")
        first = slices.create_group("0")
        first.create_dataset("row", data=np.asarray([0, 1, 8, 15, 16], dtype=np.int32))
        first.create_dataset("col", data=np.asarray([0, 1, 0, 15, 16], dtype=np.int32))
        first.create_dataset("data", data=np.asarray([1, 2, 3, 4, 99], dtype=np.int32))
        second = slices.create_group("1")
        second.create_dataset("row", data=np.asarray([0, 7, 8], dtype=np.int32))
        second.create_dataset("col", data=np.asarray([8, 15, 8], dtype=np.int32))
        second.create_dataset("data", data=np.asarray([5, 6, 7], dtype=np.int32))


def test_read_10x_h5_matrix_preserves_observation_orientation(tmp_path: Path) -> None:
    path = tmp_path / "matrix.h5"
    _write_10x_h5(path)
    ids, matrix = read_10x_h5_matrix(path)
    assert ids.tolist() == ["cell_a", "cell_b", "cell_c"]
    assert matrix.toarray().tolist() == [[1, 3], [2, 0], [0, 4]]


def test_xenium_adapter_aligns_parquet_coordinates_to_matrix_order(tmp_path: Path) -> None:
    matrix, coordinates = tmp_path / "matrix.h5", tmp_path / "cells.parquet"
    _write_10x_h5(matrix)
    _write_cells_parquet(coordinates, identifiers=["cell_b", "cell_a", "cell_c"])
    result = load_xenium_h5_parquet(matrix, coordinates)
    assert result.adapter_id == "xenium_h5_parquet"
    assert result.cell_ids.tolist() == ["cell_a", "cell_b", "cell_c"]
    assert result.coordinates.tolist() == [[10.0, 1.0], [20.0, 2.0], [30.0, 3.0]]
    assert result.expression_matrix.shape == (3, 2)


def test_visium_adapter_reads_coordinates_from_archived_tissue_positions(tmp_path: Path) -> None:
    matrix, spatial = tmp_path / "matrix.h5", tmp_path / "spatial.tar.gz"
    _write_10x_h5(matrix)
    _write_spatial_tar(spatial)
    result = load_visium_h5_spatial_tar(matrix, spatial)
    assert result.adapter_id == "visium_h5_spatial_tar"
    assert result.coordinates.tolist() == [[200.0, 100.0], [201.0, 101.0], [202.0, 102.0]]


def test_visium_hd_adapter_bins_native_coordinates_and_discards_outside_mask(tmp_path: Path) -> None:
    path = tmp_path / "feature_slice.h5"
    _write_hd_feature_slice(path)
    result = load_visium_hd_feature_slice(path)
    assert result.adapter_id == "visium_hd_feature_slice"
    assert result.cell_ids.tolist() == ["0:0", "1:0", "0:1", "1:1"]
    assert result.coordinates.tolist() == [[0.0, 0.0], [0.0, 1.0], [1.0, 0.0], [1.0, 1.0]]
    assert result.expression_matrix.toarray().tolist() == [[3, 0], [3, 0], [0, 11], [4, 7]]


@pytest.mark.parametrize(
    ("adapter_id", "filenames"),
    [
        ("xenium_h5_parquet", ("matrix.h5", "cells.parquet")),
        ("visium_h5_spatial_tar", ("matrix.h5", "spatial.tar.gz")),
        ("visium_hd_feature_slice", ("feature_slice.h5",)),
    ],
)
def test_dispatcher_only_accepts_the_three_frozen_adapters(tmp_path: Path, adapter_id: str, filenames: tuple[str, ...]) -> None:
    matrix = tmp_path / "matrix.h5"
    _write_10x_h5(matrix)
    if adapter_id == "xenium_h5_parquet":
        _write_cells_parquet(tmp_path / "cells.parquet")
    elif adapter_id == "visium_h5_spatial_tar":
        _write_spatial_tar(tmp_path / "spatial.tar.gz")
    else:
        hd = tmp_path / "feature_slice.h5"
        _write_hd_feature_slice(hd)
    result = load_formal_raw_input(adapter_id=adapter_id, source_files=[tmp_path / name for name in filenames])
    assert result.adapter_id == adapter_id
    assert result.source_identity_sha256


def test_missing_coordinate_identifier_is_rejected_without_sampling(tmp_path: Path) -> None:
    matrix, coordinates = tmp_path / "matrix.h5", tmp_path / "cells.parquet"
    _write_10x_h5(matrix)
    _write_cells_parquet(coordinates, identifiers=["cell_a", "cell_b", "other"])
    with pytest.raises(FormalInputAdapterError, match="no spatial coordinate"):
        load_xenium_h5_parquet(matrix, coordinates)


def test_duplicate_coordinate_identifier_is_rejected(tmp_path: Path) -> None:
    matrix, coordinates = tmp_path / "matrix.h5", tmp_path / "cells.parquet"
    _write_10x_h5(matrix)
    _write_cells_parquet(coordinates, identifiers=["cell_a", "cell_a", "cell_c"])
    with pytest.raises(FormalInputAdapterError, match="duplicated"):
        load_xenium_h5_parquet(matrix, coordinates)


def test_unknown_adapter_is_refused(tmp_path: Path) -> None:
    with pytest.raises(FormalInputAdapterError, match="Unsupported"):
        load_formal_raw_input(adapter_id="unknown", source_files=[tmp_path / "unused.h5"])


def test_source_identity_hash_detects_a_nonstructural_input_change(tmp_path: Path) -> None:
    matrix, coordinates = tmp_path / "matrix.h5", tmp_path / "cells.parquet"
    _write_10x_h5(matrix)
    _write_cells_parquet(coordinates)
    first = load_xenium_h5_parquet(matrix, coordinates)
    with h5py.File(matrix, "r+") as handle:
        handle["matrix"]["data"][0] = 9
    second = load_xenium_h5_parquet(matrix, coordinates)
    assert first.source_identity_sha256 != second.source_identity_sha256


def test_frozen_unit_source_resolution_refuses_unfrozen_paths_or_adapter(tmp_path: Path) -> None:
    folder = tmp_path / "xenium"
    folder.mkdir()
    _write_10x_h5(folder / "matrix.h5")
    _write_cells_parquet(folder / "cells.parquet")
    freeze = {
        "datasets": [
            {
                "dataset_id": "dataset_a",
                "frozen_sample_ids": ["sample_a"],
                "adapter_id": "xenium_h5_parquet",
                "input_file_relative_paths": ["xenium/matrix.h5", "xenium/cells.parquet"],
            }
        ]
    }
    unit = {"dataset_id": "dataset_a", "sample_id": "sample_a", "adapter": "xenium_h5_parquet"}
    adapter, sources = resolve_frozen_unit_sources(execution_unit=unit, dataset_freeze=freeze, data_root=tmp_path)
    assert adapter == "xenium_h5_parquet"
    assert [path.name for path in sources] == ["matrix.h5", "cells.parquet"]
    result = load_frozen_unit_raw_input(execution_unit=unit, dataset_freeze=freeze, data_root=tmp_path)
    assert result.n_obs == 3
    changed = dict(unit, adapter="visium_h5_spatial_tar")
    with pytest.raises(FormalInputAdapterError, match="does not match"):
        resolve_frozen_unit_sources(execution_unit=changed, dataset_freeze=freeze, data_root=tmp_path)


def test_raw_input_adapter_is_read_only_and_has_no_sampler_dependency() -> None:
    source = (Path(__file__).resolve().parents[1] / "src" / "spaquotasketch" / "benchmark" / "formal_multiplatform_input_adapters.py").read_text(encoding="utf-8")
    assert "run_registered_r2_method" not in source
    assert "spaquotasketch.samplers" not in source
    assert "result_storage" not in source
