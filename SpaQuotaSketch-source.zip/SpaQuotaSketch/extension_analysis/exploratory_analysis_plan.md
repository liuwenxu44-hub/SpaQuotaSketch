# Frozen plan for the mechanism and cost extension

## Status and scope

This plan was saved before the new explanatory metric or performance results were calculated.  The explanatory analysis is retrospective and exploratory.  It does not change the frozen endpoints, sampling fractions, methods, thresholds, input set, or formal efficacy results, and it is not an independent validation or a causal analysis.

## Formal-result source and version check

- Formal result source: the corrected method- and endpoint-level tables in the accepted repair package and their retained project source tables.
- Required version check, recalculated from the source table before analysis: 240 method-endpoint records, 120 paired records, Equal/SRS wins 77/43, mean relative benefit 3.14%, and median relative benefit 1.54% after display rounding.
- The mouse-brain cache must be the repaired 16 micrometre input whose raw integer matrix passed the independent official-reference comparison.

## Primary explanatory metric

For each dataset and sampling fraction, use the frozen spatial strata for that condition and the same eight-nearest-neighbour expression graph used by the formal Equal sampler.  Within every eligible stratum, compare:

1. the mean per-gene absolute target difference over graph edges; and
2. the corresponding mean over uniformly generated within-stratum random pairs.

The primary explanatory ratio is graph-edge mean difference divided by random-pair mean difference.  It is calculated separately for the normalized log-expression matrix and the binary indicator of raw count greater than zero.  A smaller ratio indicates greater local similarity of the relevant target values, but it does not imply or guarantee a smaller sampling error.

The graph is built from the saved 30-dimensional expression embedding, using the formal eight-neighbour definition independently within each frozen spatial stratum.  A graph edge is an undirected unique pair.  Strata with quotas of zero, quotas equal to the stratum population, or fewer than two observations contribute no formal pivotal edge and are excluded.  The analysis records their counts.

## Distance, weighting and zero denominators

- Pair distance: mean absolute difference across all retained genes.  The ratio is unchanged if the unnormalised sum is used, but the exported table reports the per-gene scale.
- Stratum weighting: each stratum mean is weighted by its full number of formal graph edges.  Thus the dataset-level numerator estimates the mean over the full formal edge population rather than giving equal weight to differently sized strata.
- Random comparison: the same number of diagnostic random pairs as retained graph edges is generated within each stratum, with replacement across pairs and rejection of self-pairs.  Its stratum means use the same full-edge-count weights.
- Zero denominator: if the weighted random-pair mean is zero, the ratio is reported as missing with an explicit flag; no constant is added.

## Diagnostic edge limit and seed

- Diagnostic seed: 2026091901.
- Maximum retained graph edges per dataset-by-fraction condition: 50,000.
- If a condition has more graph edges, seeded reservoir sampling is applied once to the concatenated full edge population.  Every formal graph edge therefore has the same retention probability, and the expected retained contribution of each stratum is proportional to its full edge count.  The realised stratum coverage is recorded.
- Sparse matrices remain sparse.  Pair distances are evaluated in batches of at most 512 pairs; the full gene-by-observation matrix is never converted to dense form.
- This diagnostic subsampling estimates an explanatory summary only and is not a new formal sampling experiment.

## Benefit summary and descriptive association

For every dataset, fraction and endpoint, calculate the mean, median, standard deviation, interquartile range, minimum and maximum of the five technical-seed relative benefits from the accepted formal paired table.  The two endpoints remain separate.  Technical seeds are repeated algorithmic draws, not biological replicates.

The compact figure places the corresponding explanatory ratio against mean relative benefit.  Spearman coefficients may be reported only as descriptive summaries across the 12 dataset-by-fraction conditions, with and without the renal dataset.  No p value, confidence interval, regression model or independent-observation claim will be made.  If the pattern is unclear or changes materially when the renal dataset is removed, the report will say that the metric does not provide a stable explanation.

## Performance-test plan

- Machine: the current local machine only; operating system, processor, logical cores, installed memory, Python and package versions, and thread settings are captured before timing.
- Threads: numerical-library thread variables are fixed to one for each timed child process.
- Performance seeds: 2026091902, 2026091903 and 2026091904, fixed before timing and different from the formal efficacy seeds.
- Inputs: the same four full cached inputs and the repaired mouse-brain cache.  No input is downsampled.
- One-time stages, measured once per dataset: cached raw-matrix and coordinate reading; normalized log transformation plus rank-30 truncated SVD; and expression-neighbour plan construction for each fraction.  Single measurements are labelled as such.
- Repeated stages, measured in three independent child processes for each dataset, fraction and method: SRS sampling, Equal sampling using a prebuilt cached plan, and endpoint evaluation.  Performance outputs are stored only under `extension_analysis`.
- Peak resident memory is the maximum process resident set size sampled by a parent monitor.  Stage peaks are reported separately and are not added.
- The full-run estimate combines measured one-time and repeated stage medians with clearly stated boundaries.  Cached incremental sampling is reported from the repeated sampling and evaluation stages.  Amortized cost for `m` repeated samples is calculated as `(one-time shared cost + Equal-only graph cost + m × Equal repeated cost) / m`; it is labelled as calculated, not directly timed.
- Resource limit: one timed child process at a time, at most 12 GB observed resident memory and 45 minutes per one-time preprocessing process.  Any exceeded or unavailable condition is marked unmeasured rather than replaced by a smaller input.
