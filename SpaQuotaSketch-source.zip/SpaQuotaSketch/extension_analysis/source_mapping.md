# Source mapping

## Accepted formal results

- Corrected paired method–endpoint table: `C:\Work\SpaQuotaSketch\manuscript\expert_feedback_revision_v1\source_data\corrected_paired_endpoint_results.csv`
- SHA256: `a12588fa22fbc29dd8679a6d0961e3a7d93efebd30834c6235e60882f2325778`
- Version check derived from that table: `source_data/formal_result_version_check.json`
- No performance-test output was written into this table or any accepted formal result directory.

## Exploratory local-similarity analysis

- Frozen plan: `exploratory_analysis_plan.md`
- Script: `scripts/run_exploratory_similarity.py`
- Input matrices, spatial strata and saved embeddings: the accepted repair package and retained caches enumerated by the script and its run summary.
- Corrected mouse-brain retained cache: `C:\Work\SpaQuotaSketch\results\mouse_brain_16um_input_correction_20260917`
- Main metric table: `source_data/exploratory_local_similarity_metrics.csv`
- Graph-level analysis units: `source_data/exploratory_metric_benefit_analysis_units.csv`
- Edge coverage: `source_data/exploratory_edge_sampling_coverage.csv`
- Formal-benefit summaries: `source_data/formal_benefit_by_condition_endpoint.csv`
- Figure: `figures/S3_Fig_exploratory_local_similarity.*`

## Computational-cost evaluation

- Measurement script: `scripts/benchmark_costs.py`
- Summarization and figure script: `scripts/summarize_performance.py`
- Hardware/software/thread settings: `performance_environment.json` and `performance_environment.md`
- Per-process logs: `logs/performance_processes/*.json`
- All measured stage records: `source_data/performance_run_records.csv`
- Condition summaries: `source_data/performance_condition_costs.csv`
- Calculated amortization: `source_data/performance_amortized_costs.csv`
- Figure: `figures/S4_Fig_computational_cost.*`

## Manuscript integration

- Editing script: `scripts/update_documents.py`
- Revised main document: `..\manuscript_plos_one.docx`
- Revised supplementary methods: `..\supporting_information\S1_Text.docx`
- Actual Word-rendered PDFs: `..\manuscript_plos_one_rendered.pdf` and `..\supporting_information\S1_Text.pdf`
