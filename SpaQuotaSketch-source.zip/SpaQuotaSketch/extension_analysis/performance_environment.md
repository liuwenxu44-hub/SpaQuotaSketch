# Performance environment and timing boundaries

- Operating system: Windows 11, build 26100.
- Processor: Intel Core i5-12600K; 10 physical cores and 16 logical processors.
- Installed memory: 34,031,325,184 bytes.
- Python: 3.14.5, 64-bit.
- Core packages: NumPy 2.4.6; SciPy 1.17.1; pandas 2.3.3; scikit-learn 1.8.0; anndata 0.12.19; psutil 7.2.2; matplotlib 3.10.9.
- Thread limits: `OMP_NUM_THREADS=1`, `OPENBLAS_NUM_THREADS=1`, `MKL_NUM_THREADS=1`, and `NUMEXPR_NUM_THREADS=1` for every timed worker.
- Wall time: `time.perf_counter()` around each declared stage in a fresh worker process.
- Peak memory: resident set size of the timed worker sampled every 0.02 seconds.  Timed workers created no child processes.
- File-cache state: the operating-system cache was not flushed.  Measurements therefore describe ordinary repeated local access, not controlled cold-disk performance.
- One-time stages: data read, normalized-log transformation, rank-30 truncated SVD, spatial strata and quotas, and Equal's expression-neighbour plan.  Normalization is shared because both methods' endpoints require normalized expression; SVD and neighbour-plan construction are Equal-only.
- Repeated stages: method draw and two-endpoint evaluation.  Three fresh processes were used per dataset, fraction and method with seeds 2026091902–2026091904.
- Full-run and amortized values: calculated by adding measured stage values.  They were not directly timed as whole processes.  Peak resident memories are stage maxima and are not added.

