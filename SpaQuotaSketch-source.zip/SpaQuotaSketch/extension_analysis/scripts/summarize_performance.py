"""Summarize finite performance measurements and draw the cost supplement."""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(r"C:\Users\dell\Desktop\manuscript_mechanism_cost_extension_v1")
ANALYSIS = ROOT / "extension_analysis"
SOURCE = ANALYSIS / "source_data"
FIGURES = ANALYSIS / "figures"
RUNS = SOURCE / "performance_run_records.csv"
DATASETS = (
    "visium_cytassist_human_breast_cancer_2023",
    "visium_hd_mouse_brain_fresh_frozen_2024",
    "xenium_human_brain_alzheimers_2023",
    "xenium_human_renal_cell_carcinoma_2025",
)
SHORT = {
    DATASETS[0]: "Breast",
    DATASETS[1]: "Mouse brain",
    DATASETS[2]: "Human brain",
    DATASETS[3]: "Renal",
}


def value(frame, dataset, phase, fraction=None, method=None, statistic="median"):
    selected = frame[(frame.dataset_id == dataset) & (frame.phase == phase)]
    if fraction is not None:
        selected = selected[np.isclose(selected.fraction.astype(float), fraction)]
    if method is not None:
        selected = selected[selected.method == method]
    series = selected.wall_seconds.astype(float)
    if series.empty:
        raise RuntimeError(f"Missing timing value: {dataset}, {phase}, {fraction}, {method}")
    return float(getattr(series, statistic)())


def peak(frame, dataset, phases, fraction=None, method=None):
    selected = frame[(frame.dataset_id == dataset) & frame.phase.isin(phases)]
    if fraction is not None:
        selected = selected[np.isclose(selected.fraction.astype(float), fraction)]
    if method is not None:
        selected = selected[selected.method == method]
    if selected.empty:
        raise RuntimeError(f"Missing peak value: {dataset}, {phases}, {fraction}, {method}")
    medians = selected.groupby("phase").peak_rss_mb.median()
    return float(medians.max())


def main():
    runs = pd.read_csv(RUNS)
    expected = {
        "data_read": 4,
        "normalization_log1p": 4,
        "rank30_svd_equal_only": 4,
        "spatial_strata_and_quota": 12,
        "expression_neighbor_graph_equal_only": 12,
        "cached_sampling": 72,
        "endpoint_evaluation": 72,
    }
    observed = runs.groupby("phase").size().to_dict()
    if observed != expected:
        raise RuntimeError(f"Performance record count mismatch: {observed}")
    repeated = runs[runs.phase.isin(["cached_sampling", "endpoint_evaluation"])]
    repeat_counts = repeated.groupby(["dataset_id", "fraction", "method", "phase"]).size()
    if not (repeat_counts == 3).all():
        raise RuntimeError("Every repeated performance condition must contain three processes")

    stage_summary = (
        runs.groupby(["dataset_id", "dataset_label", "fraction", "method", "phase"], dropna=False)
        .agg(
            process_count=("wall_seconds", "size"),
            wall_seconds_mean=("wall_seconds", "mean"),
            wall_seconds_median=("wall_seconds", "median"),
            wall_seconds_min=("wall_seconds", "min"),
            wall_seconds_max=("wall_seconds", "max"),
            peak_rss_mb_median=("peak_rss_mb", "median"),
            peak_rss_mb_max=("peak_rss_mb", "max"),
        )
        .reset_index()
    )
    stage_summary.to_csv(SOURCE / "performance_stage_costs.csv", index=False)

    conditions = []
    amortized = []
    for dataset in DATASETS:
        read = value(runs, dataset, "data_read")
        normalize = value(runs, dataset, "normalization_log1p")
        svd = value(runs, dataset, "rank30_svd_equal_only")
        for fraction in (0.02, 0.05, 0.10):
            spatial = value(runs, dataset, "spatial_strata_and_quota", fraction=fraction)
            graph = value(runs, dataset, "expression_neighbor_graph_equal_only", fraction=fraction)
            srs_sample = value(runs, dataset, "cached_sampling", fraction=fraction, method="SRS")
            srs_eval = value(runs, dataset, "endpoint_evaluation", fraction=fraction, method="SRS")
            equal_sample = value(runs, dataset, "cached_sampling", fraction=fraction, method="Equal")
            equal_eval = value(runs, dataset, "endpoint_evaluation", fraction=fraction, method="Equal")
            srs_cached = srs_sample + srs_eval
            equal_cached = equal_sample + equal_eval
            common = read + normalize + spatial
            srs_full = common + srs_cached
            equal_full = common + svd + graph + equal_cached
            srs_cached_peak = peak(
                runs, dataset, ["cached_sampling", "endpoint_evaluation"], fraction, "SRS"
            )
            equal_cached_peak = peak(
                runs, dataset, ["cached_sampling", "endpoint_evaluation"], fraction, "Equal"
            )
            srs_full_peak = max(
                peak(runs, dataset, ["data_read", "normalization_log1p"]),
                peak(runs, dataset, ["spatial_strata_and_quota"], fraction),
                srs_cached_peak,
            )
            equal_full_peak = max(
                peak(runs, dataset, ["data_read", "normalization_log1p", "rank30_svd_equal_only"]),
                peak(runs, dataset, ["spatial_strata_and_quota"], fraction),
                peak(runs, dataset, ["expression_neighbor_graph_equal_only"], fraction, "Equal"),
                equal_cached_peak,
            )
            row = {
                "dataset_id": dataset,
                "dataset_label": SHORT[dataset],
                "fraction": fraction,
                "data_read_seconds_single_measurement": read,
                "normalization_seconds_single_measurement": normalize,
                "rank30_svd_seconds_equal_only_single_measurement": svd,
                "spatial_quota_seconds_single_measurement": spatial,
                "neighbor_graph_seconds_equal_only_single_measurement": graph,
                "srs_cached_sampling_seconds_median_of_3": srs_sample,
                "equal_cached_sampling_seconds_median_of_3": equal_sample,
                "srs_endpoint_evaluation_seconds_median_of_3": srs_eval,
                "equal_endpoint_evaluation_seconds_median_of_3": equal_eval,
                "srs_cached_incremental_seconds": srs_cached,
                "equal_cached_incremental_seconds": equal_cached,
                "equal_minus_srs_cached_incremental_seconds": equal_cached - srs_cached,
                "equal_to_srs_cached_incremental_time_ratio": equal_cached / srs_cached,
                "srs_full_run_estimated_seconds": srs_full,
                "equal_full_run_estimated_seconds": equal_full,
                "equal_minus_srs_full_run_estimated_seconds": equal_full - srs_full,
                "equal_to_srs_full_run_estimated_time_ratio": equal_full / srs_full,
                "srs_cached_peak_rss_mb": srs_cached_peak,
                "equal_cached_peak_rss_mb": equal_cached_peak,
                "equal_to_srs_cached_peak_rss_ratio": equal_cached_peak / srs_cached_peak,
                "srs_full_run_stage_max_peak_rss_mb": srs_full_peak,
                "equal_full_run_stage_max_peak_rss_mb": equal_full_peak,
                "equal_to_srs_full_run_stage_max_peak_rss_ratio": equal_full_peak / srs_full_peak,
                "full_run_values_are_stage_sum_estimates": True,
                "peak_memory_values_are_stage_maxima_not_sums": True,
            }
            conditions.append(row)
            for draws in (1, 5, 20):
                amortized.append(
                    {
                        "dataset_id": dataset,
                        "dataset_label": SHORT[dataset],
                        "fraction": fraction,
                        "repeated_draw_count_m": draws,
                        "srs_amortized_seconds_per_draw": (common + draws * srs_cached) / draws,
                        "equal_amortized_seconds_per_draw": (
                            common + svd + graph + draws * equal_cached
                        ) / draws,
                        "equal_to_srs_amortized_time_ratio": (
                            (common + svd + graph + draws * equal_cached)
                            / (common + draws * srs_cached)
                        ),
                        "formula": "(one-time method costs + m * cached repeated cost) / m",
                        "measurement_status": "calculated_from_measured_stage_values_not_directly_timed",
                    }
                )
    conditions = pd.DataFrame(conditions)
    amortized = pd.DataFrame(amortized)
    conditions.to_csv(SOURCE / "performance_condition_costs.csv", index=False)
    amortized.to_csv(SOURCE / "performance_amortized_costs.csv", index=False)

    summary = {
        "measured_processes": 88,
        "measured_stage_records": int(len(runs)),
        "cached_incremental_time_ratio_median": float(
            conditions.equal_to_srs_cached_incremental_time_ratio.median()
        ),
        "cached_incremental_time_ratio_range": [
            float(conditions.equal_to_srs_cached_incremental_time_ratio.min()),
            float(conditions.equal_to_srs_cached_incremental_time_ratio.max()),
        ],
        "cached_peak_rss_ratio_median": float(
            conditions.equal_to_srs_cached_peak_rss_ratio.median()
        ),
        "cached_peak_rss_ratio_range": [
            float(conditions.equal_to_srs_cached_peak_rss_ratio.min()),
            float(conditions.equal_to_srs_cached_peak_rss_ratio.max()),
        ],
        "full_run_estimated_time_ratio_median": float(
            conditions.equal_to_srs_full_run_estimated_time_ratio.median()
        ),
        "full_run_estimated_time_ratio_range": [
            float(conditions.equal_to_srs_full_run_estimated_time_ratio.min()),
            float(conditions.equal_to_srs_full_run_estimated_time_ratio.max()),
        ],
        "largest_observed_stage_peak_rss_mb": float(runs.peak_rss_mb.max()),
        "one_time_preprocessing_repetitions_per_dataset": 1,
        "repeated_processes_per_dataset_fraction_method": 3,
    }
    (ANALYSIS / "performance_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    draw_figure(conditions)
    print(json.dumps(summary, indent=2))


def draw_figure(conditions):
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
            "font.size": 7,
            "axes.titlesize": 8,
            "axes.labelsize": 7,
            "xtick.labelsize": 6.3,
            "ytick.labelsize": 6.3,
            "legend.fontsize": 6.2,
            "axes.linewidth": 0.8,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
        }
    )
    colors = {
        DATASETS[0]: "#4C78A8",
        DATASETS[1]: "#72B7B2",
        DATASETS[2]: "#9C755F",
        DATASETS[3]: "#E07B39",
    }
    markers = {0.02: "o", 0.05: "s", 0.10: "^"}
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.05), constrained_layout=True)
    axis = axes[0]
    labels = []
    positions = np.arange(len(conditions))
    svd = conditions.rank30_svd_seconds_equal_only_single_measurement.to_numpy()
    graph = conditions.neighbor_graph_seconds_equal_only_single_measurement.to_numpy()
    if np.any(svd + graph <= 0):
        raise ValueError("The cost panel requires strictly positive measured stage times.")
    bar_colors = [colors[item] for item in conditions.dataset_id]
    axis.bar(positions, svd, color="#BDBDBD", label="Rank-30 SVD")
    axis.bar(positions, graph, bottom=svd, color="#377EB8", label="Neighbour graph")
    for row in conditions.itertuples():
        labels.append(f"{SHORT[row.dataset_id]}\n{int(row.fraction*100)}%")
    axis.set_ylim(bottom=0)
    axis.set_xticks(positions, labels, rotation=45, ha="right")
    axis.set_ylabel("Measured Equal-only time (s)")
    axis.set_title("One-time Equal-only stages", loc="left", fontweight="bold")
    axis.text(-0.11, 1.04, "A", transform=axis.transAxes, fontsize=9, fontweight="bold")
    axis.legend(loc="upper left")

    axis = axes[1]
    for row in conditions.itertuples():
        axis.scatter(
            row.equal_to_srs_cached_incremental_time_ratio,
            row.equal_to_srs_cached_peak_rss_ratio,
            color=colors[row.dataset_id],
            marker=markers[float(row.fraction)],
            s=38,
            edgecolor="white",
            linewidth=0.5,
        )
    axis.axvline(1, color="#777777", linestyle="--", linewidth=0.7)
    axis.axhline(1, color="#777777", linestyle="--", linewidth=0.7)
    axis.set_xlabel("Cached Equal/SRS time ratio")
    axis.set_ylabel("Cached Equal/SRS peak RSS ratio")
    axis.set_title("Repeated sampling with shared inputs cached", loc="left", fontweight="bold")
    axis.text(-0.11, 1.04, "B", transform=axis.transAxes, fontsize=9, fontweight="bold")
    dataset_handles = [
        plt.Line2D([0], [0], marker="o", color=colors[item], linestyle="none", markersize=4, label=SHORT[item])
        for item in DATASETS
    ]
    fraction_handles = [
        plt.Line2D([0], [0], marker=markers[item], color="#444444", linestyle="none", markersize=4, label=f"{int(item*100)}%")
        for item in (0.02, 0.05, 0.10)
    ]
    fig.legend(
        handles=dataset_handles + fraction_handles,
        loc="outside lower center",
        ncol=7,
        frameon=False,
        bbox_to_anchor=(0.5, -0.04),
    )
    stem = FIGURES / "S4_Fig_computational_cost"
    fig.savefig(stem.with_suffix(".svg"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".png"), dpi=300, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()
