"""Finite same-machine performance measurements for SRS and Equal.

The worker modes never write formal efficacy results.  The orchestration mode
launches every measurement in a fresh process and stores acceptance-only timing
records under extension_analysis.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
import json
import os
import platform
import subprocess
import sys
import threading
import time
from pathlib import Path

import numpy as np
import pandas as pd
import psutil
from scipy import sparse


OUTPUT_ROOT = Path(r"C:\Users\dell\Desktop\manuscript_mechanism_cost_extension_v1")
ANALYSIS_ROOT = OUTPUT_ROOT / "extension_analysis"
SOURCE_DIR = ANALYSIS_ROOT / "source_data"
LOG_DIR = ANALYSIS_ROOT / "logs" / "performance_processes"
FIGURE_DIR = ANALYSIS_ROOT / "figures"
PROJECT_ROOT = Path(r"C:\Work\SpaQuotaSketch")
CORE_ROOT = PROJECT_ROOT / "results" / "core_direct_comparison_reproduction_20260909"
MOUSE_ROOT = PROJECT_ROOT / "results" / "mouse_brain_16um_input_correction_20260917"
PROJECT_SRC = PROJECT_ROOT / "src"
DATASETS = (
    "visium_cytassist_human_breast_cancer_2023",
    "visium_hd_mouse_brain_fresh_frozen_2024",
    "xenium_human_brain_alzheimers_2023",
    "xenium_human_renal_cell_carcinoma_2025",
)
DISPLAY = {
    DATASETS[0]: "Breast Visium",
    DATASETS[1]: "Mouse brain Visium HD",
    DATASETS[2]: "Human brain Xenium",
    DATASETS[3]: "Renal cancer Xenium",
}
FRACTIONS = (0.02, 0.05, 0.10)
SEEDS = (2026091902, 2026091903, 2026091904)
THREAD_ENV = {
    "OMP_NUM_THREADS": "1",
    "OPENBLAS_NUM_THREADS": "1",
    "MKL_NUM_THREADS": "1",
    "NUMEXPR_NUM_THREADS": "1",
}


def cache_root(dataset_id: str) -> Path:
    base = MOUSE_ROOT if dataset_id == DATASETS[1] else CORE_ROOT
    return base / "cache" / dataset_id


def design_root(dataset_id: str) -> Path:
    base = MOUSE_ROOT if dataset_id == DATASETS[1] else CORE_ROOT
    return base / "unit_details" / dataset_id


def target_n(dataset_id: str, fraction: float) -> int:
    design = np.load(
        design_root(dataset_id) / f"{int(round(100*fraction)):02d}pct" / "design.npz",
        allow_pickle=False,
    )
    return int(round(float(design["direct_inclusion_probability"].sum())))


class PeakRSS:
    def __init__(self):
        self.process = psutil.Process(os.getpid())
        self.peak = self.process.memory_info().rss
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def _run(self):
        while not self._stop.wait(0.02):
            try:
                self.peak = max(self.peak, self.process.memory_info().rss)
            except psutil.Error:
                return

    def start(self):
        self.peak = self.process.memory_info().rss
        self._thread.start()
        return self

    def reset(self):
        self.peak = self.process.memory_info().rss

    def value_mb(self):
        self.peak = max(self.peak, self.process.memory_info().rss)
        return self.peak / (1024 * 1024)

    def close(self):
        self._stop.set()
        self._thread.join(timeout=1)


def base_record(dataset_id, phase, seconds, peak_mb, **extra):
    row = {
        "record_type": "measured",
        "dataset_id": dataset_id,
        "dataset_label": DISPLAY[dataset_id],
        "fraction": extra.pop("fraction", ""),
        "method": extra.pop("method", ""),
        "performance_seed": extra.pop("performance_seed", ""),
        "replicate": extra.pop("replicate", ""),
        "phase": phase,
        "wall_seconds": float(seconds),
        "peak_rss_mb": float(peak_mb),
        "threads": 1,
        "cache_state": extra.pop("cache_state", "OS cache not flushed; ordinary local reuse state"),
    }
    row.update(extra)
    return row


def load_design(dataset_id, fraction):
    label = f"{int(round(100*fraction)):02d}pct"
    root = design_root(dataset_id) / label
    design = np.load(root / "design.npz", allow_pickle=False)
    quotas_frame = pd.read_csv(root / "quota_audit.csv")
    quotas = dict(zip(quotas_frame["spatial_stratum"].astype(str), quotas_frame["q_g"].astype(int)))
    return np.asarray(design["spatial_strata"], dtype=str), quotas


def worker_preprocess(dataset_id):
    sys.path.insert(0, str(PROJECT_SRC))
    from anndata import AnnData
    from sklearn.decomposition import TruncatedSVD
    from spaquotasketch.preprocess import normalized_log1p_expression_matrix
    from spaquotasketch.v2_1.quota import allocate_largest_remainder_quotas
    from spaquotasketch.v2_1.spatial import choose_adaptive_regular_partition

    monitor = PeakRSS().start()
    rows = []
    cache = cache_root(dataset_id)
    start = time.perf_counter()
    raw = sparse.load_npz(cache / "raw_counts_csr.npz").tocsr()
    coordinates = np.load(cache / "coordinates.npy")
    raw.sum()
    coordinates.sum()
    rows.append(base_record(dataset_id, "data_read", time.perf_counter() - start, monitor.value_mb()))

    monitor.reset()
    start = time.perf_counter()
    adata = AnnData(X=raw)
    adata.obsm["spatial"] = coordinates
    normalized = normalized_log1p_expression_matrix(adata, target_sum=10000.0)
    rows.append(
        base_record(
            dataset_id,
            "normalization_log1p",
            time.perf_counter() - start,
            monitor.value_mb(),
            matrix_rows=int(normalized.shape[0]),
            matrix_columns=int(normalized.shape[1]),
            matrix_nnz=int(normalized.nnz),
        )
    )

    monitor.reset()
    start = time.perf_counter()
    model = TruncatedSVD(n_components=30, algorithm="arpack", random_state=0)
    embedding = model.fit_transform(normalized)
    rows.append(
        base_record(
            dataset_id,
            "rank30_svd_equal_only",
            time.perf_counter() - start,
            monitor.value_mb(),
            embedding_rows=int(embedding.shape[0]),
            embedding_columns=int(embedding.shape[1]),
        )
    )

    for fraction in FRACTIONS:
        monitor.reset()
        n = target_n(dataset_id, fraction)
        start = time.perf_counter()
        partition = choose_adaptive_regular_partition(
            coordinates, n, minimum_quota=1, max_n_x=20, max_n_y=20
        )
        allocation = allocate_largest_remainder_quotas(
            partition.stratum_audit, n, minimum_quota=1
        )
        seconds = time.perf_counter() - start
        frozen_strata, frozen_quotas = load_design(dataset_id, fraction)
        strata_equal = np.array_equal(np.asarray(partition.stratum_ids, dtype=str), frozen_strata)
        quotas_equal = allocation.quotas == frozen_quotas
        if not strata_equal or not quotas_equal:
            raise RuntimeError(f"Rebuilt spatial design differs for {dataset_id} {fraction}")
        rows.append(
            base_record(
                dataset_id,
                "spatial_strata_and_quota",
                seconds,
                monitor.value_mb(),
                fraction=fraction,
                target_n=n,
                frozen_design_exact_match=True,
            )
        )
    monitor.close()
    return rows


def worker_graph(dataset_id, fraction):
    sys.path.insert(0, str(PROJECT_SRC))
    from spaquotasketch.v2_1.sampling import build_sampling_plan

    cache = cache_root(dataset_id)
    embedding = np.load(cache / "embedding.npy")
    strata, quotas = load_design(dataset_id, fraction)
    monitor = PeakRSS().start()
    monitor.reset()
    start = time.perf_counter()
    plan = build_sampling_plan(
        strata,
        quotas,
        embedding,
        np.ones(strata.size, dtype=float),
        method="v2_1_coordinate_only",
        max_weight_inflation=4.0,
    )
    seconds = time.perf_counter() - start
    edge_count = int(sum(len(edges) for edges in plan.local_edges_by_stratum.values()))
    row = base_record(
        dataset_id,
        "expression_neighbor_graph_equal_only",
        seconds,
        monitor.value_mb(),
        fraction=fraction,
        method="Equal",
        target_n=int(sum(quotas.values())),
        formal_graph_edges=edge_count,
    )
    monitor.close()
    return [row]


def direct_srs(strata, quotas, seed):
    rng = np.random.default_rng(int(np.random.SeedSequence([int(seed), 0]).generate_state(1)[0]))
    parts = []
    probability = np.zeros(strata.size, dtype=float)
    for stratum in sorted(quotas):
        positions = np.flatnonzero(strata == stratum)
        quota = int(quotas[stratum])
        probability[positions] = quota / positions.size
        local = positions if quota == positions.size else rng.choice(positions, size=quota, replace=False)
        parts.append(np.asarray(local, dtype=int))
    return np.sort(np.concatenate(parts)), 1.0 / probability


def worker_repeated(dataset_id, fraction, method, seed, replicate):
    sys.path.insert(0, str(PROJECT_SRC))
    from spaquotasketch.fixed_quota_probability import hajek_normalized_expression_fidelity
    from spaquotasketch.v2_1.sampling import build_sampling_plan, draw_fixed_size_sample

    cache = cache_root(dataset_id)
    strata, quotas = load_design(dataset_id, fraction)
    normalized = sparse.load_npz(cache / "normalized_log1p_csr.npz").tocsr()
    plan = None
    if method == "Equal":
        embedding = np.load(cache / "embedding.npy")
        plan = build_sampling_plan(
            strata,
            quotas,
            embedding,
            np.ones(strata.size, dtype=float),
            method="v2_1_coordinate_only",
            max_weight_inflation=4.0,
        )
    monitor = PeakRSS().start()
    monitor.reset()
    start = time.perf_counter()
    if method == "SRS":
        selected, weights = direct_srs(strata, quotas, seed)
    else:
        derived = int(np.random.SeedSequence([int(seed), 0]).generate_state(1)[0])
        selected = draw_fixed_size_sample(plan, random_seed=derived)
        weights = plan.sampling_weight
    sampling_seconds = time.perf_counter() - start
    sampling_peak = monitor.value_mb()
    monitor.reset()
    start = time.perf_counter()
    endpoint_values = hajek_normalized_expression_fidelity(normalized, selected, weights)
    evaluation_seconds = time.perf_counter() - start
    evaluation_peak = monitor.value_mb()
    monitor.close()
    common = {
        "fraction": fraction,
        "method": method,
        "performance_seed": seed,
        "replicate": replicate,
        "target_n": int(selected.size),
        "selected_index_checksum": hashlib.sha256(np.ascontiguousarray(selected).tobytes()).hexdigest(),
        "performance_output_only": True,
    }
    return [
        base_record(
            dataset_id,
            "cached_sampling",
            sampling_seconds,
            sampling_peak,
            cache_state=(
                "normalized matrix loaded; Equal plan built before timed draw"
                if method == "Equal"
                else "normalized matrix loaded; no expression graph constructed"
            ),
            **common,
        ),
        base_record(
            dataset_id,
            "endpoint_evaluation",
            evaluation_seconds,
            evaluation_peak,
            cache_state="normalized matrix and selected indices resident",
            endpoint_gene_mean_error=endpoint_values["gene_mean_l1_error_hajek"],
            endpoint_detection_error=endpoint_values["gene_detection_l1_error_hajek"],
            **common,
        ),
    ]


def run_worker(command, tag, timeout):
    env = os.environ.copy()
    env.update(THREAD_ENV)
    started = time.time()
    completed = subprocess.run(command, capture_output=True, text=True, env=env, timeout=timeout)
    log = {
        "command": command,
        "started_unix": started,
        "completed_unix": time.time(),
        "returncode": completed.returncode,
        "stdout": completed.stdout,
        "stderr": completed.stderr,
    }
    (LOG_DIR / f"{tag}.json").write_text(json.dumps(log, indent=2), encoding="utf-8")
    if completed.returncode != 0:
        raise RuntimeError(f"Worker failed: {tag}\n{completed.stderr}")
    return json.loads(completed.stdout)


def environment_record():
    computer = {
        "platform": platform.platform(),
        "python": sys.version,
        "python_executable": sys.executable,
        "processor": platform.processor(),
        "logical_cpu_count": psutil.cpu_count(logical=True),
        "physical_cpu_count": psutil.cpu_count(logical=False),
        "total_memory_bytes": psutil.virtual_memory().total,
        "thread_environment": THREAD_ENV,
        "rss_collection": "worker-process RSS sampled every 0.02 seconds; no child processes were created by timed workers",
        "os_file_cache": "not flushed between processes; measurements represent ordinary local reuse",
        "package_versions": {},
    }
    for package in ("numpy", "scipy", "pandas", "scikit-learn", "anndata", "psutil", "matplotlib"):
        try:
            computer["package_versions"][package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            computer["package_versions"][package] = "not installed"
    return computer


def orchestrate():
    SOURCE_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    (ANALYSIS_ROOT / "performance_environment.json").write_text(
        json.dumps(environment_record(), indent=2), encoding="utf-8"
    )
    script = str(Path(__file__).resolve())
    records = []
    for dataset_id in DATASETS:
        records.extend(
            run_worker(
                [sys.executable, script, "worker-preprocess", "--dataset", dataset_id],
                f"preprocess__{dataset_id}",
                2700,
            )
        )
    for dataset_id in DATASETS:
        for fraction in FRACTIONS:
            pct = int(round(100 * fraction))
            records.extend(
                run_worker(
                    [sys.executable, script, "worker-graph", "--dataset", dataset_id, "--fraction", str(fraction)],
                    f"graph__{dataset_id}__{pct:02d}pct",
                    900,
                )
            )
    for dataset_id in DATASETS:
        for fraction in FRACTIONS:
            pct = int(round(100 * fraction))
            for method in ("SRS", "Equal"):
                for replicate, seed in enumerate(SEEDS, start=1):
                    records.extend(
                        run_worker(
                            [
                                sys.executable,
                                script,
                                "worker-repeated",
                                "--dataset",
                                dataset_id,
                                "--fraction",
                                str(fraction),
                                "--method",
                                method,
                                "--seed",
                                str(seed),
                                "--replicate",
                                str(replicate),
                            ],
                            f"repeat__{dataset_id}__{pct:02d}pct__{method}__r{replicate}",
                            900,
                        )
                    )
    frame = pd.DataFrame(records)
    frame.to_csv(SOURCE_DIR / "performance_run_records.csv", index=False)
    print(json.dumps({"records": len(frame), "status": "complete"}, indent=2))


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "mode",
        choices=("orchestrate", "worker-preprocess", "worker-graph", "worker-repeated"),
    )
    parser.add_argument("--dataset", choices=DATASETS)
    parser.add_argument("--fraction", type=float)
    parser.add_argument("--method", choices=("SRS", "Equal"))
    parser.add_argument("--seed", type=int)
    parser.add_argument("--replicate", type=int)
    return parser.parse_args()


def main():
    args = parse_args()
    if args.mode == "orchestrate":
        orchestrate()
        return
    if args.mode == "worker-preprocess":
        rows = worker_preprocess(args.dataset)
    elif args.mode == "worker-graph":
        rows = worker_graph(args.dataset, args.fraction)
    else:
        rows = worker_repeated(args.dataset, args.fraction, args.method, args.seed, args.replicate)
    print(json.dumps(rows))


if __name__ == "__main__":
    main()
