"""Run the frozen post-outcome explanatory diagnostic and draw its source-data figure."""

from __future__ import annotations

import csv
import hashlib
import json
import math
import sys
from collections import Counter, defaultdict
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import sparse
from scipy.stats import spearmanr


OUTPUT_ROOT = Path(r"C:\Users\dell\Desktop\manuscript_mechanism_cost_extension_v1")
ANALYSIS_ROOT = OUTPUT_ROOT / "extension_analysis"
SOURCE_DIR = ANALYSIS_ROOT / "source_data"
FIGURE_DIR = ANALYSIS_ROOT / "figures"
PROJECT_ROOT = Path(r"C:\Work\SpaQuotaSketch")
CORE_ROOT = PROJECT_ROOT / "results" / "core_direct_comparison_reproduction_20260909"
MOUSE_ROOT = PROJECT_ROOT / "results" / "mouse_brain_16um_input_correction_20260917"
RESULT_SOURCE = (
    PROJECT_ROOT
    / "manuscript"
    / "expert_feedback_revision_v1"
    / "source_data"
    / "corrected_paired_endpoint_results.csv"
)
SNAPSHOT_SRC = PROJECT_ROOT / "src"

DIAGNOSTIC_SEED = 2026091901
MAX_EDGES = 50_000
PAIR_BATCH = 512
FRACTIONS = (0.02, 0.05, 0.10)
DATASETS = (
    "visium_cytassist_human_breast_cancer_2023",
    "visium_hd_mouse_brain_fresh_frozen_2024",
    "xenium_human_brain_alzheimers_2023",
    "xenium_human_renal_cell_carcinoma_2025",
)
DISPLAY = {
    DATASETS[0]: "Breast Visium",
    DATASETS[1]: "Mouse brain Visium HD",
    DATASETS[2]: "Human brain Xenium",
    DATASETS[3]: "Renal cancer Xenium",
}
SHORT = {
    DATASETS[0]: "Breast",
    DATASETS[1]: "Mouse brain",
    DATASETS[2]: "Human brain",
    DATASETS[3]: "Renal",
}
ENDPOINT_LABEL = {
    "normalized_log_expression_gene_mean": "Normalized log-expression mean",
    "raw_count_detection_proportion": "Raw-count detection proportion",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def cache_root(dataset_id: str) -> Path:
    base = MOUSE_ROOT if dataset_id == DATASETS[1] else CORE_ROOT
    return base / "cache" / dataset_id


def design_root(dataset_id: str) -> Path:
    base = MOUSE_ROOT if dataset_id == DATASETS[1] else CORE_ROOT
    return base / "unit_details" / dataset_id


def load_formal_local_edges():
    sys.path.insert(0, str(SNAPSHOT_SRC))
    from spaquotasketch.v2.inference import _local_edges

    return _local_edges


def reservoir_edges(embedding, strata, quotas, rng, formal_local_edges):
    reservoir: list[tuple[int, int, str]] = []
    seen = 0
    full_by_stratum: Counter[str] = Counter()
    retained_by_stratum: Counter[str] = Counter()
    eligible = 0
    ineligible = 0
    for stratum in sorted(set(strata.tolist())):
        positions = np.flatnonzero(strata == stratum)
        quota = int(quotas[stratum])
        if positions.size < 2 or quota <= 1 or quota >= positions.size:
            ineligible += 1
            continue
        eligible += 1
        edges = formal_local_edges(embedding[positions], n_neighbors=8)
        full_by_stratum[stratum] = len(edges)
        for _, first, second in edges:
            item = (int(positions[first]), int(positions[second]), stratum)
            seen += 1
            if len(reservoir) < MAX_EDGES:
                reservoir.append(item)
            else:
                slot = int(rng.integers(0, seen))
                if slot < MAX_EDGES:
                    reservoir[slot] = item
    for _, _, stratum in reservoir:
        retained_by_stratum[stratum] += 1
    return reservoir, full_by_stratum, retained_by_stratum, eligible, ineligible


def graph_identity(strata, quotas):
    eligible = sorted(
        stratum
        for stratum in set(strata.tolist())
        if 1 < int(quotas[stratum]) < int(np.sum(strata == stratum))
    )
    digest = hashlib.sha256()
    digest.update(np.ascontiguousarray(strata.astype("U")).tobytes())
    digest.update("\n".join(eligible).encode("utf-8"))
    return digest.hexdigest(), eligible


def matched_random_pairs(reservoir, strata, rng):
    positions_by_stratum = {
        stratum: np.flatnonzero(strata == stratum)
        for stratum in sorted({item[2] for item in reservoir})
    }
    first = np.empty(len(reservoir), dtype=np.int64)
    second = np.empty(len(reservoir), dtype=np.int64)
    for index, (_, _, stratum) in enumerate(reservoir):
        positions = positions_by_stratum[stratum]
        a = int(rng.integers(0, positions.size))
        b = int(rng.integers(0, positions.size - 1))
        if b >= a:
            b += 1
        first[index] = positions[a]
        second[index] = positions[b]
    return first, second


def sparse_pair_mean(matrix, first, second, binary):
    total = 0.0
    pairs = int(first.size)
    for start in range(0, pairs, PAIR_BATCH):
        stop = min(start + PAIR_BATCH, pairs)
        left = matrix[first[start:stop]].copy()
        right = matrix[second[start:stop]].copy()
        if binary:
            left.data = np.ones_like(left.data, dtype=np.float64)
            right.data = np.ones_like(right.data, dtype=np.float64)
        difference = left - right
        total += float(np.abs(difference).sum())
    return total / max(pairs * matrix.shape[1], 1)


def build_benefit_table():
    paired = pd.read_csv(RESULT_SOURCE)
    expected_rows = 120
    if len(paired) != expected_rows:
        raise RuntimeError(f"Expected {expected_rows} accepted paired rows, found {len(paired)}")
    if paired.duplicated(["dataset_id", "fraction", "seed", "endpoint"]).any():
        raise RuntimeError("Accepted paired result table has duplicate keys")
    benefit = paired["new_relative_benefit_equal_vs_srs"].astype(float)
    version = {
        "source": str(RESULT_SOURCE),
        "sha256": sha256(RESULT_SOURCE),
        "paired_rows": int(len(paired)),
        "method_endpoint_rows": int(len(paired) * 2),
        "equal_wins": int((paired["new_winner"] == "Equal").sum()),
        "srs_wins": int((paired["new_winner"] == "SRS").sum()),
        "mean_relative_benefit": float(benefit.mean()),
        "median_relative_benefit": float(benefit.median()),
    }
    if (version["equal_wins"], version["srs_wins"]) != (77, 43):
        raise RuntimeError(f"Formal win-count version mismatch: {version}")
    if round(100 * version["mean_relative_benefit"], 2) != 3.14:
        raise RuntimeError(f"Formal mean-benefit version mismatch: {version}")
    if round(100 * version["median_relative_benefit"], 2) != 1.54:
        raise RuntimeError(f"Formal median-benefit version mismatch: {version}")
    (SOURCE_DIR / "formal_result_version_check.json").write_text(
        json.dumps(version, indent=2), encoding="utf-8"
    )

    def iqr(series):
        return float(series.quantile(0.75) - series.quantile(0.25))

    summary = (
        paired.groupby(["dataset_id", "fraction", "endpoint"], as_index=False)
        .agg(
            technical_seed_count=("seed", "nunique"),
            mean_relative_benefit=("new_relative_benefit_equal_vs_srs", "mean"),
            median_relative_benefit=("new_relative_benefit_equal_vs_srs", "median"),
            sd_relative_benefit=("new_relative_benefit_equal_vs_srs", "std"),
            iqr_relative_benefit=("new_relative_benefit_equal_vs_srs", iqr),
            min_relative_benefit=("new_relative_benefit_equal_vs_srs", "min"),
            max_relative_benefit=("new_relative_benefit_equal_vs_srs", "max"),
            equal_wins=("new_winner", lambda values: int((values == "Equal").sum())),
            srs_wins=("new_winner", lambda values: int((values == "SRS").sum())),
        )
        .sort_values(["dataset_id", "fraction", "endpoint"])
    )
    for column in [name for name in summary.columns if "benefit" in name]:
        summary[column + "_percent"] = 100.0 * summary[column]
    summary.to_csv(SOURCE_DIR / "formal_benefit_by_condition_endpoint.csv", index=False)
    return summary


def calculate_metrics():
    formal_local_edges = load_formal_local_edges()
    metric_rows = []
    coverage_rows = []
    for dataset_order, dataset_id in enumerate(DATASETS):
        cache = cache_root(dataset_id)
        embedding = np.load(cache / "embedding.npy", mmap_mode="r")
        normalized = sparse.load_npz(cache / "normalized_log1p_csr.npz").tocsr()
        raw = sparse.load_npz(cache / "raw_counts_csr.npz").tocsr()
        if embedding.shape[0] != normalized.shape[0] or raw.shape != normalized.shape:
            raise RuntimeError(f"Cache alignment failed for {dataset_id}")
        for fraction_order, fraction in enumerate(FRACTIONS):
            label = f"{int(round(100*fraction)):02d}pct"
            design_path = design_root(dataset_id) / label / "design.npz"
            quota_path = design_root(dataset_id) / label / "quota_audit.csv"
            design = np.load(design_path, allow_pickle=False)
            strata = np.asarray(design["spatial_strata"], dtype=str)
            quota_frame = pd.read_csv(quota_path)
            quotas = dict(zip(quota_frame["spatial_stratum"].astype(str), quota_frame["q_g"].astype(int)))
            if strata.shape[0] != embedding.shape[0] or set(strata) != set(quotas):
                raise RuntimeError(f"Design alignment failed for {dataset_id} {fraction}")
            graph_id, eligible_names = graph_identity(strata, quotas)
            graph_seed_component = int(graph_id[:16], 16)
            rng = np.random.default_rng(
                np.random.SeedSequence([DIAGNOSTIC_SEED, dataset_order, graph_seed_component])
            )
            reservoir, full_counts, retained_counts, eligible, ineligible = reservoir_edges(
                embedding, strata, quotas, rng, formal_local_edges
            )
            edge_first = np.asarray([item[0] for item in reservoir], dtype=np.int64)
            edge_second = np.asarray([item[1] for item in reservoir], dtype=np.int64)
            random_first, random_second = matched_random_pairs(reservoir, strata, rng)
            for stratum in sorted(full_counts):
                coverage_rows.append(
                    {
                        "dataset_id": dataset_id,
                        "fraction": fraction,
                        "graph_id": graph_id,
                        "graph_shared_across_fractions": False,
                        "spatial_stratum": stratum,
                        "full_formal_graph_edges": int(full_counts[stratum]),
                        "retained_diagnostic_edges": int(retained_counts[stratum]),
                    }
                )
            for endpoint, matrix, binary in (
                ("normalized_log_expression_gene_mean", normalized, False),
                ("raw_count_detection_proportion", raw, True),
            ):
                edge_mean = sparse_pair_mean(matrix, edge_first, edge_second, binary)
                random_mean = sparse_pair_mean(matrix, random_first, random_second, binary)
                ratio = math.nan if random_mean == 0 else edge_mean / random_mean
                metric_rows.append(
                    {
                        "dataset_id": dataset_id,
                        "dataset_label": DISPLAY[dataset_id],
                        "fraction": fraction,
                        "graph_id": graph_id,
                        "endpoint": endpoint,
                        "endpoint_label": ENDPOINT_LABEL[endpoint],
                        "n_observations": int(matrix.shape[0]),
                        "n_genes": int(matrix.shape[1]),
                        "formal_neighbor_count": 8,
                        "eligible_strata": int(eligible),
                        "ineligible_strata": int(ineligible),
                        "full_formal_graph_edges": int(sum(full_counts.values())),
                        "retained_diagnostic_edges": int(len(reservoir)),
                        "random_pairs": int(len(reservoir)),
                        "mean_graph_edge_absolute_difference_per_gene": edge_mean,
                        "mean_random_pair_absolute_difference_per_gene": random_mean,
                        "neighbor_to_random_difference_ratio": ratio,
                        "zero_random_difference_denominator": bool(random_mean == 0),
                        "diagnostic_seed": DIAGNOSTIC_SEED,
                        "design_path": str(design_path),
                        "embedding_path": str(cache / "embedding.npy"),
                    }
                )
    metric = pd.DataFrame(metric_rows).sort_values(["dataset_id", "fraction", "endpoint"])
    graph_condition_count = metric.groupby(["dataset_id", "graph_id"])["fraction"].transform("nunique")
    metric["graph_shared_across_fractions"] = graph_condition_count > 1
    coverage = pd.DataFrame(coverage_rows).sort_values(["dataset_id", "fraction", "spatial_stratum"])
    metric.to_csv(SOURCE_DIR / "exploratory_local_similarity_metrics.csv", index=False)
    coverage.to_csv(SOURCE_DIR / "exploratory_edge_sampling_coverage.csv", index=False)
    unique_rows = []
    for (_, graph_id, endpoint), frame in metric.groupby(["dataset_id", "graph_id", "endpoint"], sort=True):
        first = frame.iloc[0].copy()
        first["fractions_applicable"] = ";".join(f"{100*x:.0f}%" for x in sorted(frame["fraction"].unique()))
        first["condition_count_sharing_metric"] = int(frame["fraction"].nunique())
        unique_rows.append(first)
    pd.DataFrame(unique_rows).to_csv(
        SOURCE_DIR / "exploratory_local_similarity_unique_graphs.csv", index=False
    )
    return metric


def join_and_associate(metric, benefit):
    joined = metric.merge(
        benefit,
        on=["dataset_id", "fraction", "endpoint"],
        validate="one_to_one",
    )
    joined.to_csv(SOURCE_DIR / "exploratory_metric_benefit_joined.csv", index=False)
    analysis_units = (
        joined.groupby(
            [
                "dataset_id",
                "dataset_label",
                "endpoint",
                "endpoint_label",
                "graph_id",
                "neighbor_to_random_difference_ratio",
            ],
            dropna=False,
            as_index=False,
        )
        .agg(
            condition_count=("fraction", "nunique"),
            fractions=("fraction", lambda values: ";".join(f"{100*x:.0f}%" for x in sorted(values.unique()))),
            mean_relative_benefit=("mean_relative_benefit", "mean"),
            mean_relative_benefit_percent=("mean_relative_benefit_percent", "mean"),
        )
    )
    analysis_units.to_csv(
        SOURCE_DIR / "exploratory_metric_benefit_analysis_units.csv", index=False
    )
    rows = []
    for endpoint in ENDPOINT_LABEL:
        selected = analysis_units[
            (analysis_units["endpoint"] == endpoint)
            & analysis_units["neighbor_to_random_difference_ratio"].notna()
        ]
        for scope, frame in (
            ("all_four_datasets", selected),
            ("excluding_renal_dataset", selected[selected["dataset_id"] != DATASETS[3]]),
        ):
            coefficient = float(spearmanr(
                frame["neighbor_to_random_difference_ratio"], frame["mean_relative_benefit"]
            ).statistic) if len(frame) >= 2 else math.nan
            rows.append(
                {
                    "endpoint": endpoint,
                    "scope": scope,
                    "dataset_fraction_conditions": int(len(frame)),
                    "dataset_count": int(frame["dataset_id"].nunique()),
                    "unique_graph_analysis_units": int(len(frame)),
                    "descriptive_spearman_rho": coefficient,
                    "inferential_p_value_calculated": False,
                    "independence_claimed": False,
                }
            )
    associations = pd.DataFrame(rows)
    associations.to_csv(SOURCE_DIR / "exploratory_descriptive_associations.csv", index=False)
    return joined, analysis_units, associations


def draw_figure(joined, associations):
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
            "font.size": 7,
            "axes.titlesize": 8,
            "axes.labelsize": 7,
            "axes.linewidth": 0.8,
            "xtick.labelsize": 6.5,
            "ytick.labelsize": 6.5,
            "legend.fontsize": 6.2,
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
            "axes.spines.top": False,
            "axes.spines.right": False,
        }
    )
    colors = {
        DATASETS[0]: "#4C78A8",
        DATASETS[1]: "#72B7B2",
        DATASETS[2]: "#9C755F",
        DATASETS[3]: "#E07B39",
    }
    markers = {0.02: "o", 0.05: "s", 0.10: "^"}
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.05), constrained_layout=True)
    for panel, (axis, endpoint) in enumerate(zip(axes, ENDPOINT_LABEL), start=1):
        frame = joined[joined["endpoint"] == endpoint]
        for dataset_id in DATASETS:
            data = frame[frame["dataset_id"] == dataset_id].sort_values("fraction")
            axis.plot(
                data["neighbor_to_random_difference_ratio"],
                data["mean_relative_benefit_percent"],
                color=colors[dataset_id],
                linewidth=0.8,
                alpha=0.55,
                zorder=1,
            )
            for _, row in data.iterrows():
                axis.scatter(
                    row["neighbor_to_random_difference_ratio"],
                    row["mean_relative_benefit_percent"],
                    color=colors[dataset_id],
                    marker=markers[float(row["fraction"])],
                    s=34,
                    edgecolor="white",
                    linewidth=0.5,
                    zorder=2,
                )
        axis.axhline(0, color="#666666", linewidth=0.7, linestyle="--", zorder=0)
        axis.axvline(1, color="#B0B0B0", linewidth=0.7, linestyle=":", zorder=0)
        axis.set_title(ENDPOINT_LABEL[endpoint], loc="left", fontweight="bold")
        axis.set_xlabel("Neighbour/random target-difference ratio")
        axis.set_ylabel("Mean Equal benefit versus SRS (%)")
        axis.text(-0.12, 1.04, chr(64 + panel), transform=axis.transAxes, fontsize=9, fontweight="bold")
        row = associations[
            (associations["endpoint"] == endpoint)
            & (associations["scope"] == "all_four_datasets")
        ].iloc[0]
        row_without = associations[
            (associations["endpoint"] == endpoint)
            & (associations["scope"] == "excluding_renal_dataset")
        ].iloc[0]
        axis.text(
            0.98,
            0.97,
            f"Descriptive Spearman ρ = {row.descriptive_spearman_rho:.2f}\nwithout renal: {row_without.descriptive_spearman_rho:.2f}",
            transform=axis.transAxes,
            ha="right",
            va="top",
            fontsize=6.2,
            color="#444444",
        )
    dataset_handles = [
        plt.Line2D([0], [0], marker="o", color=colors[item], linewidth=1, markersize=4, label=SHORT[item])
        for item in DATASETS
    ]
    fraction_handles = [
        plt.Line2D([0], [0], marker=markers[value], color="#444444", linestyle="none", markersize=4, label=f"{int(value*100)}%")
        for value in FRACTIONS
    ]
    fig.legend(
        handles=dataset_handles + fraction_handles,
        loc="outside lower center",
        ncol=7,
        frameon=False,
        bbox_to_anchor=(0.5, -0.04),
    )
    stem = FIGURE_DIR / "S3_Fig_exploratory_local_similarity"
    fig.savefig(stem.with_suffix(".svg"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(stem.with_suffix(".png"), dpi=300, bbox_inches="tight")
    plt.close(fig)


def main():
    SOURCE_DIR.mkdir(parents=True, exist_ok=True)
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    benefit = build_benefit_table()
    metric = calculate_metrics()
    joined, analysis_units, associations = join_and_associate(metric, benefit)
    draw_figure(joined, associations)
    summary = {
        "metric_rows": int(len(metric)),
        "benefit_rows": int(len(benefit)),
        "joined_rows": int(len(joined)),
        "unique_graph_analysis_units": int(len(analysis_units)),
        "metric_zero_denominators": int(metric["zero_random_difference_denominator"].sum()),
        "max_diagnostic_edges_per_condition": MAX_EDGES,
        "diagnostic_seed": DIAGNOSTIC_SEED,
    }
    (ANALYSIS_ROOT / "logs" / "exploratory_similarity_run_summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
