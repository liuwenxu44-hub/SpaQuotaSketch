# Official raw 16 micrometre matrix validation

The authoritative audit aligns the official Space Ranger 3.1.1 raw square_016um matrix to the exact frozen set of 113,885 retained bin identifiers and all 32,285 gene identifiers. It verifies exact integer equality for 258,048,868 nonzero entries and 469,221,411 counts, with zero mismatching elements. The official filtered matrix has a different 19,059-feature scope and is not the raw-feature scope used by the rerun.
