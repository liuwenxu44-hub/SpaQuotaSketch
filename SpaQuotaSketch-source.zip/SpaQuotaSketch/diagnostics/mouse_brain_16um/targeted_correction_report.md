# Targeted Visium HD mouse-brain input correction

Completed 60/60 method-endpoint rows and 30/30 paired endpoint rows.
All spatial quotas exact: True.

The corrected run used the same official feature-slice file, fractions, seeds, methods, endpoints and quota rules as the frozen reproduction. The only scientific correction was aggregation of native 2-um feature coordinates into the square_016um mask by an 8-by-8 sum.

Historical results were not overwritten.
