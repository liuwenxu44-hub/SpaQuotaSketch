# Controlled reproduction discrepancy report

Classification: `D. REPRODUCTION_INCOMPLETE`

Completed endpoint rows: 60/240; paired endpoint records: 30/120.
Float64 rule: atol=1e-10, rtol=1e-07.

## New-versus-history numerical comparison

60 method-endpoint records did not meet the prerecorded numerical rule. No tolerance was changed and no sampling parameter was adjusted.

Potential sources requiring evidence-directed review: input/order, preprocessing/target, spatial strata/quota, neighbourhood/ties, seed split, dependency numerics, sampling logic, or endpoint evaluation. This run does not search alternative seeds or implementations.

## Historical fields unavailable for direct comparison

Historical selected identifiers, quota vectors and inclusion-probability vectors were not retained in the three direct-comparison result folders. Their status is therefore NOT_AVAILABLE_FOR_COMPARISON; the new values are fully retained in each unit detail file.

## Mouse-brain high absolute error audit

The new endpoint rows retain target and estimate vectors, numerator, denominator and weight denominator. Detection uses raw count > 0. Relative L1 is sum(abs(estimate-target))/sum(target). No high-error point was removed.
