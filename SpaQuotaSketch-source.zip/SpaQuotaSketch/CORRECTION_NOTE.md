# Visium HD mouse-brain correction note

The prior adapter directly matched native feature-slice row and column coordinates to a `square_016um` mask. The feature slice is indexed at 2 μm resolution, so the correct 16 μm mapping is `row // 8` and `col // 8`, followed by summation of counts sharing a gene and target bin.

Using the same retained source object (1,033,655,638 bytes; SHA256 `be0515a9c3b4601bf2153eccb7f0bcd8e41081e5e66cb0ab8cd6161c0903c7f5`), the incorrect matrix had 93,246 all-zero rows among 113,885 nominal bins. The corrected matrix had no all-zero bins, 258,048,868 nonzero gene-bin entries and 469,221,411 total counts.

Only the affected mouse-brain conditions were rerun. Fractions, seeds, sampling methods, spatial quotas, estimators, endpoints and thresholds were unchanged. Historical outputs were retained for audit and were not silently overwritten.
